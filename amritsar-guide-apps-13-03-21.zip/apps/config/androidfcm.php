<?php
defined('BASEPATH') or exit('No direct script access allowed');
/*
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
|| Android Firebase Push Notification Configurations
|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
 */

/*
|--------------------------------------------------------------------------
| Firebase API Key
|--------------------------------------------------------------------------
|
| The secret key for Firebase API
|
 */
$config['key'] = 'AAAAxZm_5Fs:APA91bEA5lRidcI74Lb5NA-lJulre84DgcxR-lyWFhXQRbqwpzs3Zi1EvNBOG30sxSaTt7G7SPyxZPS-p8H41ADmmA3nTDKlapD43UMvYEcXAmPXr4Oq6NgvOjNVBCcYQNv_vkxQDnmu';

//$config['key'] = 'AAAAPj87DR0:APA91bGHjk524ZuD0NMI2tInNnJCCoj_A2Y3Qcdyv--zR5GSkwC5-jIFpCtRyfH4bsbMqqp6IH4hg6V1hWHZGbv2_duo_w3_LPNnlFa2Mq1kyyolU53OSKkQxd-ooUGP6VkUnrAyJlKy';





/*
|--------------------------------------------------------------------------
| Firebase Cloud Messaging API URL
|--------------------------------------------------------------------------
|
| The URL for Firebase Cloud Messafing
|
 */

$config['fcm_url'] = 'https://fcm.googleapis.com/fcm/send';
