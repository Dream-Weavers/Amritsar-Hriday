<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
defined('SHOW_DEBUG_BACKTRACE') OR define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
defined('FILE_READ_MODE')  OR define('FILE_READ_MODE', 0644);
defined('FILE_WRITE_MODE') OR define('FILE_WRITE_MODE', 0666);
defined('DIR_READ_MODE')   OR define('DIR_READ_MODE', 0755);
defined('DIR_WRITE_MODE')  OR define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/
defined('FOPEN_READ')                           OR define('FOPEN_READ', 'rb');
defined('FOPEN_READ_WRITE')                     OR define('FOPEN_READ_WRITE', 'r+b');
defined('FOPEN_WRITE_CREATE_DESTRUCTIVE')       OR define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
defined('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE')  OR define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
defined('FOPEN_WRITE_CREATE')                   OR define('FOPEN_WRITE_CREATE', 'ab');
defined('FOPEN_READ_WRITE_CREATE')              OR define('FOPEN_READ_WRITE_CREATE', 'a+b');
defined('FOPEN_WRITE_CREATE_STRICT')            OR define('FOPEN_WRITE_CREATE_STRICT', 'xb');
defined('FOPEN_READ_WRITE_CREATE_STRICT')       OR define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
defined('EXIT_SUCCESS')        OR define('EXIT_SUCCESS', 0); // no errors
defined('EXIT_ERROR')          OR define('EXIT_ERROR', 1); // generic error
defined('EXIT_CONFIG')         OR define('EXIT_CONFIG', 3); // configuration error
defined('EXIT_UNKNOWN_FILE')   OR define('EXIT_UNKNOWN_FILE', 4); // file not found
defined('EXIT_UNKNOWN_CLASS')  OR define('EXIT_UNKNOWN_CLASS', 5); // unknown class
defined('EXIT_UNKNOWN_METHOD') OR define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT')     OR define('EXIT_USER_INPUT', 7); // invalid user input
defined('EXIT_DATABASE')       OR define('EXIT_DATABASE', 8); // database error
defined('EXIT__AUTO_MIN')      OR define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX')      OR define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code

define('title','Hriday');
define('company_name','Hriday');
define('company_short_name','Hriday');
define('helpemail','info@hriday.com');
define('infoemail','info@hriday.com');
define('per_page','50'); 

define('common_error_msg','You have some form errors. Please check below.');

define('SUPERADMIN','A');
define('EMPLOYEE','E');
define('DEPARTMENT','D');
define('USERS','U');

define('washroom_facility_type','1');
define('parking_facility_type','2');
define('dispensary_facility_type','3');
define('police_booth_facility_type','4');
define('shoe_facility_type','5');
define('luggage_facility_type','6');
define('langar_facility_type','7');
define('ticketcounter_facility_type','8');
define('enquiry_facility_type','9');
define('resthouse_facility_type','10');
define('loccontacts_facility_type','11');

define('audio_files','1');
define('gallery_files','2');
define('video_files','3');
define('vr_files','4');
define('map2d_files','5');
define('panorama_files','6');
define('video360_files','7');
define('vt_files','8');
define('image360_files','9');

define('header_banner','11');
define('footer_banner','12');
define('popup_banner','13');
define('full_page_popup_banner','14');

define('max_file_size','70000000');
define('audo_file_extensions','mp3|wav|webm|m4p|3gp');
define('video_file_extensions','mpg|mp2|mpeg|mpe|mpv|ogg|mp4|m4p|m4v|avi|wmv|mov|qt|flv|swf|MPG|MP2|MPEG|MPE|MPV|OGG|MP4|M4P|M4V|AVI|WMV|MOV|QT|FLV|SWF');

define('slide_image_path','assets/static/slides/');
define('icon_url_path','assets/static/locations/icons/');
define('gallery_path','assets/static/locations/gallery/');
define('audio_path','assets/static/locations/audio/');
define('location_path','assets/static/locations/');
define('facility_path','assets/static/locations/facility/');
define('category_icons_path','images/category-icons/');
define('categorytype_icons_path','images/categorytype-icons/');
define('document_path_url','/home/dsysin607/public_html/');
define('live_complaint_image','https://amritsar.guide/assets/complaints/image/');
define('live_complaint_audio','https://amritsar.guide/assets/complaints/audio/');
define('live_complaint_video','https://amritsar.guide/assets/complaints/video/');
define('users_photo_path','https://amritsar.guide/assets/static/user_photos/original/');


// SMS information
define('sms_username','myhotline_sms');
define('sms_pass','_9byY0!C');
define('sms_url','http://www.smsjust.com/sms/user/urlsms.php/?');
define('sms_senderid','HOTLNE');
define('sms_msgtype',"UNI");
define('sms_response',"Y");

//Section Links
define('category_type_page_link','Categories/getcategories/');
define('category_page_link','Locations/getlocations/');
define('location_page_link','Locations/getlocationdetails/'); 
define('tour_trails_page_link','tours/tourdetails/'); 
//define('event_page_link','Locations/eventdetail/'); 


// Google Translation API
define('google_translate_api','AIzaSyAYw0uYK4Za3MuRiKjWHurXAXU0fKx7BMk');  // This API is from theamritsar.guide@gmail.com email
