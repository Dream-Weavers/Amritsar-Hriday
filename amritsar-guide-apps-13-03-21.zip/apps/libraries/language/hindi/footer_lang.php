<?php
$lang['text_copyright_footer'] = 'कॉपीराइट &copy; Hriday '.date('Y').'. सर्वाधिकार सुरक्षित';
?>