<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['user_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';


//Users Heading
$lang['users_title']		= 'Users';
$lang['add_user_title']		= 'Create User';
$lang['edit_user_title']		= 'Edit User';
$lang['view_users_title']		= 'View Users';

//Users Placeholder Text
$lang['user_email_placeholder_text']		= 'We’ll send login details to this email address';
$lang['user_password_placeholder_text']		= 'Minimum of 4 characters.';

//Users Fields Add/Edit Text
$lang['user_first_name_text']		      = 'First name';
$lang['user_last_name_text']		      = 'Last name';
$lang['user_primary_email_text']		  = 'Primary Email';
$lang['user_primary_mobile_text']		  = 'Primary Mobile no';
$lang['user_password_text']				  = 'Password';
$lang['user_confirm_password_text']		  = 'Confirm Password';
$lang['user_country_text']		 		  = 'Country';
$lang['user_state_text']		 		  = 'State';
$lang['user_city_text']		  			  = 'City';
$lang['user_pin_code_text']		  		  = 'Pincode';
$lang['user_address_text']		  		  = 'Address';
$lang['user_valid_upto_text']		 	  = 'Valid Upto';
$lang['user_reportingto_text']		  	  = 'Reporting To';
$lang['user_designation_text']		  	  = 'Designation';
$lang['user_other_designation_text']	  = 'Other Designation';
$lang['user_department_text']		  	  = 'Department';
$lang['user_other_department_text']	      = 'Other Department';
$lang['user_role_text']  		  		  = 'Role';
$lang['user_gender_text']  		  		  = 'Gender';
$lang['user_alternate_email_text']  	  = 'Alternate Email';
$lang['user_alternate_mobile_text']  	  = 'Alternate Mobile no';
$lang['user_landline_text']  		  	  = 'Landline no';
$lang['user_dob_text']  		  		  = 'Date of Birth';
$lang['user_doj_text']  		  		  = 'Date of Joining';
$lang['user_user_code_text']  		  	  = 'User code';
$lang['user_photo_text']  		  		  = 'Select image ';


//Users Columns
$lang['user_srno_column']			      = 'Srno.';
$lang['user_full_name_column']		      = 'Name';
$lang['user_primary_email_column']	      = 'Email';
$lang['user_designation_column']	      = 'Designation';
$lang['user_department_column']		      = 'Department';
$lang['user_role_column']			      = 'Role';
$lang['user_reportingto_column']	      = 'Reporting To';
$lang['user_primary_mobile_column']       = 'Primary Mobile no';
$lang['user_gender_column']			      = 'Gender';
$lang['user_validupto_column']		      = 'Valid Upto';
$lang['user_createdby_column']		      = 'Created By';
$lang['user_createdon_column']		      = 'Created On';
$lang['user_status_column']			      = 'Status';
$lang['user_action_column']			      ='Action';
