<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_validation_required']		= 'The {field} field is required.';
$lang['form_validation_isset']			= 'The {field} field must have a value.';

// title
$lang['text_title_header'] = 'Welcome to Hriday Superadmin';
$lang['text_name_header'] = 'Hriday';

// Super Admin  Menu
$lang['admin_menu_dashboard'] = 'Dashboard';
$lang['admin_menu_masters'] = 'MASTERS';
$lang['admin_menu_country'] = 'View Countries';
$lang['admin_menu_states'] = 'View States';
$lang['admin_menu_citys'] = 'View Cities';
$lang['admin_menu_locality'] = 'View Localities';
$lang['admin_menu_roles'] = 'View Roles';

$lang['admin_menu_permissions'] = 'Permissions';
$lang['admin_menu_users'] = 'Users';
$lang['admin_menu_projects'] = 'Projects';
$lang['admin_menu_category_types'] = 'Category Types';
$lang['admin_menu_categories'] = 'Categories';

$lang['text_menu_demo_header'] = 'Live Demo'; 
$lang['text_menu_tutorials_header'] = 'Tutorials';
$lang['text_menu_contact_header'] = 'Contact';
?>
