<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_validation_errors']		= 'You have some form errors. Please check below.';
$lang['form_validation_success']			= 'Your form validation is successful!';
$lang['default_pasword_text']			= 'Note : Default Password : (abc123)';

$lang['active_user_text']			= 'Active';
$lang['deactive_user_text']			= 'De-active';

$lang['form_submit_text']			= 'Submit';
$lang['form_reset_text']			= 'Reset';
$lang['select_all_text']			= 'Select All';