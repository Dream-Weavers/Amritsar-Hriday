<?php
// title
$lang['text_title_header'] = 'Hriday में आपका स्वागत है';
$lang['text_name_header'] = 'Hriday';

// Main Menu
$lang['text_menu_home_header'] = 'घर';
$lang['text_menu_demo_header'] = 'लाइव डेमो';
$lang['text_menu_tutorials_header'] = 'ट्यूटोरियल';
$lang['text_menu_contact_header'] = 'संपर्क करें';
?>