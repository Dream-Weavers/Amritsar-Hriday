<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_validation_errors']		= 'You have some form errors. Please check below.';
$lang['form_validation_success']			= 'Your form validation is successful!';
$lang['default_pasword_text']			= 'Note : Default Password : (abc123)';

$lang['photo_choose_text']				= 'Select image';
$lang['photo_change_text']				= 'Change';
$lang['photo_remove_text']				= 'Remove';
$lang['photo_note_text']				= 'NOTE!';
$lang['photo_extension_text']			= 'Attached image thumbnail format JPG,PNG,JPEG';


$lang['form_submit_text']			= 'Submit';
$lang['form_reset_text']			= 'Reset';
$lang['select_all_text']			= 'Select All';