<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text'] = 'Dashboard';
$lang['survey_additional_fields_text'] = 'Additional Fields';
$lang['click_to_view_file'] = 'Click to view file';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']	= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_survey_text']			= 'Active';
$lang['deactive_survey_text']		= 'De-active';

//Surveys Heading
$lang['surveys_title']		= 'Surveys';
$lang['add_survey_title']		= 'Create Survey';
$lang['edit_survey_title']		= 'Edit Survey';
$lang['view_surveys_title']		= 'View Surveys';

//Surveys Placeholder Text
$lang['survey_email_placeholder_text']		= 'We’ll send login details to this email address';
$lang['survey_password_placeholder_text']		= 'Minimum of 4 characters.';

//Surveys Fields Add/Edit Text
$lang['survey_id_text']		      = 'Id';
$lang['survey_dated_text']		      = 'Dated';
$lang['survey_name_text']		      = 'Name';
$lang['survey_gender_text']		      = 'Gender';
$lang['survey_gender_option1_text']		      = 'Male';
$lang['survey_gender_option2_text']		      = 'Female';
$lang['survey_age_text']		      = 'Age';
$lang['survey_address_text']		      = 'Address';
$lang['survey_area_text']		      = 'Area/Locality';
$lang['survey_city_text']		      = 'City';
$lang['survey_city2_text']		  = 'City2';
$lang['survey_state_text']		  = 'State';
$lang['survey_staying_text']		  = 'Are you staying in Amritsar';
$lang['survey_after_independence_staying_text']		  = 'If After Independence for how long you are staying in Amritsar';

$lang['survey_place_existence_text']			  = 'Do you know any place/site, which is not in existence for now? Like Havelis, Chopal, Panchayat etc';
$lang['survey_place_existence_option1_text']			  = 'No';
$lang['survey_place_existence_option2_text']			  = 'Yes';
$lang['survey_place_details_text']	  = 'Place Details';


$lang['survey_event_existence_text']			  = 'Which is not in the existence for now? Please describe: Any Mela, Event, Food, Culture.';
$lang['survey_event_existence_option1_text']			  = 'No';
$lang['survey_event_existence_option2_text']			  = 'Yes';
$lang['survey_event_details_text']	  = 'Event Details';


$lang['survey_site_existence_text']			  = 'Any famous site, where major alteration took place, what is that alteration?';
$lang['survey_site_existence_option1_text']			  = 'No';
$lang['survey_site_existence_option2_text']			  = 'Yes';
$lang['survey_site_details_text']	  = 'Event Details';


$lang['survey_audio_text']		 	  = 'Audios';
$lang['survey_video_text']		 	  = 'Videos';
$lang['survey_gallery_text']		 	  = 'Gallery';
$lang['survey_old_pictures_text']		 	  = 'Old Pictures Collected';
$lang['survey_add_more_text']		 	  = 'Add more';
$lang['survey_exact_location_text']		 	  = 'Exact Location';
$lang['survey_longitude_text']		 	  = 'Longitude';
$lang['survey_remarks_text']		 	  = 'Remarks';
$lang['survey_latitude_text']		 	  = 'Latitude';

$lang['survey_mainremarks_text']		 	  = 'Remarks';

$lang['survey_customer_text']		 	  = 'Customer Name';
$lang['survey_action_column']		 	  = 'Action';
$lang['survey_action_manage_column']		 	  = 'Manage';


