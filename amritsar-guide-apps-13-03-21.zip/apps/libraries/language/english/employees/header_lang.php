<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_validation_required']		= 'The {field} field is required.';
$lang['form_validation_isset']			= 'The {field} field must have a value.';

// title
$lang['text_title_header'] = 'Welcome to Hriday Employee Panel';
$lang['text_name_header'] = 'Hriday';

// Employee Menus
$lang['employee_menu_dashboard'] = 'Dashboard';
$lang['employee_menu_survey'] = 'P2PSurvey';
$lang['employee_menu_locations'] = 'Locations';
$lang['employee_menu_add_location'] = 'Add Location';
$lang['employee_menu_view_locations'] = 'View Locations';


$lang['employee_menu_permissions'] = 'Permissions';
$lang['employee_menu_users'] = 'Users';
$lang['employee_menu_projects'] = 'Projects';
$lang['employee_menu_category_types'] = 'Category Types';
$lang['employee_menu_categories'] = 'Categories';

$lang['text_menu_demo_header'] = 'Live Demo'; 
$lang['text_menu_tutorials_header'] = 'Tutorials';
$lang['text_menu_contact_header'] = 'Contact';

$lang['content_language_text'] = 'Content Language';
?>
