<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['location_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['delete_text_message']		= 'Record has been deleted successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_location_text']			= 'Active';
$lang['deactive_location_text']			= 'De-active';

$lang['publish_location_text']			= 'Publish';

$lang['copy_location_text']			= 'Copy';
$lang['copy_success_text_message']		= 'Record has been copied successfully.';
$lang['copy_error_text_message']		= 'Copy error occurs, try again';

//Users Heading
$lang['locations_title']		= 'Locations';
$lang['add_location_title']		= 'Add Location';
$lang['edit_location_title']		= 'Edit Location';
$lang['view_locations_title']		= 'View Locations';

//Users Placeholder Text
$lang['location_email_placeholder_text']		= 'We’ll send login details to this email address';
$lang['location_password_placeholder_text']		= 'Minimum of 4 characters.';
$lang['location_title_placeholder_text']	    = 'Title';
//Users Fields Add/Edit Text
$lang['location_category_type_text']		  = 'Category Type';
$lang['location_category_text']		          = 'Category';
$lang['location_location_name_text']		  = 'Location Name';
$lang['location_short_name_text']		      = 'Alias';
$lang['location_locality_text']		      = 'Select Locality';
$lang['location_serial_no_text']			  = 'Serial No.';
$lang['location_locality_text']		          = 'Locality';
$lang['location_estimated_visit_time_text']	  = 'Estimated time to visit';
$lang['location_short_description_text']	  = 'Short Description';
$lang['location_description_text']		      = 'Description';
$lang['location_website_url_text']		 	  = 'Website Url';
$lang['location_mobile_text']		 	  = 'Mobile No';
$lang['location_landline_text']		 	  = 'Landline';
$lang['location_pin_code_text']		  		  = 'Pincode';
$lang['location_state_text']		  		  = 'State';
$lang['location_city_text']		  		      = 'City';
$lang['location_address_text']		  		  = 'Address';
$lang['location_entry_ticket_text']		 	  = 'Entry Ticket';
$lang['location_adult_fee_text']		  	  = 'Adult Fee';
$lang['location_child_fee_text']		  	  = 'Child Fee';
$lang['location_senior_citizen_fee_text']	  = 'Senior Citizen';

$lang['location_2dmap_distance_text']		  = '2D map';

$lang['location_longitude_text']		 	  = 'Longitude';
$lang['location_latitude_text']		  	 	  = 'Latitude ';
$lang['location_alert1_distance_text']		  = 'Alert 1 Distance';
$lang['location_alert2_distance_text']		  = 'Alert 2 Distance';
$lang['location_alert3_distance_text']		  = 'Alert 3 Distance';
$lang['location_alert4_distance_text']		  = 'Alert 4 Distance';
$lang['location_sound_file_text']		 	  = 'Sound File';
$lang['location_north_text']	  			  = 'North';
$lang['location_north_title_text']			  = 'Title';
$lang['location_south_text']	 			  = 'South';
$lang['location_south_title_text']	 		  = 'Title';
$lang['location_east_text']	    			  = 'East';
$lang['location_east_title_text']	 		  = 'Title';
$lang['location_west_text']	 				  = 'West';
$lang['location_west_title_text']	  		  = 'Title';
$lang['location_north_area_sound_text']	  	  = 'North Sound File';
$lang['location_south_area_sound_text']	  	  = 'South Sound File';
$lang['location_east_area_sound_text']	  	  = 'East Sound File';
$lang['location_west_area_sound_text']	  	  = 'West Sound File';


$lang['location_map_icon_text']		  	      = 'Map Icon';
$lang['location_web_icon_text']	              = 'Web Icon';
$lang['location_app_icon_text']  	  		  = 'App Icon';
$lang['location_audio_text']  		  		  = 'Audio';
$lang['location_gallery_text']  	  		  = 'Gallery Images';
$lang['location_video_text']  		  		  = 'Video';
$lang['location_vr_text']  		  			  = 'V/R';
$lang['location_2dmap_text']  		  		  = '2D Map';
$lang['location_panorama_text']  			  = 'Panorama Img';
$lang['location_video360_text']  			  = 'Video 360';
$lang['location_vt_text']  			          = 'V/T';

$lang['location_title_text']  		  		  = 'Title';
$lang['location_description_text']  		  = 'Description';
$lang['location_quiz_text']  			      = 'Quiz';
$lang['location_quiz_section_text']  	      = 'Quiz Section';
$lang['location_quiz_setting_text']  	      = 'Quiz Setting';

//Washroom
$lang['location_availability_text']  		  = 'Availability';
$lang['location_map_location_text']  		  = 'Map Location';
$lang['location_washroom_images_text']  	  = 'Images';
$lang['location_washroom_2dmap_text']  		  = '2D map';


//Parking
$lang['location_parking_ticket_text']  		  = 'Parking Ticket';
$lang['location_parking_fees_text']  		  = 'Parking Fees';
$lang['location_map_location_text']  		  = 'Map Location';
$lang['location_washroom_images_text']  	  = 'Images';
$lang['location_washroom_2dmap_text']  		  = '2D map';


//Dispensary
$lang['location_dispensary_images_text']  	  = 'Images';
$lang['location_dispensary_2dmap_text']  		  = '2D map';


//Police Booth
$lang['location_policebooth_images_text']  	  = 'Images';
$lang['location_policebooth_2dmap_text']  		  = '2D map';

//Distance & Others
$lang['location_airport_distance_text']  	  = 'Airport Distance';
$lang['location_railway_station_distance_text'] = 'Railway Station Distance';
$lang['location_bus_stand_distance_text'] 	   = 'Bus Stand Distance';
$lang['location_city_centre_distance_text']    = 'City Centre Distance';
$lang['location_wifi_avail_text']  	  = 'WI-FI Availability';
$lang['location_headphn_avail_text']  	  = 'Headphone Availability';
$lang['location_distance_km_text']  	  = 'KM';


//Working Hours
$lang['location_timing_hours_text']  	= 'Hours';
$lang['location_timing_available_text']  = 'Availability';
$lang['location_timing_starttime_text']  = 'Start Time';
$lang['location_timing_closetime_text']  = 'Close Time';

$lang['location_railway_station_distance_text'] = 'Railway Station Distance';
$lang['location_bus_stand_distance_text'] 	   = 'Bus Stand Distance';
$lang['location_city_centre_distance_text']    = 'City Centre Distance';
$lang['location_wifi_avail_text']  	  = 'WI-FI Availability';
$lang['location_distance_km_text']  	  = 'KM';


//Rules & Regulations
$lang['location_rules_regulations_text']  	= 'Rules & Regulations';
$lang['location_visitors_in_month_text']  = 'Total visitor in a month ';
$lang['location_location_review_text']   = 'Public review about location';
$lang['location_surveyor_remarks_text']  = 'Surveyor Remarks';


//Beacons
$lang['location_beacon_name_text']  	= 'Beacon location name';
$lang['location_beacon_id_text']  = 'Beacon Id';
$lang['location_beacon_action_plan_text']   = 'Action Plan';
$lang['location_beacon_choose_instruction_text']  = 'Choose Instruction';
$lang['location_beacon_sound_file_text']  = 'Sound File';
$lang['location_beacon_upload_media_text']  = 'Upload Media';
$lang['location_beacon_remarks_text']  = 'Remarks';

//Users Columns
$lang['location_srno_column']			      = 'Srno.';
$lang['location_category_type_column']		  = 'Category Type';
$lang['location_category_column']	      	  = 'Category';
$lang['location_location_column']	     	  = 'Location name';
$lang['location_location_short_column']		  = 'Alias Name';
$lang['location_address_column']			  = 'Address';
$lang['location_locality_column']	          = 'Locality';
$lang['location_description_column']	      = 'Description';
$lang['location_locality_pincode_column']     = 'Pincode';
$lang['location_entry_ticket_column']		  = 'Entry Ticket';
$lang['location_estimated_time_column']		  = 'Estimated time to visit';
$lang['location_createdby_column']		      = 'Created By';
$lang['location_createdon_column']		      = 'Created On';
$lang['location_status_column']			      = 'Status';
$lang['location_action_column']			      ='Action';


//events
$lang['events_title']		= 'Events';
$lang['add_event_title']		= 'Add Event';
$lang['edit_event_title']		= 'Edit Event';
$lang['view_events_title']		= 'View Events';
$lang['location_event_text']		  = 'Event Name';
$lang['location_event_column']	     	  = 'Event name';