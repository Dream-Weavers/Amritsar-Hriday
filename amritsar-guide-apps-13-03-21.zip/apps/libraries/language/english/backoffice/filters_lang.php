<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['filter_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_filter_text']			= 'Active';
$lang['deactive_filter_text']			= 'De-active';

//Filters Heading
$lang['filters_title']		= 'Filters';
$lang['add_filter_title']		= 'Add Filter';
$lang['edit_filter_title']		= 'Edit Filter';
$lang['view_filter_title']		= 'View Filters';

//Filters Fields Add/Edit Text
$lang['filter_name_text']		      = 'Filter name';
$lang['filter_weight_text']		      = 'Weight';

//Filters Columns
$lang['filter_srno_column']			      = 'Srno.';
$lang['filter_name_column']		      	  = 'Filter Name';
$lang['filter_weight_column']	 	      = 'Weight';
$lang['filter_createdby_column']		  = 'Created By';
$lang['filter_createdon_column']		  = 'Created On';
$lang['filter_status_column']			  = 'Status';
$lang['filter_action_column']			  = 'Action';