<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['filter_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_filter_text']			= 'Active';
$lang['deactive_filter_text']			= 'De-active';

//Kiosks Heading
$lang['category_title']		= 'Categories';
$lang['add_category_title']		= 'Add Category';
$lang['edit_category_title']	= 'Edit Category';
$lang['view_category_title']	= 'View Categories';
$lang['kiosk_title']		= 'Kiosks';
$lang['add_kiosk_title']		= 'Add Kiosk';
$lang['edit_kiosk_title']		= 'Edit Kiosk';
$lang['view_kiosk_title']		= 'View Kiosks';

$lang['ad_title']		= 'Ads';
$lang['add_ad_title']		= 'Create Ad';
$lang['edit_ad_title']		= 'Edit Ads';
$lang['view_ad_title']		= 'View Ads';



//Category Fields Add/Edit Text
$lang['category_name_text']		  	   = 'Category name';
$lang['description_text']		       = 'Description';


//Kiosks Fields Add/Edit Text
$lang['kiosk_category_text']		   = 'Category';
$lang['kiosk_name_text']		       = 'Kiosk name';
$lang['kiosk_type_text']		       = 'Kiosk type';
$lang['kiosk_mac_id_text']		       = 'MAC ID';
$lang['kiosk_unique_id_text']		   = 'Unique ID';
$lang['kiosk_longitude_text']		   = 'Longitude';
$lang['kiosk_latitude_text']		   = 'Latitude ';
$lang['kiosk_address_text']  		   = 'Address';
$lang['kiosk_description_text']  	   = 'Description';
$lang['kiosk_unique_id_text']		   = 'Kiosk unique id';


//Kiosks Columns
$lang['kiosk_srno_column']			      = 'Srno.';
$lang['kiosk_category_column']		      = 'Category';
$lang['kiosk_name_column']		      	  = 'Kiosk Name';
$lang['kiosk_type_column']		      	  = 'Kiosk Type';
$lang['kiosk_mac_id_column']		      = 'MAC ID';
$lang['kiosk_uniqueid_column']	 	      = 'Kiosk unique id';
$lang['kiosk_address_column']	 	      = 'Address';
$lang['kiosk_description_column']	 	  = 'Description';
$lang['kiosk_createdon_column']		 	  = 'Created On';
$lang['kiosk_status_column']			  = 'Status';
$lang['kiosk_action_column']			  = 'Action';


//Category Columns
$lang['category_srno_column']			      = 'Srno.';
$lang['category_name_column']		      	  = 'Category Name';
$lang['category_description_column']	 	  = 'Description';
$lang['category_createdon_column']		 	  = 'Created On';
$lang['category_status_column']			  = 'Status';
$lang['category_action_column']			  = 'Action';


//Ads Fields Add/Edit Text
$lang['ad_category_text']		   = 'Category';
$lang['ad_title_text']		       = 'Ad Title';
$lang['ad_vendor_text']		       = 'Vendor';
$lang['ad_description_text']  	   = 'Description';
$lang['ad_goal_description_text']  	   = 'Goal Description';


//Ads Columns
$lang['ad_srno_column']			      = 'Srno.';
$lang['ad_category_column']		      = 'Category';
$lang['ad_title_column']		      = 'Add Title';
$lang['ad_vendor_column']		      = 'Vendor';
$lang['ad_desc_column']		      	  = 'Description';
$lang['ad_createdon_column']		  = 'Created On';
$lang['ad_status_column']			  = 'Status';
$lang['ad_action_column']			  = 'Action';

