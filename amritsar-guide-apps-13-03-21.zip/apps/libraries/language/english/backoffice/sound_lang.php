<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['sound_file_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_sound_file_text']			= 'Active';
$lang['deactive_sound_file_text']			= 'De-active';

//sound_files Heading
$lang['sound_files_title']		= 'Sound Files';
$lang['add_sound_file_title']		= 'Add Sound File';
$lang['edit_sound_file_title']		= 'Edit Sound File';
$lang['view_sound_files_title']		= 'View Sound Files';
$lang['show_all_sound_files_title']		= 'Show All Sound Files';

//sound_files Placeholder Text
$lang['sound_file_email_placeholder_text']		= 'We’ll send login details to this email address';
$lang['sound_file_password_placeholder_text']		= 'Minimum of 4 characters.';

//sound_files Fields Add/Edit Text
$lang['sound_file_name_text']		      = 'Sound File';
$lang['sound_upload_text']		      = 'Upload Audio File';



//sound_files Columns
$lang['sound_file_column']		      = 'Sound File';
