<?php
// title
 $lang['text_copyright_footer'] = 'Copyright &copy; Hriday '.date('Y').'. All Rights Reserved';
?>