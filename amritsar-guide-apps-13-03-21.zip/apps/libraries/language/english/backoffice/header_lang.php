<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_validation_required']		= 'The {field} field is required.';
$lang['form_validation_isset']			= 'The {field} field must have a value.';

// title
$lang['text_title_header'] = 'Welcome to Hriday Superadmin';
$lang['text_name_header'] = 'Hriday';

// Super Admin  Menu
$lang['admin_menu_dashboard'] = 'Dashboard';
$lang['admin_menu_masters'] = 'MASTERS';
$lang['admin_menu_country'] = 'View Countries';
$lang['admin_menu_states'] = 'View States';
$lang['admin_menu_citys'] = 'View Cities';
$lang['admin_menu_locality'] = 'View Localities';
$lang['admin_menu_roles'] = 'View Roles';
$lang['admin_menu_beacons'] = 'View Beacons';

$lang['admin_menu_permissions'] = 'Permissions';
$lang['admin_menu_users'] = 'Users';
$lang['admin_menu_projects'] = 'Projects';
$lang['admin_menu_areas'] = 'Areas';
$lang['admin_menu_soundfiles'] = 'Sound Files';
$lang['admin_menu_category_types'] = 'Category Types';
$lang['admin_menu_categories'] = 'Categories';
$lang['admin_menu_filters'] = 'Filters';
$lang['admin_menu_view_filters'] = 'View Filters';
$lang['admin_menu_location_filters'] = 'Location Filters';

$lang['admin_surveyor_menu_locations'] = 'Surveyor Data';
$lang['admin_menu_surveyor_add_location'] = 'Add';
$lang['admin_menu_surveyor_view_locations'] = 'View';

$lang['text_menu_demo_header'] = 'Live Demo'; 
$lang['text_menu_tutorials_header'] = 'Tutorials';
$lang['text_menu_contact_header'] = 'Contact';


$lang['locations_quiz'] = 'Locations Quizzes';
$lang['add_location_quiz'] = 'Add Quiz';
$lang['view_locations_quiz'] = 'View Quizzes';


// Employee Menus
$lang['employee_menu_dashboard'] = 'Dashboard';
$lang['employee_menu_survey'] = 'P2PSurvey';
$lang['employee_menu_locations'] = 'Locations';
$lang['employee_menu_add_location'] = 'Add Location';
$lang['employee_menu_view_locations'] = 'View Locations';

?>
