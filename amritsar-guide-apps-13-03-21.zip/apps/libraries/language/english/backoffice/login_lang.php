<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_name_text']		= 'Login';
$lang['username_placeholder']		= 'Username';
$lang['password_placeholder']		= 'Password';
$lang['btn_text']		= 'Sign In';



