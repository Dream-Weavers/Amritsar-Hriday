<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';


//Messages
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_category_type_text']			= 'Active';
$lang['deactive_category_type_text']			= 'De-active';

//category_types Heading
$lang['category_types_title']		= 'Category Types';
$lang['add_category_type_title']		= 'Add Category Type';
$lang['edit_category_type_title']		= 'Edit Category Type';
$lang['view_category_types_title']		= 'View Category Types';
$lang['show_all_category_types_title']		= 'Show All Category Types';


//category_types Fields Add/Edit Text
$lang['category_type_name_text']		      = 'Category Type';




//category_types Columns

$lang['category_type_column']		      = 'Category Type';
$lang['category_type_project_column']		      = 'Project';
$lang['category_type_name_column']		      = 'Category Type';
$lang['category_type_icon_column']		      = 'Icon';
$lang['category_type_description_column']		      = 'Description';
$lang['category_type_picture_limit_column']		      = 'Picture Limit';
$lang['category_type_videos_limit_column']		      = 'Videos Limit';
$lang['category_type_panorama_limit_column']		      = 'Panorama Limit';
$lang['category_type_audio_limit_column']		      = 'Audio Limit';


$lang['category_type_select_project']		      = 'Select Project';
$lang['category_type_select_name']		      = 'Category Type';
$lang['category_type_description']		      = 'Description';
$lang['category_type_surveyor_limit_column']		      = 'Surveyer Limits';
$lang['category_type_picture_limit_column']		      = 'Pictures Limit';
$lang['Minimum_Limit']		      = 'Minimum';
$lang['Maximum_Limit']		      = 'Maximum';
$lang['category_type_videos_limit_column']		      = 'Videos Limit';
$lang['category_type_panorama_limit_column']		      = 'Panorama Limit';
$lang['category_type_audio_limit_column']		      = 'Audio Limit';


