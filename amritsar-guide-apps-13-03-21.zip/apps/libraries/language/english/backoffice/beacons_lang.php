<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['filter_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_filter_text']			= 'Active';
$lang['deactive_filter_text']			= 'De-active';

//Beacons Heading
$lang['beacons_title']		= 'Beacons';
$lang['add_beacon_title']		= 'Add Beacon';
$lang['edit_beacon_title']		= 'Edit Beacon';
$lang['view_beacon_title']		= 'View Beacons';

//Beacons Fields Add/Edit Text
$lang['beacon_name_text']		      = 'Beacon name';
$lang['beacon_unique_id_text']		  = 'Beacon unique id';

//Beacons Columns
$lang['beacon_srno_column']			      = 'Srno.';
$lang['beacon_name_column']		      	  = 'Beacon Name';
$lang['beacon_uniqueid_column']	 	      = 'Beacon unique id';
$lang['beacon_createdon_column']		  = 'Created On';
$lang['beacon_status_column']			  = 'Status';
$lang['beacon_action_column']			  = 'Action';
