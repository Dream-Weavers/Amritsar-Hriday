<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
//categories Heading
$lang['categories_title']		= 'Categories';
$lang['add_category_title']		= 'Add Category';
$lang['edit_category_title']		= 'Edit Category';
$lang['view_categories_title']		= 'View Categories';
$lang['show_all_categories_title']		= 'Show All Categories';


//categories Fields Add/Edit Text
$lang['category_name_text']		      = 'Category';




//categories Columns

$lang['category_column']		      = 'Category';
$lang['category_project_column']		      = 'Project';
$lang['category_name_column']		      = 'Category';
$lang['category_icon_column']		      = 'Icon';
$lang['category_description_column']		      = 'Description';



$lang['category_select_project']		      = 'Select Project';
$lang['category_select_name']		      = 'Category';
$lang['category_description']		      = 'Description';


$lang['category_choose_filter']		      = 'Choose Filter';
$lang['category_parent_name']		      = 'Parent';
$lang['category_name_text']		      = 'Category Name';
$lang['category_parent_category_text']		      = 'Parent Category';


