<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Search
$lang['search_heading_text']			= 'Search';
$lang['search_designation_text']			= 'Designation';
$lang['search_role_text']			= 'Role';
$lang['search_status_text']			= 'Status';
$lang['search_search_by_text']			= 'Search by';
$lang['search_search_value_text']			= 'Search value';
$lang['search_perpage_text']			= 'Per page';
$lang['search_button_text']			= 'Search';


//Common Texts
$lang['shadow_text']			= 'Shadow';
$lang['no_rec_found_text']			      = 'No Record Found';
$lang['action_column']			      ='Action';
$lang['srno_column']			      = 'Sr No.';

//Buttons
$lang['submit_button_text']		      = 'Submit';
$lang['reset_button_text']		      = 'Reset';
$lang['back_button_text']		      = 'Back';

//Heading
$lang['dashboard_text']		= 'Dashboard';


//Messages
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';