<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_name_text']		= 'Login';
$lang['username_placeholder']		= 'Username';
$lang['password_placeholder']		= 'Password';
$lang['login_btn_text']		= 'Sign In';
$lang['forgot_pwd_btn_text']		= 'Forgot Password';
$lang['back_btn_text']		= 'Back';
$lang['submit_btn_text']		= 'Submit';

$lang['login_invalid_message']		= '<center>Invalid Username or Password.</center>';
$lang['login_deactivated_message']		= 'Your login is de-activated. Please contact administrator.';
$lang['login_expired_message']		= 'Your login validity has been expired.';
$lang['forgot_pwd_txt']		= 'Enter your e-mail address below to reset your password.';

