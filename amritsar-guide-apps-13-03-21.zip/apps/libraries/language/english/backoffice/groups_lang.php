<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['filter_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_filter_text']			= 'Active';
$lang['deactive_filter_text']		= 'De-active';

//Groups Heading
$lang['group_type']		= 'Group Type';
$lang['group_title']		= 'Groups';
$lang['add_group_title']		= 'Add Group';
$lang['edit_group_title']		= 'Edit Group';
$lang['view_group_title']		= 'View Groups';



$lang['mapping_title']		= 'Mapping';
$lang['add_mapping_title']		= 'Add Mapping';
$lang['edit_mapping_title']		= 'Edit Mapping';
$lang['view_mapping_title']		= 'View Mapping';

//Groups Fields Add/Edit Text
$lang['group_type_text']		   = 'Group Type';
$lang['group_category_text']		   = 'Category';
$lang['group_name_text']		       = 'Group name';
$lang['group_kisok_text']		       = 'Kiosk';

//Groups Columns
$lang['group_srno_column']			      = 'Srno.';
$lang['group_type_column']		     	  = 'Group Type';
$lang['group_name_column']		      	  = 'Group Name';
$lang['group_createdon_column']		 	  = 'Created On';
$lang['group_status_column']			  = 'Status';
$lang['group_action_column']			  = 'Action';

//Mapping Columns
$lang['mapping_srno_column']			      = 'Srno.';
$lang['mapping_type_column']		     	  = 'Group Type';
$lang['mapping_group_name_column']		      = 'Group Name';
$lang['mapping_title_name_column']		      = 'Name';
$lang['mapping_createdon_column']		 	  = 'Created On';
$lang['mapping_status_column']			  = 'Status';
$lang['mapping_action_column']			  = 'Action';



//Category Columns
$lang['category_srno_column']			  = 'Srno.';
$lang['category_name_column']		      = 'Category Name';
$lang['category_description_column']	  = 'Description';
$lang['category_createdon_column']		  = 'Created On';
$lang['category_status_column']			  = 'Status';
$lang['category_action_column']			  = 'Action';
