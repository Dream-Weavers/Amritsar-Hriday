<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['area_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';

$lang['active_area_text']			= 'Active';
$lang['deactive_area_text']			= 'De-active';

//areas Heading
$lang['areas_title']		= 'Areas';
$lang['add_area_title']		= 'Add Area';
$lang['edit_area_title']		= 'Edit Area';
$lang['view_areas_title']		= 'View Areas';
$lang['show_all_areas_title']		= 'Show All Areas';

//areas Placeholder Text
$lang['area_email_placeholder_text']		= 'We’ll send login details to this email address';
$lang['area_password_placeholder_text']		= 'Minimum of 4 characters.';

//areas Fields Add/Edit Text
$lang['area_name_text']		      = 'Area';




//areas Columns

$lang['area_column']		      = 'Area';

