<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';
$lang['location_additional_fields_text']			= 'Additional Fields';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['delete_text_message']		= 'Record has been deleted successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['status_success_text_message']		= 'Status has been updated successfully.';
$lang['status_error_text_message']		= 'There is some error in status updation.';


$lang['location_quiz_text']  			      = 'Quiz';
$lang['location_quiz_section_text']  	      = 'Quiz Section';
$lang['location_quiz_setting_text']  	      = 'Quiz Setting';

$lang['quiz_type']  	      = 'Select Type';
$lang['quiz_general_settings']  	      = 'General Settings';
$lang['quiz_general_type_settings']  	      = 'Quiz Type Settings';
$lang['quiz_location_text']  	      = 'Location';
$lang['quiz_name_text']  	      = 'Name';
$lang['quiz_theme_text']  	      = 'Theme';
$lang['quiz_status_text']  	      = 'Quiz Status';
$lang['quiz_audio_status_text']  	      = 'Audio Status';
$lang['quiz_manual_type_text']  	      = 'Manual Type Quiz';
$lang['quiz_automatic_type_text']  	      = 'Automatic Type Quiz';
$lang['quiz_rapid_type_text']  	      = 'Rapid Type Quiz';
$lang['quiz_question_text']  	      = 'Question';
$lang['quiz_order_text']  	      = 'Order';
$lang['quiz_option1_text']  	      = 'Option 1';
$lang['quiz_option2_text']  	      = 'Option 2';
$lang['quiz_option3_text']  	      = 'Option 3';
$lang['quiz_option4_text']  	      = 'Option 4';
$lang['quiz_answer_text']  	      = 'Answer';
$lang['quiz_add_more_button_text']  	      = 'Add More';//View
//$lang['quiz_srno_column']='Sr No.'