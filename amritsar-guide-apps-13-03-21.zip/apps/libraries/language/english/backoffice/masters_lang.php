<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//Heading
$lang['dashboard_text']		= 'Dashboard';

//Messages
$lang['already_exists_text']		= '{field} already exists, Please try another.';
$lang['success_text_message']		= 'Record has been added successfully.';
$lang['update_text_message']		= 'Record has been updated successfully.';
$lang['error_text_message']		= 'There is some error in form.';

$lang['country_text']		= 'Countries';
$lang['add_country_text']		= 'Add Country';
$lang['edit_country_text']		= 'Edit Country';
$lang['view_country_text']		= 'View Countries';

//Locality Heading
$lang['locality_title']		= 'Localities';
$lang['add_locality_title']		= 'Add Locality';
$lang['edit_locality_title']		= 'Edit Locality';
$lang['view_locality_title']		= 'View Localities';

//Locality Fields Add/Edit Text
$lang['locality_country_text']		= 'Country';
$lang['locality_state_text']		= 'State';
$lang['locality_city_text']		= 'City';
$lang['locality_name_text']		= 'Locality name';

//Locality Columns
$lang['locality_srno_column']		= 'Srno.';
$lang['locality_state_column']		= 'State';
$lang['locality_city_column']		= 'City';
$lang['locality_name_column']		= 'Locality name';
$lang['locality_action_column']		='Action';


//Roles Heading
$lang['role_title']		= 'Roles';
$lang['add_role_title']		= 'Add Role';
$lang['edit_role_title']		= 'Edit Role';
$lang['view_role_title']		= 'View Roles';

//Roles Column Add/Edit Text
$lang['role_name_text']		= 'Role name';
$lang['role_description_text']		= 'Description';
$lang['role_permission_text']		= 'Permissions';


//Roles Columns
$lang['role_srno_column']		= 'Srno.';
$lang['role_name_column']		= 'Role name';
$lang['role_description_column']= 'Description';
$lang['role_created_by_column']= 'Created By';
$lang['role_action_column']		='Action';
