<?php
 // Feilds
  $lang['username'] = 'Username';
  $lang['password'] = 'Password';
  $lang['invalidmsg'] = 'Invalid Username or Password.';
?>
