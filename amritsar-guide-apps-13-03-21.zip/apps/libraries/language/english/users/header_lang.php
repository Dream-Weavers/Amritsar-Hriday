<?php
// title
$lang['text_title_header'] = 'Welcome to Hriday';
$lang['text_name_header'] = 'Hriday';

// Main Menu
$lang['text_menu_home_header'] = 'Home';
$lang['text_menu_demo_header'] = 'Live Demo'; 
$lang['text_menu_tutorials_header'] = 'Tutorials';
$lang['text_menu_contact_header'] = 'Contact';
?>