<!-- Head Part -->
<?php $this->load->view('backoffice/layout/head'); ?>
<!-- End Head Part -->
<body class=" login">
        <!-- BEGIN LOGO -->
        <div class="logo">
            <!--<a href="index.html">
                <img src="../assets/pages/img/logo-big.png" alt="" /> 
			</a>-->
        </div>
        <!-- END LOGO -->
        <!-- BEGIN LOGIN -->
        <div class="content">
            <!-- BEGIN LOGIN FORM -->
			<?php
			
			?>
            <form class="login-form" action="<?php echo base_url()?>backoffice/login" method="post">
                <h3 class="form-title font-green">Sign In</h3>
				<?php 
					//print '<pre>'; print_r(validation_errors()); die;
					if(empty(validation_errors()) && empty($this->session->flashdata('error'))){
						$class='display-hide';
					}else{
						$class='';
					}
				?>
                <div class="alert alert-danger <?php echo $class; ?>">
                    <button class="close" data-close="alert"></button>
                     <?php echo validation_errors(); ?>
					 <?php
					
						 echo $this->session->flashdata('error');
					
					 ?>
                </div>
                <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">Email ID</label>
                    <input class="form-control form-control-solid placeholder-no-fix" type="text" autocomplete="off" placeholder="Email id" value='<?php echo $emailid;?>' name="emailid" /> </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Password</label>
                    <input class="form-control form-control-solid placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" name="password" /> </div>
                <div class="form-actions">
                    <button type="submit" class="btn green uppercase">Login</button>
    
                </div>
                
            </form>
            <!-- END LOGIN FORM -->
        </div>

    </body>