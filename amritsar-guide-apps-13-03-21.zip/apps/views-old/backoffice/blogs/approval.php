<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		 <link href="<?php echo base_url();?>assets/layouts/layout3/css/copy_loc_popup.css" rel="stylesheet" type="text/css" />
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
		<div class="page-wrapper-row full-height">
			<div class="page-wrapper-middle">
				<!-- BEGIN CONTAINER -->
				<div class="page-container">
				<!-- BEGIN CONTENT -->
					<div class="page-content-wrapper">
						<!-- BEGIN CONTENT BODY -->
					
						<!-- BEGIN PAGE CONTENT BODY -->
						<div class="page-content">
							<div class="container">
<!-- BEGIN PAGE CONTENT INNER -->
<div class="page-content-inner">
	<div class="mt-content-body">
			<?php if((validation_errors()) || ($already_msg)):?>
			<div class="alert alert-danger">
				<button class="close" data-close="alert"></button>
				 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
			</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet light bordered">
						<div id="copyLocPopup">
						  <div class="form-popup" id="popupForm">
							
							<?php  $attributes = array('class' => 'form-container copylocform');
							 echo form_open(base_url().'employees/locations/reccpy/', $attributes);
							 ?>
							  <label class="control-label"><h4>Add remarks if you want to</h4> </label>
							  <textarea name="rejection_status_remarks" rows='5' cols='42'></textarea><br />
							
								
							  <button type="submit" class="btn">Proceed</button>
							  <!--<button type="button" class="btn cancel closeForm">Close</button>-->
							  
							<?php echo form_close(); ?>
							
						  </div>
						</div>
						<div class="portlet-title">
							<div class="caption"> <i class=" fa fa-categorytype font-green-sharp"></i> <span class="caption-subject font-green-sharp bold uppercase"><?php echo $heading;?></span> </div>
							<div class="actions">
								<!--<div class="btn-categorytype">
											<a href="<?php //echo base_url();?>backoffice/blogs/add" id="sample_editable_1_new" class="btn sbold green">
												<i class="fa fa-plus"></i> Create Blog
											</a>
										</div>-->
							</div>
						</div>
						<div class="portlet-body">
						
							<div class="table-toolbar">
							<?php 
							if($this->session->flashdata('success_message')){
							success_message($this->session->flashdata('success_message'));
							}
							?>    
							</div>
							<?php //$this->load->view("includes/notifications.php");?>
                                                <!-- BEGIN FILTER TABLE-->
												 <?php  $attributes = array('id' => 'form1','name' => 'form1','class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
                                                    echo form_open(base_url().'backoffice/blogs/approval', $attributes);
                                                  ?>
                                                <div class="portlet box blue-hoki">  
                                                    <div class="portlet-title">
                                                        <div class="caption">
                                                            <i class="fa fa-search"></i>Search </div>
                                                        <div class="tools">
                                                            <a href="javascript:;" class="expand"> </a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body portlet-collapsed">
                                                        <div class="row">
                                                        
                                                        
                                                        <div class="col-md-3">
                                                            <label>Category</label>
														<?php
                                                            $fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
                                                            $category_array = gettabledropdown('blog_categories',$fields,'category_id',
															'category_name','category_id','ASC');
                                                            $selected = ($this->input->post('category_id')) ? $this->input->post('category_id') : $this->input->post('category_id');
                                                            echo form_dropdown('category_id', $category_array,  $selected,'id="category_id" class="form-control form-filter input-sm"  ');
                                                         ?>
                                                        </div>
														
                                                        <div class="col-md-3">
                                                            <label>Keyword</label>
                                                                   <?php 
																     $data = array(
																	  'name'        => 'title',
																	 
																	  'value'       => set_value('title'),									
																	  'maxlength'   => '80',
																	  'placeholder'   => 'Enter any Keyword',
																	  'class'   => 'form-control form-filter input-sm',
                                                                      );
                                                                    echo form_input($data);
                                                                    ?>
                                                        </div>
                                                        
                                                       
                                                      
                                                        
                                                        
                                                    
                                                    </div>  
                                                        <div class="margin-top-10"><button class="btn btn-sm btn-success filter-submit margin-bottom"><i class="fa fa-search"></i> Search</button></div>
                                                    </div>
                                                </div>
                                                  <?php echo form_close(); ?>
							<div class="portlet box green">
                                                    <div class="portlet-title">
                                                        <div class="caption">
                                                            <i class="fa fa-users"></i><?php echo $heading; ?>: <?php echo '('.$num_rows.')'; ?>  </div>
                                                        <div class="tools"> </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div class="table-responsive">
														<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
								<thead>
									<tr>
										<th>Sr No.</th>
										<th>Category</th>
										<th>Title</th>
										<!--<th width="20">Description</th>-->
										<th>Featured Image</th>
										<th>Video</th>
										<th>Created By</th>
										<th>Created Date</th>
										<th>Last Modified</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								
								<?php if($results){ $srno=0;
									foreach($results as $rec){
										$srno++;
										
									?>
									<tr class="odd gradeX">
										<td><?php echo $srno;?></td>
										<td> <?php echo ucfirst($rec->category_name);?></td>
										<td> <?php echo ucfirst($rec->title);?></td>
										<!--<td><?php echo $rec->description; ?></td>-->
										<td><?php if($rec->image_url!='') { ?><a  class='imagelightbox' data-toggle="modal" href="#lightboxresponsive"><img src='<?php echo base_url();?>images/blogs/<?php echo $rec->image_url; ?>' width='50'><?php } ?></a></td>
										<td>
											<?php if($rec->video_url!=''){ 
											$video_id = get_youtube_video_id($rec->video_url); 
											?>
											<a class='videolightbox' get_id= '<?php echo $video_id ?>' data-toggle="modal" href="#lightboxresponsive"><i class="fa fa-youtube-play youtube-play"></i></a>
											<?php } ?>
										</td>
										<td> <?php echo $rec->fullname;?></td>
										 <td><?php echo date('d M, Y h:ia',strtotime($rec->created_date));?></td>
										  <td><?php if($rec->modified_date!='NULL') { echo date('d M, Y h:ia',strtotime($rec->modified_date)); }?></td>
										  
										<td><a class="label label-sm label-success" onclick="return confirm('Do you want to publish ?');" href="<?php echo base_url();?>backoffice/blogs/publish/<?php echo $rec->blog_id; ?>/1">Publish Now! </a>
										<br /><br />
										<a id="<?php echo $rec->blog_id; ?>" class="label label-sm label-success rejectrecord">Reject! </a>										
										</td>
										<td> <a href="<?php echo base_url();?>backoffice/blogs/approvalblog/<?php echo $rec->blog_id;?>" class="btn btn-xs yellow"><i class="fa fa-edit"></i></a></td>
									</tr>
							   <?php } } else { echo "<td colspan='8'>".$this->lang->line('no_rec_found_text')."</td>"; } ?>   
								</tbody>
							</table>
							<span class='mypagination'><?php echo $links; ?></span>
							</div></div></div>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				</div>
			</div>
    
    </div>
</div>
<!-- END PAGE CONTENT INNER -->
							</div>
						</div>
						<!-- END PAGE CONTENT BODY -->
						<!-- END CONTENT BODY -->
					</div>
					<!-- END CONTENT -->
				</div>
				<!-- END CONTAINER -->
		</div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
		<script>
		$(document).ready(function(){
			$('.rejectrecord').click(function(){ 
				var con=confirm('Do you want to reject?');
				if(con){
					$('#copyLocPopup').show();
					var blog_id=$(this).attr('id');
					//alert(blog_id);
					$('.copylocform').attr('action','<?php echo base_url() ?>backoffice/blogs/reject/'+blog_id+'/2');
				} 
				return false;
			}); 
			$('.closeForm').click(function(){
				$('#copyLocPopup').hide();
			}); 
			
		});

		  // When the user clicks anywhere outside of the modal, close it
		  window.onclick = function(event) {
			var modal = document.getElementById('copyLocPopup'); 
			if (event.target == modal) {
			  closeForm();
			}
		  }
		</script>
    </body>

</html>