<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
					<!-- BEGIN CONTENT -->
						<div class="page-content-wrapper">
							<!-- BEGIN CONTENT BODY -->
							<!-- BEGIN PAGE CONTENT BODY -->
							<div class="page-content">
								<div class="container">
									<!-- BEGIN PAGE BREADCRUMBS -->
									<!--<ul class="page-breadcrumb breadcrumb">
										<li>
											<a href="index.html">Home</a>
											<i class="fa fa-circle"></i>
										</li>
										<li>
											<span>Tutors</span>
										</li>
									</ul>-->
									<!-- END PAGE BREADCRUMBS -->
									<!-- BEGIN PAGE CONTENT INNER -->
									<div class="page-content-inner">
										<div class="mt-content-body">
										    <div class="row">
													<div class="col-md-12">
														
														 <div class="portlet box green">
															<div class="portlet-title">
																<div class="caption">
																	<i class="fa fa-gift"></i><?php echo $heading; ?> </div>
															</div>
															<div class="portlet-body">
																<div class="row">
																	
											<div class="col-md-12">
											  <?php  $attributes = array('class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
													if($blog_id==0)
													 echo form_open_multipart(base_url().'backoffice/Blogs/add', $attributes);
													else
													echo form_open_multipart(base_url().'backoffice/blogs/edit/'.$blog_id, $attributes);
											  ?>
											<div class="form-body">
											 
											
											<?php if((validation_errors()) || ($already_msg)):?>
											<div class="alert alert-danger">
												<button class="close" data-close="alert"></button>
												 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
											</div>
											<?php endif; ?>
													
													<div class="form-group">
														<label class="col-md-1 control-label">Category</label>
														<div class="col-md-2"> 
														 <?php
															$category=array();
															$selected=$category_id;
															$category['']="Select Category";
															
															$fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
                                                            $categories = gettableresult('blog_categories',$fields);
													
															foreach($categories as $key=>$value){
																$category[$value->category_id]=ucfirst($value->category_name);
															}

															 
															echo form_dropdown('category_id', $category,$selected,'id="category_id" class="form-control" required'); 
														 ?>
														 
														</div>
														
														<label class="col-md-1 control-label">Title</label>
														 <div class="col-md-2"> 
														 <?php $data = array(
														  'name'        => 'title',
														  'value'       => $title,								
														  'maxlength'   => '255',
														  'class'   => 'form-control',
														  'required'   => 'required',
														  );
														echo form_input($data);
														?>
														</div>
														
														<label class="control-label col-md-1">Featured Image</label>
														<div class="col-md-2">
															<span class="btn btn-outline btn-file">
													
																
															<input type="file" name="featured_image"> </span>
																
															 <br /><span class="label label-success"><?php echo $this->lang->line('photo_note_text'); ?>!</span> JPG,PNG,JPEG 
														</div>
														
														
													</div>
													<div class="form-group">
													   <label class="col-md-1 control-label">Youtube Video Url</label>
														 <div class="col-md-4"> 
															 <?php $data = array(
															  'name'        => 'video_url',
															  'id'          => 'video_url',	
															  'value'       => $video_url,
															  'maxlength'   => '255',
															  'class'   => 'form-control',
															  );
															echo form_input($data);
															?>
														 </div>
													</div>
													<div class="form-group">
														<label class="control-label col-md-1">Description</label>
														<div class="col-md-10">
															<textarea name="description" id="summernote_1"><?php echo $description?></textarea>
														</div>
													</div>
													
											  </div>
													
											  <div class="form-actions">
													<div class="row">
														<div class="col-md-offset-5 col-md-4">
															<button type="submit" class="btn green" value="<?php echo $this->lang->line('submit_button_text'); ?>"><?php echo $this->lang->line('submit_button_text'); ?></button>
															
															<a class="btn default" href='<?php echo base_url() ?>backoffice/blogs/'><?php echo $this->lang->line('back_button_text'); ?></a>
														</div>
													</div>
											   </div>
															
												<?php echo form_close(); ?>
												</div>
																</div>
															</div>
														</div>
														
														
													</div>
													
												</div>
											
										</div>
									</div>
									<!-- END PAGE CONTENT INNER -->
								</div>
							</div>
							<!-- END PAGE CONTENT BODY -->
							<!-- END CONTENT BODY -->
						</div>
						<!-- END CONTENT -->
                    </div>
                    <!-- END CONTAINER -->
               </div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
    </body>

</html>