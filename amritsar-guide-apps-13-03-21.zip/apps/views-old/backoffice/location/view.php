<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
		
		<div class="page-wrapper-row full-height">
			<div class="page-wrapper-middle">
				<!-- BEGIN CONTAINER -->
				<div class="page-container">
				<!-- BEGIN CONTENT -->
					<div class="page-content-wrapper">
						<!-- BEGIN CONTENT BODY -->
						<!-- BEGIN PAGE HEAD-->
						<div class="page-head">
							<div class="container">
								<!-- BEGIN PAGE TITLE -->
								<div class="page-title">
									<h1><?php echo $title; ?>
										<small><?php echo  $main_heading; ?></small>
									</h1>
								</div>
								<!-- END PAGE TITLE -->
								<!-- BEGIN PAGE TOOLBAR -->
								
								<!-- END PAGE TOOLBAR -->
							</div>
						</div>
						<!-- END PAGE HEAD-->
						<!-- BEGIN PAGE CONTENT BODY -->
						<div class="page-content">
							<div class="container">
<!-- BEGIN PAGE CONTENT INNER -->
<div class="page-content-inner">
	<div class="mt-content-body">
			<?php if((validation_errors()) || ($already_msg)):?>
			<div class="alert alert-danger">
				<button class="close" data-close="alert"></button>
				 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
			</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet light bordered">
						<div class="portlet-title">
							<div class="caption"> <i class=" fa fa-category font-green-sharp"></i> <span class="caption-subject font-green-sharp bold uppercase"><?php echo $heading;?></span> </div>
						</div>
						<div class="portlet-body">
							<div class="table-toolbar">
							<?php 
							if($this->session->flashdata('success_message')){
							success_message($this->session->flashdata('success_message'));
							}
							?>    
							</div>
							<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
								<thead>
									<tr>
										<th> Title/Language</th>
										<th> English</th>
										<th> Hindi</th>
										<th> Punjabi</th>
									</tr>
								</thead>
								<tbody>
								<?php if($categories){ $countcategories=array();
										foreach($categories as $rec){
											$countcategories[$rec->language_id]=$rec->countedrecords;
										}
									?>
									<tr class="odd gradeX">
										<td>Categories</td>
										<td> <?php echo $countcategories[1];?></td>
										<td> <?php echo $countcategories[2];?></td>
										<td> <?php echo $countcategories[3];?></td>
										
									
										
									</tr>
							   <?php } if($category_types){ $countcategorytypes=array();
										foreach($category_types as $rec){
											$countcategorytypes[$rec->language_id]=$rec->countedrecords;
										}
									?>
									<tr class="odd gradeX">
										<td>Category Types</td>
										<td> <?php echo $countcategorytypes[1];?></td>
										<td> <?php echo $countcategorytypes[2];?></td>
										<td> <?php echo $countcategorytypes[3];?></td>
										
									
										
									</tr>
							   <?php } if($locations){ $countlocations=array();
										foreach($locations as $rec){
											$countlocations[$rec->language_id]=$rec->countedrecords;
										}
									?>
									<tr class="odd gradeX">
										<td>Locations</td>
										<td> <?php echo $countlocations[1];?></td>
										<td> <?php echo $countlocations[2];?></td>
										<td> <?php echo $countlocations[3];?></td>
										
									
										
									</tr>
							   <?php } if($beacon_locations){ $countbeaconlocations=array();
										foreach($beacon_locations as $rec){
											$countbeaconlocations[$rec->language_id]=$rec->countedrecords;
										}
									?>
									<tr class="odd gradeX">
										<td>Beacons</td>
										<td> <?php echo $countbeaconlocations[1];?></td>
										<td> <?php echo $countbeaconlocations[2];?></td>
										<td> <?php echo $countbeaconlocations[3];?></td>
										
									
										
									</tr>
							   <?php }  if($question_bank){ $countquestionbank=array();
										foreach($question_bank as $rec){
											$countquestionbank[$rec->language_id]=$rec->countedrecords;
										}
									?>
									<tr class="odd gradeX">
										<td>Quizzes</td>
										<td> <?php echo $countquestionbank[1];?></td>
										<td> <?php echo $countquestionbank[2];?></td>
										<td> <?php echo $countquestionbank[3];?></td>
										
									
										
									</tr>
							   <?php } ?>    
								</tbody>
							</table>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				</div>
			</div>
     
    </div>
</div>
<!-- END PAGE CONTENT INNER -->
							</div>
						</div>
						<!-- END PAGE CONTENT BODY -->
						<!-- END CONTENT BODY -->
					</div>
					<!-- END CONTENT -->
				</div>
				<!-- END CONTAINER -->
			</div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
    </body>

</html>