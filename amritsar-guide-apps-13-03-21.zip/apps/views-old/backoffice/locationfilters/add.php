<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo $this->lang->line('text_title_header'); ?></title>
        <?php $this->load->view("includes/styles.php");?>
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/clockface/css/clockface.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
        </head>
    <!-- END HEAD -->
<?php  $mobile=$this->agent->is_mobile();

?>
    <body class="page-container-bg-solid">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
					  <?php if(!$mobile){ ?>
                    <!-- BEGIN HEADER -->
                    <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
					  <?php } ?>
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
                        <!-- BEGIN CONTENT -->
                        <div class="page-content-wrapper">
                            <!-- BEGIN CONTENT BODY -->
                            <!-- BEGIN PAGE HEAD-->
                            <div class="page-head">
                                <div class="container">
                                    <!-- BEGIN PAGE TITLE -->
									<?php if(!$mobile){ ?>
                                    <div class="page-title">
                                        <h1><?php echo $main_heading; ?></h1>
                                    </div>
									<?php } ?>
                                    <!-- END PAGE TITLE -->
                                    <!-- BEGIN PAGE TOOLBAR -->
									<?php if(!$mobile){ ?>
                                    <?php $this->load->view("includes/toolbar.php");?>
									<?php } ?>
                                    <!-- END PAGE TOOLBAR -->
                                </div>
                            </div>
                            <!-- END PAGE HEAD-->
                            <!-- BEGIN PAGE CONTENT BODY -->
                            <div class="page-content">
                                <div class="container">
                                    <!-- BEGIN PAGE BREADCRUMBS -->
									<?php if(!$mobile){ ?>
                                    <ul class="page-breadcrumb breadcrumb">
                                        <li>
                                            <a href="<?php echo base_url();?>employees/dashboard"><?php echo $this->lang->line('dashboard_text'); ?></a>
                                            <i class="fa fa-circle"></i>
                                        </li>
                                        <li>
                                        <a href="<?php echo base_url(); ?>employees/locations/view">
                                            <?php echo $main_heading; ?>
                                        </a> <i class="fa fa-circle"></i> </li>
                                    <li> <span><?php echo $heading; ?></span> </li>
                                    </ul>
									<?php } ?>
                                    <!-- END PAGE BREADCRUMBS -->
                                    <!-- BEGIN PAGE CONTENT INNER -->
                                    <div class="page-content-inner">
                                        <div class="row">
                                          <?php  $attributes = array('id' => 'location_form','name' => 'location_form','class' => 'horizontal-form','role' => 'form','autocomplete' => 'off');
                                             echo form_open_multipart(base_url().'employees/locations/add', $attributes);
                                           ?>
                                            <div class="col-md-12">
                                            
                                            
                                                 
                                                <div class="portlet box blue">
                                                    <div class="portlet-title">
                                                        <div class="caption">
                                                            <i class="fa fa-plus-square"></i><?php echo $heading; ?></div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div class="tabbable-custom nav-justified">
                                                            <ul class="nav nav-tabs nav-justified">
                                                                <li class="active">
                                                                    <a href="#tab_1" data-toggle="tab"> Basic Details </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#tab_2" data-toggle="tab"> Digital Media </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#tab_3" data-toggle="tab"> Location Text </a>
                                                                </li>
                                                                 <li>
                                                                    <a href="#tab_4" data-toggle="tab"> Facilities </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#tab_5" data-toggle="tab"> Distance & Timings </a>
                                                                </li>
                                                            </ul>
                                                            <div class="tab-content">
                                                                <div class="tab-pane active" id="tab_1">
                                                                    <div class="row">
                                                                     
                                                                       <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_category_type_text'); ?> <span class="required"> * </span></label>
                                                                                 <?php
																					$fields = array('is_active'=>'1');
																					$designation_array = gettabledropdown('category_types',$fields,'category_type_id','category_type','category_type','ASC');
																					$selected = ($this->input->post('category_type_id')) ? $this->input->post('category_type_id') : $this->input->post('category_type_id');
																					echo form_dropdown('category_type_id', $designation_array,  $selected,'id="category_type_id" class="form-control" required ');
																					echo form_error('category_type_id');
																				   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_category_text'); ?> <span class="required"> * </span></label>
                                                                               <div  style="height:150px;  overflow-x:hidden; overflow:scroll;">
                                                                                <div class="category_list"></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                        <div class="col-md-6">
                                                                            <div class="form-group">
                                                                               <label class="control-label"><?php echo $this->lang->line('location_description_text'); ?> </label>
																				 <?php $data = array(
                                                                                      'name'        => 'description',
                                                                                      'id'          => 'description',	
                                                                                      'value'       => set_value('description') ? $this->input->post("description") : $this->input->post("description"),																		
                                                                                      'class'   => 'form-control',
                                                                                      'rows'   => '7',	
                                                                                      );
                                                                                   echo form_textarea($data);
                                                                                   echo form_error('description');
                                                                                  ?>
                                                                            </div>
                                                                        </div>
                                                                  
                                                                      </div>
                                                                    <!--/row-->
                                                                    
                                                                    <div class="clearfix">&nbsp;</div>
                                                                    
                                                                     <div class="caption">
                                                                     <i class="icon-map font-dark"></i>
                                                                      <span class="caption-subject font-dark sbold uppercase">Location Details</span>
                                                                     </div>
                                                                     
                                                                     <div class="clearfix">&nbsp;</div>
                                                                       
                                                                    <div class="row">
                                                                       
                                                                       <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_location_name_text'); ?> <span class="required"> * </span></label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'location_name',
                                                                                      'id'          => 'location_name',	
                                                                                      'value'       => set_value('location_name') ? $this->input->post("location_name") : $this->input->post("location_name"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control',
																					  'required'   => 'required',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('location_name');
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_short_name_text'); ?> <span class="required"> * </span></label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'short_name',
                                                                                      'id'          => 'short_name',	
                                                                                      'value'       => set_value('short_name') ? $this->input->post("short_name") : $this->input->post("short_name"),												
                                                                                      'maxlength'   => '100',
                                                                                      'class'   => 'form-control',
																					  'required'   => 'required',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('short_name');
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_short_description_text'); ?>  <span class="required"> * </span></label>
                                                                                   <?php $data = array(
                                                                                      'name'        => 'short_description',
                                                                                      'id'          => 'short_description',	
                                                                                      'value'       => set_value('short_description') ? $this->input->post("short_description") : $this->input->post("short_description"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control',
																					  'required'   => 'required',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('short_description');
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                         
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_estimated_visit_time_text'); ?> </label>
                                                                                 <?php
																					$estimated_time_array = get_estimated_time_array();
																					$selected = ($this->input->post('estimated_visit_time')) ? $this->input->post('estimated_visit_time') : $this->input->post('estimated_visit_time');
																					echo form_dropdown('estimated_visit_time', $estimated_time_array,  $selected,'id="estimated_visit_time" class="form-control" ');
																					echo form_error('estimated_visit_time');
																				   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                         </div>
                                                                    <!--/row-->
                                                                        
                                                                        
                                                                        <div class="row">
                                                                        
                                                                          <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_address_text'); ?> <span class="required"> * </span></label>
                                                                                <?php $data = array(
																				  'name'        => 'address',
																				  'id'          => 'address',	
																				  'value'       => set_value('address') ? $this->input->post("address") : $this->input->post("address"),																		
																				  'class'   => 'form-control',
																				  );
																			   echo form_input($data);
																			   echo form_error('address');
																			  ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_locality_text'); ?>  <span class="required"> * </span></label>
                                                                               <?php
																					$fields = array('is_active'=>'1','city_id'=>$this->session->userdata('city_id'));
																					$locality_array = gettabledropdown('locality',$fields,'locality_id','locality_name','locality_name','ASC');
																					$selected = ($this->input->post('locality_id')) ? $this->input->post('locality_id') : $this->input->post('locality_id');
																					echo form_dropdown('locality_id', $locality_array,  $selected,'id="locality_id" class="form-control select2"  required="required"');
																					echo form_error('locality_id');
																				   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="row">
                                                                                <div class="col-md-4">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_pin_code_text'); ?> </label>
                                                                                     <?php $data = array(
                                                                                          'name'        => 'pin_code',
                                                                                          'id'          => 'pin_code',	
                                                                                          'value'       => set_value('pin_code') ? $this->input->post("pin_code") : $this->input->post("pin_code"),												
                                                                                          'maxlength'   => '8',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('pin_code');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-md-4">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_state_text'); ?> </label>
                                                                                     <?php $data = array(
                                                                                          'name'        => 'state_name',
                                                                                          'id'          => 'state_name',	
                                                                                          'value'       => set_value('state_name') ? $this->input->post("state_name") : $this->session->userdata('state_name'),												
                                                                                          'maxlength'   => '80',
                                                                                          'class'   => 'form-control',
																						  'readonly'   => true,
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('state_name');
                                                                                       ?>
                                                                                </div>
                                                                             </div>
                                                                            
                                                                            <div class="col-md-4">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_city_text'); ?> </label>
                                                                                     <?php $data = array(
                                                                                          'name'        => 'city_name',
                                                                                          'id'          => 'city_name',	
                                                                                          'value'       => set_value('city_name') ? $this->input->post("city_name") : $this->session->userdata('city_name'),												
                                                                                          'maxlength'   => '80',
                                                                                          'class'   => 'form-control',
																						  'readonly'   => true,
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('city_name');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_website_url_text'); ?> </label>
                                                                                <?php $data = array(
																				  'name'        => 'website_url',
																				  'id'          => 'website_url',	
																				  'value'       => set_value('website_url') ? $this->input->post("website_url") : $this->input->post("website_url"),																		
																				  'class'   => 'form-control',
																				  );
																			   echo form_input($data);
																			   echo form_error('website_url');
																			  ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                      
                                                                    </div>
                                                                    <!--/row-->
                                                                    
                                                                    <div class="row">
                                                                        
                                                                          <div class="col-md-3">
                                                                          <div class="form-group">
                                                                          <label><?php echo $this->lang->line('location_entry_ticket_text'); ?> <span class="required"> * </span> </label>
                                                                           <div class="md-radio-inline">
                                                                            <?php $entry_ticket_type_array = get_list_options('entry_ticket_type','ASC'); 
                                                                                  unset($entry_ticket_type_array['']);
                                                                               
                                                                               foreach($entry_ticket_type_array as $entrytypekey=>$entrytypeval){
                                                                                if($this->input->post('location_entry_ticket')==$entrytypekey)
                                                                                $selected='checked="checked"';
																				elseif($entrytypekey=='fr')
                                                                                $selected='checked="checked"';
                                                                                else
                                                                                $selected='';
                                                                             ?>
                                                                            <div class="md-radio">
                                                                             <input type="radio" value="<?php echo $entrytypekey; ?>" <?php echo $selected; ?> name="location_entry_ticket" required="required" id="location_entry_ticket<?php echo $entrytypekey; ?>" class="md-radiobtn">
                                                                                <label for="location_entry_ticket<?php echo $entrytypekey; ?>">
                                                                                    <span class="inc"></span>
                                                                                    <span class="check"></span>
                                                                                    <span class="box"></span> <?php echo $entrytypeval; ?> </label>
                                                                            </div>
                                                                            <?php } ?>
                                                                         </div>
                                                                         </div>
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="row">
                                                                                <div class="col-md-4" id="adult_fee_div_id" style="display:none;">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_adult_fee_text'); ?> <span class="required"> * </span></label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'adult_fee',
                                                                                          'id'          => 'adult_fee',	
                                                                                          'value'       => set_value('adult_fee') ? $this->input->post("adult_fee") : $this->input->post("adult_fee"),												
                                                                                          'maxlength'   => '10',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('adult_fee');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-md-4" id="child_fee_div_id" style="display:none;">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_child_fee_text'); ?> <span class="required"> * </span></label>
                                                                                      <?php $data = array(
                                                                                          'name'        => 'child_fee',
                                                                                          'id'          => 'child_fee',	
                                                                                          'value'       => set_value('child_fee') ? $this->input->post("child_fee") : $this->input->post("child_fee"),												
                                                                                          'maxlength'   => '10',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('child_fee');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-md-4" id="senior_citizen_fee_div_id" style="display:none;">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_senior_citizen_fee_text'); ?> <span class="required"> * </span></label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'senior_citizen_fee',
                                                                                          'id'          => 'senior_citizen_fee',	
                                                                                          'value'       => set_value('senior_citizen_fee') ? $this->input->post("senior_citizen_fee") : $this->input->post("senior_citizen_fee"),												
                                                                                          'maxlength'   => '10',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('senior_citizen_fee');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row-->
                                                                    
                                                                     <div class="clearfix">&nbsp;</div>
                                                                     <div class="caption">
                                                                     <i class="icon-map font-dark"></i>
                                                                     <span class="caption-subject font-dark sbold uppercase">Physical Location</span>
                                                                     </div>
                                                                     <div class="clearfix">&nbsp;</div>
                                                                    
                                                                    <div class="row">
                                                                      <div class="col-md-3">
                                                                        <button type="button" class="btn green btn-sm getLocation">Get Location</button>
                                                                     </div>
                                                                                                                                            
                                                                          <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_longitude_text'); ?> <span class="required"> * </span></label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'longitude',
                                                                                          'id'          => 'longitude',	
                                                                                          'value'       => set_value('longitude') ? $this->input->post("longitude") : $this->input->post("longitude"),												
                                                                                          'maxlength'   => '100',
                                                                                          'class'   => 'form-control long',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('longitude');
                                                                                       ?>
                                                                                </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_latitude_text'); ?> <span class="required"> * </span></label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'latitude',
                                                                                          'id'          => 'latitude',	
                                                                                          'value'       => set_value('latitude') ? $this->input->post("latitude") : $this->input->post("latitude"),												
                                                                                          'maxlength'   => '100',
                                                                                          'class'   => 'form-control lat',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('latitude');
                                                                                       ?>
                                                                                </div>
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row--> 
                                                                    
                                                                    
                                                                    <div class="row">
                                                                        
                                                                          <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_alert1_distance_text'); ?> </label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'alert1_distance',
                                                                                          'id'          => 'alert1_distance',	
                                                                                          'value'       => set_value('alert1_distance') ? $this->input->post("alert1_distance") : $this->input->post("alert1_distance"),												
                                                                                          'maxlength'   => '100',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('alert1_distance');
                                                                                       ?>
                                                                                </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_alert2_distance_text'); ?> </label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'alert2_distance',
                                                                                          'id'          => 'alert2_distance',	
                                                                                          'value'       => set_value('alert2_distance') ? $this->input->post("alert2_distance") : $this->input->post("alert2_distance"),												
                                                                                          'maxlength'   => '100',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('alert2_distance');
                                                                                       ?>
                                                                                </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_alert3_distance_text'); ?> </label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'alert3_distance',
                                                                                          'id'          => 'alert3_distance',	
                                                                                          'value'       => set_value('alert3_distance') ? $this->input->post("alert3_distance") : $this->input->post("alert3_distance"),												
                                                                                          'maxlength'   => '100',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('alert3_distance');
                                                                                       ?>
                                                                                </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_alert4_distance_text'); ?> </label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'alert4_distance',
                                                                                          'id'          => 'alert4_distance',	
                                                                                          'value'       => set_value('alert4_distance') ? $this->input->post("alert4_distance") : $this->input->post("alert4_distance"),												
                                                                                          'maxlength'   => '100',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('alert4_distance');
                                                                                       ?>
                                                                                </div>
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row-->  
                                                                    
                                                                    
                                                                    <div class="row">
                                                                        
                                                                          <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_sound_file_text'); ?> </label>
                                                                                   <?php
																					$fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					$sound_file_array = gettabledropdown('sound_files',$fields,'sound_file_id','sound_file_title','sound_file_title','ASC');
																					$selected = ($this->input->post('alert1_sound_file_id')) ? $this->input->post('alert1_sound_file_id') : $this->input->post('alert1_sound_file_id');
																					echo form_dropdown('alert1_sound_file_id', $sound_file_array,  $selected,'id="alert1_sound_file_id" class="form-control" ');
																					echo form_error('alert1_sound_file_id');
																				   ?>
                                                                                </div>
                                                                           </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_sound_file_text'); ?> </label>
                                                                                   <?php
																					$fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					$sound_file_array = gettabledropdown('sound_files',$fields,'sound_file_id','sound_file_title','sound_file_title','ASC');
																					$selected = ($this->input->post('alert2_sound_file_id')) ? $this->input->post('alert2_sound_file_id') : $this->input->post('alert2_sound_file_id');
																					echo form_dropdown('alert2_sound_file_id', $sound_file_array,  $selected,'id="alert2_sound_file_id" class="form-control" ');
																					echo form_error('alert2_sound_file_id');
																				   ?>
                                                                                </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_sound_file_text'); ?> </label>
                                                                                    <?php
																					 $fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					 $sound_file_array = gettabledropdown('sound_files',$fields,'sound_file_id','sound_file_title','sound_file_title','ASC');
																					 $selected = ($this->input->post('alert3_sound_file_id')) ? $this->input->post('alert3_sound_file_id') : $this->input->post('alert3_sound_file_id');
																					 echo form_dropdown('alert3_sound_file_id', $sound_file_array,  $selected,'id="alert3_sound_file_id" class="form-control" ');
																					 echo form_error('alert3_sound_file_id');
																				    ?>
                                                                              </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_sound_file_text'); ?> </label>
                                                                                    <?php
																					 $fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					 $sound_file_array = gettabledropdown('sound_files',$fields,'sound_file_id','sound_file_title','sound_file_title','ASC');
																					 $selected = ($this->input->post('alert4_sound_file_id')) ? $this->input->post('alert4_sound_file_id') : $this->input->post('alert4_sound_file_id');
																					 echo form_dropdown('alert4_sound_file_id', $sound_file_array,  $selected,'id="alert4_sound_file_id" class="form-control" ');
																					 echo form_error('alert4_sound_file_id');
																				    ?>
                                                                                </div>
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row-->  
                                                                    
                                                                    
                                                                    <div class="row">
                                                                        
                                                                          <div class="col-md-3">
                                                                          
                                                                             <div class="row">
                                                                                <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_north_text'); ?> </label>
                                                                                    <?php
																					 $fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					 $area_array = gettabledropdown('areas',$fields,'area_id','area_name','area_name','ASC');
																					 $selected = ($this->input->post('north_area')) ? $this->input->post('north_area') : $this->input->post('north_area');
																					 echo form_dropdown('north_area', $area_array,  $selected,'id="north_area" class="form-control" ');
																					 echo form_error('north_area');
																				     ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_north_title_text'); ?> </label>
                                                                                     <?php $data = array(
                                                                                          'name'        => 'north_area_title',
                                                                                          'id'          => 'north_area_title',	
                                                                                          'value'       => set_value('north_area_title') ? $this->input->post("north_area_title") : $this->input->post("north_area_title"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('north_area_title');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="row">
                                                                                <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_south_text'); ?> </label>
                                                                                    <?php
																					 $fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					 $area_array = gettabledropdown('areas',$fields,'area_id','area_name','area_name','ASC');
																					 $selected = ($this->input->post('south_area')) ? $this->input->post('south_area') : $this->input->post('south_area');
																					 echo form_dropdown('south_area', $area_array,  $selected,'id="south_area" class="form-control" ');
																					 echo form_error('south_area');
																				     ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_south_title_text'); ?> </label>
                                                                                     <?php $data = array(
                                                                                          'name'        => 'south_area_title',
                                                                                          'id'          => 'south_area_title',	
                                                                                          'value'       => set_value('south_area_title') ? $this->input->post("south_area_title") : $this->input->post("south_area_title"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('south_area_title');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="row">
                                                                                <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_east_text'); ?> </label>
                                                                                    <?php
																					 $fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					 $area_array = gettabledropdown('areas',$fields,'area_id','area_name','area_name','ASC');
																					 $selected = ($this->input->post('east_area')) ? $this->input->post('east_area') : $this->input->post('east_area');
																					 echo form_dropdown('east_area', $area_array,  $selected,'id="east_area" class="form-control" ');
																					 echo form_error('east_area');
																				     ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_east_title_text'); ?> </label>
                                                                                     <?php $data = array(
                                                                                          'name'        => 'east_area_title',
                                                                                          'id'          => 'east_area_title',	
                                                                                          'value'       => set_value('east_area_title') ? $this->input->post("east_area_title") : $this->input->post("east_area_title"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('east_area_title');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="row">
                                                                                <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_west_text'); ?> </label>
                                                                                    <?php
																					 $fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					 $area_array = gettabledropdown('areas',$fields,'area_id','area_name','area_name','ASC');
																					 $selected = ($this->input->post('west_area')) ? $this->input->post('west_area') : $this->input->post('west_area');
																					 echo form_dropdown('west_area', $area_array,  $selected,'id="west_area" class="form-control" ');
																					 echo form_error('west_area');
																				     ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            <div class="col-md-6">
                                                                                <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_west_title_text'); ?> </label>
                                                                                     <?php $data = array(
                                                                                          'name'        => 'west_area_title',
                                                                                          'id'          => 'west_area_title',	
                                                                                          'value'       => set_value('west_area_title') ? $this->input->post("west_area_title") : $this->input->post("west_area_title"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('west_area_title');
                                                                                       ?>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                            </div>
                                                                            
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row--> 
                                                                    
                                                                    
                                                                    <div class="row">
                                                                        
                                                                          <div class="col-md-3">
                                                                              <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_north_area_sound_text'); ?> </label>
                                                                                   <input type="file" id="north_area_sound_file" name="north_area_sound_file">
                                                                              </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                              <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_south_area_sound_text'); ?> </label>
                                                                                   <input type="file" id="south_area_sound_file" name="south_area_sound_file">
                                                                              </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_east_area_sound_text'); ?> </label>
                                                                                   <input type="file" id="east_area_sound_file" name="east_area_sound_file">
                                                                              </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                              <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_west_area_sound_text'); ?> </label>
                                                                                   <input type="file" id="west_area_sound_file" name="west_area_sound_file">
                                                                               </div>
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row-->  
                                                                     
                                                                        
                                                                  
                                                                </div>
                                                                <div class="tab-pane" id="tab_2">
                                                                    <div class="clearfix">&nbsp;</div> 
                                                                    <div class="caption">
                                                                        <i class="icon-settings font-dark"></i>
                                                                        <span class="caption-subject font-dark sbold uppercase">Icons</span>
                                                                    </div>
                                                                    <div class="clearfix">&nbsp;</div> 
                                                                    <div class="row">
                                                                        
                                                                          <div class="col-md-4">
                                                                              <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_map_icon_text'); ?> </label>
                                                                                   <input type="file" id="map_icon_file" name="map_icon_file">
                                                                               </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-4">
                                                                              <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_web_icon_text'); ?> </label>
                                                                                   <input type="file" id="web_icon_file" name="web_icon_file">
                                                                               </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-4">
                                                                             <div class="form-group">
                                                                                  <label class="control-label"><?php echo $this->lang->line('location_app_icon_text'); ?> </label>
                                                                                   <input type="file" id="app_icon_file" name="app_icon_file">
                                                                               </div>
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row-->
                                                                    
                                                                    <div class="clearfix">&nbsp;</div> 
                                                                    <div class="caption">
                                                                        <i class="icon-settings font-dark"></i>
                                                                        <span class="caption-subject font-dark sbold uppercase">Digital Media</span>
                                                                    </div>
                                                                   <div class="clearfix">&nbsp;</div> 
                                                                    <div class="row">
                                                                        
                                                                          <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-audio">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_audio_text'); ?></label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <input type="file" id="audio_file" name="audio_file" class="form-control mt-repeater-input-inline">
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-gallery">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_gallery_text'); ?></label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <input type="file" id="gallery_images" name="gallery_images" class="form-control mt-repeater-input-inline">
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-video">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_video_text'); ?></label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <?php $data = array(
                                                                                          'name'        => 'video_url',
                                                                                          'id'          => 'video_url',	
                                                                                          'value'       => set_value('video_url') ? $this->input->post("video_url") : $this->input->post("video_url"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control mt-repeater-input-inline',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('video_url');
                                                                                       ?>
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-vr">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_vr_text'); ?></label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <input type="file" id="vr_files" name="vr_files" class="form-control mt-repeater-input-inline">
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row-->
                                                                    
                                                                    
                                                                    <div class="row">
                                                                        
                                                                          <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-2dmap">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_2dmap_text'); ?></label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <input type="file" id="2dmap_file" name="2dmap_file" class="form-control mt-repeater-input-inline">
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-panorama">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_panorama_text'); ?></label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <input type="file" id="panorama_images" name="panorama_images" class="form-control mt-repeater-input-inline">
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-video360">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_video360_text'); ?></label>
                                                                                    <div class="mt-repeater-cell">
                                                                                     <?php $data = array(
                                                                                          'name'        => 'video360_url',
                                                                                          'id'          => 'video360_url',	
                                                                                          'value'       => set_value('video360_url') ? $this->input->post("video360_url") : $this->input->post("video360_url"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control mt-repeater-input-inline',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('video360_url');
                                                                                       ?>
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-vt">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_vt_text'); ?></label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <input type="file" id="vt_files" name="vt_files" class="form-control mt-repeater-input-inline">
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                       
                                                                    </div>
                                                                    <!--/row-->
                                                                    
                                                                    
                                                                </div>
                                                                <div class="tab-pane" id="tab_3">
                                                                <div class="clearfix">&nbsp;</div> 
                                                                <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Location Text</span>
                                                                 </div>
                                                                  <div class="clearfix">&nbsp;</div>    
                                                                <div class="row">
                                                                
                                                                  <div class="col-md-12">
                                                                    <div class="mt-repeater">
                                                                        <div data-repeater-list="location-section">
                                                                            <div data-repeater-item class="row">
                                                                                <div class="col-md-4">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_title_text'); ?></label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'section_title',
                                                                                          'id'          => 'section_title',	
                                                                                          'value'       => set_value('section_title') ? $this->input->post("section_title") : $this->input->post("section_title"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control mt-repeater-input-inline',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('section_title');
                                                                                       ?>
                                                                                   </div>
                                                                                <div class="col-md-4">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_description_text'); ?></label>
                                                                                 <?php $data = array(
																					  'name'        => 'section_description',
																					  'id'          => 'section_description',	
																					  'value'       => set_value('section_description') ? $this->input->post("section_description") : $this->input->post("section_description"),																		
																					  'class'   => 'form-control',
																					  'rows'   => '2',	
																					  );
																				   echo form_textarea($data);
																				   echo form_error('section_description');
																				  ?>
                                                                                </div>
                                                                                    
                                                                                <!--<div class="col-md-2">
                                                                                    <label class="control-label"><?php //echo $this->lang->line('location_quiz_text'); ?></label>
                                                                                   <div class="md-checkbox-list">
                                                                                    <div class="md-checkbox">
                                                                                        <input type="checkbox" id="quiz_options" name="quiz_options" class="md-check">
                                                                                        <label for="quiz_options">
                                                                                            <span></span>
                                                                                            <span class="check"></span>
                                                                                            <span class="box"></span>  </label>
                                                                                    </div>
                                                                                  </div>
                                                                               </div>-->
                                                                               
                                                                                <div class="col-md-2">
                                                                                    <label class="control-label">&nbsp;</label>
                                                                                    <a href="javascript:;" data-repeater-delete class="btn btn-danger">
                                                                                        <i class="fa fa-close"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        <hr>
                                                                        <a href="javascript:;" data-repeater-create class="btn btn-sm btn-sm btn-success mt-repeater-add">
                                                                            <i class="fa fa-plus"></i> Add more</a>
                                                                        <br>
                                                                        <br> </div>
                                                                </div>
                                                                
                                                                </div>
                                                                 <!--/row-->
                                                            
                                                                </div> 
                                                                
                                                                <div class="tab-pane" id="tab_4">
                                                                 <div class="clearfix">&nbsp;</div>
                                                                 <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Washroom</span>
                                                                 </div>
                                                                  <div class="clearfix">&nbsp;</div>
                                                                     
                                                                <div class="row">
                                                                
                                                                  <div class="col-md-12">
                                                                    <div class="mt-repeater">
                                                                        <div data-repeater-list="washroom-group">
                                                                            <div data-repeater-item class="row">
                                                                                <div class="col-md-1">
                                                                                    <label class="control-label"><?php echo $this->lang->line('location_availability_text'); ?></label>
                                                                                     <?php $washroom_availability_array =  get_list_options('washroom_availability','ASC'); 
																					   unset($washroom_availability_array['']);
																					   $x=0;
																		   		       foreach($washroom_availability_array as $washroomkey=>$washroomval){
																					   if($this->input->post('washroom_availability')==$washroomkey)
																						$selected='checked="checked"';
																						else
																						$selected='';
																						$x++;
																						if($x=='1')
																						$inline_class ='inline';
																						else
																						$inline_class ='';
																					 ?>
                                                                                    <div class="md-checkbox-<?php echo $inline_class; ?>">
                                                                                    <div class="md-checkbox">
                                                                                        <input type="checkbox" value="<?php echo $washroomkey; ?>" <?php echo $selected; ?> id="washroom_availability<?php echo $washroomkey; ?>" name="washroom_availability" class="md-check">
                                                                                        <label for="washroom_availability<?php echo $washroomkey; ?>">
                                                                                            <span></span>
                                                                                            <span class="check"></span>
                                                                                            <span class="box"></span> <?php echo $washroomval; ?> </label>
                                                                                    </div>
                                                                                </div>
                                                                                <?php } ?>
                                                                                
                                                                                 </div>
                                                                                 
                                                                                <div class="col-md-2">
                                                                              
                                                                                   <label class="control-label"><?php echo $this->lang->line('location_map_location_text'); ?></label>
                                                                                   <button type="button" class="btn green btn-sm getLocation">Get Location</button>
																				 <?php /*$data = array(
                                                                                      'name'        => 'washroom_map_location',
                                                                                      'id'          => 'washroom_map_location',	
                                                                                      'value'       => set_value('washroom_map_location') ? $this->input->post("washroom_map_location") : $this->input->post("washroom_map_location"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('washroom_map_location');*/
                                                                                   ?>
                                                                                </div>
                                                                                    
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_longitude_text'); ?></label>
																				 <?php $data = array(
                                                                                      'name'        => 'washroom_longitude',
                                                                                      'id'          => 'washroom_longitude',	
                                                                                      'value'       => set_value('washroom_longitude') ? $this->input->post("washroom_longitude") : $this->input->post("washroom_longitude"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control long',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('washroom_longitude');
                                                                                   ?>
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_latitude_text'); ?></label>
																				 <?php $data = array(
                                                                                      'name'        => 'washroom_latitude',
                                                                                      'id'          => 'washroom_latitude',	
                                                                                      'value'       => set_value('washroom_latitude') ? $this->input->post("washroom_latitude") : $this->input->post("washroom_latitude"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control lat',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('washroom_latitude');
                                                                                   ?>
                                                                                </div>
                                                                                
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_washroom_images_text'); ?></label>
																				  <input type="file" id="washroom_images" name="washroom_images" class="form-control">
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_washroom_2dmap_text'); ?></label>
																				  <input type="file" id="washroom_2dmap" name="washroom_2dmap" class="form-control">
                                                                                </div>
                                                                               
                                                                                <div class="col-md-1">
                                                                                    <label class="control-label">&nbsp;</label>
                                                                                    <a href="javascript:;" data-repeater-delete class="btn btn-danger">
                                                                                        <i class="fa fa-close"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        <hr>
                                                                        <!--<a href="javascript:;" data-repeater-create class="btn btn-sm btn-sm btn-success mt-repeater-add">
                                                                            <i class="fa fa-plus"></i> Add more</a>
                                                                        <br>
                                                                        <br>--> </div>
                                                                </div>
                                                                
                                                                </div>
                                                                 <!--/row-->
                                                                 
                                                                 <hr>
                                                                 
                                                                 <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Parking</span>
                                                                 </div>
                                                                 <div class="clearfix">&nbsp;</div>   
                                                                
                                                                      
                                                                <div class="row">
                                                                
                                                                  <div class="col-md-12">
                                                                    <div class="mt-repeater">
                                                                        <div data-repeater-list="parking-group">
                                                                            <div data-repeater-item class="row">
                                                                            
                                                                                <div class="col-md-1">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_map_location_text'); ?></label>
                                                                                 <button type="button" class="btn green btn-sm getLocation">Get Location</button>
																				 <?php /*$data = array(
                                                                                      'name'        => 'parking_map_location',
                                                                                      'id'          => 'parking_map_location',	
                                                                                      'value'       => set_value('parking_map_location') ? $this->input->post("parking_map_location") : $this->input->post("parking_map_location"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('parking_map_location');*/
                                                                                   ?>
                                                                                </div>
                                                                                 
                                                                                <div class="col-md-1">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_longitude_text'); ?></label>
																				 <?php $data = array(
                                                                                      'name'        => 'parking_longitude',
                                                                                      'id'          => 'parking_longitude',	
                                                                                      'value'       => set_value('parking_longitude') ? $this->input->post("parking_longitude") : $this->input->post("parking_longitude"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control long',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('parking_longitude');
                                                                                   ?>
                                                                                </div>
                                                                                
                                                                                <div class="col-md-1">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_latitude_text'); ?></label>
																				 <?php $data = array(
                                                                                      'name'        => 'parking_latitude',
                                                                                      'id'          => 'parking_latitude',	
                                                                                      'value'       => set_value('parking_latitude') ? $this->input->post("parking_latitude") : $this->input->post("parking_latitude"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control lat',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('parking_latitude');
                                                                                   ?>
                                                                                </div>
                                                                                
                                                                                    
                                                                                <div class="col-md-2">
                                                                                <label class="control-label"><?php echo $this->lang->line('location_parking_ticket_text'); ?></label>
                                                                                <div class="md-radio-inline">
                                                                                    <?php $entry_ticket_type_array =  get_list_options('entry_ticket_type','ASC'); 
                                                                                       unset($entry_ticket_type_array['']);
                                                                                       
                                                                                       foreach($entry_ticket_type_array as $entrytypekey=>$entrytypeval){
                                                                                        if($this->input->post('parking_entry_ticket')==$entrytypekey)
                                                                                        $selected='checked="checked"';
                                                                                        elseif($entrytypekey=='fr')
                                                                                        $selected='checked="checked"';
                                                                                        else
                                                                                        $selected='';
                                                                                     ?>
                                                                                     <div class="md-radio1">
                                                                                     <input type="radio" value="<?php echo $entrytypekey; ?>" <?php echo $selected; ?> name="parking_entry_ticket" id="parking_entry_ticket<?php echo $entrytypekey; ?>" class="md-radiobtn parkingentryticket">
                                                                                        <label for="parking_entry_ticket<?php echo $entrytypekey; ?>">
                                                                                            <span class="inc"></span>
                                                                                            <span class="check"></span>
                                                                                            <span class="box"></span> <?php echo $entrytypeval; ?> </label>
                                                                                    </div>
                                                                                    
                                                                                    <!--<div class="md-radio">
                                                                                     <input type="radio" value="<?php echo $entrytypekey; ?>" <?php echo $selected; ?> name="parking_entry_ticket" id="parking_entry_ticket<?php echo $entrytypekey; ?>" class="md-radiobtn parkingentryticket">
                                                                                        <label for="parking_entry_ticket<?php echo $entrytypekey; ?>">
                                                                                            <span class="inc"></span>
                                                                                            <span class="check"></span>
                                                                                            <span class="box"></span> <?php echo $entrytypeval; ?> </label>
                                                                                    </div>-->
                                                                                    <?php } ?>
                                                                                 </div> 
                                                                                 
                                                                                 </div>
                                                                                 
                                                                                 
                                                                                 <div class="col-md-2" id="parking_fees_amt_div_id" style="display:none;">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_parking_fees_text'); ?></label>
																				 <?php $data = array(
                                                                                       'name'        => 'parking_fees_amt',
                                                                                       'id'          => 'parking_fees_amt',	
                                                                                       'value'       => set_value('parking_fees_amt') ? $this->input->post("parking_fees_amt") : $this->input->post("parking_fees_amt"),												
                                                                                       'maxlength'   => '10',
                                                                                       'class'   => 'form-control',
                                                                                       );
                                                                                      echo form_input($data);
                                                                                      echo form_error('parking_fees_amt');
                                                                                   ?>
                                                                                </div>                                                                             
                                                                                 
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_washroom_images_text'); ?></label>
																				  <input type="file" id="parking_images" name="parking_images" class="form-control">
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_washroom_2dmap_text'); ?></label>
																				  <input type="file" id="parking_2dmap" name="parking_2dmap" class="form-control">
                                                                                </div>
                                                                                
                                                                             
                                                                                <div class="col-md-1">
                                                                                    <label class="control-label">&nbsp;</label>
                                                                                    <a href="javascript:;" data-repeater-delete class="btn btn-danger">
                                                                                        <i class="fa fa-close"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        <hr>
                                                                        <a href="javascript:;" data-repeater-create class="btn btn-sm btn-sm btn-success mt-repeater-add">
                                                                            <i class="fa fa-plus"></i> Add more</a>
                                                                        <br>
                                                                        <br> </div>
                                                                </div>
                                                                
                                                                </div>
                                                                 <!--/row-->
                                                                 
                                                                 
                                                                 
                                                                 <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Dispensary</span>
                                                                 </div>
                                                                 <div class="clearfix">&nbsp;</div>   
                                                                      
                                                                <div class="row">
                                                                
                                                                  <div class="col-md-12">
                                                                    <div class="mt-repeater">
                                                                        <div data-repeater-list="group-dispensary">
                                                                            <div data-repeater-item class="row">
                                                                            
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_map_location_text'); ?></label>
                                                                                 <button type="button" class="btn green btn-sm getLocation">Get Location</button>
																				 <?php /*$data = array(
                                                                                      'name'        => 'dispensary_map_location',
                                                                                      'id'          => 'dispensary_map_location',	
                                                                                      'value'       => set_value('dispensary_map_location') ? $this->input->post("dispensary_map_location") : $this->input->post("dispensary_map_location"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('dispensary_map_location');*/
                                                                                   ?>
                                                                                </div>
                                                                                 
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_longitude_text'); ?></label>
																				 <?php $data = array(
                                                                                      'name'        => 'dispensary_longitude',
                                                                                      'id'          => 'dispensary_longitude',	
                                                                                      'value'       => set_value('dispensary_longitude') ? $this->input->post("dispensary_longitude") : $this->input->post("dispensary_longitude"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control long',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('dispensary_longitude');
                                                                                   ?>
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_latitude_text'); ?></label>
																				 <?php $data = array(
                                                                                      'name'        => 'dispensary_latitude',
                                                                                      'id'          => 'dispensary_latitude',	
                                                                                      'value'       => set_value('dispensary_latitude') ? $this->input->post("dispensary_latitude") : $this->input->post("dispensary_latitude"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control lat',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('dispensary_latitude');
                                                                                   ?>
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_dispensary_images_text'); ?></label>
																				  <input type="file" id="dispensary_images" name="dispensary_images" class="form-control">
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_dispensary_2dmap_text'); ?></label>
																				  <input type="file" id="dispensary_2dmap" name="dispensary_2dmap" class="form-control">
                                                                                </div>
                                                                             
                                                                                <div class="col-md-2">
                                                                                    <label class="control-label">&nbsp;</label>
                                                                                    <a href="javascript:;" data-repeater-delete class="btn btn-danger">
                                                                                        <i class="fa fa-close"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        <hr>
                                                                        <a href="javascript:;" data-repeater-create class="btn btn-sm btn-sm btn-success mt-repeater-add">
                                                                            <i class="fa fa-plus"></i> Add more</a>
                                                                        <br>
                                                                        <br> </div>
                                                                </div>
                                                                
                                                                </div>
                                                                 <!--/row-->
                                                                 <div class="clearfix">&nbsp;</div> 
                                                                 
                                                                 
                                                                 <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Police Booth</span>
                                                                 </div>
                                                                 <div class="clearfix">&nbsp;</div> 
                                                                     
                                                                <div class="row">
                                                                
                                                                  <div class="col-md-12">
                                                                    <div class="mt-repeater">
                                                                        <div data-repeater-list="group-police-booth">
                                                                            <div data-repeater-item class="row">
                                                                            
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_map_location_text'); ?></label>
                                                                                 <button type="button" class="btn green btn-sm getLocation">Get Location</button>
																				 <?php /*$data = array(
                                                                                      'name'        => 'police_booth_map_location',
                                                                                      'id'          => 'police_booth_map_location',	
                                                                                      'value'       => set_value('police_booth_map_location') ? $this->input->post("police_booth_map_location") : $this->input->post("police_booth_map_location"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('police_booth_map_location');*/
                                                                                   ?>
                                                                                </div>
                                                                                 
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_longitude_text'); ?></label>
																				 <?php $data = array(
                                                                                      'name'        => 'police_booth_longitude',
                                                                                      'id'          => 'police_booth_longitude',	
                                                                                      'value'       => set_value('police_booth_longitude') ? $this->input->post("police_booth_longitude") : $this->input->post("police_booth_longitude"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control long',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('police_booth_longitude');
                                                                                   ?>
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_latitude_text'); ?></label>
																				 <?php $data = array(
                                                                                      'name'        => 'police_booth_latitude',
                                                                                      'id'          => 'police_booth_latitude',	
                                                                                      'value'       => set_value('police_booth_latitude') ? $this->input->post("police_booth_latitude") : $this->input->post("police_booth_latitude"),												
                                                                                      'maxlength'   => '255',
                                                                                      'class'   => 'form-control lat',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('police_booth_latitude');
                                                                                   ?>
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_policebooth_images_text'); ?></label>
																				  <input type="file" id="police_booth_images" name="police_booth_images" class="form-control">
                                                                                </div>
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label"><?php echo $this->lang->line('location_policebooth_2dmap_text'); ?></label>
																				  <input type="file" id="police_booth_2dmap" name="police_booth_2dmap" class="form-control">
                                                                                </div>
                                                                             
                                                                                <div class="col-md-2">
                                                                                    <label class="control-label">&nbsp;</label>
                                                                                    <a href="javascript:;" data-repeater-delete class="btn btn-danger">
                                                                                        <i class="fa fa-close"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        <hr>
                                                                        <a href="javascript:;" data-repeater-create class="btn btn-sm btn-sm btn-success mt-repeater-add">
                                                                            <i class="fa fa-plus"></i> Add more</a>
                                                                        <br>
                                                                        <br> </div>
                                                                </div>
                                                                
                                                                </div>
                                                                 <!--/row-->
                                                                 
                                                            
                                                                </div>
                                                                
                                                                
                                                                <div class="tab-pane" id="tab_5">
                                                                 <div class="clearfix">&nbsp;</div> 
                                                                 <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Distances & Timings</span>
                                                                 </div>
                                                                 
                                                                <div class="clearfix">&nbsp;</div> 
                                                                     
                                                                <div class="row">
                                                                       
                                                                       <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_airport_distance_text'); ?> </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'airport_distance',
                                                                                      'id'          => 'airport_distance',	
                                                                                      'value'       => set_value('airport_distance') ? $this->input->post("airport_distance") : $this->input->post("airport_distance"),												
                                                                                      'maxlength'   => '10',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('airport_distance');
                                                                                   ?>
                                                                                  <?php echo $this->lang->line('location_distance_km_text'); ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_railway_station_distance_text'); ?> </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'railway_station_distance',
                                                                                      'id'          => 'railway_station_distance',	
                                                                                      'value'       => set_value('railway_station_distance') ? $this->input->post("railway_station_distance") : $this->input->post("railway_station_distance"),												
                                                                                      'maxlength'   => '10',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('railway_station_distance');
                                                                                   ?>
                                                                                   <?php echo $this->lang->line('location_distance_km_text'); ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_bus_stand_distance_text'); ?> </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'bus_stand_distance',
                                                                                      'id'          => 'bus_stand_distance',	
                                                                                      'value'       => set_value('bus_stand_distance') ? $this->input->post("bus_stand_distance") : $this->input->post("bus_stand_distance"),												
                                                                                      'maxlength'   => '10',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('bus_stand_distance');
                                                                                   ?>
                                                                                   <?php echo $this->lang->line('location_distance_km_text'); ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_city_centre_distance_text'); ?> </label>
                                                                              <?php $data = array(
																				  'name'        => 'city_centre_distance',
																				  'id'          => 'city_centre_distance',	
																				  'value'       => set_value('city_centre_distance') ? $this->input->post("city_centre_distance") : $this->input->post("city_centre_distance"),																		
																				  'class'   => 'form-control',
																				  'maxlength'   => '10',
																				  );
																			   echo form_input($data);
																			   echo form_error('city_centre_distance');
																			  ?>
                                                                              <?php echo $this->lang->line('location_distance_km_text'); ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                          <div class="form-group">
                                                                          <label><?php echo $this->lang->line('location_wifi_avail_text'); ?> <span class="required"> * </span> </label>
                                                                           <div class="md-radio-inline">
                                                                            <?php $yesno_array =  get_list_options('yesno','ASC'); 
                                                                               unset($yesno_array['']);
                                                                               
                                                                            foreach($yesno_array as $wifikey=>$wifival){
                                                                                if($this->input->post('wifi_availability')==$wifikey)
                                                                                $selected='checked="checked"';
																				elseif($wifikey=='no')
                                                                                $selected='checked="checked"';
                                                                                else
                                                                                $selected='';
                                                                             ?>
                                                                            <div class="md-radio">
                                                                             <input type="radio" value="<?php echo $wifikey; ?>" <?php echo $selected; ?> name="wifi_availability" id="wifi_availability<?php echo $wifikey; ?>" class="md-radiobtn">
                                                                                <label for="wifi_availability<?php echo $wifikey; ?>">
                                                                                    <span class="inc"></span>
                                                                                    <span class="check"></span>
                                                                                    <span class="box"></span> <?php echo $wifival; ?> </label>
                                                                            </div>
                                                                            <?php } ?>
                                                                         </div>
                                                                         </div>
                                                                            
                                                                        </div>
                                                                        
                                                                  </div>
                                                            
                                                                 <!--/row-->
                                                                 
                                                                 
                                                                 <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Opening Closing/Times</span>
                                                                 </div>
                                                                 
                                                                  <div class="clearfix">&nbsp;</div> 
                                                                  <div class="row">
                                                                      <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_timing_hours_text'); ?> </label>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_timing_available_text'); ?> </label>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_timing_starttime_text'); ?> </label>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_timing_closetime_text'); ?> </label>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                     </div>   
                                                                        
                                                                   <?php 
                                                                    $week_days_array = get_list_options('week_days','ASC'); 
																    unset($week_days_array['']);
																    foreach($week_days_array as $weekdayskey=>$weekdaysval){
																	?>
																  
                                                                    <div class="row">
                                                                       
                                                                       <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <?php echo $weekdaysval; ?>
                                                                              <input type="hidden" name="week_days[]" id="week_days" value="<?php echo $weekdayskey; ?>">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                               <input type="checkbox" data-on-text="Open" data-off-text="Closed"  class="make-switch" id="availability" name="availability[]" value="<?php echo $weekdayskey; ?>" data-size="small">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                                <input type="text" name="starttime[]" id="starttime" class="form-control timepicker timepicker-no-seconds" value="9:30 AM">
                                                                                 <span class="input-group-btn">
                                                                                <button class="btn default" type="button">
                                                                                    <i class="fa fa-clock-o"></i>
                                                                                </button>
                                                                            </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                                <input type="text" name="closetime[]" id="closetime" class="form-control timepicker timepicker-no-seconds" value="6:00 PM">
                                                                                 <span class="input-group-btn">
                                                                                <button class="btn default" type="button">
                                                                                    <i class="fa fa-clock-o"></i>
                                                                                </button>
                                                                            </span>
                                                                            </div>
                                                                        </div>
                                                                         
                                                                  </div>
                                                                  <?php } ?>
                                                                  
                                                                  
                                                                  <div class="clearfix">&nbsp;</div> 
                                                                <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Rules & Regulations</span>
                                                                 </div>
                                                                 
                                                                <div class="clearfix">&nbsp;</div> 
                                                                     
                                                                <div class="row">
                                                                       
                                                                       <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_rules_regulations_text'); ?> </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'rules_regulations',
                                                                                      'id'          => 'rules_regulations',	
                                                                                      'value'       => set_value('rules_regulations') ? $this->input->post("rules_regulations") : $this->input->post("rules_regulations"),												
                                                                                      'class'   => 'form-control',
																					  'rows'   => '4',	
                                                                                      );
                                                                                    echo form_textarea($data);
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_visitors_in_month_text'); ?> </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'visitors_in_month',
                                                                                      'id'          => 'visitors_in_month',	
                                                                                      'value'       => set_value('visitors_in_month') ? $this->input->post("visitors_in_month") : $this->input->post("visitors_in_month"),												
                                                                                      'class'   => 'form-control',
																					  'maxlength'   => '255',
																					  );
                                                                                    echo form_input($data);
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_location_review_text'); ?> </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'location_review',
                                                                                      'id'          => 'location_review',	
                                                                                      'value'       => set_value('location_review') ? $this->input->post("location_review") : $this->input->post("location_review"),												
                                                                                      'class'   => 'form-control',
																					  'rows'   => '4',
                                                                                      );
                                                                                    echo form_textarea($data);
                                                                                    echo form_error('location_review');
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label"><?php echo $this->lang->line('location_surveyor_remarks_text'); ?> </label>
                                                                              <?php $data = array(
																				  'name'        => 'surveyor_remarks',
																				  'id'          => 'surveyor_remarks',	
																				  'value'       => set_value('surveyor_remarks') ? $this->input->post("surveyor_remarks") : $this->input->post("surveyor_remarks"),																		
																				  'class'   => 'form-control',
																				  'rows'   => '4',
																				  );
																			   echo form_textarea($data);
																			   echo form_error('surveyor_remarks');
																			  ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                  </div>
                                                            
                                                                 <!--/row-->
                                                                 
                                                                 
                                                             
                                                                </div>
                                                                
                                                                
                                                                 
                                                               
                                                               </div>
                                                               
                                                               
                                                        </div>
                                                        
                                                    </div>
                                                </div>
												<div class="row">
                                                <div class="col-md-offset-8 col-md-4">
                                                    <button type="submit" id="submit_btn" class="btn green" value="Submit"><?php echo $this->lang->line('form_submit_text'); ?></button>&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <input type="reset" class="btn default" name="Reset" value="<?php echo $this->lang->line('form_reset_text'); ?>">
                                                </div>
                                            </div>
                                            </div>
                                          <?php echo form_close(); ?>  
                                        </div>
                                    </div>
                                    <!-- END PAGE CONTENT INNER -->
                                </div>
                            </div>
                            <!-- END PAGE CONTENT BODY -->
                            <!-- END CONTENT BODY -->
                        </div>
                        <!-- END CONTENT -->
                        <!-- BEGIN QUICK SIDEBAR -->
						<?php if(!$mobile){ ?>
                        <?php $this->load->view("includes/sidebar.php");?>
						<?php } ?>
                        <!-- END QUICK SIDEBAR -->
                    </div>
                    <!-- END CONTAINER -->
                </div>
            </div>
			<?php if(!$mobile){ ?>
                      <?php $this->load->view("includes/footer.php");?>
			<?php } ?>
           
        </div>
        <!-- BEGIN QUICK NAV -->
        <?php $this->load->view("includes/quicknav.php");?>
        
        <!-- <script src="<?php echo base_url();?>assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <!--<script src="<?php echo base_url();?>assets/global/plugins/moment.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/clockface/js/clockface.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <!--<script src="<?php echo base_url();?>assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <!--<script src="<?php echo base_url();?>assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <!--<script src="<?php echo base_url();?>assets/layouts/layout3/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/layout3/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>-->
        
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
        <script src="<?php echo base_url();?>assets/global/plugins/respond.min.js"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/excanvas.min.js"></script> 
        <script src="<?php echo base_url();?>assets/global/plugins/ie8.fix.min.js"></script> 
        <![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
         <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-repeater/jquery.repeater.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js" type="text/javascript"></script>
        
        <script src="<?php echo base_url();?>assets/global/plugins/moment.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/clockface/js/clockface.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
       
        <script src="<?php echo base_url();?>assets/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/scripts/app.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/pages/scripts/components-select2.min.js" type="text/javascript"></script>
        
        <script src="<?php echo base_url();?>assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <!-- END THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assets/pages/scripts/form-repeater.min.js" type="text/javascript"></script>
        
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo base_url();?>assets/layouts/layout3/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/layout3/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/pages/js/custom.js" type="text/javascript"></script>
         <script type="text/javascript">
		var path = '<?php echo base_url();?>';
		</script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <script>
		$(document).ready(function(){
			
		$('#category_type_id').bind('change', function () {
			var category_type_id=$(this).val();
			var category_id=$("#category_id").val();
			if(category_type_id === null){ 
				var category_type_id=<?php echo $category_type_id; ?>;
			}
			get_categorylist(category_type_id,<?php echo $category_id; ?>);
			
		});
		$('#category_type_id').trigger('change');
		
		  $("input[type='radio']").click(function(){
            var location_entry_ticket = $("input[name='location_entry_ticket']:checked").val();
			if(location_entry_ticket=='pa'){
		 	 $('#adult_fee_div_id').show();
		 	 $('#child_fee_div_id').show();
 		 	 $('#senior_citizen_fee_div_id').show();
            }
			else{
		 	 $('#adult_fee_div_id').hide();
		 	 $('#child_fee_div_id').hide();
			 $('#senior_citizen_fee_div_id').hide();
            }
          });
		
		 $("input[type='radio'].parkingentryticket").click(function() {
			if($(this).is(':checked')) {
				if ($(this).val() == 'paid') {
					$('#parking_fees_amt_div_id').show();
				}
				else if ($(this).val() == 'free') {
					$('#parking_fees_amt_div_id').hide();
				}
				else{
					('#parking_fees_amt_div_id').hide();
				}
			}
		  });
		  
		  
		  $(document).on( "click", '.getLocation',function() {
			  longitude=$(this).parent().siblings().find(".long");
			  latitude=$(this).parent().siblings().find(".lat");
				if(navigator.geolocation) {
					navigator.geolocation.getCurrentPosition(function(position) {
						//document.getElementById(latitude).value  = position.coords.latitude;
						latitude.val(position.coords.latitude);
						longitude.val(position.coords.longitude);
						//document.getElementById(longitude).value  = position.coords.longitude;
					});
				} else {
					alert("Sorry, your browser does not support HTML5 geolocation.");
				}
		  });
		  
		  

	    });
       </script>
    </body>

</html>