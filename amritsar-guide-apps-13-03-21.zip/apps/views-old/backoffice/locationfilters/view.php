<!DOCTYPE html>

<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->

    <head>
        <meta charset="utf-8" />
       <title><?php echo $this->lang->line('text_title_header'); ?></title>
        <?php $this->load->view("includes/styles.php");?></head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                    <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
                        <!-- BEGIN CONTENT -->
                        <div class="page-content-wrapper">
                            <!-- BEGIN CONTENT BODY -->
                            <!-- BEGIN PAGE HEAD-->
                            <div class="page-head">
                                <div class="container">
                                    <!-- BEGIN PAGE TITLE -->
                                    <div class="page-title">
                                        <h1><?php echo $main_heading; ?></h1>
                                    </div>
                                    <!-- END PAGE TITLE -->
                                    <!-- BEGIN PAGE TOOLBAR -->
                                    <?php $this->load->view("includes/toolbar.php");?>
                                    <!-- END PAGE TOOLBAR -->
                                </div>
                            </div>
                            <!-- END PAGE HEAD-->
                            <!-- BEGIN PAGE CONTENT BODY -->
                            <div class="page-content">
                                <div class="container">
                                    <!-- BEGIN PAGE BREADCRUMBS -->
                                    <div class="row margin-bottom-10">
                                    <div class="col-md-8">
                                      <ul class="page-breadcrumb breadcrumb">
                                        <li> <a href="<?php echo base_url();?>backoffice/dashboard"><?php echo $this->lang->line('dashboard_text'); ?></a> <i class="fa fa-circle"></i> </li>
                                        <li> <a href="<?php echo base_url(); ?>backoffice/locationfilters/view"> <?php echo $main_heading; ?></a><i class="fa fa-circle"></i> </li>
                                        <li> <span><?php echo $heading; ?></span> </li>
                                      </ul>
                                    </div>
                                    <!--<div class="col-md-4"><a href="<?php echo base_url();?>employees/locations/add" class="btn btn-circle btn-success pull-right"> <i class="fa fa-plus"></i><span class="hidden-xs"> <?php //echo $this->lang->line('add_location_title'); ?></span> </a></div>-->
                                    
                                  </div>
                                    
                                    <!-- END PAGE BREADCRUMBS -->
                                    <!-- BEGIN PAGE CONTENT INNER -->
                                    <div class="page-content-inner">
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <?php $this->load->view("includes/notifications.php");?>
                                                <!-- BEGIN FILTER TABLE-->
												 <?php  $attributes = array('id' => 'form1','name' => 'form1','class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
                                                     echo form_open(base_url().'backoffice/locationfilters/view', $attributes);
                                                  ?>
                                                <div class="portlet box blue-hoki">  
                                                    <div class="portlet-title">
                                                        <div class="caption">
                                                            <i class="fa fa-search"></i>Search </div>
                                                        <div class="tools">
                                                            <a href="javascript:;" class="expand"> </a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body portlet-collapsed">
                                                        <div class="row">
                                                        
                                                        <div class="col-md-2">
                                                            <label>Category Type</label>
														<?php
                                                            $fields = array('is_active'=>'1');
                                                            $category_types_array = gettabledropdown('category_types',$fields,'category_type_id',
															'category_type','category_type','ASC');
                                                            $selected = ($this->input->post('category_type_id')) ? $this->input->post('category_type_id') : $this->input->post('category_type_id');
                                                            echo form_dropdown('category_type_id', $category_types_array,  $selected,'id="category_type_id" class="form-control form-filter input-sm select2"  ');
                                                         ?>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <label>Location</label>
                                                                <?php
                                                                    $fields = array();
                                                                    $location_array = gettabledropdown('locations',$fields,'location_id','location_name','location_name','ASC');
                                                                    $selected = ($this->input->post('location_id')) ? $this->input->post('location_id') : $this->input->post('location_id');
                                                                    echo form_dropdown('location_id', $location_array,  $selected,'id="location_id" class="form-control form-filter input-sm select2"  ');
                                                                 ?>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <label>Location name</label>
                                                                 <?php 
																     $data = array(
																	  'name'        => 'location_name',
																	  'id'          => 'location_name',	
																	  'value'       => set_value('location_name'),									
																	  'maxlength'   => '255',
																	  'class'   => 'form-control form-filter input-sm',
                                                                      );
                                                                    echo form_input($data);
                                                                    ?>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <label>Serial no.</label>
                                                                 <?php 
																     $data = array(
																	  'name'        => 'serial_no',
																	  'id'          => 'serial_no',	
																	  'value'       => set_value('serial_no'),									
																	  'maxlength'   => '80',
																	  'class'   => 'form-control form-filter input-sm',
                                                                      );
                                                                    echo form_input($data);
                                                                    ?>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <label>Status</label>
                                                                  <?php
																    $status_type_array = get_list_options('status_type','ASC'); 
                                                                    $selected = ($this->input->post('status')) ? $this->input->post('status') : $this->input->post('status');
                                                                    echo form_dropdown('status', $status_type_array,  $selected,'id="status" class="form-control form-filter input-sm"');
                                                                    ?>
                                                        </div>
                                                        
                                                        
                                                        <div class="col-md-2">
                                                            <label>Perpage</label>
                                                                    <?php
                                                                    $per_page_records = per_page_records();
                                                                    $selected = ($this->input->post('per_page')) ? $this->input->post('per_page') : $this->input->post('per_page');
                                                                    echo form_dropdown('per_page', $per_page_records,  $selected,'id="per_page" onChange="document.form1.submit();" class="form-control form-filter input-sm"');
                                                                    ?>
                                                        </div>
                                                    
                                                    </div>  
                                                        <div class="margin-top-10"><button class="btn btn-sm btn-success filter-submit margin-bottom"><i class="fa fa-search"></i> Search</button></div>
                                                    </div>
                                                </div>
                                                  <?php echo form_close(); ?>
                                                  <!-- END FILTER TABLE--> 
                          
                                                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                                                <div class="portlet box green">
                                                    <div class="portlet-title">
                                                        <div class="caption">
                                                            <i class="fa fa-users"></i><?php echo $heading; ?>: <?php echo '('.$num_rows.')'; ?>  </div>
                                                        <div class="tools"> </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div class="table-responsive">
                                               <?php  $attributes = array('id' => 'form2','name' => 'form2','class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
                                                     echo form_open(base_url().'backoffice/locationfilters/update', $attributes);
                                                  ?>
                             							 <table class="table table-bordered table-striped table-condensed flip-content">
                                                            <thead class="flip-content">
                                                                <tr>
                                                                    <th> <?php echo $this->lang->line('location_srno_column'); ?> </th>
														            <th> <?php echo $this->lang->line('location_category_type_column'); ?></th>
                                                                    <th> <?php echo $this->lang->line('location_category_column'); ?></th>
                                                                    <th> <?php echo $this->lang->line('location_location_column'); ?></th>
                                                                    <th> <?php echo $this->lang->line('location_location_short_column'); ?></th>
                                                                    <!--<th> <?php echo $this->lang->line('location_locality_column'); ?></th>-->
                                                                    
                                                                    
                                                                    <th> Manage Filters</th>                                                                   <th> <?php echo $this->lang->line('location_createdby_column'); ?></th>
                                                                    <th> <?php echo $this->lang->line('location_createdon_column'); ?></th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>	
                                                            <?php 
															  if(is_array($results))
															  {  
															     $srno = $this->uri->segment(9)? ( $this->uri->segment(9) + $this->uri->segment(10)? $this->uri->segment(10):0 ):0;
																 if($srno=='')
																 $srno=0;
																 else
																 $srno=$srno;
															 	 foreach($results as $row) {
																 $srno++;
																 
																
																 
																 $cattyperow = get_table_info('category_types','category_type_id',$row->category_type_id);
																 $createdrow = get_table_info('users','user_id',$row->created_by);
															  ?>
                                                                <tr>
                                                                    <td><?php echo $srno; ?></td>
                                                                    <td><?php echo $cattyperow->category_type; ?></td>
                                                                    <td><?php echo $row->category_name; ?></td>
                                                                    <td><?php echo $row->location_name; ?>
                                                                    <input type="hidden" name="location_id[]" id="location_id" value="<?php echo $row->location_id; ?>"></td>
                                                                    <td><?php echo $row->short_name; ?></td>
                                  				                    <!--<td><?php echo $row->locality_name; ?></td>-->
                                                                    <td> <div style="height:200px; margin-left:05px;overflow-y:scroll;"><table class="table table-bordered table-striped table-condensed">
                                                             <thead>
                                                                <tr style="font-size:11px !important;">
                                                                    <th> Srno. </th>
                                                                    <th> Category name </th>
                                                                    <th> Action </th>
                                                                </tr>
                                                            </thead>
                                                             <?php
                                                              $categoryresults = $this->locationfilters_model->get_location_categories($row->location_id);
															  /*echo "<pre>";
															  print_r($categoryresults);
															  echo "</pre>";*/
                                                              if(is_array($categoryresults))
                                                              {  $sr_no=0; 
															     $all_category_array = get_categories_list('0','1','0','0');
                                                                 foreach($categoryresults as $categoryrow) {
                                                               
															    $category_name = $all_category_array[$categoryrow->category_id];
																
																$fields =  array('is_active'=>'1','category_id'=>$categoryrow->category_id);
                                                                $filterresults =gettableresult('category_filters',$fields,$order=NULL,$group=NULL);
																$totalfilters = count($filterresults);
																//	echo "------------>".$totalfilters;
																if($totalfilters>1)
																{
																$sr_no++;	 
                                                              ?> 
                                                                <tr>
                                                                <td><?php echo $sr_no; ?></td>
                                                                <td style="font-size:11px;"><?php echo $category_name; ?>
                                                                <input type="hidden" name="<?php echo $row->location_id; ?>_category_id[]" id="category_id" value="<?php echo $categoryrow->category_id; ?>"></td>
                                                                 <td>
                                                                 
                                                                 <div style="height:80px; margin-left:05px;overflow-y:scrol; font-size:11px;">
                                                                           <div class="md-checkbox-list">
                                                                           <?php
																		 
																			if(is_array($filterresults))
																			{							
																			  	 $field = array('is_active'=>'1','category_id'=>$categoryrow->category_id,'location_id'=>$row->location_id);
                                                                  			     $defaultfilters =gettableresult('location_filters',$field,$order=NULL,$group=NULL);																	
																			     $default_filters =array();
																				 if(is_array($defaultfilters))
																				 { foreach($defaultfilters as $rrow){
																						 $default_filters[$rrow->filterid]=$rrow->filterid;
																					 }
																				 }
																				 
																			    
																				foreach($filterresults as $filterkey=> $filterrow){
																				
																				if(in_array($filterrow->filterid,$default_filters))
																				$checked='checked';
																				else
																				$checked='';
																				
																				
																				//echo "--------------->".$filterrow->filterid;
																				//$desigrow = get_table_info('designation','designation_id',$row['designation_id']);
																				
																				$filterrow= get_table_info('filters','filterid',$filterrow->filterid);
																																					  ?>
                                                                            <div class="md-checkbox">
                                                                                <input id="<?php echo $row->location_id; ?>_<?php echo $categoryrow->category_id; ?>_filter_id<?php echo $filterrow->filterid; ?>" name="<?php echo $row->location_id; ?>_<?php echo $categoryrow->category_id; ?>_filter_id[]" value="<?php echo $filterrow->filterid; ?>" <?php echo $checked; ?> class="md-check" type="checkbox">
                                                                                <label for="<?php echo $row->location_id; ?>_<?php echo $categoryrow->category_id; ?>_filter_id<?php echo $filterrow->filterid; ?>">
                                                                                    <span class="inc"></span>
                                                                                    <span class="check"></span>
                                                                                    <span class="box"></span> <?php echo $filterrow->filter_name; ?></label>
                                                                            </div>
                                                                            <?php 
                                                                              }
																			}
																		   ?>
                                                                        </div>
                                                                        </div>
                                                                 
                                                                 
                                                                 <?php ?></td>
                                                                </tr>
                                                                <?php
                                                                 } } } ?>
                                                                
                                                              
                                                                </table> </div>
                                                         </td>
                                                                    <td><?php echo $createdrow->first_name.' '.$createdrow->last_name; ?></td>
                                                                    <td><?php echo date('d M, Y',strtotime($row->created_on));?></td>
                                                                  </tr>
                                                              <?php 
																  } 
																} ?>  
                                                            </tbody>
                                                        </table>
                                                        
                                                      <div align="center"><?php if(isset($links)): echo  $links; endif; ?></div>  
                                                        
                                                   <div class="row">
                                                    <div class="col-md-offset-6 col-md-4">
                                                        <button type="submit" id="submit_btn" class="btn green" value="Submit"><?php echo $this->lang->line('form_submit_text'); ?></button>&nbsp;&nbsp;&nbsp;&nbsp;
                                                        <input type="reset" class="btn default" name="Reset" value="<?php echo $this->lang->line('form_reset_text'); ?>">
                                                    </div>
                                                </div>
                                            
                                                         <?php echo form_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- END EXAMPLE TABLE PORTLET-->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- END PAGE CONTENT INNER -->
                                </div>
                            </div>
                            <!-- END PAGE CONTENT BODY -->
                            <!-- END CONTENT BODY -->
                        </div>
                        <!-- END CONTENT -->
                        <!-- BEGIN QUICK SIDEBAR -->
                        <?php $this->load->view("includes/sidebar.php");?>
                        <!-- END QUICK SIDEBAR -->
                    </div>
                    <!-- END CONTAINER -->
                </div>
            </div>
             <?php $this->load->view("includes/footer.php");?>
        </div>
        <!-- BEGIN QUICK NAV -->
        <?php $this->load->view("includes/quicknav.php");?>
        <!-- END QUICK NAV -->
        <?php $this->load->view("includes/scripts.php");?>
        <!-- END THEME LAYOUT SCRIPTS -->
        
    </body>

</html>