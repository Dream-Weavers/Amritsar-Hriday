<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo $this->lang->line('text_title_header'); ?></title>
        <?php $this->load->view("includes/styles.php");?></head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                    <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
                        <!-- BEGIN CONTENT -->
                        <div class="page-content-wrapper">
                            <!-- BEGIN CONTENT BODY -->
                            <!-- BEGIN PAGE HEAD-->
                            <div class="page-head">
                                <div class="container">
                                    <!-- BEGIN PAGE TITLE -->
                                    <div class="page-title">
                                        <h1><?php echo $main_heading; ?></h1>
                                    </div>
                                    <!-- END PAGE TITLE -->
                                    <!-- BEGIN PAGE TOOLBAR -->
                                    <?php $this->load->view("includes/toolbar.php");?>
                                    <!-- END PAGE TOOLBAR -->
                                </div>
                            </div>
                            <!-- END PAGE HEAD-->
                            <!-- BEGIN PAGE CONTENT BODY -->
                            <div class="page-content">
                                <div class="container">
                                    <!-- BEGIN PAGE BREADCRUMBS -->
                                    <ul class="page-breadcrumb breadcrumb">
                                        <li>
                                            <a href="<?php echo base_url();?>backoffice/dashboard"><?php echo $this->lang->line('dashboard_text'); ?></a>
                                            <i class="fa fa-circle"></i>
                                        </li>
                                        <li>
                                        <a href="<?php echo base_url(); ?>backoffice/masters/view_localitys">
                                            <?php echo $main_heading; ?>
                                        </a> <i class="fa fa-circle"></i> </li>
                                    <li> <span><?php echo $heading; ?></span> </li>
                                    </ul>
                                    <!-- END PAGE BREADCRUMBS -->
                                    <!-- BEGIN PAGE CONTENT INNER -->
                                    <div class="page-content-inner">
                                        <div class="row">
                                            <div class="col-md-9">
                                            
                                            <div class="portlet box green">
                                                <div class="portlet-title">
                                                    <div class="caption">
                                                        <i class="fa fa-plus-square"></i><?php echo $heading; ?> </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="row">
                                                        
                                                        <div class="col-md-12 col-sm-9 col-xs-9">
                                                        <?php  $attributes = array('id' => 'locality_form','name' => 'locality_form','class' => 'horizontal-form','role' => 'form','autocomplete' => 'off');
															     echo form_open_multipart(base_url().'backoffice/masters/edit_locality/'.$edit_data->locality_id.'/'.$edit_data->city_id.'', $attributes);
																 echo form_hidden('locality_id', $edit_data->locality_id);
																 echo form_hidden('city_id', $edit_data->city_id);
                                                          ?>
                                                         <div class="form-body">
                                                         <div class="alert alert-danger display-hide">
                                                            <button class="close" data-close="alert"></button> <?php echo $this->lang->line('form_validation_errors'); ?></div>
                                                         <div class="alert alert-success display-hide">
                                                            <button class="close" data-close="alert"></button> <?php echo $this->lang->line('form_validation_success'); ?> </div>
                                                              
														 <?php if((validation_errors()) || ($already_msg)):?>
                                                        <div class="alert alert-danger">
                                                            <button class="close" data-close="alert"></button>
                                                             <span> <?php echo common_error_msg; ?>&nbsp;<?php echo $already_msg;?></span>
                                                        </div>
                                                        <?php endif; ?>
                                                        
			                                              
                                                            <div class="row">
                                                             
                                                               <div class="col-md-6">
                                                                    <div class="form-group">
                                                                      <label class="control-label"><?php echo $this->lang->line('locality_country_text'); ?> <span class="required"> * </span></label>
                                                                     <?php
																		$fields = array('is_active'=>'1');
																		$country_array = gettabledropdown('country',$fields,'country_id','country_name','country_name','ASC');
																		$selected = ($this->input->post('country_id')) ? $this->input->post('country_id') :  $country_id;
																		echo form_dropdown('country_id', $country_array,  $selected,'id="country_id" class="form-control"  required ');
																		echo form_error('country_id');
																	   ?>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                      <label class="control-label"><?php echo $this->lang->line('locality_state_text'); ?> <span class="required"> * </span></label>
                                                                     <?php
																		$state_array = array();
																		$state_array[''] = 'Select'; 
																		$selected = "";
																		echo form_dropdown('state_id', $state_array,  $selected,'id="state_id" class="form-control"  required ');
																		echo form_error('state_id');
																	   ?>
                                                                    </div>
                                                                </div>
                                                             
                                                            </div>
                                                            <!--/row-->
                                                            
                                                            <div class="row">
                                                                 
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                      <label class="control-label"><?php echo $this->lang->line('locality_city_text'); ?> <span class="required"> * </span></label>
                                                                     <?php
																		$city_array = array();
																		$city_array[''] = 'Select'; 
																		$selected = "";
																		echo form_dropdown('city_id', $city_array,  $selected,'id="city_id" class="form-control"  required ');
																		echo form_error('city_id');
																	   ?>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label class="control-label"><?php echo $this->lang->line('locality_name_text'); ?> <span class="required"> * </span></label>
                                                                          <?php $data = array(
																			  'name'        => 'locality_name',
																			  'id'          => 'locality_name',	
																			  'value'       => set_value('locality_name') ? $this->input->post("locality_name") :  $edit_data->locality_name,												
																			  'maxlength'   => '80',
																			  'class'   => 'form-control',
																			  'required'   => 'required',
																			  );
																			echo form_input($data);
																			echo form_error('locality_name');
																		   ?>
                                                                    </div>
                                                                </div>
                                                                
                                                            </div>
                                                             <!--/row-->
                                                         
                                                          
                                                          <div class="row">
                                                            <div class="col-md-12">
                                                            <label class="col-md-2 control-label">&nbsp;&nbsp;&nbsp;&nbsp;</label>
                                                            </div>
                                                          </div>
                                                          
                                                          <!--/row-->  
                                                          
                                                         </div>
                                                            
                                                        
                                                        <div class="form-actions">
                                                            <div class="row">
                                                                <div class="col-md-offset-6 col-md-8">
                                                                    <button type="submit" id="submit_btn" class="btn green" value="Submit"><?php echo $this->lang->line('form_submit_text'); ?></button>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                    <input type="reset" class="btn default" name="Reset" value="<?php echo $this->lang->line('form_reset_text'); ?>">
                                                                </div>
                                                            </div>
                                                       </div>
                                                                    
                                                             <?php echo form_close(); ?>
                                                             <?php $this->load->view("includes/loader.php");?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                            
                                        </div>
                                        
                                    </div>
                                    <!-- END PAGE CONTENT INNER -->
                                </div>
                            </div>
                            <!-- END PAGE CONTENT BODY -->
                            <!-- END CONTENT BODY -->
                        </div>
                        <!-- END CONTENT -->
                        <!-- BEGIN QUICK SIDEBAR -->
                         <?php $this->load->view("includes/sidebar.php");?>
                        <!-- END QUICK SIDEBAR -->
                    </div>
                    <!-- END CONTAINER -->
                </div>
            </div>
            <?php $this->load->view("includes/footer.php");?>
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php $this->load->view("includes/quicknav.php");?>
        <!-- END QUICK NAV -->
       <?php $this->load->view("includes/scripts.php");?>
        <script type="text/javascript">
		 var path = '<?php echo base_url();?>';
		 </script>
         <script>
            $(document).ready(function() {
                $('#country_id').bind('change', function() {
                    var country_id = $(this).val();
                    var state_id = $("#state_id").val();
                    if (country_id === null) {
                        var country_id = '<?php echo $country_id; ?>';
                    }
                    if (state_id === null || state_id == '') {
                        var state_id = '<?php echo $state_id; ?>';
                    } else {
                        var state_id = 0;
                    }
                    get_state(country_id, state_id);
                });
                $('#country_id').trigger('change');

                $('#state_id').bind('change', function() {
                    var state_id = $(this).val();
                    var city_id = $("#city_id").val();
                    if (state_id === null) {
                        var state_id = <?php echo $state_id; ?>;
                    }
                    if (city_id === null || city_id == '') {
                        var city_id = <?php echo $city_id; ?>;
                    } else {
                        var city_id = 0;
                    }
                    get_city(state_id, city_id);

                });
                $('#state_id').trigger('change');
				
				$('#city_id').bind('change', function() {
                    var locality_id = $(this).val();
                    var locality_id = $("#locality_id").val();
                    if (city_id === null) {
                        var city_id = <?php echo $city_id; ?>;
                    }
                    if (locality_id === null || locality_id == '') {
                        var locality_id = <?php echo $locality_id; ?>;
                    } else {
                        var locality_id = 0;
                    }
                    get_locality(city_id, locality_id);
                });
                $('#city_id').trigger('change');

            });
        </script>
    </body>

</html>