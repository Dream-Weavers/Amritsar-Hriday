<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo $this->lang->line('text_title_header'); ?></title>
        <?php $this->load->view("includes/styles.php");?>
		 <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/clockface/css/clockface.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
		<style>          
          #location_map{ 
            height: 400px;    
            width: 100%;            
          } 
		         
        </style>
	</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid">
        <div class="page-wrapper">
            <div class="page-wrapper-row"> 
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                    <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
                        <!-- BEGIN CONTENT -->
                        <div class="page-content-wrapper">
                            <!-- BEGIN CONTENT BODY -->
                            <!-- BEGIN PAGE HEAD-->
                            <div class="page-head">
                                <div class="container">
                                    <!-- BEGIN PAGE TITLE -->
                                    <div class="page-title">
                                        <h1><?php echo $main_heading; ?></h1>
                                    </div>
                                    <!-- END PAGE TITLE -->
                                    <!-- BEGIN PAGE TOOLBAR -->
                                    <?php $this->load->view("includes/toolbar.php");?>
                                    <!-- END PAGE TOOLBAR -->
                                </div>
                            </div>
                            <!-- END PAGE HEAD-->
                            <!-- BEGIN PAGE CONTENT BODY -->
                            <div class="page-content">
                                <div class="container">
                                    <!-- BEGIN PAGE BREADCRUMBS -->
                                    <ul class="page-breadcrumb breadcrumb">
                                        <li>
                                            <a href="<?php echo base_url();?>backoffice/dashboard"><?php echo $this->lang->line('dashboard_text'); ?></a>
                                            <i class="fa fa-circle"></i>
                                        </li>
                                        <li>
                                        <a href="<?php echo base_url(); ?>backoffice/vendors/view">
                                            <?php echo $main_heading; ?>
                                        </a> <i class="fa fa-circle"></i> </li>
                                    <li> <span><?php echo $heading; ?></span> </li>
                                    </ul>
                                    <!-- END PAGE BREADCRUMBS -->
                                    <!-- BEGIN PAGE CONTENT INNER -->
                                    <div class="page-content-inner">
                                        <div class="row">
                                            <div class="col-md-12">
                                            
                                            <div class="portlet box green">
                                                <div class="portlet-title">
                                                    <div class="caption">
                                                        <i class="fa fa-plus-square"></i><?php echo $heading; ?> </div>
                                                </div>
                                                <div class="portlet-body">
													<div class="tabbable-custom nav-justified">
                                                            <ul class="nav nav-tabs nav-justified">
                                                                <li class="active">
                                                                    <a href="#tab_1" data-toggle="tab"> Basic Details </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#tab_2" data-toggle="tab"> Digital Media </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#tab_3" data-toggle="tab"> Distance & Timings </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#tab_4" data-toggle="tab"> Beacons </a>
                                                                </li>
																
                                                            </ul>
											 <?php  $attributes = array('id' => 'user_form','name' => 'user_form','class' => 'horizontal-form','role' => 'form','autocomplete' => 'off');
												 echo form_open_multipart(base_url().'backoffice/vendors/add', $attributes);
										   ?>
											<div class="tab-content">
												<div class="tab-pane active" id="tab_1">
                                                    <div class="row">
                                                        
                                                        <div class="col-md-12 col-sm-9 col-xs-9">
                                                         
                                                         <div class="form-body">
                                                        
														 <?php if($already_msg):?>
                                                        <div class="alert alert-danger">
                                                            <button class="close" data-close="alert"></button>
                                                             <span> <?php echo $already_msg;?></span>
                                                        </div>
                                                        <?php endif; ?>
                                                         <div class="row">
                                                         <div class="col-md-12"> <small class="pull-right"><?php echo $this->lang->line('default_pasword_text'); ?></small></div>
                                                         </div>
                                                        
			                                              
                                                            <div class="row">
                                                               <div class="col-md-4">
																	<div class="form-group">
																	 <label class="control-label">Shop Title <span class="required"> * </span></label>
																		<?php $data = array(
																		  'name'        => 'shop_title',
																		  'id'          => 'shop_title',	
																		  'value'       => set_value('shop_title'),									
																		
																		  'class'   => 'form-control',
																		  );
																		 echo form_input($data);
																		 echo form_error('shop_title');
																		 ?>
																		</div>
																</div>
                                                               <div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">First name <span class="required"> * </span></label>
                                                                         <?php $data = array(
																			  'name'        => 'first_name',
																			  'id'          => 'first_name',	
																			  'value'       => set_value('first_name') ? $this->input->post("first_name") : $this->input->post("first_name"),												
																			  'maxlength'   => '80',
																			  'class'   => 'form-control',
																			  'required'   => 'required',
																			  );
																			echo form_input($data);
																			echo form_error('first_name');
																		   ?>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">Last name<span class="required"> * </span> </label>
                                                                         <?php $data = array(
																			  'name'        => 'last_name',
																			  'id'          => 'last_name',	
																			  'value'       => set_value('last_name') ? $this->input->post("last_name") : $this->input->post("last_name"),												
																			  'maxlength'   => '80',
																			  'class'   => 'form-control',
																			  );
																			echo form_input($data);
																			echo form_error('last_name');
																		   ?>
                                                                    </div>
                                                                </div>
                                                             
                                                               
                                                                
                                                            </div>
                                                            <!--/row-->
                                                            
															
															
																	

                                                            <div class="row">
                                                                
																<div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">Email <span class="required"> * </span></label>
                                                                         <?php $data = array(
																			  'name'        => 'email',
																			  'id'          => 'email',	
																			  'value'       => set_value('email') ? $this->input->post("email") : $this->input->post("email"),												
																			  'maxlength'   => '100',
																			  'class'   => 'form-control',
																			  'required'   => 'required',
																			  'placeholder'   => $this->lang->line('user_email_placeholder_text'),
																			  'email'   => true,
																			  );
																		   echo form_input($data);
																		   echo form_error('email');
																		  ?>
                                                                    </div>
                                                                </div>
																
                                                                
                                                                
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">Password <span class="required"> * </span></label>
                                                                        <?php $data = array(
																		  'name'        => 'userpass',
																		  'id'          => 'userpass',
																		  'value'       => set_value('userpass') ? $this->input->post("userpass") : "abc123",
																		  'maxlength'   => '32',
																		  'class'   => 'form-control',
																		  'type'   => 'password',
																		  'minlength'   => '4',
																		  'required'   => 'required',
																		  'placeholder'   => $this->lang->line('user_password_placeholder_text'),
																		  );
																		  echo form_input($data);
																		  echo form_error('userpass');
																         ?>
                                                                    </div>
                                                                </div>
                                                                
                                                                
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">Confirm Password <span class="required"> * </span></label>
                                                                         <?php $data = array(
																			  'name'        => 'compass',
																			  'id'          => 'compass',
																			  'value'       => set_value('compass') ? $this->input->post("compass") : "abc123",
																			  'maxlength'   => '32',
																			  'class'   => 'form-control',
																			  'type'   => 'password',
																			  'required'   => 'required',
																			  );
																			  echo form_input($data);
																			  echo form_error('compass');
																	      ?>
                                                                    </div>
                                                                </div>
                                                             
                                                            </div>
                                                            <!--/row-->
                                                           
                                                           
                                                           
                                                            <div class="row">
                                                                
                                                                
                                                                 <div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">Country<span class="required"> * </span></label>
                                                                         <?php
																			$fields = array('is_active'=>'1');
																			$country_array = gettabledropdown('country',$fields,'country_id','country_name','country_name','ASC');
																			$selected = ($this->input->post('country_id')) ? $this->input->post('country_id') : '101';
																			echo form_dropdown('country_id', $country_array,  $selected,'id="country_id" class="form-control"  required ');
																			echo form_error('country_id');
																		   ?>
                                                                    </div>
                                                                </div>
                                                                
                                                                
                                                                <div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">State <span class="required"> * </span></label>
                                                                        <?php
																		$state_array = array();
																		$state_array[''] = 'Select'; 
																		$selected = "";
																		echo form_dropdown('state_id', $state_array,  $selected,'id="state_id" class="form-control"  required ');
																		echo form_error('state_id');
																	   ?>
                                                                    </div>
                                                                </div>
                                                             
																<div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">City <span class="required"> * </span></label>
                                                                       <?php
																		$city_array = array();
																		$city_array[''] = 'Select City'; 
																		$selected = "";
																		echo form_dropdown('city_id', $city_array,  $selected,'id="city_id" class="form-control" ');
																		echo form_error('city_id');
																	   ?>
                                                                    </div>
                                                                </div>
																
                                                            </div>
                                                            <!--/row-->
                                                            
															
															<div class="row">
                                                                <div class="form-group">
																	
																	<div class="col-md-4">
                                                                    <div class="form-group">
                                                                      <label class="control-label">Mobile <span class="required"> * </span></label>
                                                                         <?php $data = array(
																		  'name'        => 'mobile_no1',
																		  'id'          => 'mobile_no1',									
																		  'value'       => set_value('mobile_no1') ? $this->input->post("mobile_no1") : $this->input->post("mobile_no1"),												
																		  'maxlength'   => '15',
																		  'class'   => 'form-control',
																		  'required'   => 'required',
																		  );
																		 echo form_input($data);
																		 echo form_error('mobile_no1');
																		?>
                                                                    </div>
                                                                </div>
																	
																	<div class="col-md-4">
																		 <label class="control-label">Shop Address </label>
																		   <?php $data = array(
																			  'name'        => 'shop_address',
																			  'id'          => 'shop_address',	
																			  'value'       => set_value('shop_address') ? $this->input->post("shop_address") : $this->input->post("shop_address"),																		
																			  'class'   => 'form-control',
																			  'rows'   => '3',	
																			  );
																		   echo form_textarea($data);
																		   echo form_error('shop_address');
																		  ?>
																	</div>
																	
																	<div class="col-md-4">
                                                                
																	 <div class="fileinput fileinput-new" data-provides="fileinput">
																			<div class="fileinput-new thumbnail" style="width: 200px; height: 150px;" id="dvPreview">
																				<img id="preview" src="http://www.placehold.it/200x150/EFEFEF/AAAAAA&amp;text=no+image" alt="" /> </div>
																			
																			<div>
																				<span class="btn default btn-file">
																					
																					
																					<input id="user_photo" type="file" name="user_photo" class="upload"  accept="image/*"/> </span>
																			  
																			</div>
																		</div>
																		<div class="clearfix margin-top-10">
																			 <span class="label label-danger">NOTE! </span>
																			 <span> Attached image thumbnail format JPG,PNG,JPEG</span>
																		</div>	
																	 
																	</div>
																</div>
                                                            </div> 
															
                                                            <!--/row--> 
															
															
															<div class="row">
                                                                     
                                                                       <div class="col-md-4">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Category Type <span class="required"> * </span></label>
                                                                                 <?php
																					$fields = array('is_active'=>'0','language_id'=>$this->session->userdata('lang_id'),'category_type_id'=>'35');
																					$designation_array = gettabledropdown('category_types',$fields,'category_type_id','category_type','category_type','ASC');
																					$selected = ($this->input->post('category_type_id')) ? $this->input->post('category_type_id') : $this->input->post('category_type_id');
																					echo form_dropdown('category_type_id', $designation_array,  $selected,'id="category_type_id" class="form-control" required ');
																					echo form_error('category_type_id');
																				   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-4">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Category </label>
                                                                               <div  style="height:150px;  overflow-x:hidden; overflow:scroll;">
                                                                                <div class="category_list"></div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                        
                                                                  
                                                                      </div>
                                                                    <!--/row-->		
																	
                                                           <div class="row">
																<div class="col-md-12">
																	 <h3 class="form-group location_set_marker">
																		Set marker on map by clicking exact location
																	 </h3>
																	 <div class="form-group" id="location_map">
																	
																	 </div>
																	 <button type="button" class="btn green map_button col-mb-10">Proceed</button>
																</div>
																
															</div>
                                                           <div class="row">
																  <div class="col-md-1">
																	<button type="button" class="btn green btn-sm getLocation">Get Location</button>
																 </div>
																																												<div class="col-md-2">
																 <div class="form-group">
																	  <label class="control-label">Latitude</label>
																		<?php $data = array(
																			  'name'        => 'latitude',
																			  'id'          => 'latitude',	
																			  'value'       => set_value('latitude') ? $this->input->post("latitude") : $this->input->post("latitude"),												
																			  'maxlength'   => '100',
																			  'class'   => 'form-control lat',
																			  );
																			echo form_input($data);
																			echo form_error('latitude');
																		   ?>
																	</div>
																</div>
																
																<div class="col-md-2">
																 <div class="form-group">
																	  <label class="control-label">Longitude</label>
																		<?php $data = array(
																			  'name'        => 'longitude',
																			  'id'          => 'longitude',	
																			  'value'       => set_value('longitude') ? $this->input->post("longitude") : $this->input->post("longitude"),												
																			  'maxlength'   => '100',
																			  'class'   => 'form-control long',
																			  );
																			echo form_input($data);
																			echo form_error('longitude');
																		   ?>
																	</div>
																</div>
																
															</div>
															<!--/row--> 
																	
                                                         </div>
                                                            
                                                        
                                                        <div class="form-actions">
                                                            <div class="row">
                                                                <div class="col-md-offset-5 col-md-6">
                                                                    <button type="submit" id="submit_btn" class="btn green" value="Submit">Submit</button>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                    <input type="reset" class="btn default" name="Reset" value="Reset">
                                                                </div>
                                                            </div>
                                                       </div>
                                                                    
                                                           
                                                             <?php $this->load->view("includes/loader.php");?>
                                                        </div>
                                                    </div>
												</div>
												<div class="tab-pane" id="tab_2">
                                                                    <div class="clearfix">&nbsp;</div> 
                                                                    
                                                                    
                                                                    <div class="clearfix">&nbsp;</div> 
                                                                    <div class="caption">
                                                                        <i class="icon-settings font-dark"></i>
                                                                        <span class="caption-subject font-dark sbold uppercase">Digital Media</span>
                                                                    </div>
                                                                   <div class="clearfix">&nbsp;</div> 
                                                                    <div class="row">
                                                                        
                                                                          
                                                                        
                                                                        <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-gallery">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label">Images</label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <input type="file" id="gallery_images" name="gallery_images" class="form-control mt-repeater-input-inline">
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                           <div class="form-group mt-repeater">
                                                                            <div data-repeater-list="digital-video">
                                                                                <div data-repeater-item class="mt-repeater-item mt-overflow">
                                                                                    <label class="control-label">Videos</label>
                                                                                    <div class="mt-repeater-cell">
                                                                                    <?php $data = array(
                                                                                          'name'        => 'video_url',
                                                                                          'id'          => 'video_url',	
                                                                                          'value'       => set_value('video_url') ? $this->input->post("video_url") : $this->input->post("video_url"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control mt-repeater-input-inline',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('video_url');
                                                                                       ?>
                                                                                        <a href="javascript:;" data-repeater-delete class="btn btn-danger mt-repeater-delete mt-repeater-del-right mt-repeater-btn-inline">
                                                                                            <i class="fa fa-close"></i>
                                                                                        </a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <a href="javascript:;" data-repeater-create class="btn btn-sm btn-success mt-repeater-add">
                                                                                <i class="fa fa-plus"></i> Add more</a>
                                                                        </div>
                                                            
                                                                            
                                                                        </div>
                                                                        
                                                                        
                                                                       
                                                                    </div>
                                                                    <!--/row-->
                                                                    
                                                                    
                                                                    
                                                                    
												</div>
												<div class="tab-pane" id="tab_3">
                                                                 <div class="clearfix">&nbsp;</div> 
                                                                 <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Distances & Timings</span>
                                                                 </div>
                                                                 
                                                                <div class="clearfix">&nbsp;</div> 
                                                                     
                                                                <div class="row">
                                                                       
                                                                       <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Airport Distance</label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'airport_distance',
                                                                                      'id'          => 'airport_distance',	
                                                                                      'value'       => set_value('airport_distance'),												
                                                                                      'maxlength'   => '10',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('airport_distance');
                                                                                   ?>
                                                                                  <?php echo $this->lang->line('location_distance_km_text'); ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Railway Station Distance </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'railway_station_distance',
                                                                                      'id'          => 'railway_station_distance',	
                                                                                      'value'       => set_value('railway_station_distance') ? $this->input->post("railway_station_distance") : $this->input->post("railway_station_distance"),												
                                                                                      'maxlength'   => '10',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('railway_station_distance');
                                                                                   ?>
                                                                                   <?php echo $this->lang->line('location_distance_km_text'); ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Bus Stand Distance  </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'bus_stand_distance',
                                                                                      'id'          => 'bus_stand_distance',	
                                                                                      'value'       => set_value('bus_stand_distance') ? $this->input->post("bus_stand_distance") : $this->input->post("bus_stand_distance"),												
                                                                                      'maxlength'   => '10',
                                                                                      'class'   => 'form-control',
                                                                                      );
                                                                                    echo form_input($data);
                                                                                    echo form_error('bus_stand_distance');
                                                                                   ?>
                                                                                   <?php echo $this->lang->line('location_distance_km_text'); ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label">City Centre Distance  </label>
                                                                              <?php $data = array(
																				  'name'        => 'city_centre_distance',
																				  'id'          => 'city_centre_distance',	
																				  'value'       => set_value('city_centre_distance') ? $this->input->post("city_centre_distance") : $this->input->post("city_centre_distance"),																		
																				  'class'   => 'form-control',
																				  'maxlength'   => '10',
																				  );
																			   echo form_input($data);
																			   echo form_error('city_centre_distance');
																			  ?>
                                                                              <?php echo $this->lang->line('location_distance_km_text'); ?>
                                                                            </div>
                                                                        </div>
                                                                         
                                                                  </div>
                                                            
                                                                 <!--/row-->
                                                                 
                                                                 
                                                                 <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Opening Closing/Times</span>
                                                                 </div>
                                                                 
                                                                  <div class="clearfix">&nbsp;</div> 
                                                                  <div class="row">
																		<div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Hours </label>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Availability </label>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Start Time </label>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Close Time </label>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                     </div>   
                                                                        
                                                                   <?php 
                                                                    $week_days_array = get_list_options('week_days','ASC'); 
																	/* echo "<pre>";
																	print_r($week_days_array);
																	die; */
																    unset($week_days_array['']);
																    foreach($week_days_array as $weekdayskey=>$weekdaysval){
																	?>
																  
                                                                    <div class="row">
                                                                       
                                                                       <div class="col-md-2">
                                                                            <div class="form-group">
                                                                              <?php echo $weekdaysval; ?>
                                                                              <input type="hidden" name="week_days[]" id="week_days" value="<?php echo $weekdayskey; ?>">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                               <input type="checkbox" data-on-text="Open" data-off-text="Closed"  class="make-switch" id="availability" name="availability[]" value="<?php echo $weekdayskey; ?>" data-size="small">
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                                <input type="text" name="starttime[]" id="starttime" class="form-control timepicker timepicker-no-seconds" value="9:30 AM">
                                                                                 <span class="input-group-btn">
                                                                                <button class="btn default" type="button">
                                                                                    <i class="fa fa-clock-o"></i>
                                                                                </button>
                                                                            </span>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-2">
                                                                            <div class="form-group">
                                                                                <input type="text" name="closetime[]" id="closetime" class="form-control timepicker timepicker-no-seconds" value="6:00 PM">
                                                                                 <span class="input-group-btn">
                                                                                <button class="btn default" type="button">
                                                                                    <i class="fa fa-clock-o"></i>
                                                                                </button>
                                                                            </span>
                                                                            </div>
                                                                        </div>
                                                                         
                                                                  </div>
                                                                  <?php } ?>
                                                                  
                                                                  
                                                                  <div class="clearfix">&nbsp;</div> 
                                                                <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Rules & Regulations</span>
                                                                 </div>
                                                                 
                                                                <div class="clearfix">&nbsp;</div> 
                                                                     
                                                                <div class="row">
                                                                       
                                                                       <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Rules & Regulations </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'rules_regulations',
                                                                                      'id'          => 'rules_regulations',	
                                                                                      'value'       => set_value('rules_regulations') ? $this->input->post("rules_regulations") : $this->input->post("rules_regulations"),												
                                                                                      'class'   => 'form-control',
																					  'rows'   => '4',	
                                                                                      );
                                                                                    echo form_textarea($data);
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Total visitor in a month </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'visitors_in_month',
                                                                                      'id'          => 'visitors_in_month',	
                                                                                      'value'       => set_value('visitors_in_month') ? $this->input->post("visitors_in_month") : $this->input->post("visitors_in_month"),												
                                                                                      'class'   => 'form-control',
																					  'maxlength'   => '255',
																					  );
                                                                                    echo form_input($data);
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Public review</label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'vendor_review',
                                                                                      'id'          => 'vendor_review',	
                                                                                      'value'       => set_value('vendor_review') ? $this->input->post("vendor_review") : $this->input->post("vendor_review"),												
                                                                                      'class'   => 'form-control',
																					  'rows'   => '4',
                                                                                      );
                                                                                    echo form_textarea($data);
                                                                                    echo form_error('vendor_review');
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Remarks </label>
                                                                              <?php $data = array(
																				  'name'        => 'remarks',
																				  'id'          => 'remarks',	
																				  'value'       => set_value('remarks') ? $this->input->post("remarks") : $this->input->post("remarks"),																		
																				  'class'   => 'form-control',
																				  'rows'   => '4',
																				  );
																			   echo form_textarea($data);
																			   echo form_error('remarks');
																			  ?>
                                                                            </div>
                                                                        </div>
                                                                        
                                                                        
                                                                  </div>
                                                            
                                                                 <!--/row-->
                                                                 
                                                                 
                                                             
												</div>
												<div class="tab-pane" id="tab_4">
                                                                <div class="clearfix">&nbsp;</div> 
                                                                <div class="caption">
                                                                 <i class="icon-map font-dark"></i>
                                                                  <span class="caption-subject font-dark sbold uppercase">Beacons</span>
                                                                 </div>
                                                                  <div class="clearfix">&nbsp;</div>    
                                                                <div class="row">
                                                                
                                                                  <div class="col-md-12">
                                                                    <div class="mt-repeater">
                                                                        <div data-repeater-list="vendor-beacon">
                                                                            <div data-repeater-item class="row">
                                                                                <div class="col-md-2">
                                                                                    <label class="control-label">Beacon name</label>
                                                                                    <?php $data = array(
                                                                                          'name'        => 'beacon_vendor_name',
                                                                                          'id'          => 'beacon_vendor_name',	
                                                                                          'value'       => set_value('beacon_vendor_name') ? $this->input->post("beacon_vendor_name") : $this->input->post("beacon_vendor_name"),												
                                                                                          'maxlength'   => '255',
                                                                                          'class'   => 'form-control mt-repeater-input-inline',
                                                                                          );
                                                                                        echo form_input($data);
                                                                                        echo form_error('beacon_vendor_name');
                                                                                       ?>
                                                                                   </div>
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label">Beacon Id</label>
                                                                                 <?php
																					$beacon_array = $this->vendors_model->get_beacons_dropdown();
																					
																					$selected = ($this->input->post('beacon_unique_id')) ? $this->input->post('beacon_unique_id') : $this->input->post('beacon_unique_id');
																					echo form_dropdown('beacon_unique_id', $beacon_array,  $selected,'id="beacon_unique_id" class="form-control" ');
																					echo form_error('beacon_unique_id');
																				   ?>
                                                                                </div>
                                                                                
                                                                                
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label">Action Plan </label>
																		 <?php
                                                                             $beacon_action_plan_array =  get_list_options('beacon_action_plan','ASC'); 
                                                                             $selected = ($this->input->post('action_plan_id')) ? $this->input->post('action_plan_id') : $this->input->post('action_plan_id');
                                                                             echo form_dropdown('action_plan_id', $beacon_action_plan_array,  $selected,'id="action_plan_id" class="form-control" ');
                                                                             echo form_error('action_plan_id');
                                                                           ?>
                                                                                </div>
                                                                                
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label">Choose Instruction</label>
                                                                                 <?php
																				   $beacon_instruction_array =  get_list_options('beacon_instruction','ASC'); 
																					$selected = ($this->input->post('instruction_id')) ? $this->input->post('instruction_id') : $this->input->post('instruction_id');
																					echo form_dropdown('instruction_id', $beacon_instruction_array,  $selected,'id="instruction_id" class="form-control" ');
																					echo form_error('instruction_id');
																				   ?>
                                                                                   
                                                                                
                                                                                </div>
                                                                                
                                                                                
                                                                                <div class="col-md-2">
                                                                                 <label class="control-label">Sound File</label>
                                                                                <?php
																					$fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
																					$sound_file_array = gettabledropdown('sound_files',$fields,'sound_file_id','sound_file_title','sound_file_title','ASC');
																					$selected = ($this->input->post('beacon_sound_file_id')) ? $this->input->post('beacon_sound_file_id') : $this->input->post('beacon_sound_file_id');
																					echo form_dropdown('beacon_sound_file_id', $sound_file_array,  $selected,'id="beacon_sound_file_id" class="form-control" ');
																					echo form_error('beacon_sound_file_id');
																				   ?>
                                                                                </div>
                                                                                
                                                                                
                                                                                <!--<div class="col-md-2">
                                                                                 <label class="control-label"><strong>OR /</strong> &nbsp;&nbsp; Upload Media</label>
                                                                                 <div class="form-group">
                                                                                  
                                                                                   <input type="file" id="beacon_media_file" name="beacon_media_file">
                                                                               </div>
                                                                                </div>-->
                                                                                
                                                                                
                                                                       <div class="col-md-3">
                                                                            <div class="form-group">
                                                                              <label class="control-label">Remarks  </label>
                                                                                 <?php $data = array(
                                                                                      'name'        => 'beacon_remarks',
                                                                                      'id'          => 'beacon_remarks',	
                                                                                      'value'       => set_value('beacon_remarks') ? $this->input->post("beacon_remarks") : $this->input->post("beacon_remarks"),												
                                                                                      'class'   => 'form-control',
																					  'rows'   => '4',	
                                                                                      );
                                                                                    echo form_textarea($data);
                                                                                   ?>
                                                                            </div>
                                                                        </div>
                                                                                    
                                                                               
                                                                               
                                                                                <div class="col-md-1">
                                                                                    <label class="control-label">&nbsp;</label>
                                                                                    <a href="javascript:;" data-repeater-delete class="btn btn-danger">
                                                                                        <i class="fa fa-close"></i>
                                                                                    </a>
                                                                                </div>
                                                                            </div>
                                                                            
                                                                        </div>
                                                                        <hr>
                                                                        <a href="javascript:;" data-repeater-create class="btn btn-sm btn-sm btn-success mt-repeater-add">
                                                                            <i class="fa fa-plus"></i> Add more</a>
                                                                        <br>
                                                                        <br> </div>
                                                                </div>
                                                                
                                                                </div>
                                                                 <!--/row-->
                                                            
												</div>
												
											</div>
											  <?php echo form_close(); ?>
										</div>
									</div>
								</div>
                                            
                                            
                                        </div>
                                            
                                        </div>
                                        
                                    </div>
                                    <!-- END PAGE CONTENT INNER -->
                                </div>
                            </div>
                            <!-- END PAGE CONTENT BODY -->
                            <!-- END CONTENT BODY -->
                        </div>
                        <!-- END CONTENT -->
                        <!-- BEGIN QUICK SIDEBAR -->
                         <?php $this->load->view("includes/sidebar.php");?>
                        <!-- END QUICK SIDEBAR -->
                    </div>
                    <!-- END CONTAINER -->
                </div>
            </div>
            <?php $this->load->view("includes/footer.php");?>
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php $this->load->view("includes/quicknav.php");?>
        <!-- END QUICK NAV -->
       <?php $this->load->view("includes/scripts.php");?>
		 <script src="<?php echo base_url();?>assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
         <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-repeater/jquery.repeater.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js" type="text/javascript"></script>
        
        <script src="<?php echo base_url();?>assets/global/plugins/moment.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/clockface/js/clockface.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
       
        <script src="<?php echo base_url();?>assets/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/scripts/app.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/pages/scripts/components-select2.min.js" type="text/javascript"></script>
        
        <script src="<?php echo base_url();?>assets/pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        <!-- END THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assets/pages/scripts/form-repeater.min.js" type="text/javascript"></script>
        
   
	   
     <script>

	 $(document).ready(function(){
		 
		 $('#category_type_id').bind('change', function () {
			var category_type_id=$(this).val();
			if(category_type_id === null){ 
				var category_type_id=<?php echo $category_type_id; ?>;
			}
			get_categorylist(category_type_id,<?php echo $category_ids; ?>);
			
		});
		$('#category_type_id').trigger('change');
		
		$('.location_set_marker').hide();
		$('.map_button').hide();
		$('#location_map').hide();
		
		
		$(document).on( "click", '.getLocation',function() {
			  longitude=$(this).parent().siblings().find(".long");
			  latitude=$(this).parent().siblings().find(".lat");
			  var lat_name=latitude.attr("name");
			  var lng_name=longitude.attr("name");
			
				if(navigator.geolocation) {
					navigator.geolocation.getCurrentPosition(function(position) {
						//document.getElementById(latitude).value  = position.coords.latitude;
						latitude.val(position.coords.latitude);
						longitude.val(position.coords.longitude);
						//longitude.val("fff");
						locationMap(position.coords.longitude,position.coords.latitude,lat_name,lng_name);
					
						
						$('#location_map').show();
						$('.map_button').show();
						$('.location_set_marker').show();
						
						
						
						//document.getElementById(longitude).value  = position.coords.longitude;
					});
				} else {
					alert("Sorry, your browser does not support HTML5 geolocation.");
				}
		  });
		
		
	  $(document).on( "click", '.map_button',function() {
		  $('.location_set_marker').hide();
		  $('.map_button').hide();
		  $('#location_map').hide();
	  });
		
		function locationMap(longitude,latitude,lat_name,lng_name) {   
				
			  var longitude1 = parseFloat(longitude);
			  var latitude1 = parseFloat(latitude);
			  
			  var myLatLng = {lat: latitude1, lng: longitude1};
			
			  map = new google.maps.Map(document.getElementById('location_map'), {
				  center: myLatLng,
				  zoom: 16,
				  //disableDoubleClickZoom: true, // disable the default
			  });
			
			// Update lat/long value of div when anywhere in the map is clicked    
			google.maps.event.addListener(map,'click',function(event) {  
				
				$("input[name='"+lat_name+"']").val(event.latLng.lat());
				$("input[name='"+lng_name+"']").val(event.latLng.lng());
				locationMap(event.latLng.lng(),event.latLng.lat(),lat_name,lng_name);
				
			});
			var marker = new google.maps.Marker({
				  position: myLatLng,  
				  map: map,
				  //title: 'Hello World'
				  
				  // setting latitude & longitude as title of the marker
				  // title is shown when you hover over the marker
				  title: latitude1 + ', ' + longitude1 
			}); 
					
		}
			
		$('#country_id').bind('change', function () {
			var country_id=$(this).val();
			var state_id=$("#state_id").val();
			if(country_id === null){ 
				var country_id=<?php echo $country_id; ?>;
			}
			if(state_id=== null || state_id==''){ 
				var state_id=<?php echo $state_id; ?>;
			}else{
				var state_id=0;
			}
			
			get_state(country_id,state_id);
			
		});
		$('#country_id').trigger('change');
			
		$('#state_id').bind('change', function () {
			var state_id=$(this).val();
			var city_id=$("#city_id").val();
			if(state_id === null){ 
				var state_id=<?php echo $state_id; ?>;
			}
			if(city_id=== null || city_id==''){ 
				var city_id=<?php echo $city_id; ?>;
			}else{
				var city_id=0;
			}
			get_city(state_id,city_id);
			
		});
		$('#state_id').trigger('change');
		
	});
    </script>
	<script type="text/javascript">
			var map;
			function initMap() {   
				
				  var longitude = parseFloat(document.getElementById('longitude').value);
				  var latitude = parseFloat(document.getElementById('latitude').value);
			
				  
				  var myLatLng = {lat: latitude, lng: longitude};
				
				  map = new google.maps.Map(document.getElementById('map'), {
					  center: myLatLng,
					  zoom: 16,
					  //disableDoubleClickZoom: true, // disable the default
				  });
				
				// Update lat/long value of div when anywhere in the map is clicked    
				google.maps.event.addListener(map,'click',function(event) {  
					
					document.getElementById('latitude').value = event.latLng.lat();
					document.getElementById('longitude').value =  event.latLng.lng();
					locationMap();
				});
				var marker = new google.maps.Marker({
					  position: myLatLng,  
					  map: map,
					  //title: 'Hello World'
					  
					  // setting latitude & longitude as title of the marker
					  // title is shown when you hover over the marker
					  title: latitude + ', ' + longitude 
				}); 
						
			}
		
        </script>
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAmPjV0y9L48TlEMLyZGyzKLrAy-yjshMY&callback=initMap"
        async defer></script>
    </body>

</html>