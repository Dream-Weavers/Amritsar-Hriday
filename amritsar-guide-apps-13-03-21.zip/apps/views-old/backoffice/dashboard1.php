<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD --><head>
        <meta charset="utf-8" />
        <title><?php echo $this->lang->line('text_title_header'); ?></title>
        <?php $this->load->view("includes/styles.php");?></head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                    <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
                        <!-- BEGIN CONTENT -->
                        <div class="page-content-wrapper">
                            <!-- BEGIN CONTENT BODY -->
                            <!-- BEGIN PAGE HEAD-->
                            <div class="page-head">
                                <div class="container">
                                    <!-- BEGIN PAGE TITLE -->
                                    <div class="page-title">
                                        <h1>Dashboard
                                            <small>dashboard & statistics</small>
                                        </h1>
                                    </div>
                                    <!-- END PAGE TITLE -->
                                    <!-- BEGIN PAGE TOOLBAR -->
                                    <?php $this->load->view("includes/toolbar.php");?>
                                    <!-- END PAGE TOOLBAR -->
                                </div>
                            </div>
                            <!-- END PAGE HEAD-->
                            <!-- BEGIN PAGE CONTENT BODY -->
                            <div class="page-content">
                                <div class="container">
                                    <!-- BEGIN PAGE BREADCRUMBS -->
                                    <ul class="page-breadcrumb breadcrumb">
                                        <li>
                                            <a href="<?php echo base_url();?>backoffice/dashboard">Dashboard</a>
                                            <i class="fa fa-circle"></i>
                                        </li>
                                        <li>
                                            <span>Dashboard</span>
                                        </li>
                                    </ul>
                                    <!-- END PAGE BREADCRUMBS -->
                                    <!-- BEGIN PAGE CONTENT INNER -->
                                    <div class="page-content-inner">
                                        <div class="mt-content-body">
											<div class="row">
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_white">
                                                            <div class="color-view bg-white bg-font-white bold uppercase"> #ffffff </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> white </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_white">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-white">white</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#white_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#white_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#white_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#white_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="white_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-white font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-white font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-white font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-white">
                                                                                        <span class="bg-font-white font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-white font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-white font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-white font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-white font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-white font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-white font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-white font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-white font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-white font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-white font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-white font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-white">
                                                                                        <i class="bg-font-white font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-white font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-white font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-white font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-white font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-white font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-white font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-white font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-white font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-white"</code> </div>
                                                                                <div class="tab-pane" id="white_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-white margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-white"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-white bg-font-white margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-white bg-font-white"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="white_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase white">Button</a> &nbsp; <code>class="btn white"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline white">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-white"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle white">Button</a> &nbsp; <code>class="btn btn-circle white"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="white_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat white">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat white"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_default">
                                                            <div class="color-view bg-default bg-font-default bold uppercase"> #e1e5ec </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> default </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_default">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-default">default</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#default_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#default_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#default_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#default_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="default_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-default font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-default font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-default font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-default">
                                                                                        <span class="bg-font-default font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-default font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-default font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-default font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-default font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-default font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-default font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-default font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-default font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-default font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-default font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-default font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-default">
                                                                                        <i class="bg-font-default font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-default font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-default font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-default font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-default font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-default font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-default font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-default font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-default font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-default"</code> </div>
                                                                                <div class="tab-pane" id="default_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-default margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-default"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-default bg-font-default margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-default bg-font-default"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="default_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase default">Button</a> &nbsp; <code>class="btn default"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline default">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-default"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle default">Button</a> &nbsp; <code>class="btn btn-circle default"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="default_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat default">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat default"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_dark">
                                                            <div class="color-view bg-dark bg-font-dark bold uppercase"> #2f353b </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> dark </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_dark">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-dark">dark</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#dark_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#dark_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#dark_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#dark_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="dark_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-dark font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-dark font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-dark font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-dark">
                                                                                        <span class="bg-font-dark font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-dark font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-dark font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-dark font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-dark font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-dark font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-dark font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-dark font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-dark font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-dark font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-dark font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-dark font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-dark">
                                                                                        <i class="bg-font-dark font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-dark font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-dark font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-dark font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-dark font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-dark font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-dark font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-dark font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-dark font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-dark"</code> </div>
                                                                                <div class="tab-pane" id="dark_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-dark margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-dark"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-dark bg-font-dark margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-dark bg-font-dark"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="dark_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase dark">Button</a> &nbsp; <code>class="btn dark"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline dark">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-dark"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle dark">Button</a> &nbsp; <code>class="btn btn-circle dark"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="dark_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat dark">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat dark"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue">
                                                            <div class="color-view bg-blue bg-font-blue bold uppercase"> #3598dc </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue">blue</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue">
                                                                                        <span class="bg-font-blue font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue">
                                                                                        <i class="bg-font-blue font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue"</code> </div>
                                                                                <div class="tab-pane" id="blue_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue bg-font-blue margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue bg-font-blue"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue">Button</a> &nbsp; <code>class="btn blue"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue">Button</a> &nbsp; <code>class="btn btn-circle blue"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue-madison">
                                                            <div class="color-view bg-blue-madison bg-font-blue-madison bold uppercase"> #578ebe </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue-madison </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue-madison">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue-madison">blue-madison</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue-madison_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-madison_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-madison_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-madison_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue-madison_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue-madison font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-madison font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-madison font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-madison">
                                                                                        <span class="bg-font-blue-madison font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-madison font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-madison font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue-madison font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue-madison font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-madison font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-madison font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue-madison font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-madison font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-madison font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue-madison font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue-madison font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-madison">
                                                                                        <i class="bg-font-blue-madison font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue-madison font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-madison font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-madison font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue-madison font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-madison font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-madison font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue-madison font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue-madison font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue-madison"</code> </div>
                                                                                <div class="tab-pane" id="blue-madison_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue-madison margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue-madison"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue-madison bg-font-blue-madison margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue-madison bg-font-blue-madison"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-madison_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue-madison">Button</a> &nbsp; <code>class="btn blue-madison"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue-madison">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue-madison"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue-madison">Button</a> &nbsp; <code>class="btn btn-circle blue-madison"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-madison_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue-madison">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue-madison"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue-chambray">
                                                            <div class="color-view bg-blue-chambray bg-font-blue-chambray bold uppercase"> #2C3E50 </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue-chambray </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue-chambray">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue-chambray">blue-chambray</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue-chambray_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-chambray_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-chambray_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-chambray_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue-chambray_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue-chambray font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-chambray font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-chambray font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-chambray">
                                                                                        <span class="bg-font-blue-chambray font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-chambray font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-chambray font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue-chambray font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue-chambray font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-chambray font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-chambray font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue-chambray font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-chambray font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-chambray font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue-chambray font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue-chambray font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-chambray">
                                                                                        <i class="bg-font-blue-chambray font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue-chambray font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-chambray font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-chambray font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue-chambray font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-chambray font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-chambray font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue-chambray font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue-chambray font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue-chambray"</code> </div>
                                                                                <div class="tab-pane" id="blue-chambray_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue-chambray margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue-chambray"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue-chambray bg-font-blue-chambray margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue-chambray bg-font-blue-chambray"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-chambray_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue-chambray">Button</a> &nbsp; <code>class="btn blue-chambray"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue-chambray">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue-chambray"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue-chambray">Button</a> &nbsp; <code>class="btn btn-circle blue-chambray"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-chambray_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue-chambray">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue-chambray"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
												<div class="row">
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue-ebonyclay">
                                                            <div class="color-view bg-blue-ebonyclay bg-font-blue-ebonyclay bold uppercase"> #22313F </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue-ebonyclay </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue-ebonyclay">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue-ebonyclay">blue-ebonyclay</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue-ebonyclay_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-ebonyclay_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-ebonyclay_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-ebonyclay_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue-ebonyclay_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue-ebonyclay font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-ebonyclay font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-ebonyclay font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-ebonyclay">
                                                                                        <span class="bg-font-blue-ebonyclay font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-ebonyclay font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-ebonyclay font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue-ebonyclay font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue-ebonyclay font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-ebonyclay font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-ebonyclay font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue-ebonyclay font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-ebonyclay font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-ebonyclay font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue-ebonyclay font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue-ebonyclay font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-ebonyclay">
                                                                                        <i class="bg-font-blue-ebonyclay font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue-ebonyclay font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-ebonyclay font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-ebonyclay font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue-ebonyclay font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-ebonyclay font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-ebonyclay font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue-ebonyclay font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue-ebonyclay font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue-ebonyclay"</code> </div>
                                                                                <div class="tab-pane" id="blue-ebonyclay_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue-ebonyclay margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue-ebonyclay"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue-ebonyclay bg-font-blue-ebonyclay margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue-ebonyclay bg-font-blue-ebonyclay"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-ebonyclay_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue-ebonyclay">Button</a> &nbsp; <code>class="btn blue-ebonyclay"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue-ebonyclay">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue-ebonyclay"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue-ebonyclay">Button</a> &nbsp; <code>class="btn btn-circle blue-ebonyclay"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-ebonyclay_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue-ebonyclay">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue-ebonyclay"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue-hoki">
                                                            <div class="color-view bg-blue-hoki bg-font-blue-hoki bold uppercase"> #67809F </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue-hoki </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue-hoki">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue-hoki">blue-hoki</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue-hoki_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-hoki_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-hoki_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-hoki_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue-hoki_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue-hoki font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-hoki font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-hoki font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-hoki">
                                                                                        <span class="bg-font-blue-hoki font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-hoki font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-hoki font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue-hoki font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue-hoki font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-hoki font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-hoki font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue-hoki font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-hoki font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-hoki font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue-hoki font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue-hoki font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-hoki">
                                                                                        <i class="bg-font-blue-hoki font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue-hoki font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-hoki font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-hoki font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue-hoki font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-hoki font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-hoki font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue-hoki font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue-hoki font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue-hoki"</code> </div>
                                                                                <div class="tab-pane" id="blue-hoki_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue-hoki margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue-hoki"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue-hoki bg-font-blue-hoki margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue-hoki bg-font-blue-hoki"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-hoki_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue-hoki">Button</a> &nbsp; <code>class="btn blue-hoki"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue-hoki">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue-hoki"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue-hoki">Button</a> &nbsp; <code>class="btn btn-circle blue-hoki"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-hoki_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue-hoki">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue-hoki"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue-steel">
                                                            <div class="color-view bg-blue-steel bg-font-blue-steel bold uppercase"> #4B77BE </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue-steel </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue-steel">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue-steel">blue-steel</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue-steel_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-steel_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-steel_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-steel_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue-steel_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue-steel font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-steel font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-steel font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-steel">
                                                                                        <span class="bg-font-blue-steel font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-steel font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-steel font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue-steel font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue-steel font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-steel font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-steel font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue-steel font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-steel font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-steel font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue-steel font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue-steel font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-steel">
                                                                                        <i class="bg-font-blue-steel font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue-steel font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-steel font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-steel font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue-steel font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-steel font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-steel font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue-steel font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue-steel font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue-steel"</code> </div>
                                                                                <div class="tab-pane" id="blue-steel_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue-steel margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue-steel"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue-steel bg-font-blue-steel margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue-steel bg-font-blue-steel"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-steel_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue-steel">Button</a> &nbsp; <code>class="btn blue-steel"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue-steel">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue-steel"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue-steel">Button</a> &nbsp; <code>class="btn btn-circle blue-steel"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-steel_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue-steel">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue-steel"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue-soft">
                                                            <div class="color-view bg-blue-soft bg-font-blue-soft bold uppercase"> #4c87b9 </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue-soft </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue-soft">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue-soft">blue-soft</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue-soft_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-soft_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-soft_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-soft_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue-soft_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue-soft font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-soft font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-soft font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-soft">
                                                                                        <span class="bg-font-blue-soft font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-soft font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-soft font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue-soft font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue-soft font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-soft font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-soft font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue-soft font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-soft font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-soft font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue-soft font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue-soft font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-soft">
                                                                                        <i class="bg-font-blue-soft font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue-soft font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-soft font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-soft font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue-soft font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-soft font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-soft font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue-soft font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue-soft font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue-soft"</code> </div>
                                                                                <div class="tab-pane" id="blue-soft_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue-soft margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue-soft"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue-soft bg-font-blue-soft margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue-soft bg-font-blue-soft"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-soft_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue-soft">Button</a> &nbsp; <code>class="btn blue-soft"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue-soft">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue-soft"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue-soft">Button</a> &nbsp; <code>class="btn btn-circle blue-soft"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-soft_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue-soft">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue-soft"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue-dark">
                                                            <div class="color-view bg-blue-dark bg-font-blue-dark bold uppercase"> #5e738b </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue-dark </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue-dark">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue-dark">blue-dark</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue-dark_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-dark_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-dark_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-dark_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue-dark_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue-dark font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-dark font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-dark font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-dark">
                                                                                        <span class="bg-font-blue-dark font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-dark font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-dark font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue-dark font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue-dark font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-dark font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-dark font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue-dark font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-dark font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-dark font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue-dark font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue-dark font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-dark">
                                                                                        <i class="bg-font-blue-dark font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue-dark font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-dark font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-dark font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue-dark font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-dark font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-dark font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue-dark font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue-dark font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue-dark"</code> </div>
                                                                                <div class="tab-pane" id="blue-dark_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue-dark margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue-dark"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue-dark bg-font-blue-dark margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue-dark bg-font-blue-dark"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-dark_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue-dark">Button</a> &nbsp; <code>class="btn blue-dark"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue-dark">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue-dark"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue-dark">Button</a> &nbsp; <code>class="btn btn-circle blue-dark"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-dark_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue-dark">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue-dark"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <div class="color-demo tooltips" data-original-title="Click to view demos for this color" data-toggle="modal" data-target="#demo_modal_blue-sharp">
                                                            <div class="color-view bg-blue-sharp bg-font-blue-sharp bold uppercase"> #5C9BD1 </div>
                                                            <div class="color-info bg-white c-font-14 sbold"> blue-sharp </div>
                                                        </div>
                                                        <div class="modal fade" id="demo_modal_blue-sharp">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content c-square">
                                                                    <div class="modal-header">
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                        <h4 class="modal-title bold uppercase font-blue-sharp">blue-sharp</h4>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="tabbable-line">
                                                                            <ul class="nav nav-tabs uppercase bold">
                                                                                <li class="active">
                                                                                    <a href="#blue-sharp_tab_1_content" data-toggle="tab">Typography</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-sharp_tab_2_content" data-toggle="tab">Background & Border</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-sharp_tab_3_content" data-toggle="tab">Buttons</a>
                                                                                </li>
                                                                                <li>
                                                                                    <a href="#blue-sharp_tab_4_content" data-toggle="tab">Components</a>
                                                                                </li>
                                                                            </ul>
                                                                            <div class="tab-content">
                                                                                <div class="tab-pane active" id="blue-sharp_tab_1_content">
                                                                                    <h4>Text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <span class="font-blue-sharp font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-sharp font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="font-blue-sharp font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Background matching text font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-sharp">
                                                                                        <span class="bg-font-blue-sharp font-lg">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-sharp font-lg sbold">Some sample text goes here...</span>
                                                                                        <br>
                                                                                        <span class="bg-font-blue-sharp font-lg bold uppercase">Some sample text goes here...</span>
                                                                                    </div>
                                                                                    <h4>Icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <i class="font-blue-sharp font-lg icon-user"></i>&nbsp;
                                                                                        <i class="font-blue-sharp font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-sharp font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-sharp font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="font-blue-sharp font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="font-blue-sharp font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="font-blue-sharp font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="font-blue-sharp font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="font-blue-sharp font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Background matching icon font</h4>
                                                                                    <div style="margin: 10px 0 30px 0; padding: 10px" class="bg-blue-sharp">
                                                                                        <i class="bg-font-blue-sharp font-lg icon-user"></i>&nbsp;
                                                                                        <i class="bg-font-blue-sharp font-lg icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-sharp font-lg icon-calendar"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-sharp font-lg fa fa-bar-chart-o"></i>&nbsp;
                                                                                        <i class="bg-font-blue-sharp font-lg fa fa-code-fork icon-settings"></i>&nbsp;
                                                                                        <i class="bg-font-blue-sharp font-lg fa fa-cogs"></i>
                                                                                        <br>
                                                                                        <i class="bg-font-blue-sharp font-lg glyphicon glyphicon-star-empty"></i>&nbsp;
                                                                                        <i class="bg-font-blue-sharp font-lg glyphicon glyphicon-leaf"></i>&nbsp;
                                                                                        <i class="bg-font-blue-sharp font-lg glyphicon glyphicon-warning-sign"></i>
                                                                                        <br> </div>
                                                                                    <h4>Class usage</h4> <code>class="font-blue-sharp"</code> </div>
                                                                                <div class="tab-pane" id="blue-sharp_tab_2_content">
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="border-blue-sharp margin-bottom-10" style="padding: 10px; border: 2px solid #fff;"> Box with custom border color </div> <code>class="border-blue-sharp"</code> </div>
                                                                                    <div style="margin: 30px 0;">
                                                                                        <div class="bg-blue-sharp bg-font-blue-sharp margin-bottom-10" style="padding: 10px; "> Box with custom background color </div> <code>class="bg-blue-sharp bg-font-blue-sharp"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-sharp_tab_3_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn uppercase blue-sharp">Button</a> &nbsp; <code>class="btn blue-sharp"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-outline blue-sharp">Button</a> &nbsp; <code>class="c-btn-border-1x c-btn-blue-sharp"</code> </div>
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <a href="#" class="btn sbold uppercase btn-circle blue-sharp">Button</a> &nbsp; <code>class="btn btn-circle blue-sharp"</code> </div>
                                                                                </div>
                                                                                <div class="tab-pane" id="blue-sharp_tab_4_content">
                                                                                    <div style="margin: 10px 0 30px 0">
                                                                                        <h4>Statistic Widgets</h4>
                                                                                        <div class="dashboard-stat blue-sharp">
                                                                                            <div class="visual">
                                                                                                <i class="fa fa-bar-chart-o"></i>
                                                                                            </div>
                                                                                            <div class="details">
                                                                                                <div class="number"> 12,5M$ </div>
                                                                                                <div class="desc"> Total Profit </div>
                                                                                            </div>
                                                                                            <a class="more" href="javascript:;"> View more
                                                                                                <i class="m-icon-swapright m-icon-white"></i>
                                                                                            </a>
                                                                                        </div> <code>class="dashboard-stat blue-sharp"</code> </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-outline dark sbold uppercase" data-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6">
                                                    <div class="portlet light ">
                                                        <div class="portlet-title">
                                                            <div class="caption caption-md">
                                                                <i class="icon-bar-chart font-dark hide"></i>
                                                                <span class="caption-subject font-green-steel uppercase bold">Sales Summary</span>
                                                                <span class="caption-helper hide">weekly stats...</span>
                                                            </div>
                                                            
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div class="row list-separated">
                                                                <div class="col-md-3 col-sm-3 col-xs-6">
                                                                    <div class="font-grey-mint font-sm"> Total Sales </div>
                                                                    <div class="uppercase font-hg font-red-flamingo"> 13,760
                                                                        <span class="font-lg font-grey-mint">$</span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3 col-sm-3 col-xs-6">
                                                                    <div class="font-grey-mint font-sm"> Revenue </div>
                                                                    <div class="uppercase font-hg theme-font"> 4,760
                                                                        <span class="font-lg font-grey-mint">$</span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3 col-sm-3 col-xs-6">
                                                                    <div class="font-grey-mint font-sm"> Expenses </div>
                                                                    <div class="uppercase font-hg font-purple"> 11,760
                                                                        <span class="font-lg font-grey-mint">$</span>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-3 col-sm-3 col-xs-6">
                                                                    <div class="font-grey-mint font-sm"> Growth </div>
                                                                    <div class="uppercase font-hg font-blue-sharp"> 9,760
                                                                        <span class="font-lg font-grey-mint">$</span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <ul class="list-separated list-inline-xs hide">
                                                                <li>
                                                                    <div class="font-grey-mint font-sm"> Total Sales </div>
                                                                    <div class="uppercase font-hg font-red-flamingo"> 13,760
                                                                        <span class="font-lg font-grey-mint">$</span>
                                                                    </div>
                                                                </li>
                                                                <li> </li>
                                                                <li class="border">
                                                                    <div class="font-grey-mint font-sm"> Revenue </div>
                                                                    <div class="uppercase font-hg theme-font"> 4,760
                                                                        <span class="font-lg font-grey-mint">$</span>
                                                                    </div>
                                                                </li>
                                                                <li class="divider"> </li>
                                                                <li>
                                                                    <div class="font-grey-mint font-sm"> Expenses </div>
                                                                    <div class="uppercase font-hg font-purple"> 11,760
                                                                        <span class="font-lg font-grey-mint">$</span>
                                                                    </div>
                                                                </li>
                                                                <li class="divider"> </li>
                                                                <li>
                                                                    <div class="font-grey-mint font-sm"> Growth </div>
                                                                    <div class="uppercase font-hg font-blue-sharp"> 9,760
                                                                        <span class="font-lg font-grey-mint">$</span>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                            <div id="sales_statistics" class="portlet-body-morris-fit morris-chart" style="height: 267px"> </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <div class="portlet light ">
                                                        <div class="portlet-title">
                                                            <div class="caption caption-md">
                                                                <i class="icon-bar-chart font-dark hide"></i>
                                                                <span class="caption-subject font-green-steel bold uppercase">Member Activity</span>
                                                                <span class="caption-helper">weekly stats...</span>
                                                            </div>
                                                            <div class="actions">
                                                                <div class="btn-group btn-group-devided" data-toggle="buttons">
                                                                    <label class="btn btn-transparent blue-oleo btn-no-border btn-outline btn-circle btn-sm active">
                                                                        <input type="radio" name="options" class="toggle" id="option1">Today</label>
                                                                    <label class="btn btn-transparent blue-oleo btn-no-border btn-outline btn-circle btn-sm">
                                                                        <input type="radio" name="options" class="toggle" id="option2">Week</label>
                                                                    <label class="btn btn-transparent blue-oleo btn-no-border btn-outline btn-circle btn-sm">
                                                                        <input type="radio" name="options" class="toggle" id="option2">Month</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div class="row number-stats margin-bottom-30">
                                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                                    <div class="stat-left">
                                                                        <div class="stat-chart">
                                                                            <!-- do not line break "sparkline_bar" div. sparkline chart has an issue when the container div has line break -->
                                                                            <div id="sparkline_bar"></div>
                                                                        </div>
                                                                        <div class="stat-number">
                                                                            <div class="title"> Total </div>
                                                                            <div class="number"> 2460 </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6 col-sm-6 col-xs-6">
                                                                    <div class="stat-right">
                                                                        <div class="stat-chart">
                                                                            <!-- do not line break "sparkline_bar" div. sparkline chart has an issue when the container div has line break -->
                                                                            <div id="sparkline_bar2"></div>
                                                                        </div>
                                                                        <div class="stat-number">
                                                                            <div class="title"> New </div>
                                                                            <div class="number"> 719 </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="table-scrollable table-scrollable-borderless">
                                                                <table class="table table-hover table-light">
                                                                    <thead>
                                                                        <tr class="uppercase">
                                                                            <th colspan="2"> MEMBER </th>
                                                                            <th> Earnings </th>
                                                                            <th> CASES </th>
                                                                            <th> CLOSED </th>
                                                                            <th> RATE </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tr>
                                                                        <td class="fit">
                                                                            <img class="user-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar4.jpg"> </td>
                                                                        <td>
                                                                            <a href="javascript:;" class="primary-link">Brain</a>
                                                                        </td>
                                                                        <td> $345 </td>
                                                                        <td> 45 </td>
                                                                        <td> 124 </td>
                                                                        <td>
                                                                            <span class="bold theme-font">80%</span>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="fit">
                                                                            <img class="user-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar5.jpg"> </td>
                                                                        <td>
                                                                            <a href="javascript:;" class="primary-link">Nick</a>
                                                                        </td>
                                                                        <td> $560 </td>
                                                                        <td> 12 </td>
                                                                        <td> 24 </td>
                                                                        <td>
                                                                            <span class="bold theme-font">67%</span>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="fit">
                                                                            <img class="user-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar6.jpg"> </td>
                                                                        <td>
                                                                            <a href="javascript:;" class="primary-link">Tim</a>
                                                                        </td>
                                                                        <td> $1,345 </td>
                                                                        <td> 450 </td>
                                                                        <td> 46 </td>
                                                                        <td>
                                                                            <span class="bold theme-font">98%</span>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="fit">
                                                                            <img class="user-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar7.jpg"> </td>
                                                                        <td>
                                                                            <a href="javascript:;" class="primary-link">Tom</a>
                                                                        </td>
                                                                        <td> $645 </td>
                                                                        <td> 50 </td>
                                                                        <td> 89 </td>
                                                                        <td>
                                                                            <span class="bold theme-font">58%</span>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6">
                                                    <div class="portlet light tasks-widget ">
                                                        <div class="portlet-title">
                                                            <div class="caption">
                                                                <i class="icon-share font-dark hide"></i>
                                                                <span class="caption-subject font-green-steel bold uppercase">Tasks</span>
                                                                <span class="caption-helper">tasks summary...</span>
                                                            </div>
                                                            <div class="actions">
                                                                <div class="btn-group">
                                                                    <a class="btn blue-oleo btn-circle btn-sm" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> More
                                                                        <i class="fa fa-angle-down"></i>
                                                                    </a>
                                                                    <ul class="dropdown-menu pull-right">
                                                                        <li>
                                                                            <a href="javascript:;"> All Project </a>
                                                                        </li>
                                                                        <li class="divider"> </li>
                                                                        <li>
                                                                            <a href="javascript:;"> AirAsia </a>
                                                                        </li>
                                                                        <li>
                                                                            <a href="javascript:;"> Cruise </a>
                                                                        </li>
                                                                        <li>
                                                                            <a href="javascript:;"> HSBC </a>
                                                                        </li>
                                                                        <li class="divider"> </li>
                                                                        <li>
                                                                            <a href="javascript:;"> Pending
                                                                                <span class="badge badge-danger"> 4 </span>
                                                                            </a>
                                                                        </li>
                                                                        <li>
                                                                            <a href="javascript:;"> Completed
                                                                                <span class="badge badge-success"> 12 </span>
                                                                            </a>
                                                                        </li>
                                                                        <li>
                                                                            <a href="javascript:;"> Overdue
                                                                                <span class="badge badge-warning"> 9 </span>
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div class="task-content">
                                                                <div class="scroller" style="height: 312px;" data-always-visible="1" data-rail-visible1="1">
                                                                    <!-- START TASK LIST -->
                                                                    <ul class="task-list">
                                                                        <li>
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> Present 2013 Year IPO Statistics at Board Meeting </span>
                                                                                <span class="label label-sm label-success">Company</span>
                                                                                <span class="task-bell">
                                                                                    <i class="fa fa-bell-o"></i>
                                                                                </span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> Hold An Interview for Marketing Manager Position </span>
                                                                                <span class="label label-sm label-danger">Marketing</span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> AirAsia Intranet System Project Internal Meeting </span>
                                                                                <span class="label label-sm label-success">AirAsia</span>
                                                                                <span class="task-bell">
                                                                                    <i class="fa fa-bell-o"></i>
                                                                                </span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> Technical Management Meeting </span>
                                                                                <span class="label label-sm label-warning">Company</span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> Kick-off Company CRM Mobile App Development </span>
                                                                                <span class="label label-sm label-info">Internal Products</span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> Prepare Commercial Offer For SmartVision Website Rewamp </span>
                                                                                <span class="label label-sm label-danger">SmartVision</span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> Sign-Off The Comercial Agreement With AutoSmart </span>
                                                                                <span class="label label-sm label-default">AutoSmart</span>
                                                                                <span class="task-bell">
                                                                                    <i class="fa fa-bell-o"></i>
                                                                                </span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group dropup">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                        <li>
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> Company Staff Meeting </span>
                                                                                <span class="label label-sm label-success">Cruise</span>
                                                                                <span class="task-bell">
                                                                                    <i class="fa fa-bell-o"></i>
                                                                                </span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group dropup">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                        <li class="last-line">
                                                                            <div class="task-checkbox">
                                                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline">
                                                                                    <input type="checkbox" class="checkboxes" value="1" />
                                                                                    <span></span>
                                                                                </label>
                                                                            </div>
                                                                            <div class="task-title">
                                                                                <span class="task-title-sp"> KeenThemes Investment Discussion </span>
                                                                                <span class="label label-sm label-warning">KeenThemes </span>
                                                                            </div>
                                                                            <div class="task-config">
                                                                                <div class="task-config-btn btn-group dropup">
                                                                                    <a class="btn btn-sm default" href="javascript:;" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                                                        <i class="fa fa-cog"></i>
                                                                                        <i class="fa fa-angle-down"></i>
                                                                                    </a>
                                                                                    <ul class="dropdown-menu pull-right">
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-check"></i> Complete </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-pencil"></i> Edit </a>
                                                                                        </li>
                                                                                        <li>
                                                                                            <a href="javascript:;">
                                                                                                <i class="fa fa-trash-o"></i> Cancel </a>
                                                                                        </li>
                                                                                    </ul>
                                                                                </div>
                                                                            </div>
                                                                        </li>
                                                                    </ul>
                                                                    <!-- END START TASK LIST -->
                                                                </div>
                                                            </div>
                                                            <div class="task-footer">
                                                                <div class="btn-arrow-link pull-right">
                                                                    <a href="javascript:;">See All Records</a>
                                                                    <i class="icon-arrow-right"></i>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <div class="portlet light ">
                                                        <div class="portlet-title">
                                                            <div class="caption caption-md">
                                                                <i class="icon-bar-chart font-dark hide"></i>
                                                                <span class="caption-subject font-green-steel bold uppercase">Customer Support</span>
                                                                <span class="caption-helper">45 pending</span>
                                                            </div>
                                                            <div class="inputs">
                                                                <div class="portlet-input input-inline input-small ">
                                                                    <div class="input-icon right">
                                                                        <i class="icon-magnifier"></i>
                                                                        <input type="text" class="form-control form-control-solid input-circle" placeholder="search..."> </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div class="scroller" style="height: 338px;" data-always-visible="1" data-rail-visible1="0" data-handle-color="#D7DCE2">
                                                                <div class="general-item-list">
                                                                    <div class="item">
                                                                        <div class="item-head">
                                                                            <div class="item-details">
                                                                                <img class="item-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar4.jpg">
                                                                                <a href="" class="item-name primary-link">Nick Larson</a>
                                                                                <span class="item-label">3 hrs ago</span>
                                                                            </div>
                                                                            <span class="item-status">
                                                                                <span class="badge badge-empty badge-success"></span> Open</span>
                                                                        </div>
                                                                        <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </div>
                                                                    </div>
                                                                    <div class="item">
                                                                        <div class="item-head">
                                                                            <div class="item-details">
                                                                                <img class="item-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar3.jpg">
                                                                                <a href="" class="item-name primary-link">Mark</a>
                                                                                <span class="item-label">5 hrs ago</span>
                                                                            </div>
                                                                            <span class="item-status">
                                                                                <span class="badge badge-empty badge-warning"></span> Pending</span>
                                                                        </div>
                                                                        <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat tincidunt ut laoreet. </div>
                                                                    </div>
                                                                    <div class="item">
                                                                        <div class="item-head">
                                                                            <div class="item-details">
                                                                                <img class="item-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar6.jpg">
                                                                                <a href="" class="item-name primary-link">Nick Larson</a>
                                                                                <span class="item-label">8 hrs ago</span>
                                                                            </div>
                                                                            <span class="item-status">
                                                                                <span class="badge badge-empty badge-primary"></span> Closed</span>
                                                                        </div>
                                                                        <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh. </div>
                                                                    </div>
                                                                    <div class="item">
                                                                        <div class="item-head">
                                                                            <div class="item-details">
                                                                                <img class="item-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar7.jpg">
                                                                                <a href="" class="item-name primary-link">Nick Larson</a>
                                                                                <span class="item-label">12 hrs ago</span>
                                                                            </div>
                                                                            <span class="item-status">
                                                                                <span class="badge badge-empty badge-danger"></span> Pending</span>
                                                                        </div>
                                                                        <div class="item-body"> Consectetuer adipiscing elit Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </div>
                                                                    </div>
                                                                    <div class="item">
                                                                        <div class="item-head">
                                                                            <div class="item-details">
                                                                                <img class="item-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar9.jpg">
                                                                                <a href="" class="item-name primary-link">Richard Stone</a>
                                                                                <span class="item-label">2 days ago</span>
                                                                            </div>
                                                                            <span class="item-status">
                                                                                <span class="badge badge-empty badge-danger"></span> Open</span>
                                                                        </div>
                                                                        <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, ut laoreet dolore magna aliquam erat volutpat. </div>
                                                                    </div>
                                                                    <div class="item">
                                                                        <div class="item-head">
                                                                            <div class="item-details">
                                                                                <img class="item-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar8.jpg">
                                                                                <a href="" class="item-name primary-link">Dan</a>
                                                                                <span class="item-label">3 days ago</span>
                                                                            </div>
                                                                            <span class="item-status">
                                                                                <span class="badge badge-empty badge-warning"></span> Pending</span>
                                                                        </div>
                                                                        <div class="item-body"> Lorem ipsum dolor sit amet, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </div>
                                                                    </div>
                                                                    <div class="item">
                                                                        <div class="item-head">
                                                                            <div class="item-details">
                                                                                <img class="item-pic rounded" src="<?php echo base_url();?>assets/pages/media/users/avatar2.jpg">
                                                                                <a href="" class="item-name primary-link">Larry</a>
                                                                                <span class="item-label">4 hrs ago</span>
                                                                            </div>
                                                                            <span class="item-status">
                                                                                <span class="badge badge-empty badge-success"></span> Open</span>
                                                                        </div>
                                                                        <div class="item-body"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 col-sm-6">
                                                    <!-- BEGIN REGIONAL STATS PORTLET-->
                                                    <div class="portlet light ">
                                                        <div class="portlet-title">
                                                            <div class="caption">
                                                                <i class="icon-share font-dark hide"></i>
                                                                <span class="caption-subject font-green-steel bold uppercase">Regional Stats</span>
                                                            </div>
                                                            <div class="actions">
                                                                <a class="btn btn-circle btn-icon-only btn-default" href="javascript:;">
                                                                    <i class="icon-cloud-upload"></i>
                                                                </a>
                                                                <a class="btn btn-circle btn-icon-only btn-default" href="javascript:;">
                                                                    <i class="icon-wrench"></i>
                                                                </a>
                                                                <a class="btn btn-circle btn-icon-only btn-default fullscreen" data-container="false" data-placement="bottom" href="javascript:;"> </a>
                                                                <a class="btn btn-circle btn-icon-only btn-default" href="javascript:;">
                                                                    <i class="icon-trash"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <div id="region_statistics_loading">
                                                                <img src="<?php echo base_url();?>assets/global/img/loading.gif" alt="loading" /> </div>
                                                            <div id="region_statistics_content" class="display-none">
                                                                <div class="btn-toolbar margin-bottom-10">
                                                                    <div class="btn-group btn-group-circle" data-toggle="buttons">
                                                                        <a href="" class="btn grey-salsa btn-sm active"> Users </a>
                                                                        <a href="" class="btn grey-salsa btn-sm"> Orders </a>
                                                                    </div>
                                                                    <div class="btn-group pull-right">
                                                                        <a href="" class="btn btn-circle grey-salsa btn-sm dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true"> Select Region
                                                                            <span class="fa fa-angle-down"> </span>
                                                                        </a>
                                                                        <ul class="dropdown-menu pull-right">
                                                                            <li>
                                                                                <a href="javascript:;" id="regional_stat_world"> World </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;" id="regional_stat_usa"> USA </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;" id="regional_stat_europe"> Europe </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;" id="regional_stat_russia"> Russia </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;" id="regional_stat_germany"> Germany </a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div id="vmap_world" class="vmaps display-none"> </div>
                                                                <div id="vmap_usa" class="vmaps display-none"> </div>
                                                                <div id="vmap_europe" class="vmaps display-none"> </div>
                                                                <div id="vmap_russia" class="vmaps display-none"> </div>
                                                                <div id="vmap_germany" class="vmaps display-none"> </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!-- END REGIONAL STATS PORTLET-->
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                    <!-- BEGIN PORTLET-->
                                                    <div class="portlet light ">
                                                        <div class="portlet-title tabbable-line">
                                                            <div class="caption">
                                                                <i class="icon-globe font-dark hide"></i>
                                                                <span class="caption-subject font-green-steel bold uppercase">Feeds</span>
                                                            </div>
                                                            <ul class="nav nav-tabs">
                                                                <li class="active">
                                                                    <a href="#tab_1_1" class="active" data-toggle="tab"> System </a>
                                                                </li>
                                                                <li>
                                                                    <a href="#tab_1_2" data-toggle="tab"> Activities </a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="portlet-body">
                                                            <!--BEGIN TABS-->
                                                            <div class="tab-content">
                                                                <div class="tab-pane active" id="tab_1_1">
                                                                    <div class="scroller" style="height: 339px;" data-always-visible="1" data-rail-visible="0">
                                                                        <ul class="feeds">
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-success">
                                                                                                <i class="fa fa-bell-o"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> You have 4 pending tasks.
                                                                                                <span class="label label-sm label-info"> Take action
                                                                                                    <i class="fa fa-share"></i>
                                                                                                </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> Just now </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New version v1.4 just lunched! </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> 20 mins </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-danger">
                                                                                                <i class="fa fa-bolt"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> Database server #12 overloaded. Please fix the issue. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 24 mins </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-info">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 30 mins </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-success">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 40 mins </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-warning">
                                                                                                <i class="fa fa-plus"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New user registered. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 1.5 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-success">
                                                                                                <i class="fa fa-bell-o"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> Web server hardware needs to be upgraded.
                                                                                                <span class="label label-sm label-default "> Overdue </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 2 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-default">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 3 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-warning">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 5 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-info">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 18 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-default">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 21 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-info">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 22 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-default">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 21 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-info">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 22 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-default">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 21 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-info">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 22 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-default">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 21 hours </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-info">
                                                                                                <i class="fa fa-bullhorn"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> New order received. Please take care of it. </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 22 hours </div>
                                                                                </div>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                                <div class="tab-pane" id="tab_1_2">
                                                                    <div class="scroller" style="height: 290px;" data-always-visible="1" data-rail-visible1="1">
                                                                        <ul class="feeds">
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New user registered </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> Just now </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New order received </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> 10 mins </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <div class="col1">
                                                                                    <div class="cont">
                                                                                        <div class="cont-col1">
                                                                                            <div class="label label-sm label-danger">
                                                                                                <i class="fa fa-bolt"></i>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="cont-col2">
                                                                                            <div class="desc"> Order #24DOP4 has been rejected.
                                                                                                <span class="label label-sm label-danger "> Take action
                                                                                                    <i class="fa fa-share"></i>
                                                                                                </span>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col2">
                                                                                    <div class="date"> 24 mins </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New user registered </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> Just now </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New user registered </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> Just now </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New user registered </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> Just now </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New user registered </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> Just now </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New user registered </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> Just now </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New user registered </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> Just now </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <a href="javascript:;">
                                                                                    <div class="col1">
                                                                                        <div class="cont">
                                                                                            <div class="cont-col1">
                                                                                                <div class="label label-sm label-success">
                                                                                                    <i class="fa fa-bell-o"></i>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="cont-col2">
                                                                                                <div class="desc"> New user registered </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="col2">
                                                                                        <div class="date"> Just now </div>
                                                                                    </div>
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!--END TABS-->
                                                        </div>
                                                    </div>
                                                    <!-- END PORTLET-->
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- END PAGE CONTENT INNER -->
                                </div>
                            </div>
                            <!-- END PAGE CONTENT BODY -->
                            <!-- END CONTENT BODY -->
                        </div>
                        <!-- END CONTENT -->
                        <!-- BEGIN QUICK SIDEBAR -->
                       <?php $this->load->view("includes/sidebar.php");?>
                        
                        <!-- END QUICK SIDEBAR -->
                    </div>
                    <!-- END CONTAINER -->
                </div>
            </div>
           <?php $this->load->view("includes/footer.php");?>
        </div>
        <!-- BEGIN QUICK NAV -->
        <?php $this->load->view("includes/quicknav.php");?>
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo base_url();?>assets/global/plugins/respond.min.js"></script>
<script src="<?php echo base_url();?>assets/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo base_url();?>assets/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/moment.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/morris/morris.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/morris/raphael-min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/counterup/jquery.waypoints.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/flot/jquery.flot.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/flot/jquery.flot.resize.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/flot/jquery.flot.categories.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-easypiechart/jquery.easypiechart.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.sparkline.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/jquery.vmap.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.russia.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.world.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.europe.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.germany.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.usa.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/data/jquery.vmap.sampledata.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo base_url();?>assets/pages/scripts/dashboard.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo base_url();?>assets/layouts/layout3/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/layout3/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <script>
            $(document).ready(function()
            {
                $('#clickmewow').click(function()
                {
                    $('#radio1003').attr('checked', 'checked');
                });
            })
        </script>
    </body>

</html>