<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($pagetitle) ? $pagetitle : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		 <link href="<?php echo base_url();?>assets/layouts/layout3/css/copy_loc_popup.css" rel="stylesheet" type="text/css" />
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
		<div class="page-wrapper-row full-height">
			<div class="page-wrapper-middle">
				<!-- BEGIN CONTAINER -->
				<div class="page-container">
				<!-- BEGIN CONTENT -->
					<div class="page-content-wrapper">
						<!-- BEGIN CONTENT BODY -->
						<!-- BEGIN PAGE HEAD-->
						<div class="page-head">
							<div class="container">
								<!-- BEGIN PAGE TITLE -->
								<div class="page-title">
									<h1><?php echo $pagetitle; ?>
										<small><?php echo  $main_heading; ?></small>
									</h1>
								</div>
								<!-- END PAGE TITLE -->
								<!-- BEGIN PAGE TOOLBAR -->
								
								<!-- END PAGE TOOLBAR -->
							</div>
						</div>
						<!-- END PAGE HEAD-->
						<!-- BEGIN PAGE CONTENT BODY -->
						<div class="page-content">
							<div class="container">
<!-- BEGIN PAGE CONTENT INNER -->
<div class="page-content-inner">
	<div class="mt-content-body">
			<?php if((validation_errors()) || ($already_msg)):?>
			<div class="alert alert-danger">
				<button class="close" data-close="alert"></button>
				 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
			</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet light bordered">
						<div class="portlet-title">
							<div class="caption"> <i class=" fa fa-categorytype font-green-sharp"></i> <span class="caption-subject font-green-sharp bold uppercase"><?php echo $heading;?></span> </div>
							<!--<div class="actions">
								<div class="btn-categorytype">
											<a href="<?php echo base_url();?>backoffice/complaints/add" id="sample_editable_1_new" class="btn sbold green">
												<i class="fa fa-plus"></i> Create Complaint
											</a>
										</div>
							</div>-->
						</div>
						<div class="portlet-body">
							<!--<div id="copyLocPopup" style="display:none;">
								<div class="form-popup" id="popupForm">
									
									<?php  $attributes = array('class' => 'form-container ');
									 echo form_open(base_url().'employees/locations/reccpy/', $attributes);
									 ?>
										
									  <button type="button" class="btn cancel closeForm">Close</button>
									  
									<?php echo form_close(); ?>
									
							    </div>
							</div>-->
							<div class="table-toolbar">
							<?php 
							if($this->session->flashdata('success_message')){
							success_message($this->session->flashdata('success_message'));
							}
							?>    
							</div>
							<?php //$this->load->view("includes/notifications.php");?>
                                                <!-- BEGIN FILTER TABLE-->
												 <?php  $attributes = array('id' => 'form1','name' => 'form1','class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
                                                    echo form_open(base_url().'backoffice/complaints/', $attributes);
                                                  ?>
                                                <div class="portlet box blue-hoki">  
                                                    <div class="portlet-title">
                                                        <div class="caption">
                                                            <i class="fa fa-search"></i>Search </div>
                                                        <div class="tools">
                                                            <a href="javascript:;" class="expand"> </a>
                                                        </div>
                                                    </div>
                                                    <div class="portlet-body portlet-collapsed">
                                                        <div class="row">
                                                        
                                                        
                                                        <div class="col-md-2">
                                                            <label>Type</label>
														<?php
                                                            $complaint_type_array =  get_list_options('complaint_type','ASC'); 
                                                           
                                                            $selected = ($this->input->post('complaint_type')) ? $this->input->post('complaint_type') : $this->input->post('complaint_type');
                                                            echo form_dropdown('complaint_type', $complaint_type_array,  $selected,'id="complaint_type" class="form-control form-filter input-sm"  ');
                                                         ?>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <label>Department</label>
														   <?php
                                                            $fields = array('is_active'=>'1','language_id'=>$this->session->userdata('lang_id'));
                                                            $department_array = gettabledropdown('department',$fields,'department_id','department_name','department_name','ASC');
                                                            $selected = ($this->input->post('department_id')) ? $this->input->post('department_id') : $this->input->post('department_id');
                                                            echo form_dropdown('department_id', $department_array,  $selected,'id="department_id" class="form-control" ');
                                                             ?>
                                                        </div>
                                                        
                                                        <div class="col-md-2">
                                                            <label>Status</label>
														<?php
                                                            $complaint_status_array =  get_list_options('complaint_status','ASC'); 
                                                           
                                                            $selected = ($this->input->post('complaint_status')) ? $this->input->post('complaint_status') : $this->input->post('complaint_status');
                                                            echo form_dropdown('complaint_status', $complaint_status_array,  $selected,'id="complaint_status" class="form-control form-filter input-sm"  ');
                                                         ?>
                                                        </div>
                                                        
														
                                                        <div class="col-md-2">
                                                            <label>Keyword</label>
                                                                   <?php 
																     $data = array(
																	  'name'        => 'title',
																	 
																	  'value'       => set_value('title'),									
																	  'maxlength'   => '80',
																	  'placeholder'   => 'Enter any Keyword',
																	  'class'   => 'form-control form-filter input-sm',
                                                                      );
                                                                    echo form_input($data);
                                                                    ?>
                                                        </div>
                                                        
                                                       
                                                      
                                                        
                                                        
                                                    
                                                    </div>  
                                                        <div class="margin-top-10"><button class="btn btn-sm btn-success filter-submit margin-bottom"><i class="fa fa-search"></i> Search</button></div>
                                                    </div>
                                                </div>
                                                  <?php echo form_close(); ?>
							<div class="portlet box green">
                                                    <div class="portlet-title">
                                                        <div class="caption">
                                                            <i class="fa fa-users"></i><?php echo $heading; ?>: <?php echo '('.$num_rows.')'; ?>  </div>
                                                        <div class="tools"> </div>
                                                    </div>
                                                    <div class="portlet-body">
                                                        <div class="table-responsive">
														<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
								<thead>
									<tr>
										<th>Sr No.</th>
										<th>Type</th>
										<th>Department</th>
										<th>Title</th>
										<th width="20%">Description</th>
										<th>Image</th>
										<th>Audio</th>
										<th>Video</th>
										<th>Posted By</th>
										<th>Posted Date</th>
										<!--<th>Last Modified</th>-->
										<th>Status</th>
									</tr>
								</thead>
								<tbody>
								<?php if($results){ $srno=0;
									$complaint_status_array =  get_list_options('complaint_status','ASC'); 
									$complaint_type_array =  get_list_options('complaint_type','ASC'); 
									foreach($results as $rec){
									$srno++;
										
									$complaint_type = $complaint_type_array[$rec->complaint_type];
									$complaint_status = $complaint_status_array[$rec->complaint_status];
									$deptrow = get_table_info('department','department_id',$rec->department_id);
									?>
									<tr class="odd gradeX">
										<td><?php echo $srno;?></td>
										<td><?php echo $complaint_type;?></td>
										<td><?php echo $deptrow->department_name;?></td>
										<td> <?php echo ucfirst($rec->complaint_title);?></td>
										<td width="25%">
											<?php 
												echo limit_words($rec->complaint_description,15);
												if(str_word_count($rec->complaint_description)>15){
													?>
													<a class="label label-sm label-success openPopup" data-toggle="modal" value="<?php echo $rec->complaint_description; ?>" href="#lightboxresponsive">Read More</a>
													<?php
												}
											?>
										</td>
											
										<td><?php if($rec->image_file!='') { ?><a  class='imagelightbox' data-toggle="modal" href="#lightboxresponsive"><img src='<?php echo base_url();?>assets/complaints/image/<?php echo $rec->image_file; ?>' width='50'><?php } ?></a></td>
										<td width="18%" nowrap>  
											  <?php
											  if($rec->audio_file!=''){
											  ?>
										
												<audio  controls="controls" src="<?php echo base_url().'assets/complaints/audio/'.$rec->audio_file;?>"></audio>
										
											  
											  <?php
											  }
											  ?>
										</td>
										<td>  
											  <?php
											  if($rec->video_file!=''){
											  ?>
												<?php $video_id = get_youtube_video_id($rec->media_file_name); ?>
													<a class='videoplay' src="<?php echo base_url().'assets/complaints/video/'.$rec->video_file;?>" data-toggle="modal" href="#lightboxresponsive"><i class="fa fa-youtube-play youtube-play"></i></a>
											  <?php
											  }
											  ?>
										</td>
										<td><?php echo ucwords($rec->tourist_name); ?></td>
										 <td><?php echo date('d M, Y h:ia',strtotime($rec->created_on));?></td>
										 <td>
										<?php  if($rec->complaint_type=='1') 
											   { 
										
												if($rec->complaint_status=='1') { ?><a href="javascript:void(0);" class="label label-sm label-success"><?php echo $complaint_status;  ?></a>
												<?php } else { ?><a class="label label-sm label-danger" onclick="return confirm('Is complaint resolved?');" href="<?php echo base_url();?>backoffice/complaints/status/<?php echo $rec->complaint_id; ?>/1"><?php echo $complaint_status; ?> </a> <?php } ?><br /><br />
																	   
										<?php  } 	?>				 
										</td>
									</tr>
							   <?php } } else { echo "<td colspan='11'>".$this->lang->line('no_rec_found_text')."</td>"; } ?>   
								</tbody>
							</table>
							<span class='mypagination'><?php echo $links; ?></span>
							</div></div></div>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				</div>
			</div>
    
    </div>
</div>
<!-- END PAGE CONTENT INNER -->
							</div>
						</div>
						<!-- END PAGE CONTENT BODY -->
						<!-- END CONTENT BODY -->
					</div>
					<!-- END CONTENT -->
				</div>
				<!-- END CONTAINER -->
		</div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
    </body>
	<script>
	$(document).ready(function(){
		//alert();
		$('.openPopup').click(function(){
			var val=$(this).attr('value');
		    $('#lightboxresponsive .lightbox').html(val);
			return false();
		}); 
		/* $('.closeForm').click(function(){
			$('#copyLocPopup').hide();
		});  */
		  $('.videoplay').click(function(){
			   var video_link=$(this).attr('src');
			   $('#lightboxresponsive .lightbox').html('<iframe width="564" height="400" src="'+video_link+'"></iframe>');
		   });
	});

	  // When the user clicks anywhere outside of the modal, close it
	  /* window.onclick = function(event) {
		var modal = document.getElementById('copyLocPopup');
		if (event.target == modal) {
		  closeForm();
		}
	  } */
    </script>
</html>