<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD --><head>
        <meta charset="utf-8" />
        <title><?php echo $this->lang->line('text_title_header'); ?></title>
        <?php $this->load->view("includes/styles.php");?></head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                    <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
                        <!-- BEGIN CONTENT -->
                        <div class="page-content-wrapper">
                            <!-- BEGIN CONTENT BODY -->
                            <!-- BEGIN PAGE HEAD-->
                            <div class="page-head">
                                <div class="container">
                                    <!-- BEGIN PAGE TITLE -->
                                    <div class="page-title">
                                        <h1>Dashboard
                                            <small>Dashboard & Statistics</small>
                                        </h1>
                                    </div>
                                    <!-- END PAGE TITLE -->
                                    <!-- BEGIN PAGE TOOLBAR -->
                                    <?php //$this->load->view("includes/toolbar.php");?>
                                    <!-- END PAGE TOOLBAR -->
                                </div>
                            </div>
                            <!-- END PAGE HEAD-->
                            <!-- BEGIN PAGE CONTENT BODY -->
                            <div class="page-content">
                                <div class="container">
                                    <!-- BEGIN PAGE BREADCRUMBS -->
                                    <ul class="page-breadcrumb breadcrumb">
                                        <li>
                                            <a href="<?php echo base_url();?>backoffice/dashboard">Dashboard</a>
                                            <i class="fa fa-circle"></i>
                                        </li>
                                        <li>
                                            <span>Dashboard</span>
                                        </li>
                                    </ul>
                                    <!-- END PAGE BREADCRUMBS -->
                                    <!-- BEGIN PAGE CONTENT INNER -->
                                    <div class="page-content-inner">
                                        <div class="mt-content-body">
										<?php
											$user_type = $this->session->userdata('user_type');
												if ($user_type=='A') {
										?>
										
											<hr style="border:1px solid black;"/>
											<h2 style="text-align:center;text-decoration:underline;">Admin</h2>
											<div class="row">
												<h3>Employees</h3>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a href='<?php echo base_url(); ?>backoffice/users/view' class="color-demo tooltips"  style="text-decoration: none;" >
                                                            <div class="color-view bg-blue-oleo bg-font-blue-oleo bold uppercase"> <?php echo $count_employees; ?></div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Employees </div>
                                                        </a>
													</div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a href='<?php echo base_url(); ?>backoffice/designation' class="color-demo tooltips"  style="text-decoration: none;" >
                                                            <div class="color-view bg-blue bg-font-blue bold uppercase"> <?php echo $countdesignation; ?></div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Designations </div>
                                                        </a>
													</div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a href='<?php echo base_url(); ?>backoffice/department' class="color-demo tooltips"  style="text-decoration: none;" >
                                                            <div class="color-view bg-blue-hoki bg-font-blue-hoki bold uppercase"><?php echo $countdepartment; ?></div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Departments </div>
                                                        </a>
													</div>
                                                    
                                                    
                                                    <div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a href='<?php echo base_url(); ?>backoffice/complaints' class="color-demo tooltips"  style="text-decoration: none;" >
                                                            <div class="color-view bg-blue-sharp bg-font-blue-sharp bold uppercase"><?php echo $totalcomplaints; ?></div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Complaints/Feedbacks </div>
                                                        </a>
													</div>
                                                    
											        <div class="col col-md-12">
													    <div class="btn btn-default synchronise">Synchronise</div>
													</div>
													
											</div>
											<hr style="border:1px solid black;"/>
											
											<div class="row">
												<h3>Locations</h3>
												<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/categorytypes">
                                                            <div class="color-view bg-blue-sharp bg-font-blue-sharp bold uppercase"> <?php echo $countLocationCategoryTypes; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase">Category Types </div>
                                                        </a>
                                                       
                                                    </div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/categories">
                                                            <div class="color-view bg-blue-chambray bg-font-blue-chambray bold uppercase"> <?php echo $countLocationCategories; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase">Categories </div>
                                                        </a>
                                                       
                                                    </div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>employees/locations/view">
                                                            <div class="color-view bg-blue-dark bg-font-blue-dark bold uppercase"> <?php echo $count_locations; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Locations </div>
                                                        </a>
                                                       
                                                    </div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/quiz/view">
                                                             <div class="color-view bg-blue-chambray bg-font-blue-chambray bold uppercase">
															 <?php echo $count_quiz; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Quizzes </div>
                                                        </a>
                                                        
                                                    </div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/beacons/view">
                                                            <div class="color-view bg-blue-hoki bg-font-blue-hoki bold uppercase"> <?php echo $count_beacons; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Beacons </div>
                                                        </a>
                                                        
                                                    </div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/soundfiles">
                                                            <div class="color-view bg-blue bg-font-blue bold uppercase"> <?php echo $count_soundfiles; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Sound Files </div>
                                                        </a>
                                                        
                                                    </div>
													
											</div>
											
											<div class="row">
												<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/areas">
                                                            <div class="color-view bg-dark bg-font-dark bold uppercase"> <?php echo $count_areas; ?></div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Areas </div>
                                                        </a>
                                                        
                                                    </div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/filters/view">
                                                            <div class="color-view bg-blue-madison bg-font-blue-madison bold uppercase"> <?php echo $count_filters; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Filters </div>
                                                        </a>
                                                        
                                                    </div>
											</div>
											<hr style="border:1px solid black;"/>
											<div class="row">
												<h3>Tourists</h3>
												<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a href='<?php echo base_url(); ?>backoffice/regusers/view' class="color-demo tooltips"  style="text-decoration: none;" >
                                                            <div class="color-view bg-blue-soft bg-font-blue-soft bold uppercase"> <?php echo $count_users; ?></div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase "> Users </div>
                                                        </a>
													</div>
													
											</div>
											<hr style="border:1px solid black;"/>
											<div class="row">
												<h3>Blogs</h3>
													
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/blogcategories">
                                                            <div class="color-view bg-blue-ebonyclay bg-font-blue-ebonyclay bold uppercase"> <?php echo $countBlogCategories; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Categories </div>
                                                        </a>
                                                        
														
                                                    </div>
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/blogs">
                                                            <div class="color-view bg-blue-ebonyclay bg-font-blue-ebonyclay bold uppercase"> <?php echo $countBlogs; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Blogs </div>
                                                        </a>
                                                        
                                                    </div>
												
													
													
											</div>
											<hr style="border:1px solid black;"/>
											<div class="row">
												<h3>Tours</h3>
													 
													
													<div class="col-md-2 col-sm-2 col-xs-6">
                                                        <a class="color-demo tooltips"  style="text-decoration: none;"  href="<?php echo base_url(); ?>backoffice/tours">
                                                            <div class="color-view bg-blue-steel bg-font-blue-steel bold uppercase"> <?php echo $countTours; ?> </div>
                                                            <div class="color-info bg-white c-font-14 sbold uppercase"> Tours </div>
                                                        </a>
                                                        
                                                    </div>
													
                                                    
                                                   
                                                    
											</div>
											<hr style="border:1px solid black;"/>
										<?php } ?>		
                                        </div>
                                    </div>
                                    <!-- END PAGE CONTENT INNER -->
                                </div>
                            </div>
                            <!-- END PAGE CONTENT BODY -->
                            <!-- END CONTENT BODY -->
                        </div>
                        <!-- END CONTENT -->
                        <!-- BEGIN QUICK SIDEBAR -->
                       <?php $this->load->view("includes/sidebar.php");?>
                        
                        <!-- END QUICK SIDEBAR -->
                    </div>
                    <!-- END CONTAINER -->
                </div>
            </div>
           <?php $this->load->view("includes/footer.php");?>
        </div>
        <!-- BEGIN QUICK NAV -->
        <?php $this->load->view("includes/quicknav.php");?>
        <!-- END QUICK NAV -->
        <!--[if lt IE 9]>
<script src="<?php echo base_url();?>assets/global/plugins/respond.min.js"></script>
<script src="<?php echo base_url();?>assets/global/plugins/excanvas.min.js"></script> 
<script src="<?php echo base_url();?>assets/global/plugins/ie8.fix.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/moment.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-daterangepicker/daterangepicker.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/morris/morris.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/morris/raphael-min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/counterup/jquery.waypoints.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/counterup/jquery.counterup.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/fullcalendar/fullcalendar.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/flot/jquery.flot.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/flot/jquery.flot.resize.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/flot/jquery.flot.categories.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-easypiechart/jquery.easypiechart.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.sparkline.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/jquery.vmap.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.russia.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.world.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.europe.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.germany.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/maps/jquery.vmap.usa.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jqvmap/jqvmap/data/jquery.vmap.sampledata.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo base_url();?>assets/pages/scripts/dashboard.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo base_url();?>assets/layouts/layout3/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/layout3/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/layouts/global/scripts/quick-nav.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        <script>
            $(document).ready(function()
            {
                $('#clickmewow').click(function()
                {
                    $('#radio1003').attr('checked', 'checked');
                });
                $('.synchronise').click(function()
                {
                    
                    var txt;
var r = confirm("Are you sure want to update version?");
if (r == true) {
    
  $.ajax({
			    url: "<?php echo base_url();?>ajaxrequest/synchronise",
			    type: "POST",
			    data: {
				   category_id: 1,
			   },
			   async:false,
			   dataType: "JSON",
			   success: function (jsonStr) {
					
                alert('Version is updated.');
                location.reload();
			   }
		   });
		   
} else {
  //txt = "You pressed Cancel!";
}
                    
        return false;            
                    
                    
                    
                });
            })
        </script>
    </body>

</html>