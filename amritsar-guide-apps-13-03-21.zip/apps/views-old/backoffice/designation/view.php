<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
		<div class="page-wrapper-row full-height">
			<div class="page-wrapper-middle">
				<!-- BEGIN CONTAINER -->
				<div class="page-container">
				<!-- BEGIN CONTENT -->
					<div class="page-content-wrapper">
						<!-- BEGIN CONTENT BODY -->
						<!-- BEGIN PAGE HEAD-->
						<div class="page-head">
							<div class="container">
								<!-- BEGIN PAGE TITLE -->
								<div class="page-title">
									<h1><?php echo $title; ?>
										<small><?php echo  $short_desc; ?></small>
									</h1>
								</div>
								<!-- END PAGE TITLE -->
								<!-- BEGIN PAGE TOOLBAR -->
								
								<!-- END PAGE TOOLBAR -->
							</div>
						</div>
						<!-- END PAGE HEAD-->
						<!-- BEGIN PAGE CONTENT BODY -->
						<div class="page-content">
							<div class="container">
								<!-- BEGIN PAGE BREADCRUMBS -->
								<!--<ul class="page-breadcrumb breadcrumb">
									<li>
										<a href="index.html">Home</a>
										<i class="fa fa-circle"></i>
									</li>
									<li>
										<span>Designation</span>
									</li>
								</ul>-->
								<!-- END PAGE BREADCRUMBS -->
<!-- BEGIN PAGE CONTENT INNER -->
<div class="page-content-inner">
	<div class="mt-content-body">
			<?php if((validation_errors()) || ($already_msg)):?>
				<div class="alert alert-danger">
					<button class="close" data-close="alert"></button>
					 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
				</div>
			<?php endif; ?>
			<div class="row add_designation">
				<div class="col-md-12">
					
					 <div class="portlet box green">
						<!--<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-gift"></i><?php echo $heading; ?> </div>
						</div>-->
						
						<div class="portlet-body">
							
							<div class="row ">
				
								<div class="col-md-12">
								  <?php  $attributes = array('id' => 'designation','class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
										 echo form_open_multipart(base_url().'backoffice/designation', $attributes);
								  ?>
											<div class="form-body">
												<div class="form-group">
													<label class="col-md-1 control-label">Designation</label>
													 <div class="col-md-2"> 
													 <?php $data = array(
													  'name'        => 'designation_name',
													  'id'          => 'designation_name',	
													  'value'       => set_value('designation_name'),								
													  'maxlength'   => '255',
													  'class'   => 'form-control',
													  'required'   => 'required',
													  );
													  echo form_input($data);
													?>
													</div>
													
													
													<div class="form-actions">	
														<div class="mt-5 col-md-2">
															<button type="submit" class="btn green" value="Submit">Submit</button>
														</div>
													 </div>
												</div>
												
											</div>
								<?php echo form_close(); ?>
								</div>
							</div>
						</div>
					</div>
			  </div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<?php $this->load->view("includes/notifications.php");?>
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet light bordered">
						
						<div class="portlet-body">
							<a class="btn btn-square btn-sm green todo-bold add_designation_button" data-toggle="modal" href="<?php echo base_url() ?>backoffice/designation">Add Designation</a>
							<?php 
								$attributes = array('id' => 'form_zone','class' => 'form-horizontal','role' => 'form');
								echo form_open(base_url().'backoffice/designation', $attributes); 
							?>
							<!--<span class='p-right'>
								<input type="text" value="<?php //if($search_keyword!='') { echo $search_keyword; } ?>" class="form-control form-filter input-sm" name="search_keyword">
								<button class="btn btn-sm green btn-outline filter-submit margin-bottom">
									<i class="fa fa-search"></i> Search
								</button>
							</span>-->
							<?php echo form_close(); ?>
	
						<div class="portlet-body">
							<table class="table table-striped table-bordered table-hover table-header-fixed" id="sample_1">
								<thead>
									<tr class="">
										<th nowrap> Sr. No. </th>
										<th nowrap> Designation </th>
										<th nowrap> Status </th>
										<th nowrap> Action</th>
									</tr>
								</thead>
								<tbody>
									 <?php 
									
									  if(!empty($results))
									  { 
										 $srno=0; 
										 foreach($results as $row) {
										 $srno++;
									  ?>
									<tr>
										<td nowrap><?php echo $srno; ?></td>
										<td nowrap><?php echo ucfirst($row->designation_name); ?></td>
										<td><?php if($row->is_active=='1') {?><a class="label label-sm label-success" onclick="return confirm('Do you want to de-activate?');" href="<?php echo base_url();?>backoffice/designation/status/<?php echo $row->designation_id; ?>/0">Activate</a>
										
										<?php } else { ?>
										
										<a class="label label-sm label-danger" onclick="return confirm('Do you want to activate?');" href="<?php echo base_url();?>backoffice/designation/status/<?php echo $row->designation_id; ?>/1">De-activate </a> <?php } ?></td>
																	 
										<td nowrap> <a href="<?php echo base_url();?>backoffice/designation/edit/<?php echo $row->designation_id; ?>" title="Edit"><i class="fa fa-edit"></i></a></td>                                                   
									</tr>
								   <?php 
									  } 
									} else { ?>
									<tr><td colspan='12'><?php echo $this->lang->line('no_rec_found_text'); ?></td></tr>
									<?php } ?>
								</tbody>
							</table>
							</div>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				   
				</div>
			</div>
		
		
	</div>
</div>
<!-- END PAGE CONTENT INNER -->
							</div>
						</div>
						<!-- END PAGE CONTENT BODY -->
						<!-- END CONTENT BODY -->
					</div>
					<!-- END CONTENT -->
				</div>
				<!-- END CONTAINER -->
			</div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
    </body>

</html>
 
		<script type="text/javascript">

		
	   $(document).ready(function(){
		 
		 $('.add_designation').hide();
			$('.dt-buttons').hide();
		  <?php if((validation_errors()) || ($already_msg)){?>
			$('.add_designation').show();
		  <?php } ?>
		  
		  $(".add_designation_button").click(function(){
			$('.add_designation').show();
			$('.alert-success').hide();
			return false;
		  });
	   });

</script>
 