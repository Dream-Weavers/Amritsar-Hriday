<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
					<!-- BEGIN CONTENT -->
						<div class="page-content-wrapper">
							<!-- BEGIN CONTENT BODY -->
							<!-- BEGIN PAGE HEAD-->
							<div class="page-head">
								<div class="container">
							<!-- BEGIN PAGE TITLE -->
									<div class="page-title">
										<h1><?php echo $this->lang->line('edit_designation_name'); ?></h1>
									</div>
									<!-- END PAGE TITLE -->
								</div>
							</div>
							<!-- END PAGE HEAD-->
							<!-- BEGIN PAGE CONTENT BODY -->
							<div class="page-content">
								<div class="container">
									<!-- BEGIN PAGE BREADCRUMBS -->
									<!--<ul class="page-breadcrumb breadcrumb">
										<li>
											<a href="index.html">Home</a>
											<i class="fa fa-circle"></i>
										</li>
										<li>
											<span>Tutors</span>
										</li>
									</ul>-->
									<!-- END PAGE BREADCRUMBS -->
									<!-- BEGIN PAGE CONTENT INNER -->
									<div class="page-content-inner">
										<div class="mt-content-body">
											<div class="row">
								<?php if((validation_errors()) || ($already_msg)):?>
								<div class="alert alert-danger">
									<button class="close" data-close="alert"></button>
									 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
								</div>
								<?php endif; ?>
								<div class="col-md-12">
								  <?php  $attributes = array('id' => 'designation','class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
										 echo form_open_multipart(base_url().'backoffice/designation/edit/'.$edit_data->designation_id, $attributes);
								  ?>
											<div class="form-body">
												<div class="form-group">
													<label class="col-md-1 control-label">Designation</label>
													 <div class="col-md-2"> 
													 <?php $data = array(
													  'name'        => 'designation_name',
													  'id'          => 'designation_name',	
													  'value'       => $edit_data->designation_name,								
													  'maxlength'   => '255',
													  'class'   => 'form-control',
													  'required'   => 'required'
													  );
													  echo form_input($data);
													?>
													</div>
												 
											    </div>
											</div>
											<div class="form-actions">
												<div class="col-md-4"></div>
												<div class="col-md-4">
													<button type="submit" class="btn green" value="Submit">Submit</button>
													<input type="reset" class="btn default" name="Reset" value="Reset">
													<a class="btn default" href='<?php echo base_url() ?>backoffice/designation/'>Back</a>
												</div>
												<div class="col-md-4"></div>
										   </div>
								<?php echo form_close(); ?>
								   
								</div>
							</div>
										   
										
											
										</div>
									</div>
									<!-- END PAGE CONTENT INNER -->
								</div>
							</div>
							<!-- END PAGE CONTENT BODY -->
							<!-- END CONTENT BODY -->
						</div>
						<!-- END CONTENT -->
                
                    </div>
                    <!-- END CONTAINER -->
               </div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
    </body>

</html>
		
        <!-- BEGIN CORE PLUGINS -->
		<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
        
		<script type="text/javascript">

		
	   $(document).ready(function(){
		 $('#country_id').bind('change', function () {
			var country_id=$(this).val();

			var state_id=$("#state_id").val();
			if(country_id === null){ 
				var country_id=<?php echo $edit_data->country_id; ?>;
			}
			if(state_id=== null || state_id==''){ 
				var state_id=<?php echo $edit_data->state_id; ?>;
			}else{
				var state_id=0;
			}
			get_state(country_id,state_id);
		});
		//$('#country_id').trigger('change');
			
			
		$('#state_id').bind('change', function () {
			var state_id=$(this).val();
			var city_id=$("#city_id").val();
			if(state_id === null){ 
				var state_id=<?php echo $edit_data->state_id; ?>;
			}
			if(city_id=== null || city_id==''){ 
				var city_id=<?php echo $edit_data->city_id; ?>;
			}else{
				var city_id=0;
			} 
			get_city(state_id,city_id);
		});
		//$('#state_id').trigger('change'); 
		
		$('#city_id').bind('change', function () {
			
			var city_id=$(this).val();
			var locality_id=$("#locality_id").val();
			if(city_id === null){ 
				var city_id=<?php echo $edit_data->city_id; ?>;
			}
			if(locality_id=== null || locality_id==''){ 
				var locality_id=<?php echo$edit_data->locality_id; ?>;
			}else{
				var locality_id=0;
			}
			get_locality(city_id,locality_id);
		});
		//$('#city_id').trigger('change'); 
		
	});
				  
	  
		 function get_state(country_id,state_id){
			$('#state_id').html('');
			var get_val=country_id;
			$("#state_id").find('option').remove();
			$.get('<?php echo base_url();?>ajaxrequest/get_states/'+get_val, function( data ) {
				var obj = jQuery.parseJSON(data);
				$('#state_id').append($("<option></option>").attr("value",'').text('Select State'));
				$.each(obj, function(idx, obj1) {
					var state_name=obj1.state_name;
					var state_id=obj1.state_id;
					$('#state_id').append($("<option></option>").attr("value",state_id).text(state_name)); 
				});
				$('#state_id option[value='+state_id+']').attr("selected", "selected");
			});
		 }
	 
	   function get_city(state_id,city_id){
		$('#city_id').html('');
		var get_val=state_id;
		$("#city_id").find('option').remove();
		$.get('<?php echo base_url();?>ajaxrequest/get_cities/'+get_val, function( data ) {
			var obj = jQuery.parseJSON(data);
			$('#city_id').append($("<option></option>").attr("value",'').text('Select City'));
			$.each(obj, function(idx, obj1) {
				var city_name=obj1.city_name;
				var city_id=obj1.city_id;
				//alert(city_name);
				$('#city_id').append($("<option></option>").attr("value",city_id).text(city_name)); 
			});
			$('#city_id option[value='+city_id+']').attr("selected", "selected");
		});
	 } 
	 
	  function get_locality(city_id,locality_id){
		$('#locality_id').html('');
		var get_val=city_id;
		$("#locality_id").find('option').remove();
		$.get('<?php echo base_url();?>ajaxrequest/get_localities/'+get_val, function( data ) {
			var obj = jQuery.parseJSON(data);
			$('#locality_id').append($("<option></option>").attr("value",'').text('Select Locality'));
			$.each(obj, function(idx, obj1) {
				var locality_name=obj1.locality_name;
				var locality_id=obj1.locality_id;
				//alert(locality_name);
				$('#locality_id').append($("<option></option>").attr("value",locality_id).text(locality_name)); 
			});
			$('#locality_id option[value='+locality_id+']').attr("selected", "selected");
		});
	 }  
             
$data['custom_js'] = array('assets/global/plugins/datatables/datatables.min.js','assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js','assets/pages/scripts/table-datatables-managed.min.js');
</script>
</body>    