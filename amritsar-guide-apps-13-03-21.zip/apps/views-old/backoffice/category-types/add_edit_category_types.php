<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		 <link rel="stylesheet" href="<?php echo base_url();?>assets/global/plugins/cropimage/css/croppie.css">
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
					<!-- BEGIN CONTENT -->
						<div class="page-content-wrapper">
							<!-- BEGIN CONTENT BODY -->
							<!-- BEGIN PAGE CONTENT BODY -->
							<div class="page-content">
								<div class="container">
									<!-- BEGIN PAGE BREADCRUMBS -->
									<!--<ul class="page-breadcrumb breadcrumb">
										<li>
											<a href="index.html">Home</a>
											<i class="fa fa-circle"></i>
										</li>
										<li>
											<span>Tutors</span>
										</li>
									</ul>-->
									<!-- END PAGE BREADCRUMBS -->
									<!-- BEGIN PAGE CONTENT INNER -->
									<div class="page-content-inner">
										<div class="mt-content-body">
											<div class="row w_block_image532">

												<div class="col-md-12 text-center">

													<div id="preview_w_block_image532" ></div>
													<button class="btn btn-success upload_result_w_block_image532">Upload Image</button><br />
												</div>
												
											</div>
											<div class="row w_block_image1600">

												<div class="col-md-12 text-center">

													<div id="preview_w_block_image1600" ></div>
													<button class="btn btn-success upload_result_w_block_image1600">Upload Image</button><br />
												</div>
												
											</div>
										    <div class="row">
													<div class="col-md-12">
														
														 <div class="portlet box green">
															<div class="portlet-title">
																<div class="caption">
																	<i class="fa fa-gift"></i><?php echo $heading; ?> </div>
															</div>
															<div class="portlet-body">
																<div class="row">
																	
											<div class="col-md-12">
											  <?php  $attributes = array('class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
													if($category_type_id==0)
													 echo form_open_multipart(base_url().'backoffice/Categorytypes/add', $attributes);
													else
													echo form_open_multipart(base_url().'backoffice/categorytypes/edit/'.$category_type_id, $attributes);
											  ?>
											<div class="form-body">
											 <?php if((validation_errors()) || ($already_msg)):?>
											<div class="alert alert-danger">
												<button class="close" data-close="alert"></button>
												 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
											</div>
											<?php endif; ?>
													
													<div class="form-group">
														<label class="col-md-1 control-label"><?php echo $this->lang->line('category_type_select_project'); ?></label>
														<div class="col-md-2"> 
														 <?php
															$project=array();
															$selected=$project_id;
															$project['']="Select Project";
															$projects=fetch_projects();
															foreach($projects as $key=>$value){
																$project[$value->project_id]=ucfirst($value->project_name);
															}

															 
															echo form_dropdown('project_id', $project,$selected,'id="project_id" class="form-control" required'); 
														 ?>
														 
														</div>
														
														<label class="col-md-1 control-label"><?php echo $this->lang->line('category_type_select_name'); ?></label>
														 <div class="col-md-2"> 
														 <?php $data = array(
														  'name'        => 'category_type',
														  'value'       => $category_type,								
														  'maxlength'   => '255',
														  'class'   => 'form-control',
														  'required'   => 'required',
														  );
														echo form_input($data);
														?>
														</div>
														
														
														
														<label class="col-md-1 control-label"><?php echo $this->lang->line('category_type_description'); ?></label>
														 <div class="col-md-3"> 
															 <?php $data = array(
															  'name'        => 'description',
															  'id'          => 'description',	
															  'value'       => $description,
															  'rows'       => 5,
															  'cols'       => 10,
															  'maxlength'   => '255',
															  'class'   => 'form-control',
															  'required'   => 'required',
															  );
															echo form_textarea($data);
															?>
														 </div>
													</div>
													<hr />
													<div class="row">
														<div class="col-md-6">
															<span class="label label-success">NOTE!</span> Attached image format JPG,PNG,JPEG 
														</div>
													</div>
													
													<div class="row">
														
														<div class="col-md-12">
															<hr />
															<h3>Web Images</h3>
															<hr />
															<div class="col-md-12">
																<label class="control-label col-md-1">Upload(532x460)</label>
																<div class="col-md-2">
																	<span class="btn btn-outline btn-file">
																	<span class="fileinput-new"> <?php echo $this->lang->line('photo_choose_text'); ?></span>
																		
																	<input id="w_image532" type="file" name="w_image532"> </span>
																</div>
																<?php if($w_image532!='') { ?>
																<div class="col-md-2"></div>
																<div class="col-md-4">
																	<a  class='imagelightbox' data-toggle="modal" href="#lightboxresponsive"><img src='<?php echo base_url();?>images/categorytype-icons/532x460/<?php echo $w_image532; ?>' width='100'></a>
																</div>
																<?php } ?>
															</div>
															&nbsp <hr />
															<div class="col-md-12">
																<label class="control-label col-md-1">Upload(1600x740)</label>
																<div class="col-md-2">
																	<span class="btn btn-outline btn-file">
																	<span class="fileinput-new"> <?php echo $this->lang->line('photo_choose_text'); ?></span>
																		
																	<input id="w_image1600" type="file" name="w_image1600"> </span>
																</div>
																<?php if($w_image1600!='') { ?>
																<div class="col-md-2"></div>
																<div class="col-md-4">
																	<a  class='imagelightbox' data-toggle="modal" href="#lightboxresponsive"><img src='<?php echo base_url();?>images/categorytype-icons/1600x740/<?php echo $w_image1600; ?>' width='100'></a>
																</div>
																<?php } ?>
															</div>
														</div>
														
													</div>
													<hr />
													<!--<div class="row">
														
														<div class="col-md-12">
                                                   
															<h3>App Images</h3>
															
															
															<label class="control-label col-md-1">Upload(532x460)</label>
															<div class="col-md-2">
																<span class="btn btn-outline btn-file">
																<span class="fileinput-new"> <?php echo $this->lang->line('photo_choose_text'); ?></span>
																	
																<input id="upload" type="file" name="categorytype_icon"> </span>
															</div>
															
															<label class="control-label col-md-1">Upload(1600x740)</label>
															<div class="col-md-2">
																<span class="btn btn-outline btn-file">
																<span class="fileinput-new"> <?php echo $this->lang->line('photo_choose_text'); ?></span>
																	
																<input id="upload" type="file" name="categorytype_icon"> </span>
															</div>
														</div>
														
													</div>
													<hr />-->
                                                     <div class="row"><div class="col-md-6"><h4>Category Type Interlinks:</h4></div></div>
                                                     
                                                     <div class="row">
                                                       <div class="col-md-2">
                                                       <div class='md-checkbox'><input class="md-check" type='checkbox'  name="location_link" id="location_link" value="1" <?php if($edit_data->location_link=='1'): echo 'checked="checked"'; endif; ?>><label for="location_link"><span></span><span class='check'></span><span class='box'></span>Locations</label></div>
                                                       <div class='md-checkbox'><input  class="md-check" type='checkbox'  name="vendor_link" id="vendor_link" value="1" <?php if($edit_data->vendor_link=='1'): echo 'checked="checked"'; endif; ?>><label for="vendor_link" ><span></span><span class='check'></span><span class='box'></span>Vendor</label></div>
                                                       
                                                       <div class='md-checkbox'><input  class="md-check" type='checkbox'  name="product_link" id="product_link" value="1" <?php if($edit_data->product_link=='1'): echo 'checked="checked"'; endif; ?>><label for="product_link" ><span></span><span class='check'></span><span class='box'></span>Products</label></div>
                                                       
                                                       </div>
                                                       
                                                       
                                                       
                                                       
                                                </div>
                                                
													<h4><?php echo $this->lang->line('category_type_surveyor_limit_column'); ?></h4>
													<hr />
													<div class="form-group">
														<label class="col-md-1 control-label"> <?php echo $this->lang->line('category_type_picture_limit_column'); ?></label>
														<div class="col-md-1"> 
														 <?php $data = array(
														  'name'        => 'picture_min_limit',
														  'value'       => $picture_min_limit,
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => $this->lang->line('Minimum_Limit'),
														  );
														echo form_input($data);
														?>
														</div>
														<div class="col-md-1"> 
														 <?php $data = array(
														  'name'        => 'picture_max_limit',
														  'value'       => $picture_max_limit,
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => $this->lang->line('Maximum_Limit'),
														  );
														echo form_input($data);
														?>
														</div>
														<label class="col-md-1 control-label"> <?php echo $this->lang->line('category_type_videos_limit_column'); ?></label>
														<div class="col-md-1"> 
														 <?php $data = array(
														  'name'        => 'video_min_limit',
														  'value'       => $video_min_limit,
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   =>$this->lang->line('Minimum_Limit'),
														  );
														echo form_input($data);
														?>
														</div>
														<div class="col-md-1"> 
														 <?php $data = array(
														  'name'        => 'video_max_limit',
														  'value'       => $video_max_limit,
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => $this->lang->line('Maximum_Limit'),
														  );
														echo form_input($data);
														?>
														</div>
														<label class="col-md-1 control-label"> <?php echo $this->lang->line('category_type_panorama_limit_column'); ?></label>
														<div class="col-md-1"> 
														 <?php $data = array(
														  'name'        => 'panorama_min_limit',
														  'value'       => $panorama_min_limit,
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => $this->lang->line('Minimum_Limit'),
														  );
														echo form_input($data);
														?>
														</div>
														<div class="col-md-1"> 
														 <?php $data = array(
														  'name'        => 'panorama_max_limit',
														  'value'       => $panorama_max_limit,
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => $this->lang->line('Maximum_Limit'),
														  );
														echo form_input($data);
														?>
														</div>
														<label class="col-md-1 control-label"> <?php echo $this->lang->line('category_type_audio_limit_column'); ?></label>
														<div class="col-md-1"> 
														 <?php $data = array(
														  'name'        => 'audio_min_limit',
														  'value'       => $audio_min_limit,
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => $this->lang->line('Minimum_Limit'),
														  );
														echo form_input($data);
														?>
														</div>
														<div class="col-md-1"> 
														 <?php $data = array(
														  'name'        => 'audio_max_limit',
														  'value'       => $audio_max_limit,
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => $this->lang->line('Maximum_Limit'),
														  );
														echo form_input($data);
														?>
														</div>
													</div>
											  </div>
													
											  <div class="form-actions">
													<div class="row">
														<div class="col-md-offset-5 col-md-4">
															<button type="submit" class="btn green" value="<?php echo $this->lang->line('submit_button_text'); ?>"><?php echo $this->lang->line('submit_button_text'); ?></button>
															
															<a class="btn default" href='<?php echo base_url() ?>backoffice/categorytypes/'><?php echo $this->lang->line('back_button_text'); ?></a>
														</div>
													</div>
											   </div>
															
												<?php echo form_close(); ?>
												</div>
																</div>
															</div>
														</div>
														
														
													</div>
													
												</div>
											
										</div>
									</div>
									<!-- END PAGE CONTENT INNER -->
								</div>
							</div>
							<!-- END PAGE CONTENT BODY -->
							<!-- END CONTENT BODY -->
						</div>
						<!-- END CONTENT -->
                    </div>
                    <!-- END CONTAINER -->
               </div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
		<script src="<?php echo base_url();?>assets/global/plugins/cropimage/js/croppie.js" type="text/javascript"></script>
		<script type="text/javascript">

$uploadCrop1 = $('#preview_w_block_image532').croppie({

    enableExif: true,

    viewport: {

		 width: 532,

		 height: 460,
			
        type: 'square'

    },

    boundary: {

        width: 1000,

        height: 800

    }

});

     
$uploadCrop2 = $('#preview_w_block_image1600').croppie({

    enableExif: true,

    viewport: {

		 width: 1600,

		 height: 740,
			
        type: 'square'

    },

    boundary: {

        width: 2000,

        height: 1000

    }

});


$('#w_image532').on('change', function () { 
	$('.w_block_image532').show();
	$('.w_block_image1600').hide();
	var reader = new FileReader();

    reader.onload = function (e) {

    	$uploadCrop1.croppie('bind', {

    		url: e.target.result

    	}).then(function(){

    		console.log('jQuery bind complete');

    	});

    	    

    }

    reader.readAsDataURL(this.files[0]);

});

$('#w_image1600').on('change', function () { 
	$('.w_block_image1600').show();
	$('.w_block_image532').hide();
	var reader = new FileReader();

    reader.onload = function (e) {

    	$uploadCrop2.croppie('bind', {

    		url: e.target.result

    	}).then(function(){

    		console.log('jQuery bind complete');

    	});

    	    

    }

    reader.readAsDataURL(this.files[0]);

});     

$('.upload_result_w_block_image532').on('click', function (ev) {
	
	$uploadCrop1.croppie('result', {

		type: 'canvas',

		size: 'viewport'

	}).then(function (resp) {

     
		$.ajax({

			url: "<?php echo base_url();?>backoffice/Categorytypes/cropped_image532",

			type: "POST",

			data: {"image":resp},
			
			success: function (data) {
				
				$('.w_block_image532').hide();

			}

		});

	});

});

$('.upload_result_w_block_image1600').on('click', function (ev) {
	
	$uploadCrop2.croppie('result', {

		type: 'canvas',

		size: 'viewport'

	}).then(function (resp) {

     
		$.ajax({

			url: "<?php echo base_url();?>backoffice/Categorytypes/cropped_image1600",

			type: "POST",

			data: {"image":resp},
			
			success: function (data) {
				
				$('.w_block_image1600').hide();

			}

		});

	});

});   

</script>
    </body>

</html>