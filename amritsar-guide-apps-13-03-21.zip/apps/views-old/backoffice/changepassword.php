<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
					<!-- BEGIN CONTENT -->
						<div class="page-content-wrapper">
							<!-- BEGIN CONTENT BODY -->
							<!-- BEGIN PAGE CONTENT BODY -->
							<div class="page-content">
								<div class="container">
									<!-- BEGIN PAGE BREADCRUMBS -->
									<!--<ul class="page-breadcrumb breadcrumb">
										<li>
											<a href="index.html">Home</a>
											<i class="fa fa-circle"></i>
										</li>
										<li>
											<span>Tutors</span>
										</li>
									</ul>-->
									<!-- END PAGE BREADCRUMBS -->
									<!-- BEGIN PAGE CONTENT INNER -->
									<div class="page-content-inner">
										<div class="mt-content-body">
											<div class="row">
													<?php $this->load->view('backoffice/layout/notifications'); ?>
													<div class="col-md-12">
														
														 <div class="portlet box green">
														 
															<div class="portlet-title">
																<div class="caption">
																	<i class="fa fa-gift"></i><?php echo $heading; ?> </div>
															</div>
															<div class="portlet-body">
																<div class="row">
																	
											<div class="col-md-12">
											  <?php  $attributes = array('id' => 'users','class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
													 echo form_open_multipart(base_url().'backoffice/changepassword', $attributes);
											  ?>
											<div class="form-body">
											 
											
											 <?php if((validation_errors()) || ($already_msg)):?>
											<div class="alert alert-danger">
												<button class="close" data-close="alert"></button>
												 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
											</div>
											<?php endif; ?>
													<!--<div class="form-group">
														<label class="col-md-3 control-label">Employee Code<span class="required"> * </span></label>
														 <div class="col-md-6"> 
														<?php $data = array(
														  'name'        => 'emp_code',
														  'id'          => 'emp_code',	
														  'value'       => set_value('emp_code'),								
														  'maxlength'   => '255',
														  'class'   => 'form-control',
														  'rules' => 'number',
														   'placeholder'   => 'Employee Code',
														  );
														echo form_input($data);
														?>
														</div>
													</div>-->
													<div class="form-group">
														<label class="col-md-3 control-label">New Password<span class="required"> * </span></label>
														 <div class="col-md-6"> 
														 <?php $data = array(
														  'name'        => 'newpassword',
														  'id'          => 'newpassword',	
														  'value'       => set_value('newpassword'),							
														  'maxlength'   => '255',
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => 'New Password',
														  );
														echo form_input($data);
														?>
														</div>
													</div>
													
													<div class="form-group">
														<label class="col-md-3 control-label">Confirm Password<span class="required"> * </span></label>
														 <div class="col-md-6"> 
														   <?php $data = array(
																  'name'        => 'confirmpass',
																  'id'          => 'confirmpass',
																  'value'       => set_value('confirmpass'),	
																  'maxlength'   => '32',
																  'class'   => 'form-control',
																  'type'   => 'text',
																  'minlength'   => '4',
																  'data-validation'  => 'required',
																  'placeholder'   => 'Confirm Password',
																  );
																  echo form_input($data);
																  echo form_error('userpass');
															 ?>
														 </div>
													</div>
													
												</div>
													
											  <div class="form-actions">
													<div class="row">
														<div class="col-md-offset-3 col-md-4">
															<button type="submit" class="btn green" value="Submit">Submit</button>
															<input type="reset" class="btn default" name="Reset" value="Reset">
															<a class="btn default" href='<?php echo base_url() ?>backoffice/users/'>Back</a>
														</div>
													</div>
											   </div>
															
												<?php echo form_close(); ?>
													 




												</div>
																</div>
															</div>
														</div>
														
														
													</div>
													
												</div>
											
										
											
										</div>
									</div>
									<!-- END PAGE CONTENT INNER -->
								</div>
							</div>
							<!-- END PAGE CONTENT BODY -->
							<!-- END CONTENT BODY -->
						</div>
						<!-- END CONTENT -->
                    </div>
                    <!-- END CONTAINER -->
              </div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
    </body>

</html>
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo PATH_TO_ADMIN ?>assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
		<script type="text/javascript">
	    $(document).ready(function(){
			$('.reported_to').hide();
			$('.selected-designation').bind('change', function () {
				if($(this).val()=='1'){
					$('.reported_to').show();
				} else {
					$('#report_to').val('');
					$('.reported_to').hide();
				}
			});		
		});
		</script>
    </body>                    