<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
		
		<div class="page-wrapper-row full-height">
			<div class="page-wrapper-middle">
				<!-- BEGIN CONTAINER -->
				<div class="page-container">
				<!-- BEGIN CONTENT -->
					<div class="page-content-wrapper">
						<!-- BEGIN CONTENT BODY -->
						<!-- BEGIN PAGE HEAD-->
						<div class="page-head">
							<div class="container">
								<!-- BEGIN PAGE TITLE -->
								<div class="page-title">
									<h1><?php echo $title; ?>
										<small><?php echo  $main_heading; ?></small>
									</h1>
								</div>
								<!-- END PAGE TITLE -->
								<!-- BEGIN PAGE TOOLBAR -->
								
								<!-- END PAGE TOOLBAR -->
							</div>
						</div>
						<!-- END PAGE HEAD-->
						<!-- BEGIN PAGE CONTENT BODY -->
						<div class="page-content">
							<div class="container">
<!-- BEGIN PAGE CONTENT INNER -->
<div class="page-content-inner">
	<div class="mt-content-body">
			<?php if((validation_errors()) || ($already_msg)):?>
			<div class="alert alert-danger">
				<button class="close" data-close="alert"></button>
				 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
			</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN EXAMPLE TABLE PORTLET-->
					<div class="portlet light bordered">
						<div class="portlet-title">
							<div class="caption"> <i class=" fa fa-category font-green-sharp"></i> <span class="caption-subject font-green-sharp bold uppercase"><?php echo $heading;?></span> </div>
							<div class="actions">
								<div class="btn-category">
											<a href="<?php echo base_url();?>backoffice/categories/add" id="sample_editable_1_new" class="btn sbold green"> <?php echo $this->lang->line('add_category_title'); ?>
												<i class="fa fa-plus"></i>
											</a>
										</div>
							</div>
						</div>
						<div class="portlet-body">
							<div class="table-toolbar">
							<?php 
							if($this->session->flashdata('success_message')){
							success_message($this->session->flashdata('success_message'));
							}
							?>    
							</div>
							<table class="table table-striped table-bordered table-hover table-checkable order-column" id="sample_1">
								<thead>
									<tr>
										<th> <?php echo $this->lang->line('srno_column'); ?></th>
										<th> <?php echo $this->lang->line('category_select_name'); ?></th>
										<th> <?php echo $this->lang->line('category_name_text'); ?></th>
										<th> <?php echo $this->lang->line('category_parent_category_text'); ?></th>
										<th> <?php echo $this->lang->line('category_icon_column'); ?> </th>
										<th> <?php echo $this->lang->line('category_description_column'); ?></th>
										<th> Translation </th>
										<th> <?php echo $this->lang->line('action_column'); ?> </th>
									</tr>
								</thead>
								<tbody>
								<?php if($results){ $srno=0;
									foreach($results as $rec){
										$srno++;
										$languages=$lang_data;
									?>
									<tr class="odd gradeX">
										<td><?php echo $srno;?></td>
										<td> <?php echo ucfirst($rec->category);?></td>
										<td> <?php echo ucfirst($rec->category_name);?></td>
										<td> <?php echo $rec->parent_category; ?></td>
										
										
										<td nowrap><?php if($rec->icon!='') { ?><a  class='imagelightbox' data-toggle="modal" href="#lightboxresponsive"><img src='<?php echo base_url();?>images/category-icons/<?php echo $rec->icon; ?>' width='50'></a><?php } ?></td>
										<td> <?php echo $rec->description; ?></td>
										<td> <?php foreach($languages as $lang){
                                            //print '<pre>';print_r($lang);die;
                                            $translate_content=get_translatecontent($lang->language_id,$rec->category_id,'categories_translation','category_id');
                                            //print '<pre>';print_r($translate_content);die;
                                            if(!empty($translate_content)){
                                                if($lang->language_id!=1){
                                                    $contentid=$translate_content->category_id;
                                                   // $reporttorow = get_table_info('category_types','category_type_id',$contentid);
                                                   $field_arr=array('category_id'=>$contentid,'language_id'=>$lang->language_id);
                                                   $reporttorow = gettableinfo('categories_translation',$field_arr);
                                                }
                                                $link='edit_translate/'.$lang->language_id.'/'.$contentid;
                                                $dropdown_trans[$link]=$reporttorow->category_name.'(in '.$lang->language_name.')';
                                                
                                                //echo '<a class="btn" href="'.base_url().'backoffice/products/edit_translate/'.$lang->language_id.'/'.$contentid.'">'.$reporttorow->product_name.'(in '.$lang->language_name.')</a>';
                                            }else{
                                                $link='translate_add/'.$lang->language_id.'/'.$rec->category_id;
                                                $dropdown_trans[$link]='Translate to '.$lang->language_name;
                                            //echo '<a class="btn" href="'.base_url().'backoffice/products/translate_add/'.$lang->language_id.'/'.$row->product_id.'">Translate to '.$lang->language_name.'</a>';
                                            }
                                        } 
                                        $selected ='';
										echo form_dropdown('language_content', $dropdown_trans,  $selected,'id="language_content" class="form-control language_content" required ');
										echo form_error('language_content');
                                        ?></td>
										<td> <a href="<?php echo base_url();?>backoffice/categories/edit/<?php echo $rec->category_id;?>" class="btn btn-xs yellow"><i class="fa fa-edit"></i></a></td>
									</tr>
							   <?php } } else { echo "<td colspan='7'>".$this->lang->line('no_rec_found_text')."</td>"; } ?>    
								</tbody>
							</table>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
				</div>
			</div>
     
    </div>
</div>
<!-- END PAGE CONTENT INNER -->
							</div>
						</div>
						<!-- END PAGE CONTENT BODY -->
						<!-- END CONTENT BODY -->
					</div>
					<!-- END CONTENT -->
				</div>
				<!-- END CONTAINER -->
			</div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
        <script>

	 $(document).ready(function(){
		 
		 $('.language_content').bind('change', function () {
			var link=$(this).val();
			//alert(link);
			window.location.replace(path+"backoffice/categories/"+link);
		});
	 });
	 </script>
    </body>

</html>