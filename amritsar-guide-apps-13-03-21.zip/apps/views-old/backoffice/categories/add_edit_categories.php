<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo isset($title) ? $title : title ; ?></title>
         <?php $this->load->view("includes/styles.php");?>
		</head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid page-header-menu-fixed">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                     <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
					<!-- BEGIN CONTENT -->
						<div class="page-content-wrapper">
							<!-- BEGIN CONTENT BODY -->
							<!-- BEGIN PAGE CONTENT BODY -->
							<div class="page-content">
								<div class="container">
									<!-- BEGIN PAGE BREADCRUMBS -->
									<!--<ul class="page-breadcrumb breadcrumb">
										<li>
											<a href="index.html">Home</a>
											<i class="fa fa-circle"></i>
										</li>
										<li>
											<span>Tutors</span>
										</li>
									</ul>-->
									<!-- END PAGE BREADCRUMBS -->
									<!-- BEGIN PAGE CONTENT INNER -->
									<div class="page-content-inner">
										<div class="mt-content-body">
										    <div class="row">
													<div class="col-md-12">
														
														 <div class="portlet box green">
															<div class="portlet-title">
																<div class="caption">
																	<i class="fa fa-gift"></i><?php echo $heading; ?> </div>
															</div>
															<div class="portlet-body">
																<div class="row">
																	
											<div class="col-md-12">
											  <?php  $attributes = array('class' => 'form-horizontal','role' => 'form','autocomplete' => 'off');
													if($category_id==0)
													 echo form_open_multipart(base_url().'backoffice/categories/add', $attributes);
													else
													echo form_open_multipart(base_url().'backoffice/categories/edit/'.$category_id, $attributes);
											  ?>
											<div class="form-body">
											 
											
											<?php if((validation_errors()) || ($already_msg)):?>
											<div class="alert alert-danger">
												<button class="close" data-close="alert"></button>
												 <span> <?php echo validation_errors(); ?><?php echo $already_msg;?></span>
											</div>
											<?php endif; ?>
												<div class="form-group">
													<label class="col-md-1 control-label"><?php echo $this->lang->line('category_select_name'); ?></label>
													<div class="col-md-2"> 
													 <?php
														$category_type=array();
														$selected=$category_type_id;
														$category_type['']="Select";
														$category_types=fetch_category_types();
														foreach($category_types as $key=>$value){
															$category_type[$value->category_type_id]=ucfirst($value->category_type);
														}

														 
														echo form_dropdown('category_type_id', $category_type,$selected,'id="category_type_id" class="form-control" required'); 
													 ?>
													 
													</div>
													<label class="col-md-1 control-label"><?php echo $this->lang->line('category_parent_name'); ?></label>
													<div class="col-md-2"> 
													 <?php
														$categories=array();
														$selected=$category_parent_id;
														$categories['']="Select";
														$allcategories=fetch_categories();
														foreach($allcategories as $key=>$value){
															$categories[$value->category_id]=ucfirst($value->category_name);
														}

														 
														echo form_dropdown('category_parent_id', $categories,$selected,'class="form-control"'); 
													 ?>
													 
													</div>
													<label class="col-md-1 control-label"><?php echo $this->lang->line('category_name_text'); ?></label>
													 <div class="col-md-2"> 
													 <?php $data = array(
													  'name'        => 'category_name',
													  'value'       => $category_name,								
													  'maxlength'   => '255',
													  'class'   => 'form-control',
													  'required'   => 'required',
													   'placeholder'   => $this->lang->line('category_enter_category_name'),
													  );
													echo form_input($data);
													?>
													</div>
													
													<label class="control-label col-md-1"><?php echo $this->lang->line('photo_upload_text'); ?> </label>
													<div class="col-md-2">
														<span class="btn btn-outline btn-file">
														<span class="fileinput-new">  <?php echo $this->lang->line('photo_choose_text'); ?> </span>
															
														<input type="file" name="category_icon"> </span>
															
														 <br /><span class="label label-success"><?php echo $this->lang->line('photo_note_text'); ?>!</span> <?php echo $this->lang->line('photo_extension_text'); ?> 
													</div>
												</div>	
												<div class="form-group">
													<label class="col-md-1 control-label"><?php echo $this->lang->line('category_description'); ?></label>
													 <div class="col-md-2"> 
														 <?php $data = array(
														  'name'        => 'description',
														  'id'          => 'description',	
														  'value'       => $description,
														  'rows'       => 5,
														  'cols'       => 10,
														  'maxlength'   => '255',
														  'class'   => 'form-control',
														  'required'   => 'required',
														   'placeholder'   => $this->lang->line('category_description')
														  );
														echo form_textarea($data);
														?>
													 </div>
                                                     
                                                      
                                                     
                                                     <label class="col-md-1 control-label"><?php echo $this->lang->line('category_choose_filter'); ?></label>
																<div class="col-md-2"> 
													 			<div style="height:130px; margin-left:05px;overflow-y:scroll">
                                                                           <div class="md-checkbox-list">
                                                                           <?php
																	    	$fields = array('is_active'=>'1');
                                                                  			$filterresults =gettableresult('filters',$fields,$order=NULL,$group=NULL);
																			if(is_array($filterresults))
																			{
																				$field = array('is_active'=>'1','category_id'=>$category_id);
                                                                  			    $defaultfilters =gettableresult('category_filters',$field,$order=NULL,$group=NULL);																	
																			     $default_filters =array();
																				 if(is_array($defaultfilters))
																				 { foreach($defaultfilters as $rrow){
																						 $default_filters[$rrow->filterid]=$rrow->filterid;
																					 }
																				 }
																				
																				foreach($filterresults as $filterkey=> $filterrow){
																				
																				if(in_array($filterrow->filterid,$default_filters))
																				$checked='checked';
																				else
																				$checked='';
																																					  ?>
                                                                            <div class="md-checkbox">
                                                                                <input id="filter_id<?php echo $filterrow->filterid; ?>" name="filter_id[]" value="<?php echo $filterrow->filterid; ?>" <?php echo $checked; ?> class="md-check" type="checkbox">
                                                                                <label for="filter_id<?php echo $filterrow->filterid; ?>">
                                                                                    <span class="inc"></span>
                                                                                    <span class="check"></span>
                                                                                    <span class="box"></span> <?php echo $filterrow->filter_name; ?></label>
                                                                            </div>
                                                                            <?php 
                                                                              }
																			}
																		   ?>
                                                                        </div>
                                                                        </div>
                                                                        <?php echo form_error('account_type[]'); ?>
													 
													</div>
													
													
												</div>
                                        
                                                
											  </div>
													
											  <div class="form-actions">
													<div class="row">
														<div class="col-md-offset-5 col-md-4">
															<button type="submit" class="btn green" value="<?php echo $this->lang->line('submit_button_text'); ?>"><?php echo $this->lang->line('submit_button_text'); ?></button>
															
															<a class="btn default" href='<?php echo base_url() ?>backoffice/Categories/'><?php echo $this->lang->line('back_button_text'); ?></a>
														</div>
													</div>
											   </div>
															
												<?php echo form_close(); ?>
												</div>
																</div>
															</div>
														</div>
														
														
													</div>
													
												</div>
											
										</div>
									</div>
									<!-- END PAGE CONTENT INNER -->
								</div>
							</div>
							<!-- END PAGE CONTENT BODY -->
							<!-- END CONTENT BODY -->
						</div>
						<!-- END CONTENT -->
                    </div>
                    <!-- END CONTAINER -->
               </div>
            </div>
            
             <?php $this->load->view("includes/footer.php");?>
             
        </div>
        
        <?php $this->load->view("includes/scripts.php");?>
    </body>

</html>