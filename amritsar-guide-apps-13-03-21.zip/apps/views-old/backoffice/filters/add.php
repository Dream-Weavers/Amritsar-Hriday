<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8" />
        <title><?php echo $this->lang->line('text_title_header'); ?></title>
        <?php $this->load->view("includes/styles.php");?></head>
    <!-- END HEAD -->

    <body class="page-container-bg-solid">
        <div class="page-wrapper">
            <div class="page-wrapper-row">
                <div class="page-wrapper-top">
                    <!-- BEGIN HEADER -->
                    <?php $this->load->view("includes/header.php");?>
                    <!-- END HEADER -->
                </div>
            </div>
            <div class="page-wrapper-row full-height">
                <div class="page-wrapper-middle">
                    <!-- BEGIN CONTAINER -->
                    <div class="page-container">
                        <!-- BEGIN CONTENT -->
                        <div class="page-content-wrapper">
                            <!-- BEGIN CONTENT BODY -->
                            <!-- BEGIN PAGE HEAD-->
                            <div class="page-head">
                                <div class="container">
                                    <!-- BEGIN PAGE TITLE -->
                                    <div class="page-title">
                                        <h1><?php echo $main_heading; ?></h1>
                                    </div>
                                    <!-- END PAGE TITLE -->
                                    <!-- BEGIN PAGE TOOLBAR -->
                                    <?php $this->load->view("includes/toolbar.php");?>
                                    <!-- END PAGE TOOLBAR -->
                                </div>
                            </div>
                            <!-- END PAGE HEAD-->
                            <!-- BEGIN PAGE CONTENT BODY -->
                            <div class="page-content">
                                <div class="container">
                                    <!-- BEGIN PAGE BREADCRUMBS -->
                                    <ul class="page-breadcrumb breadcrumb">
                                        <li>
                                            <a href="<?php echo base_url();?>backoffice/dashboard"><?php echo $this->lang->line('dashboard_text'); ?></a>
                                            <i class="fa fa-circle"></i>
                                        </li>
                                        <li>
                                        <a href="<?php echo base_url(); ?>backoffice/filters/view">
                                            <?php echo $main_heading; ?>
                                        </a> <i class="fa fa-circle"></i> </li>
                                    <li> <span><?php echo $heading; ?></span> </li>
                                    </ul>
                                    <!-- END PAGE BREADCRUMBS -->
                                    <!-- BEGIN PAGE CONTENT INNER -->
                                    <div class="page-content-inner">
                                        <div class="row">
                                            <div class="col-md-12">
                                            
                                            <div class="portlet box green">
                                                <div class="portlet-title">
                                                    <div class="caption">
                                                        <i class="fa fa-plus-square"></i><?php echo $heading; ?> </div>
                                                </div>
                                                <div class="portlet-body">
                                                    <div class="row">
                                                        
                                                        <div class="col-md-12 col-sm-9 col-xs-9">
                                                          <?php  $attributes = array('id' => 'filter_form','name' => 'filter_form','class' => 'horizontal-form','role' => 'form','autocomplete' => 'off');
                                                                 echo form_open_multipart(base_url().'backoffice/filters/add', $attributes);
                                                           ?>
                                                         <div class="form-body">
                                                         <div class="alert alert-danger display-hide">
                                                            <button class="close" data-close="alert"></button> <?php echo $this->lang->line('form_validation_errors'); ?></div>
                                                         <div class="alert alert-success display-hide">
                                                            <button class="close" data-close="alert"></button> <?php echo $this->lang->line('form_validation_success'); ?> </div>
                                                              
														 <?php if((validation_errors()) || ($already_msg)):?>
                                                        <div class="alert alert-danger">
                                                            <button class="close" data-close="alert"></button>
                                                             <span> <?php echo validation_errors(); ?>&nbsp;<?php echo $already_msg;?></span>
                                                        </div>
                                                        <?php endif; ?>
                                                           <div class="row">
                                                             
                                                               <div class="col-md-6">
                                                                    <div class="form-group">
                                                                      <label class="control-label"><?php echo $this->lang->line('filter_name_text'); ?> <span class="required"> * </span></label>
                                                                         <?php $data = array(
																			  'name'        => 'filter_name',
																			  'id'          => 'filter_name',	
																			  'value'       => set_value('filter_name') ? $this->input->post("filter_name") : $this->input->post("filter_name"),												
																			  'maxlength'   => '100',
																			  'class'   => 'form-control',
																			  'required'   => 'required',
																			  );
																			echo form_input($data);
																			echo form_error('filter_name');
																		   ?>
                                                                    </div>
                                                                </div>
                                                                
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                      <label class="control-label"><?php echo $this->lang->line('filter_weight_text'); ?> </label>
                                                                         <?php
																		 
																		 $fields = array('language_id'=>$this->session->userdata('lang_id'));
																		 $weightmax = get_max_values('filters','weight',$fields);
																		
																		  $data = array(
																			  'name'        => 'weight',
																			  'id'          => 'weight',	
																			  'value'       => $weightmax,
																			  'maxlength'   => '5',
																			  'class'   => 'form-control',
																			  'required'   => 'required',
																			  );
																			echo form_input($data);
																			echo form_error('weight');
																		   ?>
                                                                    </div>
                                                                </div>
                                                             
                                                               
                                                                
                                                            </div>
                                                            <!--/row-->
                                                            
                                                    
                                                            </div>
                                                            </div>
                                                             
                                                           
                                                          
                                                          <div class="row">
                                                            <div class="col-md-12">
                                                            <label class="col-md-2 control-label">&nbsp;&nbsp;&nbsp;&nbsp;</label>
                                                            </div>
                                                          </div>
                                                          
                                                          <!--/row-->  
                                                          
                                                         </div>
                                                            
                                                        
                                                        <div class="form-actions">
                                                            <div class="row">
                                                                <div class="col-md-offset-6 col-md-6">
                                                                    <button type="submit" id="submit_btn" class="btn green" value="Submit"><?php echo $this->lang->line('form_submit_text'); ?></button>&nbsp;&nbsp;&nbsp;&nbsp;
                                                                    <input type="reset" class="btn default" name="Reset" value="<?php echo $this->lang->line('form_reset_text'); ?>">
                                                                </div>
                                                            </div>
                                                       </div>
                                                                    
                                                             <?php echo form_close(); ?>
                                                             <?php $this->load->view("includes/loader.php");?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                            
                                        </div>
                                        
                                    </div>
                                    <!-- END PAGE CONTENT INNER -->
                                </div>
                            </div>
                            <!-- END PAGE CONTENT BODY -->
                            <!-- END CONTENT BODY -->
                        </div>
                        <!-- END CONTENT -->
                        <!-- BEGIN QUICK SIDEBAR -->
                         <?php $this->load->view("includes/sidebar.php");?>
                        <!-- END QUICK SIDEBAR -->
                    </div>
                    <!-- END CONTAINER -->
                </div>
            </div>
            <?php $this->load->view("includes/footer.php");?>
        </div>
        <!-- BEGIN QUICK NAV -->
         <?php $this->load->view("includes/quicknav.php");?>
        <!-- END QUICK NAV -->
       <?php $this->load->view("includes/scripts.php");?>
	
    </body>

</html>