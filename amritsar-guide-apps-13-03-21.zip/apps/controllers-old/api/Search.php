<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Search extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/search_model');

    }

	 
	public function get_location_get()
	{
		$language_id = $this->get('language_id');
		$search_by = $this->get('search_by');
		$search_code = $this->get('search_code');
		$data = $this->search_model->get_location($language_id,$search_by,$search_code);		
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Get Location',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	public function get_search_keywords_get()
	{
		$language_id = $this->get('language_id');
		$search_by = $this->get('search_by');
		$search_keyword = $this->get('search_keyword');
		
		$data = $this->search_model->get_search_keywords($language_id,$search_by,$search_keyword);		
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Search Keywords',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	
	public function location_search_post()
	{
		$language_id = $this->get('language_id');
		$search_keyword = $this->get('search_keyword');
		$data = $this->search_model->location_search($language_id,$search_keyword);		
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Location Search',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
}