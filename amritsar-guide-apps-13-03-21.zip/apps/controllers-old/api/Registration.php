<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Registration extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Registration_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	public function verify_userinput_post() {  
        // Get the post data
        $user_input = strip_tags($this->post('user_input'));
        
        // Validate the post data
        if(!empty($user_input)){
            
			$emailPattern = '/^\w{2,}@\w{2,}\.\w{2,4}$/'; 
			$mobilePattern ="/^[7-9][0-9]{9}$/"; 

			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$counter = $this->Registration_model->email_validate($user_input);
				if($counter>0){
					$this->response([
                        'status' => False,
                        'message' => 'This email id is already exists.',
                    ], REST_Controller::HTTP_BAD_REQUEST);
				}else{
					$otp=$this->random_fivedigit();
					$smstext='Your OTP is '.$otp.'. Please do not share this OTP with anyone.';
					//print 'ddddd';
					send_email($user_input,$smstext,"Hriday Registration OTP");
					$counter = $this->Registration_model->otp_log($user_input,$otp);
					$this->response([
                        'status' => TRUE,
                        'message' => 'You will get OTP on your email. Please enter here',
                    ], REST_Controller::HTTP_OK);
				}
			} else if(preg_match($mobilePattern, $user_input)){
				$counter = $this->Registration_model->mobile_validate($user_input);
				if($counter>0){
					$this->response([
                        'status' => False,
                        'message' => 'This mobile no is already exists.',
                    ], REST_Controller::HTTP_BAD_REQUEST);
				}else{
					$otp=$this->random_fivedigit();
					$smstext='Your OTP is '.$otp.'. Please do not share this OTP with anyone.';
					send_sms("",$user_input,$smstext);
					
					$counter = $this->Registration_model->otp_log($user_input,$otp);
					$this->response([
                        'status' => TRUE,
                        'message' => 'You will get OTP on your mobile. Please enter here',
                    ], REST_Controller::HTTP_OK);
				}
			} else {
				$this->response([
                        'status' => False,
                        'message' => 'Invalid information',
                    ], REST_Controller::HTTP_BAD_REQUEST);
			}
            
        }else{
            // Set the response and exit
           $this->response([
				'status' => False,
				'message' => 'Please enter correct mobile or email.',
			], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
	
	public function verify_userinput_otp_post() {  
		 $user_input = $this->post('user_input');
		 $user_otp = $this->post('user_otp');
		 $counter = $this->Registration_model->match_mobile_otp($user_input,$user_otp);
		 if($counter>0){
			 $logupdate = $this->Registration_model->update_mobile_otp_log($user_input,$user_otp);
			$this->response([
				'status' => TRUE,
				'message' => 'Verfication process is completed',
			], REST_Controller::HTTP_OK);
		 }else{
			$this->response([
				'status' => False,
				'message' => 'Incorrect OTP.',
			], REST_Controller::HTTP_BAD_REQUEST);
		 }
	}
	
	function random_fivedigit(){
		$x=5; // number of digits;
		$randomNum = substr(str_shuffle("0123456789"), 0, $x);
		return $randomNum;
	}
	
	function create_user_account_post(){
		$user_input = $this->post('user_input');
		$password = $this->post('password');
		$first_name = $this->post('first_name');
		$last_name = $this->post('last_name');
		$gender=$this->post('gender');
		$register_type=$this->post('register_type');
		$response_code=json_encode($this->post('response_code'));
		
		$mobilePattern ="/^[7-9][0-9]{9}$/"; 
		$photo='';
		
		if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
		   
			$result=$this->Registration_model->create_user_acc_email($user_input,$password,$first_name,$last_name,$gender,$register_type,$response_code);
		
			$fildarr=array('email'=>$user_input,'user_type'=>'U');
			$getuser_arr=gettableinfo('users',$fildarr);
			 
			if($getuser_arr->user_photo!=''){
				$photo=base_url().users_photo_path.$getuser_arr->user_photo;
			}
		}else if(preg_match($mobilePattern, $user_input)){
			$result=$this->Registration_model->create_user_acc_mobile($user_input,$password,$first_name,$last_name,$gender,$register_type,$response_code);
			$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
			$getuser_arr=gettableinfo('users',$fildarr);
			if($getuser_arr->user_photo!=''){
				$photo=base_url().users_photo_path.$getuser_arr->user_photo;
			}
		}else{
			$result=False;
		}
		 if($result>0){
			 $token = AUTHORIZATION::generateToken(['user_input' => $user_input]);
			// Prepare the response
            $status = parent::HTTP_OK;
			/*$this->response([
					'status' => TRUE,
					'message' => 'User created successfully',
					'user_id'=>$result
				], REST_Controller::HTTP_OK);*/
		    $addressfield=array('user_address_id'=>$getuser_arr->user_address_id,'is_primary'=>'1');
			$useraddressrow=gettableinfo('user_address',$addressfield);
			if($useraddressrow!='0')
			{
			 $country_id = $useraddressrow->country_id;
			 $state_id = $useraddressrow->state_id;
			 $city_id = $useraddressrow->city_id;
			 $address = $useraddressrow->address;
			 $pin_code = $useraddressrow->pin_code;
			}else
			{
			 $country_id = '';
			 $state_id = '';
			 $city_id = '';
			 $address = '';
			 $pin_code = '';
			}
			
			$response = ['status' => $status, 'token' => $token,'user_id'=>$getuser_arr->user_id,'first_name'=>$getuser_arr->first_name,'last_name'=>$getuser_arr->last_name,'mobile_no'=>$getuser_arr->mobile_no1,'email'=>$getuser_arr->email,'gender'=>$getuser_arr->gender,'user_photo'=>'','country_id'=>$country_id,'state_id'=>$state_id,'city_id'=>$city_id,'address'=>$address,'pin_code'=>$pin_code,'online_status'=>$getuser_arr->user_online_status];
					
			//$response = ['status' => $status, 'token' => $token,'first_name'=>$getuser_arr->first_name,'user_photo'=>$photo];
            $this->response($response, $status);
			
				// Create a token from the user data and send it as reponse
            
		}else{
			$this->response([
				'status' => False,
				'message' => 'There is an error.',
			], REST_Controller::HTTP_BAD_REQUEST);
		} 
		
	}
	
	private function verify_request()
{	
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
    $token = $headers['Authorization'];
	//print '<pre>';print_r($headers);die;
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}
	public function get_me_data_post()
	{
		// Call the verification method and store the return value in the variable
		
		$data = $this->verify_request();
		
		// Send the return data as reponse
		if($data==TRUE){
			$status = parent::HTTP_OK;
			$response = ['status' => $status, 'data' => $data];
			$this->response($response, $status);
		}
	}
	
	function send_email($to,$body,$subject){
	$message = $body;
	
	$header = "From:dreamweaversgroup1@gmail.com \r\n";
	$header .= "MIME-Version: 1.0\r\n";
	$header .= "Content-type: text/html\r\n";

	$retval = mail ($to,$subject,$message,$header);
	//print 'ffff';die;
	if( $retval == true ) {
		return True;
	}else {
	    //print 'ggggg';
		return False;
	}
}
	
}