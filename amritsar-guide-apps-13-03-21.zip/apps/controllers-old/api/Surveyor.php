<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Surveyor extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Surveyor_model');

    }

	/*  public function index_get($id = 0)
	 {
		//$data = $this->db->get_where("items", ['id' => $id])->row_array();
		
		if($id!=0){
            $data = $this->Surveyor_model->getRecords($id);
        }else{
            $data = $this->Surveyor_model->getRecords();
        }  
		$this->response($data, REST_Controller::HTTP_OK);
	 }   */
	 
	 public function get_survey_id_get()
	 {
		$data = $this->Surveyor_model->get_survey_id(); 
		$this->response($data, REST_Controller::HTTP_OK);
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'message' => 'Survey Id',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'message' => 'Survey Id',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	 }
	public function insert_survey_post() {  
        // Get the post data
        $customer_name = strip_tags($this->post('customer_name'));
        $survey_number = strip_tags($this->post('survey_number'));
        $gender = strip_tags($this->post('gender'));
        $city = strip_tags($this->post('city'));
        $city2 = strip_tags($this->post('city2'));
        $state = strip_tags($this->post('state'));
        $age = strip_tags($this->post('age'));
        $address = $this->post('address');
        $area = strip_tags($this->post('area'));
        $staying_amritsar_before_independence = strip_tags($this->post('staying_amritsar_before_independence'));
        $staying_amritsar_after_independence = strip_tags($this->post('staying_amritsar_after_independence'));
        $years_staying_in_amritsar_after_independence = strip_tags($this->post('years_staying_in_amritsar_after_independence'));
        $know_place_not_exists_now = strip_tags($this->post('know_place_not_exists_now'));
        $place_exact_location = strip_tags($this->post('place_exact_location'));
        $place_longitude = strip_tags($this->post('place_longitude'));
        $place_latitude = strip_tags($this->post('place_latitude'));
        $place_remarks = strip_tags($this->post('place_remarks'));
        $event_not_exists_now = strip_tags($this->post('event_not_exists_now'));
        $event_exact_location = strip_tags($this->post('event_exact_location'));
        $event_longitude = strip_tags($this->post('event_longitude'));
        $event_latitude = strip_tags($this->post('event_latitude'));
        $event_remarks = strip_tags($this->post('event_remarks'));
        $site_alteration = strip_tags($this->post('site_alteration'));
        $site_exact_location = strip_tags($this->post('site_exact_location'));
        $site_latitude = strip_tags($this->post('site_latitude'));
        $site_longitude = strip_tags($this->post('site_longitude'));
        $site_remarks = strip_tags($this->post('site_remarks'));
        $remarks = strip_tags($this->post('remarks'));
       
        // Validate the post data
        if(!empty($customer_name)){
            
				// Insert survey data
                $surveyData = array(
					'survey_number'=> $survey_number,
                    'customer_name' => $customer_name,
                    'gender' => $gender,
                    'city' => $city,
                    'city2' => $city2,
                    'state' => $state,
                    'age' => $age,
                    'address' => $address,
                    'area' => $area,
                    'staying_amritsar_before_independence' => $staying_amritsar_before_independence,
                    'staying_amritsar_after_independence' => $staying_amritsar_after_independence,
                    'know_place_not_exists_now' => $know_place_not_exists_now,
                    'years_staying_in_amritsar_after_independence' => $years_staying_in_amritsar_after_independence,
                    'place_exact_location' => $place_exact_location,
                    'place_longitude' => $place_longitude,
                    'place_latitude' => $place_latitude,
                    'place_remarks' => $place_remarks,
                    'event_not_exists_now' => $event_not_exists_now,
                    'event_exact_location' => $event_exact_location,
                    'event_longitude' => $event_longitude,
                    'event_remarks' => $event_remarks,
                    'event_latitude' => $event_latitude,
                    'site_alteration' => $site_alteration,
                    'site_exact_location' => $site_exact_location,
                    'site_latitude' => $site_latitude,
                    'site_longitude' => $site_longitude,
                    'site_remarks' => $site_remarks,
                    'remarks' => $remarks
                );
              $insert = $this->Surveyor_model->insert($surveyData);
                
                // Check if the survey data is inserted
				//$insert=1;
				//print '<pre>';print_r($insert);die;
                if($insert['status']==TRUE){
                    // Set the response and exit
                    $this->response([
                        'status' => TRUE,
                        'message' => 'The survey has been added successfully.',
                        'data' => $insert,
						'survey_id'=>$insert
                    ], REST_Controller::HTTP_OK);
                } else{
					//print 'sdsdsd';die;
                    // Set the response and exit
					$this->response([
                        'status' => False,
                        'message' => $insert['message'],
                    ], REST_Controller::HTTP_BAD_REQUEST);
                    //$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
                }
            
        }else{
            // Set the response and exit
            $this->response("Provide complete information.", REST_Controller::HTTP_BAD_REQUEST);
        }
    }

}