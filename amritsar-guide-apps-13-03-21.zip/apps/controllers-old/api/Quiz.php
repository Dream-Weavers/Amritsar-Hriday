<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Quiz extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Quiz_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}

   public function location_quiz_boolean_post(){
		$data = $this->verify_request();
		$language_id=$this->post('language_id');
		$location_id=$this->post('location_id');
	//	print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		
			$booleanresult = $this->Quiz_model->quiz_boolean($user_id,$language_id,$location_id);
			//print $booleanresult;die;
			if($booleanresult>0){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'Quiz exist',
				 'data' => TRUE];
				$this->response($response, $status);
			}else{
				$status = $status = parent::HTTP_OK;
				$response = ['status' => $status, 'msg' => 'There is no quiz of this location.','data' => false];
				$this->response($response, $status);
			}				
		}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'No response.'];
				$this->response($response, $status);
			}
	}
	
   public function start_quiz_get(){
		$language_id=$this->get('language_id');
		$location_id=$this->get('location_id');
		$data = $this->Quiz_model->start_quiz($language_id,$location_id);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Start Quiz',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
   /* public function get_quiz_questions_get(){
		$language_id=$this->get('language_id');
		$quiz_id=$this->get('quiz_id');
		$data = $this->Quiz_model->get_quiz_questions($language_id,$quiz_id);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Quiz Questions',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}*/

	public function quiz_result_save_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$quiz_id = $this->post('quiz_id');
			$type_id = $this->post('type_id');
			$location_id = $this->post('location_id');
			$quiz_spend_time = $this->post('quiz_spend_time');
			$answers = $this->post('answers');
			
			$quiz_result_data=array('language_id'=>$language_id,'user_id'=>$user_id,'quiz_id'=>$quiz_id,'type_id'=>$type_id,'location_id'=>$location_id,'quiz_spend_time'=>$quiz_spend_time,'answers'=>$answers,'quiz_appear_date'=>date('Y-m-d H:i:s'));
			
			$quiz_result_id = $this->Quiz_model->quiz_result_save($quiz_result_data);
			if($quiz_result_id){
				$status = parent::HTTP_OK;
				$response = ['status' => $status,'quiz_result_id' => $quiz_result_id, 'data' => 'Quiz Results Save successfully.'];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status,'quiz_result_id' => '', 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
		
	}
	
	public function quiz_result_score_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$quiz_result_id = $this->post('quiz_result_id');
			$quiz_percentage_score = $this->Quiz_model->quiz_result_score($language_id,$user_id,$quiz_result_id);
			$quizpercentagescore = explode(':',$quiz_percentage_score);
			$quiz_percentage = $quizpercentagescore[0];
			$quiz_scrore = $quizpercentagescore[1];
			//echo "-------------->".$quiz_percentage;
			$msg='';
			if($quiz_percentage!='999')
			 {
			//	echo "-------------->".$quiz_percentage;
			  if($quiz_percentage >=0 && $quiz_percentage < 50)
			  { $msg="You can do better, Keep trying...";}
			  elseif($quiz_percentage >50 && $quiz_percentage < 70)
			  { $msg="Good, keep it up!!!";} 
			  elseif($quiz_percentage >70)
			  {$msg="Excellent!!!. You are the master.";} 
			  else
			  { $msg='You can do better, Keep trying...';
			  }
			 }
			  
			if($quiz_percentage_score){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => $msg,
				 'data' => $quiz_scrore];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'message' => 'Error', 'data' => ''];
				$this->response($response, $status);
			    }				
		  }
	  }
	  
	public function quiz_results_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$quizresult = $this->Quiz_model->quiz_results($language_id,$user_id);
			
			  
			if($quizresult){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'Quiz Information',
				 'data' => $quizresult];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'message' => 'Error', 'data' => ''];
				$this->response($response, $status);
			    }				
		  }
	  }
  
	  
	public function quiz_result_info_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$quiz_result_id = $this->post('quiz_result_id');
			$quizresult = $this->Quiz_model->quiz_result_info($language_id,$user_id,$quiz_result_id);
			  
			if($quizresult){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'Quiz Result Info',
				 'data' => $quizresult];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'message' => 'Error', 'data' => ''];
				$this->response($response, $status);
			    }				
		  }
	  }
	  
	


}