<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Feasycon_regions extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/FeasyconRegions_model');
	   $this->load->helper(['jwt', 'authorization']);  
	   $this->load->library('getid3/getid3');
    }
    
   	
	public function feasyconregions_listing_get(){
		// Send the return data as reponse
		//if($data==TRUE){

			$regionresult = $this->FeasyconRegions_model->region_listing();
			$regioncount = $this->FeasyconRegions_model->region_listing_count();
			$get_version = $this->FeasyconRegions_model->get_version();
			if($regionresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $regionresult,'version'=>$get_version,'count'=>$regioncount,
			 'message' => 'Feasycon Region Listing.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status,'count'=>$regioncount, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		//}
	}
	
}