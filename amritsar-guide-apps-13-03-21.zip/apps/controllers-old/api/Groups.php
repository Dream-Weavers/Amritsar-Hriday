<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Groups extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Groups_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}


    public function search_friend_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		    $search_keyword  = $this->post('search_keyword');
			$searchdata = $this->Groups_model->search_friend($user_id,$search_keyword);
			if($searchdata==TRUE){
				$status = parent::HTTP_OK;
			 	$response = ['status' => $status,
				  'data' => $searchdata,
				  'message' => 'Friend search successfully.'
				 ];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function add_group_post()
	{  // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$group_name = $this->post('group_name');
			$group_passcode = $this->post('group_passcode');
			$group_desc = $this->post('group_desc');
			$group_member_ids = $this->post('friend_user_ids');
			
			$members_arr=array();
			if (strpos($group_member_ids, ',') !== false) {
                $explodeid=explode(',',$group_member_ids);
                foreach($explodeid as $val){
                        $members_arr['uid'][$val]=$val;
                   
                }
                $member_json=json_encode($members_arr);
                $group_data=array('language_id'=>$language_id,'group_name'=>$group_name,'group_passcode'=>$group_passcode,'group_desc'=>$group_desc,'group_owner_id'=>$user_id,'created_by'=>$user_id,'group_member_ids'=>$member_json,'created_on'=>date('Y-m-d H:i:s'));
                $groupresult = $this->Groups_model->insert_group($group_data);
            }else{
                 $members_arr['uid'][$group_member_ids]=$group_member_ids;
                 $member_json=json_encode($members_arr);
                $group_data=array('language_id'=>$language_id,'group_name'=>$group_name,'group_passcode'=>$group_passcode,'group_desc'=>$group_desc,'group_owner_id'=>$user_id,'created_by'=>$user_id,'group_member_ids'=>$member_json,'created_on'=>date('Y-m-d H:i:s'));
		                $groupresult = $this->Groups_model->insert_group($group_data);
            }
			
		
			if($groupresult=='1'){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
			}
			else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	
	public function edit_group_post()
	{   // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$group_id = $this->post('group_id');
			$groupsresult = $this->Groups_model->group_info($user_id,$language_id,$group_id);
			
			//$group_name = $this->post('group_name');
			//$group_passcode = $this->post('group_passcode');
			//$group_desc = $this->post('group_desc');
			//$group_member_ids = $this->post('friend_user_ids');
			
			/*$group_data=array('group_name'=>$group_name,'group_passcode'=>$group_passcode,'group_desc'=>$group_desc,'group_member_ids'=>$group_member_ids,'created_on'=>date('Y-m-d H:i:s'));
			$updategroupresult = $this->Groups_model->update_group($language_id,$group_id,$user_id,$group_data);
			if($updategroupresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data updated successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			}*/ 
			if($groupsresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => $groupsresult];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			}
			$this->response($response, $status);
		}
	}
	
	
	public function group_update_friends_post()
	{   // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$group_id = $this->post('group_id');
			$group_name = $this->post('group_name');
			$group_passcode = $this->post('group_passcode');
			$group_desc = $this->post('group_desc');
			$group_member_ids = $this->post('friend_user_ids');
			$members_arr=array();
			if($group_member_ids!=''){
    			if (strpos($group_member_ids, ',') !== false) {
                    $explodeid=explode(',',$group_member_ids);
                    foreach($explodeid as $val){
                            $members_arr['uid'][$val]=$val;
                    }
                    $member_json=json_encode($members_arr);
    			}else{
    			    $members_arr['uid'][$group_member_ids]=$group_member_ids;
                    $member_json=json_encode($members_arr);
    			}
    			
    			$group_data=array('group_name'=>$group_name,'group_passcode'=>$group_passcode,'group_desc'=>$group_desc,'group_member_ids'=>$member_json,'created_on'=>date('Y-m-d H:i:s'));
    			$updategroupresult = $this->Groups_model->update_group($language_id,$group_id,$user_id,$group_data);
			}else{
			    $group_data=array('group_name'=>$group_name,'group_passcode'=>$group_passcode,'group_desc'=>$group_desc,'created_on'=>date('Y-m-d H:i:s'));
    			$updategroupresult = $this->Groups_model->update_group($language_id,$group_id,$user_id,$group_data);
			}
			
		
		    //$updategroupresult = $this->Groups_model->group_update_friends($language_id,$group_id,$user_id,$group_member_ids);
			if($updategroupresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data updated successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	
	/*public function delete_group_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$tour_trail_location_id = $this->post('tour_trail_location_id');
			$tour_trail_id = $this->post('tour_trail_id');
			
			$deletetraillocationresult = $this->Tour_trails_model->delete_tour_trail_location($language_id,$user_id,$tour_trail_location_id,$tour_trail_id);
			if($deletetraillocationresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data Deleted successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}*/
	
	
	public function delete_group_post(){
	    $data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$group_id = $this->post('group_id');
		//	print $group_id;
			$groupsresult = $this->Groups_model->delete_group($user_id,$group_id);
			if($groupsresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' =>'group deleted.',
			 'message' => 'group deleted.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function my_groups_post()
	{	// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
			    
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			
			$language_id = $this->post('language_id');
			$groupsresult = $this->Groups_model->my_groups($user_id,$language_id);
			if($groupsresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $groupsresult,
			 'message' => 'My Groups Data.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}


}