<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Appversion extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/appversion_model');

    }
	 
	public function app_version_get()
	{	
	    //$language_id = $this->get('language_id');
		$data = $this->appversion_model->get_version();	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Get Version',
				'beacon_delay_time'=>1800,
				'gps_delay_time'=>30,
				'data' => $data,
			], REST_Controller::HTTP_OK);
			
			
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}