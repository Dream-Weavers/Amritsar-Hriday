<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class User_profile extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/User_profile_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}

	public function user_info_get(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$getuser_info = $this->User_profile_model->user_getinfo($user_id);
			if($getuser_info){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => $getuser_info];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
		
	}
	public function update_profile_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			//print $user_id;
			//$checkuser_input=
			$first_name = $this->post('first_name');
			$last_name = $this->post('last_name');
			$address = $this->post('address');
			$country_id = $this->post('country_id');
			$state_id = $this->post('state_id');
			$city_id = $this->post('city_id');
			$phone = $this->post('mobile');
			$email = $this->post('email');
			$language_id = $this->post('language_id');
			//print $user_id;
			if($email!=''){
			    $update_profile=array('first_name'=>$first_name,'last_name'=>$last_name,'email'=>$email);
			}
			if($phone!=''){
			    $update_profile=array('first_name'=>$first_name,'last_name'=>$last_name,'mobile_no1'=>$phone);
			}
			$update_address=array('user_id'=>$user_id,'country_id'=>$country_id,'state_id'=>$state_id,'city_id'=>$city_id,'address'=>$address,'language_id'=>$language_id,'post_date'=>date('Y-m-d H:i:s'));
			$counter = $this->User_profile_model->update_profile($user_id,$update_profile);
			$update_address = $this->User_profile_model->update_address($user_id,$update_address);
			if($counter==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data updated'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function user_change_password_post() {  
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$old_password=$this->post('old_password');
			$new_password=$this->post('new_password');
			$verify_old_pwd=$this->User_profile_model->verify_old_pwd($user_id,$old_password);
			if($verify_old_pwd==TRUE){
				$result = $this->User_profile_model->change_password($user_id,$new_password);
				if($result==TRUE){
					$status = parent::HTTP_OK;
					$response = ['status' => $status, 'data' => 'Password changed successfully'];
				}else{
					$status = parent::HTTP_UNAUTHORIZED;
					$response = ['status' => $status, 'msg' => 'Error'];
				} 
				
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Old password is not correct.'];
			}
			$this->response($response, $status);
		}
	
        
    }
    
    public function user_online_status_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$online_status=$this->post('online_status');
			$getuser_info = $this->User_profile_model->online_status($user_id,$online_status);
			if($getuser_info){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'user online status updated successfully'];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
		
	}
	
	public function user_latlng_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$user_latitude=$this->post('user_latitude');
			$user_longitude=$this->post('user_longitude');
			$getuser_info = $this->User_profile_model->user_latlng_status($user_id,$user_latitude,$user_longitude);
			if($getuser_info){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'user lat and lng updated successfully'];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
		
	}
	
	public function profile_image_post(){
	    $data = $this->verify_request();
	    if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		
		
		    $image_type=$this->post('profile_image');
            //print $image_type;die;
            if($image_type!=''){
            	$image = str_replace('data:image/png;base64,', '', $image_type);
            	$image = str_replace(' ', '+', $image);
            	// Decode the Base64 encoded Image
            	$data = base64_decode($image);
            	$path_orig='/home/dsysin607/public_html/codeigniter/hriday/assets/static/user_photos/original';
            	$path_resize='/home/dsysin607/public_html/codeigniter/hriday/assets/static/user_photos/resized';
            	$imgname=time().'.jpg';
            	$filename_get=$user_id.'-'.$imgname;
            	$filename = $path_orig.'/' .$filename_get;
            	$success = file_put_contents($filename, $data);
            	
            	$filename_resize = $path_resize.'/' .$filename_get;
            	$success = file_put_contents($filename_resize, $data);
            }
		
		
			$getuser_info = $this->User_profile_model->user_profile_image_update($user_id,$filename_get);
			$profile_image=base_url().'assets/static/user_photos/original/'.$filename_get;
			if($getuser_info){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => $profile_image];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
	}
    
}