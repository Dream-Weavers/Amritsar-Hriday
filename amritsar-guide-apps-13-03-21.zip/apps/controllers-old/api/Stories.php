<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Stories extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Story_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
    
    private function verify_request(){
        // Get all the headers
        $headers = $this->input->request_headers();
        // Extract the token

        $token = $headers['Authorization'];
        // Use try-catch
        // JWT library throws exception if the token is not valid
        try {
            // Validate the token
            // Successfull validation will return the decoded user data else returns false
            $data = AUTHORIZATION::validateToken($token);
            if ($data === false) {
                $status = parent::HTTP_UNAUTHORIZED;
                $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
                $this->response($response, $status);
                exit();
            } else {
                return $data;
            }
        } catch (Exception $e) {
            // Token is invalid
            // Send the unathorized access message
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
            $this->response($response, $status);
        }
    }
    
    public function add_story_post()
	{  // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$title = $this->post('title');
			$language_id = $this->post('language_id');
			$story_desc = $this->post('description');
			$featured_img = $this->post('featured_img');
			
		
			$post_vl['language_id']=$language_id;
			$post_vl['story_title']=$title;
			$post_vl['description']=$story_desc;
			$post_vl['user_id']=$user_id;
			if($featured_img!=''){
			    
    			$image = str_replace('data:image/png;base64,', '', $featured_img);
    			$image = str_replace(' ', '+', $image);
    			// Decode the Base64 encoded Image
    			$data = base64_decode($image);
    			$path='/home/u385515540/domains/g4me.in/public_html/hriday/images/story/';
    			$imgname=$user_id.'_'.time().'.jpg';
    			$filename = $path.'/' .$imgname;
    			
    			$success = file_put_contents($filename, $data);
		        $post_vl['image_url']=$imgname;
			}
		
			
		//	print '<pre>';print_r($user_info);
		 	$blogresult = $this->Story_model->add_story($post_vl);
			if($blogresult>0){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
			}
			else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	

	
	
	public function story_detail_get(){
	    $data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		//$language_id=$this->get('language_id');
		$story_id=$this->get('story_id');
		if($story_id==''){
			    $status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Story id is missing.'];
				$this->response($response, $status);
			}
		$blogresult = $this->Story_model->story_detail($user_id,$story_id);
			if($blogresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $blogresult,
			 'message' => 'Story detail.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status,'count'=>$blogcount, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function story_listing_get(){
	    $data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		$language_id=$this->get('language_id');
	//	$category_id=$this->get('category_id');
			$page_no=$this->get('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->get('limit');
			if($limit==''){
				$limit=10;
			}
			
			//print $user_id;
			$blogresult = $this->Story_model->story_listing($user_id,$language_id,$page_no,$limit);
			$blogcount = $this->Story_model->story_listing_count($user_id,$language_id,$page_no,$limit);
			if($blogresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $blogresult,'count'=>$blogcount,
			 'message' => 'Story Listing.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status,'count'=>$blogcount, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
    
}