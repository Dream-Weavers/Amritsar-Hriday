<?php

require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Vendors extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Vendor_model');
	   $this->load->helper(['jwt', 'authorization']);

    }
private function verify_request(){
        // Get all the headers
        $headers = $this->input->request_headers();
        // Extract the token

        $token = $headers['Authorization'];
        // Use try-catch
        // JWT library throws exception if the token is not valid
        try {
            // Validate the token
            // Successfull validation will return the decoded user data else returns false
            $data = AUTHORIZATION::validateToken($token);
            if ($data === false) {
                $status = parent::HTTP_UNAUTHORIZED;
                $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
                $this->response($response, $status);
                exit();
            } else {
                return $data;
            }
        } catch (Exception $e) {
            // Token is invalid
            // Send the unathorized access message
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
            $this->response($response, $status);
        }
    }

	public function particular_vendor_details_get(){
		$vendor_id=$this->get('vendor_id');
		$language_id=$this->get('language_id');
		$page_no=$this->post('page_no');
		if($page_no==''){
			$page_no=1;
		}
		$limit=$this->post('limit');
		if($limit==''){
			$limit=10;
		}
		
		$data = $this->Vendor_model->particular_vendor_details($language_id,$vendor_id,$page_no,$limit);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Vendor detail',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	public function all_vendor_details_get(){
		$page_no=$this->get('page_no');
		if($page_no==''){
			$page_no=1;
		}
		$limit=$this->get('limit');
		if($limit==''){
			$limit=10;
		}
			$language_id=$this->get('language_id');
		$data = $this->Vendor_model->all_vendor_details($page_no,$limit);	
		$count = $this->Vendor_model->all_vendor_details_count();	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Vendor detail',
				'count'=>$count,
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	public function add_vendor_review_post(){
	   
	    $data = $this->verify_request();
        // Send the return data as reponse
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        	
        	$vendor_id=$this->post('vendor_id');
            $language_id=$this->post('language_id');
            $rating=$this->post('rating');
        	
        	
        	
        	if($vendor_id==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'vendor id is missing.'];
        		$this->response($response, $status);
            }
            if($language_id==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'Language id is missing.'];
        		$this->response($response, $status);
            }
            if($rating==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'rating is missing.'];
        		$this->response($response, $status);
            }
            
            $comment=$this->post('comment');
            
            $post_vl['user_id']=$user_id;
            $post_vl['language_id']=$language_id;
            $post_vl['comment']=$comment;
            $post_vl['rating']=$rating;
            $post_vl['vendor_id']=$vendor_id;
            
            
                                
        	$blogresult = $this->Vendor_model->add_reviews($post_vl);
            if($blogresult>0){
            	$status = parent::HTTP_OK;
            	$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
            }
            else{
            	$status = parent::HTTP_BAD_REQUEST;
            	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
            }
            
        	$this->response($response, $status);
        }
	}
	public function fetch_location_review_get(){
	  
    	$vendor_id=$this->get('vendor_id');
        $language_id=$this->get('language_id');
    	
    	if($vendor_id==''){
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'vendor id is missing.'];
    		$this->response($response, $status);
        }
        if($language_id==''){
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'Language id is missing.'];
    		$this->response($response, $status);
        }
        $post_vl['language_id']=$language_id;
        $post_vl['vendor_id']=$vendor_id;
      	$page_no=$this->get('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->get('limit');
			if($limit==''){
				$limit=10;
			}
    	$reviwesresult = $this->Vendor_model->fetch_reviews($post_vl,$page_no,$limit);
    	$reviwesresultcount = $this->Vendor_model->fetch_reviews_count($post_vl);
        if($reviwesresult>0){
        	$status = parent::HTTP_OK;
        	$ratinginfo_five=$this->Vendor_model->ratingcount($vendor_id,$language_id,5);
        	$ratinginfo_four=$this->Vendor_model->ratingcount($vendor_id,$language_id,4);
        	$ratinginfo_three=$this->Vendor_model->ratingcount($vendor_id,$language_id,3);
        	$ratinginfo_two=$this->Vendor_model->ratingcount($vendor_id,$language_id,2);
        	$ratinginfo_one=$this->Vendor_model->ratingcount($vendor_id,$language_id,1);
        	$response = ['status' => $status, 'data' => $reviwesresult,'count'=>$reviwesresultcount,'5star'=>$ratinginfo_five,'4star'=>$ratinginfo_four,'3star'=>$ratinginfo_three,'2star'=>$ratinginfo_two,'1star'=>$ratinginfo_one];
        }
        else{
        	$status = parent::HTTP_BAD_REQUEST;
        	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
        }
        
    	$this->response($response, $status);
    }
    
	
	
}