<?php
require APPPATH . '/libraries/REST_Controller.php';

class Common extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Common_model');

    }


	 
	public function all_country_get(){
		$language_id = $this->get('language_id');
		$data = $this->Common_model->country_list($language_id);
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Module Information',
				'data' => $data
			], REST_Controller::HTTP_OK);
		}
	}
	public function select_state_get(){
		$language_id = $this->get('language_id');
		$country_id = $this->get('country_id');
		$data = $this->Common_model->state_list($language_id,$country_id);
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Module Information',
				'data' => $data
			], REST_Controller::HTTP_OK);
		}
	}
	public function select_city_get(){
		$language_id = $this->get('language_id');
		$state_id = $this->get('state_id');
		$data = $this->Common_model->city_list($language_id,$state_id);
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Module Information',
				'data' => $data
			], REST_Controller::HTTP_OK);
		}
	}
	
		public function select_department_get(){
		$language_id = $this->get('language_id');
		$data = $this->Common_model->department_list($language_id);
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Department Information',
				'data' => $data
			], REST_Controller::HTTP_OK);
		}
	}
	
}