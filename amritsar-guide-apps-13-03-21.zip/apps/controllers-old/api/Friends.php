<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Friends extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Friends_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}


    public function search_friend_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$page_no=$this->post('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->post('limit');
			if($limit==''){
				$limit=10;
			}
		    $search_keyword  = $this->post('search_keyword');
			$searchdata = $this->Friends_model->search_friend($user_id,$search_keyword,$page_no,$limit);
			$totalfriends = $this->Friends_model->search_total_friend($user_id,$search_keyword,$page_no,$limit);
			if($searchdata==TRUE){
				$status = parent::HTTP_OK;
			 	$response = ['status' => $status,
			 	'total'=>$totalfriends,
				  'data' => $searchdata,
				  'message' => 'Friend search successfully.'
				 ];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function add_friend_post()
	{  // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$friend_user_id = $this->post('friend_user_id');
		 	$friendresult = $this->Friends_model->insert_friend($user_id,$friend_user_id);
			if($friendresult>0){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data inserted successfully.','friendship_id'=>$friendresult];
			}
			elseif($friendresult=='already'){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Friend Request Already send.'];
			}
			else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function pending_friend_request_post()
	{	// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			
			$page_no=$this->post('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->post('limit');
			if($limit==''){
				$limit=10;
			}
			
			//print $user_id;
			$pendingresult = $this->Friends_model->pending_friend_request($user_id,$page_no,$limit);
			$pendingcount = $this->Friends_model->pending_friend_request_count_pending($user_id,$page_no,$limit);
			if($pendingresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $pendingresult,'count'=>$pendingcount,
			 'message' => 'Pending Friend Request Data.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status,'count'=>$pendingcount, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function request_status_update_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$friendship_id = $this->post('friendship_id');
			$status = $this->post('status');
			//print $user_id;
			$requeststatusresult = $this->Friends_model->request_status_update($friendship_id,$user_id,$status);
			if($requeststatusresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Request Status updated successfully.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	
	public function friend_list_post()
	{	// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$search_keyword = $this->post('search_keyword');
			$page_no = $this->post('page_no');
			$limit = $this->post('limit');
			
			
			 $friendresult = $this->Friends_model->friend_list($user_id,$search_keyword,$page_no,$limit);
			 
			 $friendresultcount = $this->Friends_model->friend_list_count($user_id,$search_keyword);
			 $pendingresult = $this->Friends_model->pending_friend_request_count($user_id);
			 if($friendresult==TRUE){
			 $status = parent::HTTP_OK;
			 $response = ['status' => $status,'pending_count'=>$pendingresult,'total_friend_count'=>$friendresultcount,
			 'data' => $friendresult,
			 'message' => 'All Friends Data.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['pending_count'=>$pendingresult,'status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function remove_friend_post(){
	    	$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$friendship_id = $this->post('friend_id');
		//	print $friendship_id;
			 $friendresult = $this->Friends_model->remove_friend($user_id,$friendship_id);
			//$pendingresult = $this->Friends_model->pending_friend_request_count($user_id);
			 if($friendresult==TRUE){
			 $status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $friendresult,
			 'message' => 'removed as friend.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}


}