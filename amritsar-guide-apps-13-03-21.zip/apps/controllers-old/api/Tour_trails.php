<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Tour_trails extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Tour_trails_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}

    public function get_Categorytype_Locations_get(){
		$language_id=$this->get('language_id');
		$data = $this->Tour_trails_model->get_Categorytypes_Locations($language_id);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Category Type Locations Information',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}

	public function user_tour_trails_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$page_no=$this->post('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->post('limit');
			if($limit==''){
				$limit=10;
			}
			$language_id = $this->post('language_id');
			$user_tour_trails_result = $this->Tour_trails_model->user_tour_trails($user_id,$language_id,$page_no,$limit);
				$user_tour_trails_count = $this->Tour_trails_model->user_tour_trails_count($user_id,$language_id);
			if($user_tour_trails_result){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,'total'=>$user_tour_trails_count,
				 'message' => 'User Tour & Trails Details',
				 'data' => $user_tour_trails_result];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
		
	}
	
	public function user_tour_trail_info_post(){
		/*$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		}else{
		    $user_id=0;
		}*/
		$user_id=0;
			$language_id = $this->post('language_id');
			$tour_trail_id = $this->post('tour_trail_id');
			$user_tour_trails_result = $this->Tour_trails_model->user_tour_trail_info($user_id,$language_id,$tour_trail_id);
			if($user_tour_trails_result){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'User Tour & Trail Info',
				 'data' => $user_tour_trails_result];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		//}
		
	}
	
	public function add_tour_trails_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		
			$tour_trail_name = $this->post('tour_trail_name');
			$tour_trail_description = $this->post('tour_trail_description');
			$language_id = $this->post('language_id');
			$location_data = $this->post('location_data');
			$userdefine_time = $this->post('userdefine_time');
			$travel_time = $this->post('travel_time');
			if($userdefine_time=='')
			{
		    	$tour_trail_data=array('language_id'=>$language_id,'user_id'=>$user_id,'tour_trail_name'=>$tour_trail_name,'tour_trail_description'=>$tour_trail_description,'created_on'=>date('Y-m-d H:i:s'));
			}else{
			    $tour_trail_data=array('language_id'=>$language_id,'user_id'=>$user_id,'tour_trail_name'=>$tour_trail_name,'tour_trail_description'=>$tour_trail_description,'created_on'=>date('Y-m-d H:i:s'),'userdefine_time'=>$userdefine_time,'travel_time'=>$travel_time);
			}
			$tour_trail_id = $this->Tour_trails_model->insert_tour_trails($tour_trail_data);
			
			if($tour_trail_id)
			{
				//$location_result_data = json_decode($location_data, true);
				$location_result_data = $location_data;
				if($location_result_data!='')
				{
				    $explode=explode(',',$location_result_data);
    				 foreach($explode as $lockey => $locval) {
    					 $location_id =  $locval;
    					 $weight=$lockey+1;
    					 $tour_trail_location_data=array('tour_trail_id'=>$tour_trail_id,'location_id'=>$location_id,'weight'=>$weight);
    					 $inserttrailresult = $this->Tour_trails_model->insert_tour_trail_locations($tour_trail_location_data);
    				 }
				}
			  }
			
			if($inserttrailresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	
	public function edit_tour_trails_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$tour_trail_id = $this->post('tour_trail_id');
			$tour_trail_name = $this->post('tour_trail_name');
			$tour_trail_description = $this->post('tour_trail_description');
			$language_id = $this->post('language_id');
			$location_data = $this->post('location_data');
			$userdefine_time = $this->post('userdefine_time');
			$travel_time = $this->post('travel_time');
			if($userdefine_time==''){
			$tour_trail_data=array('language_id'=>$language_id,'tour_trail_name'=>$tour_trail_name,'tour_trail_description'=>$tour_trail_description,'created_on'=>date('Y-m-d H:i:s'));
			}else{
			    $tour_trail_data=array('language_id'=>$language_id,'tour_trail_name'=>$tour_trail_name,'tour_trail_description'=>$tour_trail_description,'created_on'=>date('Y-m-d H:i:s'),'userdefine_time'=>$userdefine_time,'travel_time'=>$travel_time);
			}
			$updatetrailresult = $this->Tour_trails_model->update_tour_trails($tour_trail_id,$user_id,$tour_trail_data);
			if($updatetrailresult)
			{
				//$location_result_data = json_decode($location_data, true);
				$location_result_data = $location_data;
				if($location_result_data!='')
				{
				 $this->db->where('tour_trail_id',$tour_trail_id); 
				 $deleteresult = $this->db->delete('tour_trail_locations');
				 if($deleteresult)
				 {
				     $explodeloc=explode(',',$location_result_data);
				  foreach($explodeloc as $lockey => $locval) {
					 $location_id =  $locval;
					 $weight=$lockey+1;
					 $tour_trail_location_data=array('tour_trail_id'=>$tour_trail_id,'location_id'=>$location_id,'weight'=>$weight);
					 $updatetrailresult = $this->Tour_trails_model->update_tour_trail_locations($tour_trail_id,$tour_trail_location_data);
				  }
				 } 
			   }
			  }
			if($updatetrailresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data updated successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	
	public function delete_tour_trail_location_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
		//	$tour_trail_location_id = $this->post('tour_trail_location_id');
			$tour_trail_id = $this->post('tour_trail_id');
		//	print $tour_trail_id;
			$deletetraillocationresult = $this->Tour_trails_model->delete_tour_trail_location($language_id,$user_id,$tour_trail_id);
			if($deletetraillocationresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data Deleted successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	function predefined_tours_get(){
	     $page_no=$this->get('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->get('limit');
			if($limit==''){
				$limit=10;
			}
			$language_id = $this->get('language_id');
			$predefined_tour = $this->Tour_trails_model->predefined_tours($language_id,$page_no,$limit);
			$count = $this->Tour_trails_model->predefined_tours_count();
			//print '<pre>';print_r($predefined_tour);die;
			if($predefined_tour!=''){
				$status = parent::HTTP_OK;
				$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Predeifned Tours',
				'count'=>$count,
				'data' => $predefined_tour
			], REST_Controller::HTTP_OK);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			//$this->response($response, $status);
		
	}


}