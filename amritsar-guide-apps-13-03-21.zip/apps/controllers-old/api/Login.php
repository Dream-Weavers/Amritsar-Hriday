<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Login extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Login_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	
	function user_login_post(){
		$user_input = $this->post('user_input');
		$password = $this->post('password');
		
		$mobilePattern ="/^[7-9][0-9]{9}$/"; 
		$photo='';
		if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
			$result=$this->Login_model->user_login_via_email($user_input,$password);
			$fildarr=array('email'=>$user_input,'user_type'=>'U');
			$getuser_arr=gettableinfo('users',$fildarr);
			
			if($getuser_arr->user_photo!=''){
				$photo=users_photo_path.$getuser_arr->user_photo;
			}
			if($getuser_arr->response_code!='' && $photo==''){
			    $responsedecode=json_decode($getuser_arr->response_code,true);
			    $photo=$responsedecode['user_dp'];
			}
			if($photo=='' || $photo==null){
			    $photo =base_url().'images/male.jpg';
			}
		}else if(preg_match($mobilePattern, $user_input)){
			$result=$this->Login_model->user_login_via_mobile($user_input,$password);
			$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
			$getuser_arr=gettableinfo('users',$fildarr);
			if($getuser_arr->user_photo!=''){
				$photo=users_photo_path.$getuser_arr->user_photo;
			}
			if($getuser_arr->response_code!=NULL){
			    $responsedecode=json_decode($getuser_arr->response_code,true);
			    if($responsedecode['user_dp']!='')
			    $photo=$responsedecode['user_dp'];
			}
			$fileexist=$this->check_filexists($row['user_photo_path']);
			$row['user_photo_path'] =$fileexist;
			if($photo=='' || $photo==null){
			    $photo =base_url().'images/male.jpg';
			}
		}else{
			$result=False;
		    }
		   // print 'ssss'.$result.'fff';
		 if($result==1){
			 $token = AUTHORIZATION::generateToken(['user_input' => $user_input]);
			// Prepare the response
            $status = parent::HTTP_OK;
			
			$addressfield=array('user_address_id'=>$getuser_arr->user_address_id,'is_primary'=>'1');
			$useraddressrow=gettableinfo('user_address',$addressfield);
			if($useraddressrow!='0')
			{
			 $country_id = $useraddressrow->country_id;
			 $state_id = $useraddressrow->state_id;
			 $city_id = $useraddressrow->city_id;
			 $address = $useraddressrow->address;
			 $pin_code = $useraddressrow->pin_code;
			}else
			{
			 $country_id = '';
			 $state_id = '';
			 $city_id = '';
			 $address = '';
			 $pin_code = '';
			}
			
			$response = ['status' => $status, 'token' => $token,'user_id'=>$getuser_arr->user_id,'first_name'=>$getuser_arr->first_name,'last_name'=>$getuser_arr->last_name,'mobile_no'=>$getuser_arr->mobile_no1,'email'=>$getuser_arr->email,'gender'=>$getuser_arr->gender,'user_photo'=>$photo,'country_id'=>$country_id,'state_id'=>$state_id,'city_id'=>$city_id,'address'=>$address,'pin_code'=>$pin_code,'online_status'=>$getuser_arr->user_online_status];
            $this->response($response, $status);
				// Create a token from the user data and send it as reponse
		}else if($result==3){
			$this->response([
				'status' => False,
				'message' => 'User Inactive',
			], REST_Controller::HTTP_BAD_REQUEST);
		} else{
			$this->response([
				'status' => False,
				'message' => 'There is an error.',
			], REST_Controller::HTTP_BAD_REQUEST);
		} 
		
	}
	
	function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             //return base_url().'images/male.jpg';
             return '';
        }
	
	}
	
	private function verify_request()
	{
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
		
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}
	public function get_me_data_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$status = parent::HTTP_OK;
			$response = ['status' => $status, 'data' => $data];
			$this->response($response, $status);
		}
	}
	
	


}