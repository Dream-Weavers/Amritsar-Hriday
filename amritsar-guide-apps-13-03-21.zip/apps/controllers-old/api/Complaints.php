<?php
error_reporting(1);
ini_set('display_errors', 1);
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Complaints extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Complaints_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}
	
	public function add_complaint_post()
	{  // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$complaint_type = '1';
			$department_id = $this->post('department_id');
			//$department_id = 1;
			$complaint_title = $this->post('complaint_title');
			$complaint_description = $this->post('complaint_description');
			
			$image_type=$this->post('image_file');
			$audio_type=$this->post('audio_file');
			$video_type=$this->post('video_file');
			//print $image_type;die;
			if($image_type!=''){
				$image = str_replace('data:image/png;base64,', '', $image_type);
				$image = str_replace(' ', '+', $image);
				// Decode the Base64 encoded Image
				$data = base64_decode($image);
				$path='/home/u385515540/domains/g4me.in/public_html/hriday/assets/complaints/image/';
				$imgname='_'.time().'.jpg';
				$filename = $path.'/' .$imgname;
				
				$success = file_put_contents($filename, $data);
			}
			
			if($audio_type!=''){
				$audio = str_replace('data:image/png;base64,', '', $audio_type);
				$audio = str_replace(' ', '+', $audio);
				// Decode the Base64 encoded Image
				$audiodata = base64_decode($audio);
				$audiopath='/home/u385515540/domains/g4me.in/public_html/hriday/assets/complaints/audio/';
				$audioname='_'.time().'.mp3';
				$audiofilename = $audiopath.'/' .$audioname;
				
				$success = file_put_contents($audiofilename, $audiodata);
			}
			
			if($video_type!=''){
				$video = str_replace('data:image/png;base64,', '', $video_type);
				$video = str_replace(' ', '+', $video);
				// Decode the Base64 encoded Image
				$videodata = base64_decode($video);
				$videopath='/home/u385515540/domains/g4me.in/public_html/hriday/assets/complaints/video/';
				$videoname='_'.time().'.mp4';
				$videofilename = $videopath.'/' .$videoname;
				
				$success = file_put_contents($videofilename, $videodata);
			}
			
			$complaint_data=array('language_id'=>$language_id,'complaint_type'=>$complaint_type,'department_id'=>$department_id,'complaint_title'=>$complaint_title,'complaint_description'=>$complaint_description,'post_user_id'=>$user_id,'created_on'=>date('Y-m-d H:i:s'));
		    $complaint_id = $this->Complaints_model->insert_complaint($complaint_data);
			if($complaint_id)
			{

			  if($image_type!=''){
				$image_data=array(
					'image_file'=>$imgname,
					//'video_file'=>$_POST['subject'],
				); 
				$complaintimageresult = $this->Complaints_model->update_complaint_image($complaint_id,$user_id,$image_data);
			  }
			  if($audio_type!=''){
			  
				$audio_data=array(
					'audio_file'=>$audioname,
					//'video_file'=>$_POST['subject'],
				); 
				$complaintimageresult = $this->Complaints_model->update_complaint_image($complaint_id,$user_id,$audio_data);
			  }
			   if($video_type!=''){
			  
				$video_data=array(
					'video_file'=>$videoname,
					//'video_file'=>$_POST['subject'],
				); 
				$complaintimageresult = $this->Complaints_model->update_complaint_image($complaint_id,$user_id,$video_data);
			  }
			  $complaintdata = $this->Complaints_model->complaint_data($complaint_id);
			   
			}
			//print '<pre>';print_r($complaintdata);die;
			if($complaint_id==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => $complaintdata];
			}
			else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	
	public function updatecomplaint_post(){
		$audiofile='';
		$data = $this->verify_request();
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			 if(isset($_FILES["audiofile"]["name"])){
				$target_dir = '/home/dsysin607/public_html/codeigniter/hriday/assets/complaints/audio/';
				$nameget=$_FILES["audiofile"]["name"];
				$target_file = $target_dir . basename($nameget);
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				if (move_uploaded_file($_FILES["audiofile"]["tmp_name"], $target_file)) {
					$audiofile=$_FILES["audiofile"]["name"];
					
				} else {
					//echo "Sorry, there was an error uploading your file.";
				}
			}
			$image_data=array(
			   'audio_file'=>$audiofile,
			   //'video_file'=>$_POST['subject'],
			); 
			 
			$complaint_id=$this->post('complaint_id');
			$complaintimageresult = $this->Complaints_model->update_complaint_image($complaint_id,$user_id,$image_data);
			
		
			if($complaintimageresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data updated successfully.'];
			}
			else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			}
			$this->response($response, $status);			
		}	
		
	}
	
	
	public function add_feedback_post()
	{  // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$star_rating = $this->post('star_rating');
			$complaint_type = '2';
			$by_name = $this->post('by_name');
			$comments = $this->post('comments');
			
			$feedback_data=array('language_id'=>$language_id,'star_rating'=>$star_rating,'complaint_type'=>$complaint_type,'complaint_title'=>$by_name,'complaint_description'=>$comments,'post_user_id'=>$user_id,'created_on'=>date('Y-m-d H:i:s'));
		    $feedbackresult = $this->Complaints_model->insert_feedback($feedback_data);
			if($feedbackresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
			}
			else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	

}