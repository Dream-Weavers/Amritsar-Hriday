<?php

require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Products extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Product_model');
	   $this->load->helper(['jwt', 'authorization']);

    }
private function verify_request(){
        // Get all the headers
        $headers = $this->input->request_headers();
        // Extract the token

        $token = $headers['Authorization'];
        // Use try-catch
        // JWT library throws exception if the token is not valid
        try {
            // Validate the token
            // Successfull validation will return the decoded user data else returns false
            $data = AUTHORIZATION::validateToken($token);
            return $data;
            /*if ($data === false) {
                $status = parent::HTTP_UNAUTHORIZED;
                $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
                $this->response($response, $status);
                exit();
            } else {
                return $data;
            }*/
        } catch (Exception $e) {
            // Token is invalid
            // Send the unathorized access message
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
            $this->response($response, $status);
        }
    }

	public function particular_vendor_details_get(){
		$vendor_id=$this->get('vendor_id');
		$language_id=$this->get('language_id');
		$page_no=$this->post('page_no');
		if($page_no==''){
			$page_no=1;
		}
		$limit=$this->post('limit');
		if($limit==''){
			$limit=10;
		}
		
		$data = $this->Vendor_model->particular_vendor_details($language_id,$vendor_id,$page_no,$limit);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Vendor detail',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	public function all_product_details_get(){
	    $data = $this->verify_request();
	    $user_id=0;
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        }
		$page_no=$this->get('page_no');
		if($page_no==''){
			$page_no=1;
		}
		$limit=$this->get('limit');
		if($limit==''){
			$limit=10;
		}
		$language_id=$this->get('language_id');
		$data = $this->Product_model->all_product_details($language_id,$page_no,$limit,$user_id);	
		$count = $this->Product_model->all_product_details_count($language_id);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Product listing',
				'count'=>$count,
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
		public function particular_product_details_get(){
		    
		    $data = $this->verify_request();
        // Send the return data as reponse
        $user_id=0;
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        }
		    
		$product_id=$this->get('product_id');
		$language_id=$this->get('language_id');
	
		
		$data = $this->Product_model->particular_product_details($language_id,$product_id,$user_id);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Product detail',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	public function add_review_post(){
	   
	    $data = $this->verify_request();
        // Send the return data as reponse
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        	
        	$product_id=$this->post('product_id');
            $language_id=$this->post('language_id');
            $rating=$this->post('rating');
        	
        	
        	
        	if($product_id==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'vendor id is missing.'];
        		$this->response($response, $status);
            }
            if($language_id==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'Language id is missing.'];
        		$this->response($response, $status);
            }
            if($rating==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'rating is missing.'];
        		$this->response($response, $status);
            }
            
            $comment=$this->post('comment');
            
            $post_vl['user_id']=$user_id;
            $post_vl['language_id']=$language_id;
            $post_vl['comment']=$comment;
            $post_vl['rating']=$rating;
            $post_vl['product_id']=$product_id;
            
            
                                
        	$blogresult = $this->Product_model->add_reviews($post_vl);
            if($blogresult>0){
            	$status = parent::HTTP_OK;
            	$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
            }
            else{
            	$status = parent::HTTP_BAD_REQUEST;
            	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
            }
            
        	$this->response($response, $status);
        }
	}
	
	public function fetch_review_get(){
	  
    	$product_id=$this->get('product_id');
        $language_id=$this->get('language_id');
    	
    	if($product_id==''){
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'product id is missing.'];
    		$this->response($response, $status);
        }
        if($language_id==''){
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'Language id is missing.'];
    		$this->response($response, $status);
        }
        $post_vl['language_id']=$language_id;
        $post_vl['product_id']=$product_id;
      	$page_no=$this->get('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->get('limit');
			if($limit==''){
				$limit=10;
			}
    	$reviwesresult = $this->Product_model->fetch_reviews($post_vl,$page_no,$limit);
    	$reviwesresultcount = $this->Product_model->fetch_reviews_count($post_vl);
        if($reviwesresult>0){
        	$status = parent::HTTP_OK;
        	$ratinginfo_five=$this->Product_model->ratingcount($product_id,$language_id,5);
        	$ratinginfo_four=$this->Product_model->ratingcount($product_id,$language_id,4);
        	$ratinginfo_three=$this->Product_model->ratingcount($product_id,$language_id,3);
        	$ratinginfo_two=$this->Product_model->ratingcount($product_id,$language_id,2);
        	$ratinginfo_one=$this->Product_model->ratingcount($product_id,$language_id,1);
        	$response = ['status' => $status, 'data' => $reviwesresult,'count'=>$reviwesresultcount,'5star'=>$ratinginfo_five,'4star'=>$ratinginfo_four,'3star'=>$ratinginfo_three,'2star'=>$ratinginfo_two,'1star'=>$ratinginfo_one];
        }
        else{
        	$status = parent::HTTP_BAD_REQUEST;
        	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
        }
        
    	$this->response($response, $status);
    }
    
    public function getproduct_media_details_get(){
		$language_id=$this->get('language_id');
		$product_id=$this->get('product_id');
		$media_type=$this->get('media_type');
		$data = $this->Product_model->get_product_media_Details($language_id,$product_id,$media_type);	
		//print_r($data);
		//die();
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Product Digital Media detail',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	public function addfav_products_post(){
	    $data = $this->verify_request();
        // Send the return data as reponse
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        	
        	$product_id=$this->post('product_id');
            $language_id=$this->post('language_id');
        	
        	if($product_id==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'product id is missing.'];
        		$this->response($response, $status);
            }
            if($language_id==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'Language id is missing.'];
        		$this->response($response, $status);
            }
            
            
            $post_vl['user_id']=$user_id;
            $post_vl['language_id']=$language_id;
            $post_vl['product_id']=$product_id;
            $post_vl['is_active']='1';
            
                                
        	$blogresult = $this->Product_model->add_as_favt($post_vl);
            if($blogresult>0){
            	$status = parent::HTTP_OK;
            	$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
            }
            else{
            	$status = parent::HTTP_BAD_REQUEST;
            	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
            }
            
        	$this->response($response, $status);
        }
	}
    
	public function prod_favt_get(){
	    $data = $this->verify_request();
        // Send the return data as response
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        	$language_id=$this->get('language_id');
	    	$product_id=$this->get('product_id');
        	$blogresult = $this->Product_model->check_favt($user_id,$product_id,$language_id);
            if($blogresult>0){
            	$status = parent::HTTP_OK;
            	$response = ['status' => $status, 'data' => 'product favt.','favt_id'=>$blogresult];
            }
            else{
            	$status = parent::HTTP_BAD_REQUEST;
            	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
            }
            
        	$this->response($response, $status);
        }
	}
	
	public function prod_favt_list_get(){
	    $data = $this->verify_request();
        // Send the return data as response
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        	$page_no=$this->get('page_no');
    		if($page_no==''){
    			$page_no=1;
    		}
    		$limit=$this->get('limit');
    		if($limit==''){
    			$limit=10;
    		}
        	$language_id=$this->get('language_id');
	    	//$product_id=$this->get('product_id');
        	$data1 = $this->Product_model->all_product_details_favt($language_id,$page_no,$limit,$user_id);
            $count = $this->Product_model->all_product_details_favt_count($language_id,$user_id);	
            $this->response($data, REST_Controller::HTTP_OK); //200
    		if($data1!=''){
    			// Set the response and exit
    			$this->response([
    				'status' => TRUE,
    				'code' => REST_Controller::HTTP_OK,
    				'message' => 'Product Favt listing',
    				'count'=>$count,
    				'data' => $data1
    			], REST_Controller::HTTP_OK);
    		} else{
    			//print 'sdsdsd';die;
    			// Set the response and exit
    			$this->response([
    				'status' => False,
    				'code' => 400,
    				'message' => 'No Records found.',
    			], REST_Controller::HTTP_BAD_REQUEST);
    			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
    		}
        }
	}
	
	public function favtdelete_post(){
	    $data = $this->verify_request();
        // Send the return data as response
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        	
        	$language_id=$this->post('language_id');
	    	$product_id=$this->post('product_id');
        	$blogresult = $this->Product_model->deleteuser_favt($user_id,$product_id,$language_id);
            if($blogresult>0){
            	$status = parent::HTTP_OK;
            	$response = ['status' => $status, 'data' => 'favt. deleted'];
            }
            else{
            	$status = parent::HTTP_BAD_REQUEST;
            	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
            }
            
        	$this->response($response, $status);
        }
	}
	
}