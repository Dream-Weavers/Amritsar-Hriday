<?php
require APPPATH . '/libraries/REST_Controller.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
class Forgot_password extends REST_Controller {

    public function __construct() {

       parent::__construct();

		$this->load->model('api/Forgot_password_model');
		$this->load->helper(['jwt', 'authorization']);  
    }


	function user_post(){
		$user_input = $this->post('user_input');
		
		$mobilePattern ="/^[7-9][0-9]{9}$/"; 
		
		if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
			$result=$this->Forgot_password_model->email_validate($user_input);
			
			if($result==0){
				$this->response([
				'status' => REST_Controller::HTTP_BAD_REQUEST,
				'code' => REST_Controller::HTTP_BAD_REQUEST,
				'message' => 'Email is not registered yet.',
				'data' => $data
				], REST_Controller::HTTP_BAD_REQUEST);
			}else if($result>0){
				$this->response([
				'status' => REST_Controller::HTTP_OK,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'You will get an OTP on your email id. Please check it.',
				'data' => $data
				], REST_Controller::HTTP_OK);
				
				$otp=$this->random_fivedigit();
				$smstext='Your OTP is '.$otp.'. Please do not share this OTP with anyone.';
				send_email($user_input,$smstext,"Hriday - Forgot Password");
				$counter = $this->Forgot_password_model->otp_log($user_input,$otp);
			}else{
				$this->response([
				'status' => REST_Controller::HTTP_BAD_REQUEST,
				'code' => REST_Controller::HTTP_BAD_REQUEST,
				'message' => 'Invalid Information',
				'data' => $data
				], REST_Controller::HTTP_BAD_REQUEST);
			}
		}else if(preg_match($mobilePattern, $user_input)){
			$result=$this->Forgot_password_model->mobile_validate($user_input);
			if($result==0){
				$this->response([
				'status' => REST_Controller::HTTP_BAD_REQUEST,
				'code' => REST_Controller::HTTP_BAD_REQUEST,
				'message' => 'Mobile is not registered yet.',
				'data' => $data
				], REST_Controller::HTTP_BAD_REQUEST);
			}else if($result>0){
				$otp=$this->random_fivedigit();
				$smstext='Your OTP is '.$otp.'. Please do not share this OTP with anyone.';
				send_sms("",$user_input,$smstext);
				$counter = $this->Forgot_password_model->otp_log($user_input,$otp);
				$this->response([
				'status' => REST_Controller::HTTP_OK,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'You will get an OTP on your registered mobile no. Please check it.',
				'data' => $data
				], REST_Controller::HTTP_OK);
			}else{
				$this->response([
				'status' => REST_Controller::HTTP_BAD_REQUEST,
				'code' => REST_Controller::HTTP_BAD_REQUEST,
				'message' => 'Invalid Information',
				'data' => $data
				], REST_Controller::HTTP_BAD_REQUEST);
			}
		}
		
	} 
	
	public function verify_forgotpass_otp_post() {  
		 $user_input = $this->post('user_input');
		 $user_otp = $this->post('user_otp');
		 
		 $counter = $this->Forgot_password_model->match_user_otp($user_input,$user_otp);
		 if($counter>0){
			 $logupdate = $this->Forgot_password_model->update_user_otp_log($user_input,$user_otp);
			/*$this->response([
				'status' => TRUE,
				'message' => 'Verfication process is completed',
			], REST_Controller::HTTP_OK);*/
			$token = AUTHORIZATION::generateToken(['user_input' => $user_input]);
			// Prepare the response
            $status = parent::HTTP_OK;
			/*$this->response([
					'status' => TRUE,
					'message' => 'User created successfully',
					'user_id'=>$result
				], REST_Controller::HTTP_OK);*/
			$response = ['status' => $status,'message' => 'Verfication process is completed', 'token' => $token];
            $this->response($response, $status);
		 }else{
			$this->response([
				'status' => False,
				'message' => 'Incorrect OTP.',
			], REST_Controller::HTTP_BAD_REQUEST);
		 }
	}
	
	/*private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}*/

public function user_change_password_post() {  
		//$data = $this->verify_request();
		// Send the return data as reponse
		//if($data==TRUE){
			//$user_input=$data->user_input;
			$user_input = $this->post('user_input');
			$photo='';
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
				if($getuser_arr->user_photo!=''){
					$photo=base_url().users_photo_path.$getuser_arr->user_photo;
				}
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
				if($getuser_arr->user_photo!=''){
					$photo=base_url().users_photo_path.$getuser_arr->user_photo;
				}
			}
			$new_password=$this->post('new_password');
			$result = $this->Forgot_password_model->change_password($user_id,$new_password);
			if($result==TRUE){
				$status = parent::HTTP_OK;
			/*$addressfield=array('user_address_id'=>$getuser_arr->user_address_id,'is_primary'=>'1');
			$useraddressrow=gettableinfo('user_address',$addressfield);	
			if($useraddressrow!='0')
			{
			 $country_id = $useraddressrow->country_id;
			 $state_id = $useraddressrow->state_id;
			 $city_id = $useraddressrow->city_id;
			 $address = $useraddressrow->address;
			 $pin_code = $useraddressrow->pin_code;
			}else
			{
			 $country_id = '';
			 $state_id = '';
			 $city_id = '';
			 $address = '';
			 $pin_code = '';
			}*/
			
			$response = ['status' => $status, 'message' => 'Password updated successfully.','data' => 'Password updated successfully.','code'=>$status];
			//$response = ['status' => $status, 'data' => 'Password updated successfully','first_name'=>$getuser_arr->first_name,'user_photo'=>$photo];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 	
			$this->response($response, $status);
		}
	
        
    
	
	function random_fivedigit(){
		$x=5; // number of digits;
		$randomNum = substr(str_shuffle("0123456789"), 0, $x);
		return $randomNum;
	}
	
}