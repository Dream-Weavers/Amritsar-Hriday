<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Sos extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Sos_model');
    }

	
	public function getSos_category_get(){
		$language_id=$this->get('language_id');
		$category_id=$this->get('category_id');
		$sos_type=$this->get('sos_type');
		$data = $this->Sos_model->get_sos_category_Detail($language_id,$category_id,$sos_type);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'SOS Information',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	public function getSos_Details_get(){
		$language_id=$this->get('language_id');
		$location_id=$this->get('location_id');
		$data = $this->Sos_model->getSos_Details($language_id,$location_id);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'SOS Information',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}