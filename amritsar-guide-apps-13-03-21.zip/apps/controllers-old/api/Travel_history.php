<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Travel_history extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Travel_history_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}

 
   public function travel_history_select_year_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$travelhistoryyearresult = $this->Travel_history_model->travel_history_select_year($user_id);
			//print_r($travelhistoryyearresult);
		
			if($travelhistoryyearresult){
				 $status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'Travel History Year',
				 'data' => $travelhistoryyearresult];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'message' => 'Error', 'data' => ''];
				$this->response($response, $status);
			    }				
		  }
	  }
	  
	  
    public function user_travel_history_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$select_year = $this->post('select_year');
			$select_month = $this->post('select_month');
			$travelhistoryresult = $this->Travel_history_model->user_travel_history($user_id,$select_year,$select_month);
		
			if($travelhistoryresult){
				 $status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'Travel History Result',
				 'data' => $travelhistoryresult];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'message' => 'Error', 'data' => ''];
				$this->response($response, $status);
			    }				
		  }
	  }

}