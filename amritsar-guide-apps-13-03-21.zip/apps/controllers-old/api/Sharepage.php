<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Sharepage extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Sharepage_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
    
    private function verify_request(){
        // Get all the headers
        $headers = $this->input->request_headers();
        // Extract the token

        $token = $headers['Authorization'];
        // Use try-catch
        // JWT library throws exception if the token is not valid
        try {
            // Validate the token
            // Successfull validation will return the decoded user data else returns false
            $data = AUTHORIZATION::validateToken($token);
            if ($data === false) {
                $status = parent::HTTP_UNAUTHORIZED;
                $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
                $this->response($response, $status);
                exit();
            } else {
                return $data;
            }
        } catch (Exception $e) {
            // Token is invalid
            // Send the unathorized access message
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
            $this->response($response, $status);
        }
    }
    
    public function add_sharepage_post()
	{  // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$title = $this->post('title');
			$language_id = $this->post('language_id');
			$share_type = $this->post('share_type');
			$location_id = $this->post('location_id');
    		$ids = $this->post('ids');
		    $shareto = $this->post('shareto');
			$post_vl['language_id']=$language_id;
			$post_vl['share_type']=$share_type;
			$post_vl['title']=$title;
			$post_vl['ids']=$ids;
			$post_vl['location_id']=$location_id;
			$post_vl['user_id']=$user_id;
			$post_vl['shareto']=$shareto;
			
		
			
		//	print '<pre>';print_r($user_info);
		 	$blogresult = $this->Sharepage_model->add_sharepage($post_vl);
			if($blogresult>0){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
			}
			else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	

	
	public function sharepage_listing_get(){
	    $data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		$language_id=$this->get('language_id');
	//	$category_id=$this->get('category_id');
			$page_no=$this->get('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->get('limit');
			if($limit==''){
				$limit=10;
			}
			
			//print $user_id;
			$blogresult = $this->Sharepage_model->sharepage_listing($user_id,$language_id,$page_no,$limit);
			$blogcount = $this->Sharepage_model->sharepage_listing_count($user_id,$language_id,$page_no,$limit);
			/*echo "<pre>";
			print_r($blogresult);
			echo "</pre>";*/
			
			if($blogresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $blogresult,'count'=>$blogcount,
			 'message' => 'Sharepage Listing.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status,'count'=>$blogcount, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
    
}