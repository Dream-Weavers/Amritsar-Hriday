<?php
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

class Popular_search extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Popular_search_model');
    }
	public function popular_locations_get()
	{
		$language_id = $this->get('language_id');
		//print $language_id;
		$data = $this->Popular_search_model->get_locations($language_id);		
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Popular Location',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}
?>