<?php

require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Locations extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Location_model');
	   $this->load->helper(['jwt', 'authorization']);

    }

private function verify_request(){
        // Get all the headers
        $headers = $this->input->request_headers();
        // Extract the token

        $token = $headers['Authorization'];
        // Use try-catch
        // JWT library throws exception if the token is not valid
        try {
            // Validate the token
            // Successfull validation will return the decoded user data else returns false
            $data = AUTHORIZATION::validateToken($token);
            if ($data === false) {
                $status = parent::HTTP_UNAUTHORIZED;
                $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
                $this->response($response, $status);
                exit();
            } else {
                return $data;
            }
        } catch (Exception $e) {
            // Token is invalid
            // Send the unathorized access message
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
            $this->response($response, $status);
        }
    }

	public function getLocation_modules_get(){
		$language_id=$this->get('language_id');
		$location_id=$this->get('location_id');
		$data = $this->Location_model->get_locations_module_Detail($language_id,$location_id);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Location detail',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	public function getLocation_details_get(){
		$user_id='0';
		 $headers = $this->input->request_headers();
        $token = $headers['Authorization'];
        $data = AUTHORIZATION::validateToken($token);
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		 }
		// print $user_id;die;
		 /* $data = $this->verify_request();
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		 }*/
	 
		$language_id=$this->get('language_id');
		$location_id=$this->get('location_id');
		$data = $this->Location_model->get_location_Details($language_id,$location_id,$user_id);	
		//print_r($data);
		//die();
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Location full detail',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	
	
	public function getLocation_media_details_get(){
		$language_id=$this->get('language_id');
		$location_id=$this->get('location_id');
		$media_type=$this->get('media_type');
		$data = $this->Location_model->get_location_media_Details($language_id,$location_id,$media_type);	
		//print_r($data);
		//die();
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Location Digital Media detail',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	public function getLocation_facility_details_get(){
		$language_id=$this->get('language_id');
		$location_id=$this->get('location_id');
		$facility_type=$this->get('facility_type');
		$data = $this->Location_model->get_location_facility_Details($language_id,$location_id,$facility_type);	
		//print_r($data);
		//die();
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Location Facility detail',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
	
	public function add_location_review_post(){
	    $data = $this->verify_request();
        // Send the return data as reponse
        if($data==TRUE){
            $user_input=$data->user_input;
        	if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
        		$fildarr=array('email'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}else{
        		$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
        		$getuser_arr=gettableinfo('users',$fildarr);
        		$user_id=$getuser_arr->user_id;
        	}
        	
        	$location_id=$this->post('location_id');
            $language_id=$this->post('language_id');
            $rating=$this->post('rating');
        	
        	if($location_id==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'Location id is missing.'];
        		$this->response($response, $status);
            }
            if($language_id==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'Language id is missing.'];
        		$this->response($response, $status);
            }
            if($rating==''){
        		$status = parent::HTTP_OK;
        		$response = ['status' => $status, 'data' => 'rating is missing.'];
        		$this->response($response, $status);
            }
            
            $comment=$this->post('comment');
            
            $post_vl['user_id']=$user_id;
            $post_vl['language_id']=$language_id;
            $post_vl['comment']=$comment;
            $post_vl['rating']=$rating;
            $post_vl['location_id']=$location_id;
          
        	$blogresult = $this->Location_model->add_reviews($post_vl);
            if($blogresult>0){
            	$status = parent::HTTP_OK;
            	$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
            }
            else{
            	$status = parent::HTTP_BAD_REQUEST;
            	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
            }
            
        	$this->response($response, $status);
        }
	}
	public function fetch_location_review_get(){
	  
    	$location_id=$this->get('location_id');
        $language_id=$this->get('language_id');
    	
    	if($location_id==''){
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'Location id is missing.'];
    		$this->response($response, $status);
        }
        if($language_id==''){
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'Language id is missing.'];
    		$this->response($response, $status);
        }
        $post_vl['language_id']=$language_id;
        $post_vl['location_id']=$location_id;
      	$page_no=$this->get('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->get('limit');
			if($limit==''){
				$limit=10;
			}
    	$reviwesresult = $this->Location_model->fetch_reviews($post_vl,$page_no,$limit);
    	$reviwesresultcount = $this->Location_model->fetch_reviews_count($post_vl);
        if($reviwesresult>0){
            
            $ratinginfo_five=$this->Location_model->ratingcount($location_id,$language_id,5);
        	$ratinginfo_four=$this->Location_model->ratingcount($location_id,$language_id,4);
        	$ratinginfo_three=$this->Location_model->ratingcount($location_id,$language_id,3);
        	$ratinginfo_two=$this->Location_model->ratingcount($location_id,$language_id,2);
        	$ratinginfo_one=$this->Location_model->ratingcount($location_id,$language_id,1);
            
        	$status = parent::HTTP_OK;
        	$response = ['status' => $status, 'data' => $reviwesresult,'count'=>$reviwesresultcount,'5star'=>$ratinginfo_five,'4star'=>$ratinginfo_four,'3star'=>$ratinginfo_three,'2star'=>$ratinginfo_two,'1star'=>$ratinginfo_one];
        }
        else{
        	$status = parent::HTTP_BAD_REQUEST;
        	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
        }
        
    	$this->response($response, $status);
    }
    
    
    public function location_tracking_get(){
        $latitude=$this->get('latitude');
        $language_id=$this->get('language_id');
        $longitude=$this->get('longitude');
        
        if($latitude==''){
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'Latitude is missing.'];
    		$this->response($response, $status);
        }
        if($longitude==''){
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'Longitude is missing.'];
    		$this->response($response, $status);
        }
        if($language_id==''){ 
    		$status = parent::HTTP_OK;
    		$response = ['status' => $status, 'data' => 'Language is missing.'];
    		$this->response($response, $status);
        }
        	$page_no=$this->get('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->get('limit');
			if($limit==''){
				$limit=10;
			}
        
        $trackingresult = $this->Location_model->location_tracking($language_id,$latitude,$longitude,$page_no,$limit);
        $trackingresultcount = $this->Location_model->location_tracking_count($language_id,$latitude,$longitude);
        if($trackingresultcount>0){
        	$status = parent::HTTP_OK;
        	$response = ['status' => $status, 'data' => $trackingresult,'count'=>$trackingresultcount];
        }
        $this->response($response, $status);
        
    }
    
    function alllocation_info_get(){
        $trackingresult = $this->Location_model->all_location_info();
        $trackingresultcount = $this->Location_model->all_location_info_count();
        if($trackingresultcount>0){
        	$status = parent::HTTP_OK;
        	$response = ['status' => $status, 'data' => $trackingresult,'count'=>$trackingresultcount];
        }
        $this->response($response, $status);
    }
    
	
	
}