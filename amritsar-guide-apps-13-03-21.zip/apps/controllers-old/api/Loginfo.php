<?php
 require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Loginfo extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Loginfo_model');
	   $this->load->helper(['jwt', 'authorization']);
	   $this->load->library('getid3/getid3');

    }
    
    function deviceplay_post(){
        
        //print '<pre>';print_r($_POST);die;
        $device_id1=$this->post('device_id');   // Beacon ID
        $playing_type=$this->post('playing_type');  // Either B or G
        $language_id=$this->post('language_id');  // Language Id
        $mobileId=$this->post('deviceId');  // Mobile device id
        $datetime=date('Y-m-d H:i:s');   // Current date

        
        $lastrow=$this->Loginfo_model->getlast_playbeacon($mobileId);
        $last_beacondate=$lastrow->datetime;
        $device_id=$lastrow->device_id;
        $language_id1=$lastrow->language_id;
        
        //print '<pre>';print_r($lastrow);die;
        
        $date=date('Y-m-d H:i:s');
       // $logresult = $this->Loginfo_model->add_log($post_vl);
        //$lastinsertid=$logresult;
        
        $last_beacondate=date('Y-m-d H:i:s',strtotime($last_beacondate));
        
        
        $response_log['beacon_id']=$device_id;
        $response_log['language_id']=$language_id1;
        $lastrow_mdeia=$this->Loginfo_model->last_beaconresponse_log($response_log);
        $mediaurl=$lastrow_mdeia['audio'];
        
        $file = '/home/dsysin607/public_html/codeigniter/hriday/'.$mediaurl; //Enter File Name mp3/wav
        //print $file;
        
       // print $last_beacondate.'<br>';
       //  print $date.'<br>';
        
        $date1 = new DateTime( $last_beacondate );
        $date2 = new DateTime( $date );

        $diffInSeconds = $date2->getTimestamp() - $date1->getTimestamp();
        
        $seconds = strtotime($date) - strtotime($last_beacondate);
        // print $file_in_seconds.':'.$diffInSeconds;
        
        $getID3 = new GetID3;
        $ThisFileInfo = $getID3->analyze($file);
        $file_in_seconds =intval($ThisFileInfo['playtime_seconds']);
        //print $file_in_seconds.'-'.$seconds;
        if($file_in_seconds>=$seconds){
            $autoplay='Off';
        }else{
            $autoplay='On';//on
        }
        
        //$response_log['location_id']=$location_id;
        $response_log1['beacon_id']=$device_id1;
        $response_log1['language_id']=$language_id;
        //$response_log['log_result']
        //$response_log['counter']=$counter;
        //print $device_id1; 
        $response_log_return = $this->Loginfo_model->response_log($response_log1,$autoplay,$mobileId);
        //$getversion = $this->Loginfo_model->get_version();
        
        if($response_log_return){
        	$status = parent::HTTP_OK;
        	$response = ['status' => $status, 'data' => 'Data inserted successfully.','response'=>$response_log_return];
        }
        else{
        	$status = parent::HTTP_BAD_REQUEST;
        	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
        }
        $this->response($response, $status);
    }
        
        function gpsinfo_post(){
        $latitude=$this->post('latitude');
        $language_id=$this->post('language_id');
        $longitude=$this->post('longitude');
        $deviceId=$this->post('deviceId');
        $datetime=date('Y-m-d H:i');
        $post_vl['lat']=$latitude;
        $post_vl['lng']=$longitude;
        $post_vl['lang_id']=$language_id;
        $post_vl['datetime']=$datetime;
        //print $latitude;die;
        $logresult = $this->Loginfo_model->get_tracking($post_vl,$deviceId);
        $status = parent::HTTP_OK;
        //$response_log_return = $this->Loginfo_model->response_log($response_log);
        //$getversion = $this->Loginfo_model->get_version();
       // return $logresult;
        if($logresult>0){
        	$status = parent::HTTP_OK;
        	$response = ['status' => $status, 'data' => 'Data inserted successfully.','response'=>$logresult];
        }
        else{
        	$status = parent::HTTP_BAD_REQUEST;
        	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
        }
        $this->response($response, $status);
    }
        
    function calculateFileSize($file){

        $ratio = 16000; //bytespersec
    
        if (!$file) {
    
            exit("Verify file name and it's path");
    
        }
    
        $file_size = filesize($file);
    
        if (!$file_size)
            exit("Verify file, something wrong with your file");
    
        $duration = ($file_size / $ratio);
        $minutes = floor($duration / 60);
        $seconds = $duration - ($minutes * 60);
        $seconds = round($seconds);
        $totalSecs   = ($minutes * 60) + $seconds; 
        return $totalSecs;
    }    
    
    function notification_list_get(){
        $deviceId=$this->get('deviceId');
        $language_id=$this->get('language_id');
        $post_vl['mobileid']=$deviceId;
        $post_vl['language_id']=$language_id; 
        
        
        $page_no=$this->get('page_no');
		if($page_no==''){
			$page_no=1;
		}
		$limit=$this->get('limit');
		if($limit==''){
			$limit=10;
		}
        $notification_result= $this->Loginfo_model->get_listing($post_vl,$page_no,$limit);
        $notification_count= $this->Loginfo_model->get_listing_count($post_vl);
        
        //print '<pre>';print_r($notification_result);die;
        if($notification_result){
        	$status = parent::HTTP_OK;
        	$response = ['status' => $status, 'data' => 'Data inserted successfully.','count'=>$notification_count,'response'=>$notification_result];
        }
        else{
        	$status = parent::HTTP_BAD_REQUEST;
        	$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
        }
        $this->response($response, $status);

    }
    
    
}