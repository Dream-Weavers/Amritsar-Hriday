<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Appconfig extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/appconfig_model');

    }
	 
	public function get_legalinfo_get()
	{	$language_id = $this->get('language_id');
		$data = $this->appconfig_model->get_legalinfo($language_id);	
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Legal Info Data',
				'data' => $data,
			], REST_Controller::HTTP_OK);
			
			
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}