<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Users extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Users_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}

	public function user_info_get(){
		//$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		//if($data==TRUE){
			/* $user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			} */
			//$getuser_info = $this->Users_model->getusers($user_id);
			//print 'sds';die;
			$getuser_info = $this->Users_model->getusers();
			if($getuser_info){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => $getuser_info];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}			
		//}
		
	}
}