<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Blogs extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Blogs_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
    
    private function verify_request(){
        // Get all the headers
        $headers = $this->input->request_headers();
        // Extract the token

        $token = $headers['Authorization'];
        // Use try-catch
        // JWT library throws exception if the token is not valid
        try {
            // Validate the token
            // Successfull validation will return the decoded user data else returns false
            $data = AUTHORIZATION::validateToken($token);
            if ($data === false) {
                $status = parent::HTTP_UNAUTHORIZED;
                $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
                $this->response($response, $status);
                exit();
            } else {
                return $data;
            }
        } catch (Exception $e) {
            // Token is invalid
            // Send the unathorized access message
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
            $this->response($response, $status);
        }
    }
    
    public function add_blog_post()
	{  // Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$category = $this->post('category');
			$language_id = $this->post('language_id');
			$blog_title = $this->post('blog_title');
			$youtube_video_url = $this->post('youtube_video_url');
			$blog_desc = $this->post('blog_description');
			$featured_img = $this->post('featured_img');
			
			if($category==''){
			    $status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Category is missing.'];
				$this->response($response, $status);
			}
			if($blog_title==''){
			    $status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Blog title is missing.'];
				$this->response($response, $status);
			}
			$post_vl['language_id']=$language_id;
			$post_vl['category_id']=$category;
			$post_vl['title']=$blog_title;
			$post_vl['description']=$blog_desc;
			if($featured_img!=''){
			    
    			$image = str_replace('data:image/png;base64,', '', $featured_img);
    			$image = str_replace(' ', '+', $image);
    			// Decode the Base64 encoded Image
    			$data = base64_decode($image);
    			$path='/home/u385515540/domains/g4me.in/public_html/hriday/images/blogs/';
    			$imgname=$user_id.'_'.time().'.jpg';
    			$filename = $path.'/' .$imgname;
    			
    			$success = file_put_contents($filename, $data);
		        $post_vl['image_url']=$imgname;
			}
			if($youtube_video_url!=''){
			    $post_vl['video_url']=$youtube_video_url;
			}
			$user_info = $this->Blogs_model->getuser_info($user_id);
			$post_vl['approval_status']='0';
			$post_vl['visibility']='public';
			$post_vl['user_type']=$user_info->user_type;
			$post_vl['created_by']=$user_id;
			$post_vl['created_date']=date('Y-m-d H:i:s');
			
		//	print '<pre>';print_r($user_info);
		 	$blogresult = $this->Blogs_model->add_blog($post_vl);
			if($blogresult>0){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
			}
			else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function blog_category_get(){
	    $language_id = $this->get('language_id');
	    //print $language_id;
    	$blog_category = $this->Blogs_model->blog_category($language_id);
		if($blog_category){
			$status = parent::HTTP_OK;
			$response = ['status' => $status, 'data' =>$blog_category];
		}
		else{
			$status = parent::HTTP_BAD_REQUEST;
			$response = ['status' => $status, 'msg' => 'No Record Found!!!'];
		} 
		$this->response($response, $status);
	}
	
	public function blog_listing_get(){
	    $data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		$language_id=$this->get('language_id');
		$category_id=$this->get('category_id');
			$page_no=$this->get('page_no');
			if($page_no==''){
				$page_no=1;
			}
			$limit=$this->get('limit');
			if($limit==''){
				$limit=10;
			}
			
			//print $user_id;
			$blogresult = $this->Blogs_model->blog_listing($user_id,$category_id,$language_id,$page_no,$limit);
			$blogcount = $this->Blogs_model->blog_listing_count($user_id,$category_id,$language_id,$page_no,$limit);
			if($blogresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $blogresult,'count'=>$blogcount,
			 'message' => 'Blog Listing.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status,'count'=>$blogcount, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function blog_detail_get(){
	    $data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		//$language_id=$this->get('language_id');
		$blog_id=$this->get('blog_id');
		if($blog_id==''){
			    $status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Blog id is missing.'];
				$this->response($response, $status);
			}
		$blogresult = $this->Blogs_model->blog_detail($user_id,$blog_id);
			if($blogresult==TRUE){
			$status = parent::HTTP_OK;
			 $response = ['status' => $status,
			 'data' => $blogresult,
			 'message' => 'Blog detail.'];
			}else{
				$status = parent::HTTP_BAD_REQUEST;
				$response = ['status' => $status,'count'=>$blogcount, 'msg' => 'No Record Found!!!'];
			} 
			$this->response($response, $status);
		}
	}
	
    
}