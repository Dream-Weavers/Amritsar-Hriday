<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Menu extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/menu_model');

    }
	 
	public function get_main_menu_get()
	{	$language_id = $this->get('language_id');
		$main_menu_data = $this->menu_model->get_main_menu($language_id,'1');	
		$bottom_menu_data = $this->menu_model->get_main_menu($language_id,'2');	
		$memories_menu_data = $this->menu_model->get_main_menu($language_id,'3');
		$label_data = $this->menu_model->get_app_label($language_id,'2');	
		$lang_data = $this->menu_model->get_app_languages();
		$font_mode_data = $this->menu_model->get_app_font_mode($language_id);
		$location_service_hrs_data = $this->menu_model->location_service_hrs_data($language_id);	
		$this->response($main_menu_data, REST_Controller::HTTP_OK); //200
		$noti_data[]=array('label'=>'Audio','type'=>'audio');
		$noti_data[]=array('label'=>'Video','type'=>'video');
		$noti_data[]=array('label'=>'Location Notification','type'=>'location_notification');
		if($main_menu_data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Main Menu Data',
				'main_menu_data' => $main_menu_data,
				'bottom_menu_data' => $bottom_menu_data,
				'memories_menu_data' => $memories_menu_data,
				'lang_data' => $lang_data,
				'notification_data'=>$noti_data,
				'font_mode_data' => $font_mode_data,
				'location_service_hrs_data' => $location_service_hrs_data,
				'label_data' => $label_data,
			], REST_Controller::HTTP_OK);
			
			
		} else{
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}