<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class UploadSurveyor extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Surveyor_model');

    }

	
	public function addcomplaintimg_post() {  
	
$target_dir = '/home/dsysin607/public_html/codeigniter/hriday/assets/complaints/';
$nameget=$_FILES["file"]["name"];
$target_file = $target_dir . basename($nameget);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        //echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
		
    } else {
        //echo "Sorry, there was an error uploading your file.";
    }
	$this->response([
			'status' => TRUE,
			'message' => 'Image uploaded successfully.',
			'data' => 1,
		], REST_Controller::HTTP_OK);

    }
	
	public function uploadimage_post() {  
	
		// receive image as POST Parameter
		$imname=$this->post('imageName');
		$survey_id=$this->post('survey_id');
		$source_type=$this->post('source_type');
		if($source_type==1){
			$type='place';
		}elseif($source_type==2){
			$type='event';
		}elseif($source_type==3){
			$type='site';
		}
		$media_type=$this->post('media_type');
		$image = str_replace('data:image/png;base64,', '', $this->post('imageString'));
		$image = str_replace(' ', '+', $image);
		// Decode the Base64 encoded Image
		$data = base64_decode($image);
		// Create Image path with Image name and Extension
		$path='/home/dsysin607/public_html/codeigniter/hriday/assets/encrypt_surveyform/gallery/'.$type.'/';
		$fname=$imname. '_'.time().'.jpg';
		$filename = $path.'/' .$fname;
		$success = file_put_contents($filename, $data);
        // Get the post data
		$survey_step1=array();
		$survey_step1['source']=$fname;
		$survey_step1['survey_id']=$survey_id;
		$survey_step1['source_type']=$source_type;
		$survey_step1['media_type']=$media_type;
		$step1_result = $this->Surveyor_model->insert_media_step1($survey_step1);

		// Set the response and exit
		if($step1_result){
		$this->response([
			'status' => TRUE,
			'message' => 'Image uploaded successfully.',
			'data' => 1,
		], REST_Controller::HTTP_OK);
        }else{
			$this->response([
				'status' => False,
				'message' => 'Error',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
    }
	
	public function clicktocall_post() {  
	
		
		$ch = curl_init();
		$customer_no=$this->post('customer_no');
		$agent_no=$this->post('agent_no');
		//print $customer_no;die;

		// set URL and other appropriate options
		curl_setopt($ch, CURLOPT_URL, "http://myhotline.in:9090/iCallMateWebSvc/resources/click2Connect2?campid=94&leadid=2695&cfdid=17&callerid=1815045300&phoneno=".$agent_no."&alt_phone_1=&alt_phone_2=&transferno=".$customer_no."&3rdpartycalliD=1817112233&client=Dream&key=BeEdaVDnFWBFaRCnDxBAiREbdJ");
		curl_setopt($ch, CURLOPT_HEADER, 0);

		// grab URL and pass it to the browser
		curl_exec($ch);

		// close cURL resource, and free up system resources
		curl_close($ch);

		// Set the response and exit
		if($step1_result){
		$this->response([
			'status' => TRUE,
			'message' => 'Clickto call uploaded successfully.',
			'data' => 1,
		], REST_Controller::HTTP_OK);
        }else{
			$this->response([
				'status' => False,
				'message' => 'Error',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
    }
	
	public function sendsms_post() {  
		
		
		$sms_api_link_connect='http://www.smsjust.com/sms/user/urlsms.php?';
		$sms_api_username_connect='myhotline_sms';
		$sms_api_password_connect='_9byY0!C';
		$sms_api_senderid_connect='HOTLNE';
		$msgtype_uni_conenct='UNI';
		$mobile=$this->post('mobile_no');
		$body=$this->post('body');
		
		$body = urlencode($body);
        if ($msg_type == NULL) $url = '' .$sms_api_link_connect . 'username=' .$sms_api_username_connect . '&pass=' .$sms_api_password_connect . '&senderid=' . $sms_api_senderid_connect . '&msgtype=' . $msgtype_uni_conenct . '&dest_mobileno=' . $mobile . '&message=' . $body . '&response=Y';
        else $url = '' . $sms_api_link_connect . 'username=' . $sms_api_username_connect . '&pass=' . $sms_api_password_connect . '&senderid=' . $sms_api_senderid_connect . '&msgtype=' . $msgtype_uni_conenct . '&dest_mobileno=' . $mobile . '&message=' . $body . '&response=Y';
        //echo $url; die;
        $lines = @file($url);
        

		// Set the response and exit
		if($lines){
		$this->response([
			'status' => TRUE,
			'message' => 'SMS sent successfully.',
			'data' => 1,
		], REST_Controller::HTTP_OK);
        }else{
			$this->response([
				'status' => False,
				'message' => 'Error',
			], REST_Controller::HTTP_BAD_REQUEST);
		}
    }
	
	function sendfcm1_post(){
		
		$device_id=$this->post('device_id');
		$message=$this->post('msginfo');
		$title=$this->post('title');
		$spotid=$this->post('id');
		//$message='This is body';
		//$title='title';
		$url = 'https://fcm.googleapis.com/fcm/send';
		$api_key = 'AIzaSyAqiW1CQY7AwfNCbDJFOYGa-BPKUptPXHI';
           
		$msg = array
(
	'message' 	=> 'here is a message. message',
	'title'		=> 'This is a title. title',
	'subtitle'	=> 'This is a subtitle. subtitle',
	'tickerText'	=> 'Ticker text here...Ticker text here...Ticker text here',
	'vibrate'	=> 1,
	'sound'		=> 1,
	'largeIcon'	=> 'large_icon',
	'smallIcon'	=> 'small_icon'
);
$registrationIds = array( $device_id );
$fields = array
(
	'registration_ids' 	=> $registrationIds,
	'data'			=> $msg
);
		
		

		//header includes Content type and api key
		$headers = array(
			'Content-Type:application/json',
			'Authorization:key='.$api_key
		);
                
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode( $fields ) );
		$result = curl_exec($ch);
		if ($result === FALSE) {
			die('FCM Send Error: ' . curl_error($ch));
		}
		curl_close($ch);
		$this->response([
			'status' => TRUE,
			'message' => 'FCM message',
			'data' => $result,
		], REST_Controller::HTTP_OK);
        
	
	}
	
	function sendfcm_post(){
		
		$device_id=$this->post('device_id');
		$message=$this->post('msginfo');
		$title=$this->post('title');
		$spotid=$this->post('id');
		//$message='This is body';
		//$title='title';
		$url = 'https://fcm.googleapis.com/fcm/send';
		$api_key = 'AIzaSyAqiW1CQY7AwfNCbDJFOYGa-BPKUptPXHI';
           
		
		   
		/*$fields = array (
			'registration_ids' => array ($device_id),
			'data' => array ("message" => $message)
		);*/
		$notification = array('id'=>$spotid,'title' =>$title , 'text' => $message, "show_in_foreground" => true,"targetScreen" => 'Listingactivity','force-start' => 1,'priority' => 1,);
//$arrayToSend = array('to' => $device_id, 'notification' => $notification,'priority'=>'high');
$arrayToSend = array('registration_ids' => array ($device_id), 'data' => $notification);
$fields = json_encode($arrayToSend);
		
		

		//header includes Content type and api key
		$headers = array(
			'Content-Type:application/json',
			'Authorization:key='.$api_key
		);
                
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		$result = curl_exec($ch);
		if ($result === FALSE) {
			die('FCM Send Error: ' . curl_error($ch));
		}
		curl_close($ch);
		$this->response([
			'status' => TRUE,
			'message' => 'FCM message',
			'data' => $result,
		], REST_Controller::HTTP_OK);
        
	
	}
	
	public function cameraupload_post() {  
	
		// receive image as POST Parameter
		//$imname=$this->post('imageName');
		/*$imname='testfile';
		//$survey_id=$this->post('survey_id');
		$survey_id=1;
		//$source_type=$this->post('source_type');
		$source_type=1;
		if($source_type==1){
			$type='place';
		}elseif($source_type==2){
			$type='event';
		}elseif($source_type==3){
			$type='site';
		}
		$media_type=3;
		$image = str_replace('data:image/png;base64,', '', $this->post('file'));
		$image = str_replace(' ', '+', $image);
		// Decode the Base64 encoded Image
		$data = base64_decode($image);
		// Create Image path with Image name and Extension
		$path='/home/dsysin607/public_html/codeigniter/hriday/assets/encrypt_surveyform/camera/'.$type.'/';
		$fname=$imname. '_'.time().'.jpg';
		$filename = $path.'/' .$fname;
		$success = file_put_contents($filename, $data);
        // Get the post data
		$survey_step1=array();
		$survey_step1['source']=$fname;
		$survey_step1['survey_id']=$survey_id;
		$survey_step1['source_type']=$source_type;
		$survey_step1['media_type']=$media_type;
		$step1_result = $this->Surveyor_model->insert_media_step1($survey_step1);

		// Set the response and exit
		if($step1_result){
		$this->response([
			'status' => TRUE,
			'message' => 'Image uploaded successfully.',
			'data' => 1,
		], REST_Controller::HTTP_OK);
        }else{
			$this->response([
				'status' => False,
				'message' => 'Error',
			], REST_Controller::HTTP_BAD_REQUEST);
		}*/
		
	/* datat searching ---*/
	
	//$imname=$this->post('imageName');
		$imname='testfile';
		//$survey_id=$this->post('survey_id');
		$survey_id=1;
		//$source_type=$this->post('source_type');
		$source_type=1;
		if($source_type==1){
			$type='place';
		}elseif($source_type==2){
			$type='event';
		}elseif($source_type==3){
			$type='site';
		}
		$media_type=3;
$target_dir = '/home/dsysin607/public_html/codeigniter/hriday/assets/encrypt_surveyform/camera/'.$type.'/';
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["file"]["tmp_name"]);
    if($check !== false) {
        //echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        //echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    //echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["file"]["size"] > 500000) {
    //echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    //echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        //echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
		
    } else {
        //echo "Sorry, there was an error uploading your file.";
    }
	$this->response([
			'status' => TRUE,
			'message' => 'Image uploaded successfully.',
			'data' => 1,
		], REST_Controller::HTTP_OK);
}	
	/* datat searching end ---*/	
		
		
    }

}