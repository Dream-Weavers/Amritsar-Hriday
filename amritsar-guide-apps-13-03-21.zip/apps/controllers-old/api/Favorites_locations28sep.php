<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Favorites_locations extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Favorites_locations_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}

	public function user_favorite_locations_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$user_favorite_locations_result = $this->Favorites_locations_model->user_favorite_locations($user_id,$language_id);
			if($user_favorite_locations_result){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'User Favorites Locations Details',
				 'data' => $user_favorite_locations_result];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
		
	}
	

	public function add_favorite_location_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$location_id = $this->post('location_id');
			$favoriteresult = $this->Favorites_locations_model->insert_favorite_location($language_id,$user_id,$location_id);
			if($favoriteresult=='1'){
			$status = parent::HTTP_OK;
			$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
			}
			elseif($favoriteresult=='2'){
			$status = parent::HTTP_OK;
			$response = ['status' => $status, 'data' => 'This Location is Already in your favorite list.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	
	public function remove_favorite_location_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$favorite_location_id = $this->post('favorite_location_id');
			$location_id = $this->post('location_id');
			
			$removefavoriteresult = $this->Favorites_locations_model->remove_favorite_location($language_id,$favorite_location_id,$location_id,$user_id);
			if($removefavoriteresult==TRUE){
			$status = parent::HTTP_OK;
			$response = ['status' => $status, 'data' => 'Data Remove successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function share_favorite_locations_get(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->get('language_id');
			$category_types_id = $this->get('category_types_id');
			if (strpos($category_types_id, ',') !== false) {
                $imp_cat=explode(',',$category_types_id);
               // $imp_cat=implode( "','",$exp_cat);
            }else{
                 $imp_cat= array($category_types_id);
            }
           // print $imp_cat;
			$user_favorite_locations_result = $this->Favorites_locations_model->share_favorite_locations($user_id,$language_id,$imp_cat);
			if($user_favorite_locations_result){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'User Favorites Locations Details',
				 'data' => $user_favorite_locations_result];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
		
	}


}