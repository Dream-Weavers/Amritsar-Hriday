<?php

// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Shopping_modules extends REST_Controller {

    public function __construct() {

       parent::__construct();

       $this->load->model('api/Shopping_modules_model');

    }


	 
	public function get_modules_get()
	{
		$language_id = $this->get('language_id');
		//print $language_id;
		$data = $this->Shopping_modules_model->get_modules($language_id);		
		$this->response($data, REST_Controller::HTTP_OK); //200
		if($data!=''){
			// Set the response and exit
			$this->response([
				'status' => TRUE,
				'code' => REST_Controller::HTTP_OK,
				'message' => 'Module Information',
				'data' => $data
			], REST_Controller::HTTP_OK);
		} else{
			//print 'sdsdsd';die;
			// Set the response and exit
			$this->response([
				'status' => False,
				'code' => 400,
				'message' => 'No Records found.',
			], REST_Controller::HTTP_BAD_REQUEST);
			//$this->response("Some problems occurred, please try again.", REST_Controller::HTTP_BAD_REQUEST);
		}
	}
}