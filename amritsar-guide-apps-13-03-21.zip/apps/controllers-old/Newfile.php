<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Newfile extends CI_Controller {	 
	 
	public function index(Request $request){
        return '<script>
        (function() {
          var app = {
            launchApp: function() {
              window.location.replace("/open-app");
              this.timer = setTimeout(this.openWebApp, 100);
            },
        
            openWebApp: function() {
              window.location.replace("market://details?id=com.bidnite.android");
            }
          };
        
          app.launchApp();
        })();
        </script>';
    }
}