<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Ads extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/ads_model');
		$this->load->helper('string');
	}
	
	public function add_category()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_category_title')."";
		  $data['main_heading'] = $this->lang->line('category_title');
		  $data['heading'] = $this->lang->line('add_category_title');
		  $data['already_msg'] = "";
		  
		   $this->form_validation->set_rules('category_name', ''.$this->lang->line('category_name_text').'', 'trim');
		   $this->form_validation->set_rules('description', ''.$this->lang->line('description_text').'', 'required|trim');
		
		 if ($this->form_validation->run()) {
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'category_name' =>trim($this->input->post('category_name')));
		  $result = check_unique('ads_categories',$feilds);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('category_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {    $category_id=  $this->ads_model->add_category();				 
			   if($category_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/ads/view_category');
 		  }
	    } //end of add  functionality
	
	   $this->load->view('backoffice/ads/add_category.php', $data);
	}
	
	
	public function edit_category($category_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_category_title')."";
		  $data['main_heading'] = $this->lang->line('category_title');
		  $data['heading'] = $this->lang->line('edit_category_title');
		  $data['already_msg'] = "";
		  
  		   $this->form_validation->set_rules('category_name', ''.$this->lang->line('category_name_text').'', 'trim');
		   $this->form_validation->set_rules('description', ''.$this->lang->line('description_text').'', 'required|trim');
	
		if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'category_name' =>trim($this->input->post('category_name')));
		  $unique_id = array('category_id' =>$category_id);
		  $result = check_unique_edit('ads_categories',$feild,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('category_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		      $result =  $this->ads_model->update_category($this->input->post('category_id'));
		      if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/ads/view_category");
		  }
		}		
		  $result =  $this->ads_model->category_edit($category_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/ads/edit_category.php', $data);
		 
	}//end of Edit functionality*/
	
	
	public function view_category(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_category_title')."";
	    $data['main_heading'] = $this->lang->line('category_title');
	    $data['heading'] = $this->lang->line('view_category_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('category_name'))
			 $category_name = $this->input->post('category_name');
		 elseif($this->uri->segment('4'))
			 $category_name=$this->uri->segment('4');
		else
			 $category_name='0';
	
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('5'))
			 $status=$this->uri->segment('5');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/ads/view_category/".$category_name."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->ads_model->count_category($category_name,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->ads_model->view_category($category_name,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['category_name'] = $category_name;
		$data['status'] = $status;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/ads/view_category.php', $data);
		}
		
		
	
	public function category_status($category_id,$status)
	{	 // Update status  
	     $result = $this->ads_model->update_category_status($category_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/ads/view_category");		
		 
	}//end of Status  functionality*/	
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_ad_title')."";
	    $data['main_heading'] = $this->lang->line('ad_title');
	    $data['heading'] = $this->lang->line('view_ad_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('category_id'))
			 $category_id = $this->input->post('category_id');
		 elseif($this->uri->segment('4'))
			 $category_id=$this->uri->segment('4');
		else
			 $category_id='0';
			 
		if($this->input->post('vendor_id'))
			 $vendor_id = $this->input->post('vendor_id');
		 elseif($this->uri->segment('5'))
			 $vendor_id=$this->uri->segment('5');
		else
			 $vendor_id='0';	 
	
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('6'))
			 $status=$this->uri->segment('6');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('7'))
			$per_page=$this->uri->segment('7');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/ads/view/".$category_id."/".$vendor_id."/"."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 8;
		$config["total_rows"] =$this->ads_model->count_ads($category_id,$vendor_id,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(8)) ? $this->uri->segment(8) : 0; 
		$data['results'] = $this->ads_model->view_ads($category_id,$vendor_id,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['category_id'] = $category_id;
		$data['vendor_id'] = $vendor_id;
		$data['status'] = $status;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/ads/view.php', $data);
		}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_ad_title')."";
		  $data['main_heading'] = $this->lang->line('ad_title');
		  $data['heading'] = $this->lang->line('add_ad_title');
		  $data['already_msg'] = "";
		  
		   $this->form_validation->set_rules('category_id', ''.$this->lang->line('kiosk_category_text').'', 'trim');
		   $this->form_validation->set_rules('ad_title', 'Ad Title', 'required|trim');
		   $this->form_validation->set_rules('vendor_id', 'Vendor ID', 'required|trim');
		   $this->form_validation->set_rules('ad_desc', 'Description', 'trim');
		 if ($this->form_validation->run()) {
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'category_id' =>$this->input->post('category_id'),'vendor_id' =>$this->input->post('vendor_id'),'ad_title' =>trim($this->input->post('ad_title')));
		  $result = check_unique('ads',$feilds);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('ad_title'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {    $ad_id=  $this->ads_model->add();	
		  
		  	   $done_camp=0;
			   $already_camp=0;
			   if(is_array($this->input->post("place_id")))
				 {
				 $place_ids = $this->input->post("place_id");	
				 foreach($place_ids as $ckey=> $camprow){
					$place_id = $_POST['place_id'][$ckey];
					$rule_id = $_POST['rule_id'][$ckey];
					$start_date = $_POST['start_date'][$ckey];
					$end_date = $_POST['end_date'][$ckey];
					$goal_description = $_POST['goal_description'][$ckey];
					
					$feild = array('language_id' =>$this->session->userdata('lang_id'),'ad_id' =>$ad_id,'place_id' =>$place_id,'start_date' =>$start_date);
					$campresult = check_unique('campaigns',$feild);
					if($campresult==1)
					{	$already_camp++;
						
					}else
					{
					  if( ($place_id!='') && ($rule_id!='') && ($start_date!='') && ($end_date!='') )
					  {
					    $campaign_id = $this->ads_model->add_campaigns($ad_id,$place_id,$rule_id,$start_date,$end_date,$goal_description);
					    if($campaign_id)
					     $done_camp++;
					  }
						
					}
				  }
				 }
				
				   $msg1='';
				   $msg2='';
				   if($done_camp>0)
			   		$msg1=  "Ad has been created successfully. & Total (".$done_camp.") campaigns has been updated successfully.<br>";
				   if($already_camp>0)
			   		$msg2=  " (".$already_stud.")  Campaigns records already exists in database.";
					
					if($msg1!='')
				    $this->session->set_flashdata('success_message', $msg1);
					
					if($msg2!='')
				    $this->session->set_flashdata('warning_message', $msg2);
					
				redirect(base_url() . 'backoffice/ads/view');
 		  }
	    } //end of add  functionality
	
	   $this->load->view('backoffice/ads/add.php', $data);
	}
	
	public function edit($ad_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_ad_title')."";
		  $data['main_heading'] = $this->lang->line('ad_title');
		  $data['heading'] = $this->lang->line('edit_ad_title');
		  $data['already_msg'] = "";
		  
  		   $this->form_validation->set_rules('category_id', ''.$this->lang->line('kiosk_category_text').'', 'trim');
		   $this->form_validation->set_rules('ad_title', 'Ad Title', 'required|trim');
		   $this->form_validation->set_rules('vendor_id', 'Vendor ID', 'required|trim');
		   $this->form_validation->set_rules('ad_desc', 'Description', 'trim');
	
		if ($this->form_validation->run()) {
		  // Update records 
		   $feilds = array('language_id' =>$this->session->userdata('lang_id'),'category_id' =>$this->input->post('category_id'),'vendor_id' =>$this->input->post('vendor_id'),'ad_title' =>trim($this->input->post('ad_title')));
		  $unique_id = array('ad_id' =>$ad_id);
		  $result = check_unique_edit('ads',$feild,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('ad_title'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		      $result =  $this->ads_model->update_ad($this->input->post('ad_id'));
			  
			   $edit_done_camp=0;
			   $edit_already_camp=0;
			   if(is_array($this->input->post("placeid")))
				 {
				 $placeids = $this->input->post("placeid");	
				 foreach($placeids as $ckey=> $camprow){
				    $campaign_id = $_POST['campaign_id'][$ckey];
					$place_id = $_POST['placeid'][$ckey];
					$rule_id = $_POST['ruleid'][$ckey];
					$start_date = $_POST['startdate'][$ckey];
					$end_date = $_POST['enddate'][$ckey];
					$goal_description = $_POST['goaldescription'][$ckey];
					
					$feild = array('language_id' =>$this->session->userdata('lang_id'),'ad_id' =>$ad_id,'place_id' =>$place_id,'start_date' =>$start_date);
					$unique_id = array('campaign_id' =>$campaign_id);
					$campresult = check_unique_edit('campaigns',$feild,$unique_id);
					if($campresult==1)
					{	$edit_already_camp++;
						
					}else
					{
					 if( ($place_id!='') && ($rule_id!='') && ($start_date!='') && ($end_date!='') )
					  {
					  $campaign_id = $this->ads_model->update_campaigns($campaign_id,$ad_id,$place_id,$rule_id,$start_date,$end_date,$goal_description);
					  if($campaign_id)
					   $edit_done_camp++;
					  }
									  
					
					}
				  }
				 }
				 
				 $done_camp=0;
			     $already_camp=0;
			    if(is_array($this->input->post("place_id")))
				 {
				 $place_ids = $this->input->post("place_id");	
				 foreach($place_ids as $ckey=> $camprow){
					$place_id = $_POST['place_id'][$ckey];
					$rule_id = $_POST['rule_id'][$ckey];
					$start_date = $_POST['start_date'][$ckey];
					$end_date = $_POST['end_date'][$ckey];
					$goal_description = $_POST['goal_description'][$ckey];
					
					$feild = array('language_id' =>$this->session->userdata('lang_id'),'ad_id' =>$ad_id,'place_id' =>$place_id,'start_date' =>$start_date);
					$campresult = check_unique('campaigns',$feild);
					if($campresult==1)
					{	$already_camp++;
						
					}else
					{
					 if( ($place_id!='') && ($rule_id!='') && ($start_date!='') && ($end_date!='') )
					  {	
					  $campaign_id = $this->ads_model->add_campaigns($ad_id,$place_id,$rule_id,$start_date,$end_date,$goal_description);
					  if($campaign_id)
					  $done_camp++;
					  }
					}
				  }
				 }
			 
		     $msg1='';
		     $msg2='';
			 
			 if($edit_done_camp>0)
			 $msg1 .=  "Ad has updated created successfully. & Total (".$edit_done_camp.") campaigns has been updated successfully.<br>";
		     if($edit_already_camp>0)
			 $msg2 .=  " (".$edit_already_camp.")  Campaigns records already exists in database.";
			 
		     if($done_camp>0)
			 $msg1 .=  "Ad has been created successfully. & Total (".$done_camp.") campaigns has been updated successfully.<br>";
		     if($already_camp>0)
			 $msg2 .=  " (".$already_camp.")  Campaigns records already exists in database.";
			
			 if($msg1!='')
			 $this->session->set_flashdata('success_message', $msg1);
			
			 if($msg2!='')
			 $this->session->set_flashdata('warning_message', $msg2);
			 
		     redirect(base_url() . "backoffice/ads/view");
				
		  }
		}		
		  $result =  $this->ads_model->ad_edit($ad_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/ads/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	
	public function status($ad_id,$status)
	{	 // Update status  
	     $result = $this->ads_model->update_status($ad_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/ads/view");		
		 
	}//end of Status  functionality*/
	
	
	public function campaign_status($campaign_id,$status)
	{	 // Update status  
	     $result = $this->ads_model->update_campaign_status($campaign_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/ads/view");		
		 
	}//end of Status  functionality*/
	
	
}	
?>