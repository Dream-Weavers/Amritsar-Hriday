<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Filters extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/filters_model');
	}
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_filter_title')."";
	    $data['main_heading'] = $this->lang->line('filter_title');
	    $data['heading'] = $this->lang->line('view_filter_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('filter_id'))
			 $filter_id = $this->input->post('filter_id');
		 elseif($this->uri->segment('4'))
			 $filter_id=$this->uri->segment('4');
		else
			 $filter_id='0';
	
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('5'))
			 $status=$this->uri->segment('5');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/filters/view/".$filter_id."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->filters_model->count_filters($filter_id,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->filters_model->view_filters($filter_id,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['filter_id'] = $filter_id;
		$data['status'] = $status;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/filters/view.php', $data);
		}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_filter_title')."";
		  $data['main_heading'] = $this->lang->line('filter_title');
		  $data['heading'] = $this->lang->line('add_filter_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('filter_name', ''.$this->lang->line('filter_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('weight', ''.$this->lang->line('filter_weight_text').'', 'required|trim|numeric');
		
		 if ($this->form_validation->run()) {
		  $feilds = array('filter_name' =>trim($this->input->post('filter_name')),'language_id'=>$this->session->userdata('lang_id'));
		  $result = check_unique('filters',$feilds);
		 
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('filter_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {
		          $user_id =  $this->filters_model->add();				 
				 
			   if($user_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/filters/view');
 		  }
	    } //end of add  functionality
	
	   $this->load->view('backoffice/filters/add', $data);
	}
	
	public function edit($filter_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_filter_title')."";
		  $data['main_heading'] = $this->lang->line('filter_title');
		  $data['heading'] = $this->lang->line('edit_filter_title');
		  $data['already_msg'] = "";
		  
  		  $this->form_validation->set_rules('filter_name', ''.$this->lang->line('filter_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('weight', ''.$this->lang->line('filter_weight_text').'', 'required|trim|numeric');
		
		if ($this->form_validation->run()) {
		  // Update records 
		  $feild = array('filter_name' =>trim($this->input->post('filter_name')),'language_id'=>$this->session->userdata('lang_id'));
		  $unique_id = array('filterid' =>$filter_id);
		  $result = check_unique_edit('filters',$feild,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('email'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		        $result =  $this->filters_model->update_filter($this->input->post('filterid'));
		      if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/filters/view");
		  }
		}		
		  $result =  $this->filters_model->filter_edit($filter_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/filters/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	
	public function status($filter_id,$status)
	{	 // Update status  
	     $result = $this->filters_model->update_status($filter_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/filters/view");		
		 
	}//end of Status  functionality*/
	
	
}	
?>