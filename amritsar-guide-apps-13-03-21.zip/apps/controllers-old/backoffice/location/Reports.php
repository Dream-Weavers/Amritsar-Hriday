<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('backoffice/location/Reports_model');
	}
	public function index(){
	     $data['title'] = "Language Reports";
		$data['main_heading'] ="Language Reports";
		$data['heading'] = "Language Reports";
		$data['already_msg']=""; 
		/********Get Categories Records********/ 	
		$data['categories']      = $this->Reports_model->getCategories();
		$data['category_types']      = $this->Reports_model->getCategoryTypes();
		$data['locations']      = $this->Reports_model->locations();
		$data['beacon_locations']      = $this->Reports_model->beaconLocations();
		$data['question_bank']      = $this->Reports_model->questionBank();
		//$data['num_rows']     = isset($data['results'])?count($data['results']):0;
	   $this->load->view('backoffice/location/view',$data);	
	}//End of Index
	
	public function add($category_id=NULL){
		$this->add_edit_categories($category_id);	
	}
	
	public function edit($category_id=NULL){
		$this->add_edit_categories($category_id);	
	}
	public function add_edit_categories($category_id=NULL){
		  $data['main_heading'] = $this->lang->line('categories_title');
		  $data['heading']      = ($category_id=='')? $this->lang->line('add_category_title'): $this->lang->line('edit_category_title');
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $category_type_id = '';
		  $category_parent_id = '';
		  $category_name = '';
		  $description = '';
		 
		  $category_id = ($category_id!='') ? $category_id : 0;
		  $this->Reports_model->category_id   = $category_id;
		  $category_records_array = array();
	      if($category_id!='0'){
	   		$category_records_array = $this->Reports_model->editCategoriesData(); 
			/*******Assign fetched record to variables to set value of input box******/
			$category_name	= $category_records_array->category_name;
			$category_parent_id	= $category_records_array->category_parent_id;
			$category_type_id	= $category_records_array->category_type_id;
			$description	= $category_records_array->description;
	      }
		 
		 if($this->input->post()){
			$category_name	= isset($_POST['category_name'])? $_POST['category_name']: '';
			$category_type_id = isset($_POST['category_type_id'])? $_POST['category_type_id']: '';
			$category_parent_id = isset($_POST['category_parent_id'])? $_POST['category_parent_id']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			
			
			
			 /********Check validations************/
			  $this->form_validation->set_rules('category_type_id',''.$this->lang->line('category_name_text').'', 'required|is_unique[categories.category_name]');

			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
				/*****Assign posted value to model's variable******/
				$this->Reports_model->category_name = $category_name;
				$this->Reports_model->category_parent_id = $category_parent_id;
				$this->Reports_model->category_type_id = $category_type_id;
				$this->Reports_model->description = $description;
				
				if($category_id==0)
					$cat_type_id = $this->Reports_model->addCategories();
				else
					$cat_type_id = $this->Reports_model->editCategories();
				
				/* echo "<pre>";
				print_r($_FILES);
				die; */
				if($_FILES['category_icon']){	
					$config['upload_path'] = $this->icon_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['category_icon']['error']!='4'){
						  if($_FILES['category_icon']['name']!=''){
							$image_id = $this->Reports_model->add_icon($cat_type_id,$_FILES['category_icon']['name']);	
						  }
						  $config['file_name'] =$cat_type_id.'_'.$_FILES['category_icon']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('category_icon');
	
					}  
				}
			
			
			
				 if($category_id=='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				
			      redirect(base_url() . 'backoffice/location/Categories');
	    } 
				else{ 
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
		
		  $data['category_id']= $category_id;			
		  $data['category_type_id']=$category_type_id;
		  $data['category_parent_id']=$category_parent_id;
		  $data['category_name']=$category_name;
		  $data['description']=$description;
		  
		  $this->load->view('backoffice/location/add_edit_categories',$data);	
	}
}
