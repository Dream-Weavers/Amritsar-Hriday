<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Kiosks extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/kiosks_model');
	}
	
	public function add_category()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_category_title')."";
		  $data['main_heading'] = $this->lang->line('category_title');
		  $data['heading'] = $this->lang->line('add_category_title');
		  $data['already_msg'] = "";
		  
		   $this->form_validation->set_rules('category_name', ''.$this->lang->line('category_name_text').'', 'trim');
		   $this->form_validation->set_rules('description', ''.$this->lang->line('description_text').'', 'required|trim');
		
		 if ($this->form_validation->run()) {
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'category_name' =>trim($this->input->post('category_name')));
		  $result = check_unique('kiosk_categories',$feilds);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('category_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {    $kiosk_category_id=  $this->kiosks_model->add_category();				 
			   if($kiosk_category_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/kiosks/view_category');
 		  }
	    } //end of add  functionality
	
	   $this->load->view('backoffice/kiosks/add_category.php', $data);
	}
	
	
	public function edit_category($kiosk_category_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_category_title')."";
		  $data['main_heading'] = $this->lang->line('category_title');
		  $data['heading'] = $this->lang->line('edit_category_title');
		  $data['already_msg'] = "";
		  
  		   $this->form_validation->set_rules('category_name', ''.$this->lang->line('category_name_text').'', 'trim');
		   $this->form_validation->set_rules('description', ''.$this->lang->line('description_text').'', 'required|trim');
	
		if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'category_name' =>trim($this->input->post('category_name')));
		  $unique_id = array('kiosk_category_id' =>$kiosk_category_id);
		  $result = check_unique_edit('kiosk_categories',$feild,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('category_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		      $result =  $this->kiosks_model->update_category($this->input->post('kiosk_category_id'));
		      if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/kiosks/view_category");
		  }
		}		
		  $result =  $this->kiosks_model->category_edit($kiosk_category_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/kiosks/edit_category.php', $data);
		 
	}//end of Edit functionality*/
	
	
	public function view_category(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_category_title')."";
	    $data['main_heading'] = $this->lang->line('category_title');
	    $data['heading'] = $this->lang->line('view_category_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('category_name'))
			 $category_name = $this->input->post('category_name');
		 elseif($this->uri->segment('4'))
			 $category_name=$this->uri->segment('4');
		else
			 $category_name='0';
	
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('5'))
			 $status=$this->uri->segment('5');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/kiosks/view_category/".$category_name."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->kiosks_model->count_category($category_name,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->kiosks_model->view_category($category_name,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['category_name'] = $category_name;
		$data['status'] = $status;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/kiosks/view_category.php', $data);
		}
		
		
	
	public function category_status($kiosk_category_id,$status)
	{	 // Update status  
	     $result = $this->kiosks_model->update_category_status($kiosk_category_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/kiosks/view_category");		
		 
	}//end of Status  functionality*/	
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_kiosk_title')."";
	    $data['main_heading'] = $this->lang->line('kiosk_title');
	    $data['heading'] = $this->lang->line('view_kiosk_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('kiosk_id'))
			 $kiosk_id = $this->input->post('kiosk_id');
		 elseif($this->uri->segment('4'))
			 $kiosk_id=$this->uri->segment('4');
		else
			 $kiosk_id='0';
	
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('5'))
			 $status=$this->uri->segment('5');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/kiosks/view/".$kiosk_id."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->kiosks_model->count_kiosks($kiosk_id,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->kiosks_model->view_kiosks($kiosk_id,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['kiosk_id'] = $kiosk_id;
		$data['status'] = $status;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/kiosks/view.php', $data);
		}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_kiosk_title')."";
		  $data['main_heading'] = $this->lang->line('kiosk_title');
		  $data['heading'] = $this->lang->line('add_kiosk_title');
		  $data['already_msg'] = "";
		  
		   $this->form_validation->set_rules('kiosk_category_id', ''.$this->lang->line('kiosk_category_text').'', 'trim');
		   $this->form_validation->set_rules('kiosk_name', ''.$this->lang->line('kiosk_name_text').'', 'required|trim');
		   $this->form_validation->set_rules('kiosk_type_id', ''.$this->lang->line('kiosk_type_text').'', 'required|trim');
		   $this->form_validation->set_rules('mac_id', ''.$this->lang->line('kiosk_mac_id_text').'', 'required|trim');
		   $this->form_validation->set_rules('unique_id', ''.$this->lang->line('kiosk_unique_id_text').'', 'required|trim');
		   $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'trim');
		   $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'trim');
		
		 if ($this->form_validation->run()) {
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'mac_id' =>trim($this->input->post('mac_id')));
		  $result = check_unique('kiosks',$feilds);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('mac_id'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {    $kiosk_id=  $this->kiosks_model->add();				 
			   if($kiosk_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/kiosks/view');
 		  }
	    } //end of add  functionality
	
	   $this->load->view('backoffice/kiosks/add.php', $data);
	}
	
	public function edit($kiosk_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_kiosk_title')."";
		  $data['main_heading'] = $this->lang->line('kiosk_title');
		  $data['heading'] = $this->lang->line('edit_kiosk_title');
		  $data['already_msg'] = "";
		  
  		  $this->form_validation->set_rules('kiosk_category_id', ''.$this->lang->line('kiosk_category_text').'', 'trim');
		   $this->form_validation->set_rules('kiosk_name', ''.$this->lang->line('kiosk_name_text').'', 'required|trim');
		   $this->form_validation->set_rules('kiosk_type_id', ''.$this->lang->line('kiosk_type_text').'', 'required|trim');
		   $this->form_validation->set_rules('mac_id', ''.$this->lang->line('kiosk_mac_id_text').'', 'required|trim');
		   $this->form_validation->set_rules('unique_id', ''.$this->lang->line('kiosk_unique_id_text').'', 'required|trim');
		   $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'trim');
		   $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'trim');
	
		if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'mac_id' =>trim($this->input->post('mac_id')));
		  $unique_id = array('kiosk_id' =>$kiosk_id);
		  $result = check_unique_edit('kiosks',$feild,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('kiosk_unique_id'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		      $result =  $this->kiosks_model->update_kiosk($this->input->post('kiosk_id'));
		      if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/kiosks/view");
		  }
		}		
		  $result =  $this->kiosks_model->kiosk_edit($kiosk_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/kiosks/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	
	public function status($kiosk_id,$status)
	{	 // Update status  
	     $result = $this->kiosks_model->update_status($kiosk_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/kiosks/view");		
		 
	}//end of Status  functionality*/
	
	
}	
?>