<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Groups extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/groups_model');
	}
	
	public function add_mapping()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_mapping_title')."";
		  $data['main_heading'] = $this->lang->line('mapping_title');
		  $data['heading'] = $this->lang->line('add_mapping_title');
		  $data['already_msg'] = "";
		  
		   $this->form_validation->set_rules('group_id', ''.$this->lang->line('group_name_text').'', 'required|trim');
		   $this->form_validation->set_rules('kiosk_id[]', ''.$this->lang->line('kiosk_name_text').'', 'required|trim');
		
		 if ($this->form_validation->run()) {
		   $result=  $this->groups_model->add_mapping();				 
			   if($result=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/groups/view_mapping');
 		
	    } //end of add  functionality
	
	
	    $data['kiosk_category_id'] = isset($catrow->kiosk_category_id) ? $catrow->kiosk_category_id : 0;
		  
		$fields = array('language_id'=>$this->session->userdata('lang_id'),'is_active'=>'1');
		$catresult = gettableresult('kiosks',$fields,'kiosk_id');
		if(is_array($catresult))
		{
			$category_ids=array();
			foreach($catresult as $ckey => $catval) {
			  $category_ids[] = $catval->kiosk_id;	
			}
		  $categoryids =  implode(',',$category_ids);
		  //echo "---------------->".$category_ids;
		  //$categoryids =  "'".$categoryids."'";
		 //echo "---------------->".$categoryids;
		}else
		{
			$categoryids =  '';
		}
			
			//print_r($category_ids);					
		  $data['kioskcategoryids'] = $categoryids;
		  
	   $this->load->view('backoffice/groups/add_mapping.php', $data);
	}
	
	
	public function edit_category($group_category_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_category_title')."";
		  $data['main_heading'] = $this->lang->line('category_title');
		  $data['heading'] = $this->lang->line('edit_category_title');
		  $data['already_msg'] = "";
		  
  		   $this->form_validation->set_rules('category_name', ''.$this->lang->line('category_name_text').'', 'trim');
		   $this->form_validation->set_rules('description', ''.$this->lang->line('description_text').'', 'required|trim');
	
		if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'category_name' =>trim($this->input->post('category_name')));
		  $unique_id = array('group_category_id' =>$group_category_id);
		  $result = check_unique_edit('group_categories',$feild,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('category_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		      $result =  $this->groups_model->update_category($this->input->post('group_category_id'));
		      if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/groups/view_category");
		  }
		}		
		  $result =  $this->groups_model->category_edit($group_category_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/groups/edit_category.php', $data);
		 
	}//end of Edit functionality*/
	
	
	public function view_mapping(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_mapping_title')."";
	    $data['main_heading'] = $this->lang->line('mapping_title');
	    $data['heading'] = $this->lang->line('view_mapping_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('group_id'))
			 $group_id = $this->input->post('group_id');
		 elseif($this->uri->segment('4'))
			 $group_id=$this->uri->segment('4');
		else
			 $group_id='0';
	
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('5'))
			 $status=$this->uri->segment('5');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/groups/view_mapping/".$group_id."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->groups_model->count_mapping($group_id,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->groups_model->view_mapping($group_id,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['group_id'] = $group_id;
		$data['status'] = $status;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/groups/view_mapping.php', $data);
		}
		
		
	
	public function category_status($group_category_id,$status)
	{	 // Update status  
	     $result = $this->groups_model->update_category_status($group_category_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/groups/view_category");		
		 
	}//end of Status  functionality*/	
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_group_title')."";
	    $data['main_heading'] = $this->lang->line('group_title');
	    $data['heading'] = $this->lang->line('view_group_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('group_type_id'))
			 $group_type_id = $this->input->post('group_type_id');
		 elseif($this->uri->segment('4'))
			 $group_type_id=$this->uri->segment('4');
		else
			 $group_type_id='0';
	
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('5'))
			 $status=$this->uri->segment('5');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/groups/view/".$group_type_id."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->groups_model->count_groups($group_type_id,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->groups_model->view_groups($group_type_id,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['group_type_id'] = $group_type_id;
		$data['status'] = $status;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/groups/view.php', $data);
		}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_group_title')."";
		  $data['main_heading'] = $this->lang->line('group_title');
		  $data['heading'] = $this->lang->line('add_group_title');
		  $data['already_msg'] = "";
		  
		   $this->form_validation->set_rules('group_type_id', ''.$this->lang->line('group_type_text').'', 'trim');
		   $this->form_validation->set_rules('group_name', ''.$this->lang->line('group_name_text').'', 'required|trim');
		
		 if ($this->form_validation->run()) {
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'group_type_id' =>trim($this->input->post('group_type_id')),'group_name' =>trim($this->input->post('group_name')));
		  $result = check_unique('groups',$feilds);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('group_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {    $group_id=  $this->groups_model->add();				 
			   if($group_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/groups/view');
 		  }
	    } //end of add  functionality
	
	   $this->load->view('backoffice/groups/add.php', $data);
	}
	
	public function edit($group_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_group_title')."";
		  $data['main_heading'] = $this->lang->line('group_title');
		  $data['heading'] = $this->lang->line('edit_group_title');
		  $data['already_msg'] = "";
		  
  		 $this->form_validation->set_rules('group_type_id', ''.$this->lang->line('group_type_text').'', 'trim');
		 $this->form_validation->set_rules('group_name', ''.$this->lang->line('group_name_text').'', 'required|trim');
	
		if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'group_type_id' =>trim($this->input->post('group_type_id')),'group_name' =>trim($this->input->post('group_name')));
		  $unique_id = array('group_id' =>$group_id);
		  $result = check_unique_edit('groups',$feild,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('group_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		      $result =  $this->groups_model->update_group($this->input->post('group_id'));
		      if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/groups/view");
		  }
		}		
		  $result =  $this->groups_model->group_edit($group_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/groups/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	
	public function status($group_id,$status)
	{	 // Update status  
	     $result = $this->groups_model->update_status($group_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/groups/view");		
		 
	}//end of Status  functionality*/
	
	
}	
?>