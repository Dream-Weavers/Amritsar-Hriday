<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tours extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('backoffice/Tours_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->icon_path = realpath('images/tour/');
	}
	public function index(){
	    $data['title']        = "View Tours";
		$data['already_msg'] = "";	
		$data['main_heading'] = "Tours";	
		$data['heading']      = "View Tours";	
		
		if($this->input->post('tour_name'))	
			$tour_name = $this->input->post('tour_name');
		else		
			$tour_name='';		
		
		if($this->input->post('created_by'))	
			$created_by = $this->input->post('created_by');	
		else		
			$created_by='';
		
		
		if($this->input->post('status'))	
			$status = $this->input->post('status');	
		else		
			$status='0';	 
	
	
		
		$data['tour_name'] = $tour_name;	
		$data['status'] = $status;	
			
			
		/********Get Tours Records********/	
		$data['results']      = $this->Tours_model->viewTours($tour_name, $created_by, $status);
		$data['num_rows']     = isset($data['results'])?count($data['results']):0;
	   $this->load->view('backoffice/tours/view',$data);	
	}//End of Index
	
	public function setorder($tour_trail_id=NULL){	
	    
		$data=array();
		$data['title'] = title." Locations Priority";
	    $data['main_heading'] = "Locations Priority";
	    $data['heading'] = "Locations Priority";	
		
		
		$data['results'] = $this->Tours_model->location_names($tour_trail_id);
		$data['num_rows'] = count($data['results']);
		$data['tour_id'] = $tour_trail_id;
		
		if(isset($_POST['submit_weight'])){
			$fields_sorting=$this->Tours_model->module_field_sorting('tour_trail_locations','tour_trail_location_id');
			$this->session->set_flashdata('success_message', 'Field has been updated successfully.');
			redirect(base_url() . 'backoffice/tours');  
		}
		
		$this->load->view('backoffice/tours/setorder.php', $data);
		
	}
	
	public function status($tour_id,$status)

	{	 // Update status  

	     $result = $this->Tours_model->update_status($tour_id,$status);

		 if($result=='1')

		 {

		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));

		 }

		 else

		 {

			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));

		 }

		 redirect(base_url() . "backoffice/tours");		

		 

	}//end of Status  functionality*/
	public function add(){
		  $data['main_heading'] = "Tours";
		  $data['heading']      = "Add Tour";
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/

		  $tour_name = '';
		  $description = '';

		 
		 if($this->input->post()){
			/*  echo "<pre>";
			 print_r($this->input->post());
			 die; */
			$tour_name	= isset($_POST['tour_name'])? $_POST['tour_name']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			
			
			
			 /********Check validations************/
	
				$this->form_validation->set_rules('tour_name', 'Tour Name', 'required');
			  	 
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
					/*****Assign posted value to model's variable******/
					$this->Tours_model->tour_name = $tour_name;
					$this->Tours_model->description = $description;
					//echo $this->input->post('location_checkbox');die;
					$tour_id = $this->Tours_model->addTours();
				
					
					/* echo "<pre>";
					print_r($_FILES);
					die; */
					if($_FILES['tour_icon']){	
						$config['upload_path'] = $this->icon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;	
						if($_FILES['tour_icon']['error']!='4'){
							  if($_FILES['tour_icon']['name']!=''){
								$image_id = $this->Tours_model->add_icon($tour_id,$_FILES['tour_icon']['name']);	
							  }
							  $config['file_name'] =$tour_id.'_'.$_FILES['tour_icon']['name'];
							  $this->upload->initialize($config);
							  $this->upload->do_upload('tour_icon');
		
						}  
					}
				
					if(!empty($this->input->post('location_checkbox')))
					{
						foreach($this->input->post('location_checkbox') as $key=>$value){
							$this->Tours_model->addTourLocations($value,$tour_id);
						}
					}				
					
					
					$this->session->set_flashdata('success_message', 'Tour has been added.');
					redirect(base_url() . 'backoffice/Tours');
				} else {
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
			}
		
		  $data['tour_id']= $tour_id;			
		  $data['tour_name']=$tour_name;
		  $data['description']=$description;
		  
		  $this->load->view('backoffice/tours/add',$data);		
	}

	
	public function edit($tour_id=NULL,$para1){
	    
		  $data['main_heading'] = "Tours";
		  $data['heading']      = "Edit Tour";
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  $data['row'] = $this->Tours_model->fetch_record($tour_id); 
		  /*******Variable declarations*********/
		

		 
		 if($this->input->post()){
			 
			/********Check validations************/
			
			$this->form_validation->set_rules('tour_name', 'Tour Name', 'required');
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
					/*****Assign posted value to model's variable******/
		
					$this->Tours_model->editTours($tour_id);
				
					if($_FILES['tour_icon']){	
						$config['upload_path'] = $this->icon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;	
						if($_FILES['tour_icon']['error']!='4'){
							  if($_FILES['tour_icon']['name']!=''){
								$image_id = $this->Tours_model->add_icon($tour_id,$_FILES['tour_icon']['name']);	
							  }
							  $config['file_name'] =$tour_id.'_'.$_FILES['tour_icon']['name'];
							  $this->upload->initialize($config);
							  $this->upload->do_upload('tour_icon');
		
						}  
					}
					
					$location_checkbox=$this->input->post('location_checkbox');
					$already_inserted=$this->input->post('already_inserted');
					
					$fetch_selected_locations=$this->Tours_model->get_edited_data($tour_id);
					//DELETE UNTICK RECORDS
					 foreach($fetch_selected_locations as $v){
						if(!isset($location_checkbox[$v['location_id']])){
							$this->Tours_model->delete_data($already_inserted[$v['location_id']]);
						}
					 } 
								
								
					if(!empty($location_checkbox))
					{
						
						
						foreach($location_checkbox as $key=>$value){
							if(isset($already_inserted[$value]) && $already_inserted[$value]!=''){
								//$this->Tours_model->editTourLocations($already_inserted[$value]);
							} else { 
								$this->Tours_model->addTourLocations($value,$tour_id);
							}
						}
					}				
					
					
					$this->session->set_flashdata('success_message', 'Tour has been updated.');
					if($para1=="userdefined"){
					    redirect(base_url() . 'backoffice/tours/userdefined');
					}elseif($para1=="predefined"){
					    redirect(base_url() . 'backoffice/tours/predefined');
					}
					
				} else {
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
			}
		$data['para']=$para1;
		  
		  $this->load->view('backoffice/tours/edit',$data);	
	}
	
	public function predefined(){
	    $data['title']        = "View Predefined Tours";
		$data['already_msg'] = "";	
		$data['main_heading'] = "Predefined Tours";	
		$data['heading']      = "View Predefined Tours";	
		
		if($this->input->post('tour_name'))	
			$tour_name = $this->input->post('tour_name');
		else		
			$tour_name='';		
		
		if($this->input->post('created_by'))	
			$created_by = $this->input->post('created_by');	
		else		
			$created_by='';
		
		
		if($this->input->post('status'))	
			$status = $this->input->post('status');	
		else		
			$status='0';	 
	
	
		
		$data['tour_name'] = $tour_name;	
		$data['status'] = $status;	
			
			
		/********Get Tours Records********/	
		$data['results']      = $this->Tours_model->viewPredefinedTours($tour_name, $created_by, $status);
		$data['num_rows']     = isset($data['results'])?count($data['results']):0;
	    $this->load->view('backoffice/tours/predefined',$data);	
	}
	public function userdefined(){
	    $data['title']        = "View User Tours";
		$data['already_msg'] = "";	
		$data['main_heading'] = "User Tours";	
		$data['heading']      = "View User Tours";	
		
		if($this->input->post('tour_name'))	
			$tour_name = $this->input->post('tour_name');
		else		
			$tour_name='';		
		
		if($this->input->post('created_by'))	
			$created_by = $this->input->post('created_by');	
		else		
			$created_by='';
		
		
		if($this->input->post('status'))	
			$status = $this->input->post('status');	
		else		
			$status='0';	 
	
	
		
		$data['tour_name'] = $tour_name;	
		$data['status'] = $status;	
			
			
		/********Get Tours Records********/	
		$data['results']      = $this->Tours_model->viewUserTours($tour_name, $created_by, $status);
		$data['num_rows']     = isset($data['results'])?count($data['results']):0;
	    $this->load->view('backoffice/tours/userpredefined',$data);	
	}
}
