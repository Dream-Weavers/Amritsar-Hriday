<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Surveyor extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct() 
	{
		parent:: __construct();
		//valid_logged_in(FALSE,'E');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/surveyor_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->location_path = realpath('assets/static/locations');
		$this->icons_path = realpath('assets/static/locations/icons');
		$this->gallery_path = realpath('assets/static/locations/gallery');
		$this->audio_path = realpath('assets/static/locations/audio');
		$this->video_path = realpath('assets/static/locations/video');
		$this->map2d_path = realpath('assets/static/locations/2dmap');
		$this->panorama_path = realpath('assets/static/locations/panorama');
		$this->facility_path = realpath('assets/static/locations/facility');
		
	}
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_locations_title')."";
	    $data['main_heading'] = $this->lang->line('locations_title');
	    $data['heading'] = $this->lang->line('view_locations_title');	
		
	    if($this->input->post('location_id'))
			 $location_id = $this->input->post('location_id');
		 elseif($this->uri->segment('4'))
			 $location_id=$this->uri->segment('4');
		 else
			 $location_id='0';
			 
			 
	    if($this->input->post('category_type_id'))
	 		 $category_type_id = $this->input->post('category_type_id');
	    elseif($this->uri->segment('5'))
			 $category_type_id=$this->uri->segment('5');
		else
			 $category_type_id='0';
			 	 
		
	    if($this->input->post('locality_id'))
			$locality_id = $this->input->post('locality_id');
		 elseif($this->uri->segment('6'))
			$locality_id=$this->uri->segment('6');
		 else
			$locality_id='0';

		
	   if($this->input->post('status'))
			$status = $this->input->post('status');
		elseif($this->uri->segment('7'))
			 $status=$this->uri->segment('7');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('8'))
			$per_page=$this->uri->segment('8');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/surveyor/view/".$location_id."/".$category_type_id."/".$locality_id."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 9;
		$config["total_rows"] =$this->surveyor_model->count_locations($location_id,$category_type_id,$locality_id,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(9)) ? $this->uri->segment(9) : 0;  
		$data['results'] = $this->surveyor_model->view_locations($location_id,$category_type_id,$locality_id,$status,$config['per_page'], $page);
		
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['location_id'] = $location_id;
		$data['category_type_id'] = $category_type_id;
		$data['locality_id'] = $locality_id;
		$data['serial_no'] = $serial_no;
		$data['status'] = $status;	
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/surveyor/view.php', $data);
	}
	
	
	public function locationlog($location_id){	
	    
		$data=array();
		$data['title'] = "Location Log";
	    $data['main_heading'] = "Location Log";
	    $data['heading'] = "Location Log";
		
		$data['results'] = $this->surveyor_model->fetch_locations_log($location_id);
		 
	    $this->load->view('backoffice/surveyor/log.php', $data);
	}
	
	public function locationstatuslog($location_id){	
	    
		$data=array();
		$data['title'] = "Status Log";
	    $data['main_heading'] = "Status Log";
	    $data['heading'] = "Status Log";
		
		$data['results'] = $this->surveyor_model->fetch_status_log($location_id);
		 
	    $this->load->view('backoffice/surveyor/statuslog.php', $data);
	}
	
	public function edit($location_id){
		
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('edit_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('edit_location_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('location_name', ''.$this->lang->line('location_location_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_name', ''.$this->lang->line('location_short_name_text').'', 'required|trim');
	
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  $this->form_validation->set_rules('state_name', ''.$this->lang->line('location_state_text').'', 'required|trim');
		  $this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		  $this->form_validation->set_rules('estimated_visit_time', ''.$this->lang->line('location_estimated_visit_time_text').'', 'trim');

		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		  
		  $this->form_validation->set_rules('north_area', ''.$this->lang->line('location_north_text').'', 'trim');
		  $this->form_validation->set_rules('north_area_title', ''.$this->lang->line('location_north_title_text').'', 'trim');
		  $this->form_validation->set_rules('south_area', ''.$this->lang->line('location_south_text').'', 'trim');
		  $this->form_validation->set_rules('south_area_title', ''.$this->lang->line('location_south_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area_title', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('west_area', ''.$this->lang->line('location_west_text').'', 'trim');
		  $this->form_validation->set_rules('west_area_title', ''.$this->lang->line('location_west_title_text').'', 'trim');
		  
		if ($this->form_validation->run()) {
			 		
		 	 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
			  foreach($_POST['week_days'] as $key => $weekdayval) {
			  if(in_array($weekdayval,$_POST['availability']))
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			  }
			 }

			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			  
			  //Get Directions Json
			  $direction_locations =array();
			  
			  $direction_locations['northstartpointlongitude']= $_POST['northstartpointlongitude']; 	
			  $direction_locations['northstartpointlatitude']= $_POST['northstartpointlatitude']; 	
			  $direction_locations['northendpointlongitude']= $_POST['northendpointlongitude']; 	
			  $direction_locations['northendpointlatitude']= $_POST['northendpointlatitude']; 	
			  
			  $direction_locations['southstartpointlongitude']= $_POST['southstartpointlongitude']; 	
			  $direction_locations['southstartpointlatitude']= $_POST['southstartpointlatitude']; 	
			  $direction_locations['southendpointlongitude']= $_POST['southendpointlongitude']; 	
			  $direction_locations['southendpointlatitude']= $_POST['southendpointlatitude'];
			  
			  $direction_locations['eaststartpointlongitude']= $_POST['eaststartpointlongitude']; 	
			  $direction_locations['eaststartpointlatitude']= $_POST['eaststartpointlatitude']; 	
			  $direction_locations['eastendpointlongitude']= $_POST['eastendpointlongitude']; 	
			  $direction_locations['eastendpointlatitude']= $_POST['eastendpointlatitude'];
			  
			  $direction_locations['weststartpointlongitude']= $_POST['weststartpointlongitude']; 	
			  $direction_locations['weststartpointlatitude']= $_POST['weststartpointlatitude']; 	
			  $direction_locations['westendpointlongitude']= $_POST['westendpointlongitude']; 	
			  $direction_locations['westendpointlatitude']= $_POST['westendpointlatitude'];
			  
			  $directionlocations = json_encode($direction_locations);
			
				 
		 	   $result =  $this->surveyor_model->update_location($this->input->post('location_id'),$working_hours,$directionlocations);
			   
			   //Insert Digital Media
			   if($location_id!=0){
					    //Digital Audio File
					    $totalaudiofiles= count($_FILES['digital-audio']['name']);
						for($i=0;$i<$totalaudiofiles;$i++){
							if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->surveyor_model->insertDigitalMedia($location_id,audio_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 //Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->surveyor_model->insertDigitalMedia($location_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->surveyor_model->insertDigitalMedia($location_id,video_files,$file_name);
							  } 
					
						   }
						}
						
						 
						//Digital 2dMap Files
					    $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
						for($i=0;$i<$total2dmapfiles;$i++){
							if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
							
								$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
								
								$config['upload_path'] = $this->map2d_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->surveyor_model->insertDigitalMedia($location_id,map2d_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Digital panorama Files
					    $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
						for($i=0;$i<$totalpanoramafiles;$i++){
							if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
								
								$config['upload_path'] = $this->panorama_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->surveyor_model->insertDigitalMedia($location_id,panorama_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						
						 //*********************************Facilities*********************//
						 //Facilities Washroom Group
						if(isset($_POST['washroom-group']))
						{
						  $GroupLists = $_POST['washroom-group'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['washroom_longitude']!='') 
							  {
							  $washroom_availability =  implode(",",$listrow['washroom_availability']);	
							   //$washroom_availability =  $listrow['washroom_availability'];	
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_type'  => washroom_facility_type,
									'facility_name_no'  => $listrow['washroom_no'],
									'facility_description'  => $listrow['washroom_description'],
									'washroom_availability' => $washroom_availability,
									'longitude'     => $listrow['washroom_longitude'],
									'latitude'     => $listrow['washroom_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Washroom Images 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_images'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_images'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_images'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								
							  }
						   }
						}
						
						if(isset($_POST['parking-group']))
						{
						  $GroupLists = $_POST['parking-group'];
						  foreach($GroupLists as $key=> $listrow){
							  /*echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";
							  die();*/
							  if($listrow['parking_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									
									'facility_name_no'  => $listrow['parking_no'],
									'facility_description'  => $listrow['parking_description'],
									'facility_type'  => parking_facility_type,
									'parking_type' => $listrow['parking_entry_ticket'],
									'parking_fee' => $listrow['parking_fees_amt'],
									'longitude'     => $listrow['parking_longitude'],
									'latitude'     => $listrow['parking_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Parking Images 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_images'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_images'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_images'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								 
								
							  }
						   }
						}
						
						
						if(isset($_POST['group-dispensary']))
						{
						  $GroupLists = $_POST['group-dispensary'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['dispensary_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['dispensary_no'],
									'facility_description'  => $listrow['dispensary_description'],
									'facility_type'  => dispensary_facility_type,
									'longitude'     => $listrow['dispensary_longitude'],
									'latitude'     => $listrow['dispensary_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Dispensary Images 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_images'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_images'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_images'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Dispensary 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-police-booth']))
						{
						  $GroupLists = $_POST['group-police-booth'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['police_booth_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'facility_name_no'  => $listrow['police_booth_no'],
									'facility_description'  => $listrow['police_booth_description'],
									'location_id'=>$location_id,
									'facility_type'  => police_booth_facility_type,
									'longitude'     => $listrow['police_booth_longitude'],
									'latitude'     => $listrow['police_booth_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_images'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_images'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_images'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['shoe-booth']))
						{
						  $GroupLists = $_POST['shoe-booth'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['shoe_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'facility_name_no'  => $listrow['shoe_no'],
									'facility_description'  => $listrow['shoe_description'],
									'location_id'=>$location_id,
									'facility_type'  => shoe_facility_type,
									'longitude'     => $listrow['shoe_longitude'],
									'latitude'     => $listrow['shoe_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['shoe-booth']['name'][$key]['shoe_images'];
								$_FILES['userfile']['type']    = $_FILES['shoe-booth']['type'][$key]['shoe_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['shoe-booth']['tmp_name'][$key]['shoe_images'];
								$_FILES['userfile']['error']   = $_FILES['shoe-booth']['error'][$key]['shoe_images'];
								$_FILES['userfile']['size']  = $_FILES['shoe-booth']['size'][$key]['shoe_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['shoe-booth']['name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['shoe-booth']['type'][$key]['shoe_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['shoe-booth']['tmp_name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['shoe-booth']['error'][$key]['shoe_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['shoe-booth']['size'][$key]['shoe_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['luggage-booth']))
						{
						  $GroupLists = $_POST['luggage-booth'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['luggage_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'facility_name_no'  => $listrow['luggage_no'],
									'facility_description'  => $listrow['luggage_description'],
									'location_id'=>$location_id,
									'facility_type'  => luggage_facility_type,
									'longitude'     => $listrow['luggage_longitude'],
									'latitude'     => $listrow['luggage_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['luggage-booth']['name'][$key]['luggage_images'];
								$_FILES['userfile']['type']    = $_FILES['luggage-booth']['type'][$key]['luggage_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['luggage-booth']['tmp_name'][$key]['luggage_images'];
								$_FILES['userfile']['error']   = $_FILES['luggage-booth']['error'][$key]['luggage_images'];
								$_FILES['userfile']['size']  = $_FILES['luggage-booth']['size'][$key]['luggage_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['luggage-booth']['name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['luggage-booth']['type'][$key]['luggage_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['luggage-booth']['tmp_name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['luggage-booth']['error'][$key]['luggage_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['luggage-booth']['size'][$key]['luggage_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['langar-booth']))
						{
						  $GroupLists = $_POST['langar-booth'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['langar_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'facility_name_no'  => $listrow['langar_no'],
									'facility_description'  => $listrow['langar_description'],
									'location_id'=>$location_id,
									'facility_type'  => langar_facility_type,
									'longitude'     => $listrow['langar_longitude'],
									'latitude'     => $listrow['langar_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['langar-booth']['name'][$key]['langar_images'];
								$_FILES['userfile']['type']    = $_FILES['langar-booth']['type'][$key]['langar_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['langar-booth']['tmp_name'][$key]['langar_images'];
								$_FILES['userfile']['error']   = $_FILES['langar-booth']['error'][$key]['langar_images'];
								$_FILES['userfile']['size']  = $_FILES['langar-booth']['size'][$key]['langar_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['langar-booth']['name'][$key]['langar_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['langar-booth']['type'][$key]['langar_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['langar-booth']['tmp_name'][$key]['langar_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['langar-booth']['error'][$key]['langar_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['langar-booth']['size'][$key]['langar_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-ticketcounter']))
						{
						  $GroupLists = $_POST['group-ticketcounter'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['ticketcounter_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_type'  => ticketcounter_facility_type,
									'facility_name_no'  => $listrow['ticketcounter_no'],
									'facility_description'  => $listrow['ticketcounter_description'],
									'longitude'     => $listrow['ticketcounter_longitude'],
									'latitude'     => $listrow['ticketcounter_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_images'];
								$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_images'];
								$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_images'];
								$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'2dmap' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-enquiry']))
						{
						  $GroupLists = $_POST['group-enquiry'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['enquiry_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_type'  => enquiry_facility_type,
									'facility_name_no'  => $listrow['enquiry_no'],
									'facility_description'  => $listrow['enquiry_description'],
									'longitude'     => $listrow['enquiry_longitude'],
									'latitude'     => $listrow['enquiry_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_images'];
								$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_images'];
								$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_images'];
								$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'2dmap' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						
						
						if(isset($_POST['group-resthouse']))
						{
						  $GroupLists = $_POST['group-resthouse'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['resthouse_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_type'  => resthouse_facility_type,
									'facility_name_no'  => $listrow['resthouse_no'],
									'facility_description'  => $listrow['resthouse_description'],
									'longitude'     => $listrow['resthouse_longitude'],
									'latitude'     => $listrow['resthouse_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->surveyor_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_images'];
								$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_images'];
								$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_images'];
								$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'2dmap' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
				}	
		        
		  
	
		
		      if($result=='1')
				{   
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/surveyor/view/");
		
		}		
		  $result =  $this->surveyor_model->location_edit($location_id);
		  $data['edit_data'] = $result;
		  $fields = array('location_id'=>$result->location_id,'is_active'=>'1');
		  $catrow = gettableinfo('slocation_categories',$fields);
		  
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  
		    $fields = array('location_id'=>$location_id,'is_active'=>'1');
			$catresult = gettableresult('slocation_categories',$fields,'category_id');
			if(is_array($catresult))
			{
				$category_ids=array();
				foreach($catresult as $ckey => $catval) {
				  $category_ids[] = $catval->category_id;	
				}
			  $categoryids =  implode(',',$category_ids);
			  //echo "---------------->".$category_ids;
			  //$categoryids =  "'".$categoryids."'";
			 //echo "---------------->".$categoryids;
			}else
			{
				$categoryids =  '';
			}
			
			//print_r($category_ids);					
		  $data['category_ids'] = $categoryids;
		  
		  $this->load->view('backoffice/surveyor/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	public function status($location_id)
	{	 // Update status  
	     $result = $this->surveyor_model->update_status($location_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		 redirect(base_url() . "backoffice/surveyor/view");		
		 
	}//end of Status  functionality*/
	public function deletedigitalmedia($location_media_id)
	{	 // Delete Digital Media  
	     $result = $this->surveyor_model->deleteDigitalMedia($location_media_id,$this->audio_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	
	public function setdefaultmedia($location_id,$location_media_id,$media_type)
	{	 // Set Default Media  
	     $result = $this->surveyor_model->setDefaultMedia($location_id,$location_media_id,$media_type);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('update_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	

	public function deletelocsection($location_section_id)
	{	 // Delete Section  
	     $result = $this->surveyor_model->deleteLocSection($location_section_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function deletefacility($location_facility_id)
	{	 // Delete facility  
	     $result = $this->surveyor_model->deleteFacility($location_facility_id,$this->facility_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
}	
?>