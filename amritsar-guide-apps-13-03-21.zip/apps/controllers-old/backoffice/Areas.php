<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Areas extends CI_Controller {
public function __construct()
	{
		parent:: __construct();	
		validateAccess();
		$this->load->model('backoffice/Areas_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->icon_path = realpath('images/area-icons/');
	}

	public function index()
	{
		$data=array();
		$data['title'] = $this->lang->line('areas_title');
		$data['main_heading'] =$this->lang->line('areas_title');
		$data['heading'] = $this->lang->line('areas_title');
		$data['already_msg']=""; 
		$data['search_keyword'] = $this->input->post("search_keyword");	 
		$results = $this->Areas_model->view_areas();
	
		$data['country_id'] = 0; 
		$data['state_id'] = 0;
		$data['city_id'] = 0;
		$data['locality_id'] = 0;
		  
	
		  $this->form_validation->set_rules('area_name',  ''.$this->lang->line('add_area_title').'', 'required|trim');
	      if ($this->form_validation->run()) {
		
		   $area_id =  $this->Areas_model->add();
	
		   
			if($area_id!='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
			} else {
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
			}

		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/areas');  
	    } //end of add  functionality
		
 		$data['results'] = $results;

		//$num_rows = count($results);	
		//$data['num_rows'] = $num_rows; 
		

		$data['header'] = '';
		$data['title']=$this->lang->line('areas_title');
		$data['short_desc']=$this->lang->line('show_all_areas_title');
		$this->load->view('backoffice/areas/view',$data);
		
    } //end of view functionality
	
	public function add()
	{
		  $data['title'] = $this->lang->line('add_area_title');
		  $data['main_heading'] =$this->lang->line('areas_title');
		  $data['heading'] = $this->lang->line('add_area_title');
		  $data['already_msg']="";
		  
	
		   $this->form_validation->set_rules('area_name',  ''.$this->lang->line('area_name_text').'', 'required|trim');
		  if ($this->form_validation->run()) {
		
		   $area_id =  $this->Areas_model->add();

			if($area_id!='0')
			{
			  $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
		    }
			else {
			   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
			}
			 
			
			  redirect(base_url() . 'backoffice/areas/add');  
		  
			
			
	    } //end of add  functionality

		$data['header'] = '';
		$data['title']=$this->lang->line('areas_title');
		$data['short_desc']=$this->lang->line('areas_title');
		$this->load->view('backoffice/areas/add',$data); 
	}

	
	public function edit($area_id){
		
		  $data['title'] = $this->lang->line('edit_area_title');
		  $data['main_heading'] =$this->lang->line('areas_title');
		  $data['heading'] = $this->lang->line('edit_area_title');
          $data['already_msg']="";
		  

		  
		  $results = $this->Areas_model->fetcharea($area_id);
		  $data['edit_data'] = $results;
			
		  $this->form_validation->set_rules('area_name', 'Area Name', 'required|trim');
		  if ($this->form_validation->run()) {
			  // Update records 
	  
			  
			   $result =  $this->Areas_model->update_area($area_id);
			   
				if($result=='1') {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
				
			    redirect(base_url() . "backoffice/areas");
			  
		  }
		  
		$data['header'] = '';
		$data['title']=$this->lang->line('edit_area_title');
		$data['short_desc']=$this->lang->line('edit_area_title');
		$this->load->view('backoffice/areas/edit',$data);
		 
	}//end of Edit functionality*/
}	
?>