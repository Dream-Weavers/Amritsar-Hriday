<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogcategories extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('backoffice/Blogcategories_model');
	}
	public function index(){
	    $data['title'] = $this->lang->line('categories_title');
		$data['main_heading'] =$this->lang->line('show_all_categories_title');
		$data['heading'] = $this->lang->line('categories_title');
		$data['already_msg']=""; 
		/********Get Categories Records********/	
		$data['results']      = $this->Blogcategories_model->viewCategories();
		$data['num_rows']     = isset($data['results'])?count($data['results']):0;
	   $this->load->view('backoffice/blogcategories/view',$data);	
	}//End of Index
	
	public function add($category_id=NULL){
		$this->add_edit_categories($category_id);	
	}
	
	public function edit($category_id=NULL){
		$this->add_edit_categories($category_id);	
	}
	public function add_edit_categories($category_id=NULL){
		  $data['main_heading'] = $this->lang->line('categories_title');
		  $data['heading']      = ($category_id=='')? $this->lang->line('add_category_title'): $this->lang->line('edit_category_title');
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $category_type_id = '';
		  $category_parent_id = '';
		  $category_name = '';
		  $description = '';
		 
		  $category_id = ($category_id!='') ? $category_id : 0;
		  $this->Blogcategories_model->category_id   = $category_id;
		  $category_records_array = array();
	      if($category_id!='0'){
	   		$category_records_array = $this->Blogcategories_model->editCategoriesData(); 
			/*******Assign fetched record to variables to set value of input box******/
			$category_name	= $category_records_array->category_name;
			$description	= $category_records_array->description;
	      }
		 
		 if($this->input->post()){
			$category_name	= isset($_POST['category_name'])? $_POST['category_name']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			
			 /********Check validations************/
			  $this->form_validation->set_rules('category_name','Category Name', 'required|is_unique[blog_categories.category_name]');
			  
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
				/*****Assign posted value to model's variable******/
				$this->Blogcategories_model->category_name = $category_name;
				$this->Blogcategories_model->description = $description;
				
				if($category_id==0)
					$this->Blogcategories_model->addCategories();
				else
					$this->Blogcategories_model->editCategories();
				

			
				 if($category_id=='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else { 
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				
			      redirect(base_url() . 'backoffice/Blogcategories');
	    } 
				else{ 
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
		
		  $data['category_id']= $category_id;			
		  $data['category_name']=$category_name;
		  $data['description']=$description;
		  
		  $this->load->view('backoffice/blogcategories/add_edit_categories',$data);	
	}
}
