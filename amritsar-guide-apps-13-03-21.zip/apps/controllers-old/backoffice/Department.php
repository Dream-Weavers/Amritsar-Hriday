<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Department extends CI_Controller {
public function __construct()
	{
		parent:: __construct();	
		validateAccess();
		$this->load->model('backoffice/Department_model');
	}

	public function index()
	{
		$data=array();
		$data['title'] = "Department";
		$data['main_heading'] ="Department";
		$data['heading'] = "Department";
		$data['already_msg']=""; 
		//$data['search_keyword'] = $this->input->post("search_keyword");	 
		$results = $this->Department_model->view_department();

	
		  $this->form_validation->set_rules('department_name', 'Department Name', 'required|trim');
	      if ($this->form_validation->run()) {
		
		   $department_id =  $this->Department_model->add();
	
		  
			if($department_id!='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
			} else {
				   $msg=  "Department already exists or some other error, please try again!";
				   $this->session->set_flashdata('error_message', $msg);
			}
		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/department');  
	    } //end of add  functionality
		
 		$data['results'] = $results;

		//$num_rows = count($results);	
		//$data['num_rows'] = $num_rows; 
		

		$data['header'] = '';
		$data['title']="Department";
		$data['short_desc']="Show All Departments";
		$this->load->view('backoffice/department/view',$data);
		
    } //end of view functionality
	
	public function add()
	{
		   $data['title'] = $this->lang->line('add_department_name');
		  $data['main_heading'] ="Department";
		  $data['heading'] = $this->lang->line('add_department_name');
		  $data['already_msg']="";
		  
	
		  $this->form_validation->set_rules('department_name', 'Department Name', 'required|trim');
		  if ($this->form_validation->run()) {
		
		   $department_id =  $this->Department_model->add();

		   
			if($department_id!='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
			} else {
				   $msg=  "Department already exists or some other error, please try again!";
				   $this->session->set_flashdata('error_message', $msg);
			}
		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/department/add');  
		  
			
			
	    } //end of add  functionality

		$data['header'] = '';
		$data['title']="Department";
		$data['short_desc']="Department";
		$this->load->view('backoffice/department/add',$data); 
	}

	
	public function edit($department_id){
		
		  $data['title'] = "Edit Department";
		  $data['main_heading'] ="Edt Department";
		  $data['heading'] = "Edit Department";
          $data['already_msg']="";
		  

		  
		  $results = $this->Department_model->fetchdepartment($department_id);
		  $data['edit_data'] = $results;
			
		  $this->form_validation->set_rules('department_name', 'Department Name', 'required|trim');
		  if ($this->form_validation->run()) {
			  // Update records 
	  
			  
			   $result =  $this->Department_model->update_department($department_id);
			   
			  
				if($result=='1') {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg=  "Department already exists or some other error, please try again!";
				   $this->session->set_flashdata('error_message', $msg);
				}
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/department");
			  
		  }
		  
		$data['header'] = '';
		$data['title']=$this->lang->line('edit_department_name');
		$data['short_desc']=$this->lang->line('edit_department_name');
		$this->load->view('backoffice/department/edit',$data);
		 
	}//end of Edit functionality*/
	
	public function status($department_id,$status)
	{	 // Update status  
	     $result = $this->Department_model->update_status($department_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', "Status has been changed successfully");
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', "There is some issue, please try again!");
		 }
		  redirect(base_url() . "backoffice/department");		
		 
	}//end of Status  functionality*/
}	
?>