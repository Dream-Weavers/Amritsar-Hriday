<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Changepassword extends CI_Controller {
 var $original_path;
var $resized_path;
public function __construct()
	{
		parent:: __construct();
		$this->load->model('backoffice/Confirmpassword_model');
/* 		is_logged_in();
		$this->load->model('profile_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
 */
	}
	
	
	public function index()
	{
		$data = array();
		$data['view_name'] = 'backoffice/changepassword';
		$data['header'] = '';
		$data['title']='Change Password';
		$data['short_desc']='Change Password';
		$data['heading']='Change Password';
		$data['already_msg']='';
		$this->form_validation->set_rules('newpassword', 'Password', 'required',
				array('required' => 'You must provide a %s.')
		  );
		$this->form_validation->set_rules('confirmpass', 'Confirm Password', 'required|matches[newpassword]');
		if ($this->form_validation->run()) {
			$result =  $this->Confirmpassword_model->update_password();
			if($result=='0')
			   $msg = "There is some error.";
			 else  
			  $msg = "Password has been changed successfully.";
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/changepassword');  
		}
		$this->load->view('backoffice/layout/layout',$data);
    } 
}	
?>