<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Vendors extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/vendors_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->original_path = realpath('assets/vendors/original');
	   	$this->resized_path = realpath('assets/vendors/resized');
		$this->gallery_path = realpath('assets/vendors/gallery');
		//$this->beacon_path = realpath('assets/vendors/beacons');
	} 
	
	public function setdefaultmedia($location_id,$location_media_id,$media_type)
	{	 // Set Default Media  
	     $result = $this->vendors_model->setDefaultMedia($location_id,$location_media_id,$media_type);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('update_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function view(){	
		$data=array();
		$data['title'] = "View Vendors";
	    $data['main_heading'] = "Vendors";
	    $data['heading'] = "View Vendors";
		
	   //print_r($_POST);	
	    if($this->input->post('user_id'))
			 $user_id = $this->input->post('user_id');
		 elseif($this->uri->segment('4'))
			 $user_id=$this->uri->segment('4');
		else
			 $user_id='0';
	
			
		if($this->input->post('search_value'))
			$search_value = trim($this->input->post('search_value'));
		elseif($this->uri->segment('5'))
			$search_value=trim($this->uri->segment('5'));
		else
			$search_value='0';
		
		
		/* if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('6'))
			 $status=$this->uri->segment('6');
		else
			 $status='0';	 */ 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/vendors/view/".$search_value."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->vendors_model->count_users($search_value,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->vendors_model->view_users($search_value,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['status'] = $status;
		$data['search_by'] = $search_by;	
		$data['search_value'] = $search_value;	
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/vendors/view.php', $data);
	}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = "Add Vendor";
		  $data['main_heading'] = "Vendors";
		  $data['heading'] = "Add Vendor";
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('shop_title', 'Shop Title', 'required');
		  $this->form_validation->set_rules('first_name', 'First Name', 'required|trim');
		  $this->form_validation->set_rules('last_name', 'Last Name', 'required|trim');
		  $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
		  $this->form_validation->set_rules('mobile_no1', 'Mobile', 'required|numeric|min_length[10]');
		  if($this->input->post('vendor_type_id')=='1' || $this->input->post('vendor_type_id')=='3')
		  {
		   $this->form_validation->set_rules('userpass', 'Password', 'required|trim|min_length[3]|matches[compass]');
		   $this->form_validation->set_rules('compass', 'Confirm Password', 'required|trim');
		  }
		  $this->form_validation->set_rules('country_id', 'Country', 'required|trim');
		  $this->form_validation->set_rules('state_id', 'State', 'required');
		  $this->form_validation->set_rules('city_id', 'City', 'required');
		  
		  //$this->form_validation->set_rules('shop_address', 'Shop Address', 'required');
		 $products =  $this->vendors_model->products();	
		 
		 $product_categories=$this->vendors_model->product_category();	
		  
		 if ($this->form_validation->run()) {
		  $emailfeilds = array('email' =>trim($this->input->post('email')),'user_type'=>'V');
		  $emailresult = check_unique('users',$emailfeilds);
		  
		  $mobilefeilds = array('mobile_no1' =>trim($this->input->post('mobile_no1')),'user_type'=>'V');
		  $mobileresult = check_unique('users',$mobilefeilds);
		  
		  if($emailresult==1)
		  {
			$already_msg_text   = "Email already exists";
			$data['already_msg']= $already_msg_text;
		  }
		  elseif($mobileresult==1)
		  {
			$already_msg_text   = "Mobile number already exists";
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {
		          $user_id =  $this->vendors_model->add();		
				  
				  if($_FILES['user_photo']['error'] != 4){		
					  $config['upload_path'] = $this->original_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= max_file_size;
					  $config['max_width']  = '0';
					  $config['max_height']  = '0';
					  $config['overwrite'] = true;			
					  $config['file_name'] =$user_id.'-'.$_FILES['user_photo']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('user_photo')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			      else{
					 $data = $this->upload->data();
					 $file_name = $data['file_name'];
					 $original_path = $data['full_path'];
					 $image_thumb  =$this->resized_path.'/'.$file_name;
					 $config1['image_library']    = 'gd2';
					 $config1['source_image']     = $original_path;
					 $config1['new_image']        = $image_thumb;
					 $config1['maintain_ratio']   = TRUE;
					 $config1['height']              = 150;
					 $config1['width']              = 150;
					 $this->image_lib->initialize( $config1);
					 $this->image_lib->resize();
					 $this->image_lib->clear();									
					 $result_photo = $this->vendors_model->update_photo($user_id,$file_name);
			     }
		       }
			   //Insert Digital Media
			   if($user_id!=0){
					
						//Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,video_files,$file_name);
							  } 
					
						   }
						}
						
						
						//Digital Header Banner Files
					    $totalheadergalleryfiles= count($_FILES['header-gallery']['name']);
						
						for($i=0;$i<$totalheadergalleryfiles;$i++){
							if($_FILES['header-gallery']['name'][$i]['header_banner']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['header-gallery']['name'][$i]['header_banner'];
								$_FILES['userfile']['type']    = $_FILES['header-gallery']['type'][$i]['header_banner'];
								$_FILES['userfile']['tmp_name'] = $_FILES['header-gallery']['tmp_name'][$i]['header_banner'];
								$_FILES['userfile']['error']       = $_FILES['header-gallery']['error'][$i]['header_banner'];
								$_FILES['userfile']['size']    = $_FILES['header-gallery']['size'][$i]['header_banner'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,header_banner,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						 //Digital Footer Banner Files
					    $totalfootergalleryfiles= count($_FILES['footer-gallery']['name']);
						
						for($i=0;$i<$totalfootergalleryfiles;$i++){
							if($_FILES['footer-gallery']['name'][$i]['footer_banner']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['footer-gallery']['name'][$i]['footer_banner'];
								$_FILES['userfile']['type']    = $_FILES['footer-gallery']['type'][$i]['footer_banner'];
								$_FILES['userfile']['tmp_name'] = $_FILES['footer-gallery']['tmp_name'][$i]['footer_banner'];
								$_FILES['userfile']['error']       = $_FILES['footer-gallery']['error'][$i]['footer_banner'];
								$_FILES['userfile']['size']    = $_FILES['footer-gallery']['size'][$i]['footer_banner'];
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,footer_banner,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//Digital Popup Banner Files
					    $totalpopupgalleryfiles= count($_FILES['popup-gallery']['name']);
						
						for($i=0;$i<$totalpopupgalleryfiles;$i++){
							if($_FILES['popup-gallery']['name'][$i]['popup_banner']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['popup-gallery']['name'][$i]['popup_banner'];
								$_FILES['userfile']['type']    = $_FILES['popup-gallery']['type'][$i]['popup_banner'];
								$_FILES['userfile']['tmp_name'] = $_FILES['popup-gallery']['tmp_name'][$i]['popup_banner'];
								$_FILES['userfile']['error']       = $_FILES['popup-gallery']['error'][$i]['popup_banner'];
								$_FILES['userfile']['size']    = $_FILES['popup-gallery']['size'][$i]['popup_banner'];
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,popup_banner,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 //Digital FullPopup Banner Files
					    $totalfullpopupgalleryfiles= count($_FILES['fullpopup-gallery']['name']);
						
						for($i=0;$i<$totalfullpopupgalleryfiles;$i++){
							if($_FILES['fullpopup-gallery']['name'][$i]['full_page_popup_banner']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['fullpopup-gallery']['name'][$i]['full_page_popup_banner'];
								$_FILES['userfile']['type']    = $_FILES['fullpopup-gallery']['type'][$i]['full_page_popup_banner'];
								$_FILES['userfile']['tmp_name'] = $_FILES['fullpopup-gallery']['tmp_name'][$i]['full_page_popup_banner'];
								$_FILES['userfile']['error']       = $_FILES['fullpopup-gallery']['error'][$i]['full_page_popup_banner'];
								$_FILES['userfile']['size']    = $_FILES['fullpopup-gallery']['size'][$i]['full_page_popup_banner'];
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,full_page_popup_banner,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						$hours_details =array();
						 if(is_array($_POST['week_days']))
						 {
			/* 				 echo "<pre>";
							 print_r($_POST['availability']);
							 echo "</pre>";
							 die; */
							foreach($_POST['week_days'] as $key => $weekdayval) {
								if(in_array($weekdayval,$_POST['availability']))
								{
								 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
								 $availability = 'open';
								 $hoursdetails['availability']= $availability; 
								 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
								 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
								}
								else
								{
								 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
								 $availability = 'close';
								 $hoursdetails['availability']= $availability; 
								 $hoursdetails['starttime']= ''; 
								 $hoursdetails['closetime']= ''; 
								}
								$hours_details[] = $hoursdetails;
								 
							}
						 }
						  /*echo "<br>";
						  echo "<br>";
						  echo "<pre>";
						  print_r($hours_details);
						  echo "</pre>"; 
						echo "<br>";
						  echo "<br>";*/
						  if(is_array($hours_details))
						  $working_hours = json_encode($hours_details);
						  else
						  $working_hours = '';
						   
						$this->vendors_model->vendor_distance_timings($working_hours,$user_id);
						
						if(isset($_POST['vendor-beacon']))
						{
						  $GroupLists = $_POST['vendor-beacon'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['beacon_vendor_name']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'vendor_id'=>$user_id,
									'beacon_vendor_name'  => $listrow['beacon_vendor_name'],
									'beacon_unique_id'  => $listrow['beacon_unique_id'],
									'remarks'  => $listrow['beacon_remarks'],
									'created_by'  => $this->session->userdata('user_id'),
									'created_on'      => date('Y-m-d H:i:s')
								);
								$beacon_vendor_id = $this->vendors_model->insertBeacon($insert_data);
								
								$insertdata = array(
									'beacon_vendor_id'=>$beacon_vendor_id,
									'action_plan_id'  => $listrow['action_plan_id'],
									'instruction_id'     => $listrow['instruction_id'],
									'sound_file_id'     => $listrow['beacon_sound_file_id'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$beacon_action_id = $this->vendors_model->insertBeaconvendors($insertdata);
								
								/* //Beacon Images 
								$_FILES['userfile']['name']  = $_FILES['vendor-beacon']['name'][$key]['beacon_media_file'];
								$_FILES['userfile']['type']    = $_FILES['vendor-beacon']['type'][$key]['beacon_media_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['vendor-beacon']['tmp_name'][$key]['beacon_media_file'];
								$_FILES['userfile']['error']   = $_FILES['vendor-beacon']['error'][$key]['beacon_media_file'];
								$_FILES['userfile']['size']  = $_FILES['vendor-beacon']['size'][$key]['beacon_media_file'];
								
								$config['upload_path'] = $this->beacon_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$updatefield =array( 
											'media_file' => $file_name
										);	
										$unique_id = array('beacon_action_id' =>$beacon_action_id);
										$resultupdate = update_table_fields('beacon_vendor_actions',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
										$data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
										$data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  */
							  }
						   }
						}
				  }
		  
				if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Vendor added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/vendors/view');
			} 
		 }
			
		$data['country_id'] = isset($_POST['country_id']) ? $_POST['country_id'] : 101;
		$data['state_id'] = isset($_POST['state_id']) ? $_POST['state_id'] : 0;
		$data['city_id'] = isset($_POST['city_id']) ? $_POST['city_id'] : 0;
		  
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
		if(!empty($_POST['location_category'])){
			foreach($_POST['location_category'] as $key=>$val){
				$category_ids[] = $val;
			}
			$categoryids =  implode(',',$category_ids);
		} else  {
			$categoryids =  '';
		}
		
		$data['category_ids'] = $categoryids;
		$data['products'] = $products;
		$data['product_categories'] =$product_categories;
		
	   $this->load->view('backoffice/vendors/add.php', $data);
	}
	
	public function edit($user_id){
		
		  $data['title'] = "Edit Vendor";
			$data['main_heading'] = "Vendors";
			$data['heading'] = "Edit Vendor";
		  $data['already_msg'] = "";
		   $product_categories=$this->vendors_model->product_category();	
		  $data['product_categories'] =$product_categories;
		  $selected_product_categories=$this->vendors_model->selected_product_category($user_id);
		  $sel_categories=array();
		  foreach($selected_product_categories as $cat){
		      $sel_categories[$cat->category_id]=$cat->category_id;
		  }
		  $data['sel_categories_product']=$sel_categories;
		  
		  $sel_products=array();
		  foreach($selected_product_categories as $cat){
		      $sel_products[$cat->product_id]=$cat->product_id;
		  }
		  
		  $data['sel_products']=$sel_products;
		  //print '<pre>';print_r($productlist);die;
		  $productlist=$this->vendors_model->all_products_listing($sel_categories);
		  
		  $data['pro_listing']=$productlist;
  		  $this->form_validation->set_rules('shop_title', 'Business Title', 'required');
		  $this->form_validation->set_rules('first_name', 'First Name', 'required|trim');
		  $this->form_validation->set_rules('last_name', 'Last Name', 'required|trim');
		  $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
		  $this->form_validation->set_rules('mobile_no1', 'Mobile Number', 'required|numeric|min_length[10]');
		   $this->form_validation->set_rules('country_id', 'Country', 'required|trim');
		  $this->form_validation->set_rules('state_id', 'State', 'required');
		  $this->form_validation->set_rules('city_id', 'City', 'required');
		  
		  //$this->form_validation->set_rules('shop_address', 'Shop Address', 'required');
		 $products =  $this->vendors_model->products();	
		 
		 $selected_product =  $this->vendors_model->selected_products($user_id);	
		  
		if ($this->form_validation->run()) {
		  // Update records 
		  $email_feild = array('email' =>trim($this->input->post('email')),'user_type'=>'V');
		  $unique_id = array('user_id' =>$user_id);
		  $email_result = check_unique_edit('users',$email_feild,$unique_id);
		  
		  $mobile_feild = array('mobile_no1' =>trim($this->input->post('mobile_no1')),'user_type'=>'V');
		  $unique_id = array('user_id' =>$user_id);
		  $mobile_result = check_unique_edit('users',$mobile_feild,$unique_id);
		  if($email_result==1)
		  {
			$already_msg_text   = "Email already exists";
			$data['already_msg']= $already_msg_text;
		  }
		  elseif($mobile_result==1)
		  {
			$already_msg_text   = "Mobile number already exists";
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
			  $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
			  foreach($_POST['week_days'] as $key => $weekdayval) {
			  if(in_array($weekdayval,$_POST['availability']))
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			  }
			 }
		
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
		  
		  
		        $vendor_id =  $this->vendors_model->update_user($this->input->post('user_id'),$this->input->post('user_address_id'),$working_hours);
		        if($_FILES['user_photo']['error'] != 4){		
				  $config['upload_path'] = $this->original_path;
				  $config['allowed_types'] = 'jpeg|gif|jpg|png';
				  $config['max_size']	= '20000000000';
				  $config['max_width']  = '0';
				  $config['max_height']  = '0';
				  $config['overwrite'] = true;			
				  $config['file_name'] =$user_id.'-'.$_FILES['user_photo']['name'];
				  $this->upload->initialize($config);
				
				if ( ! $this->upload->do_upload('user_photo')){
					
					$data['already_msg']=$this->upload->display_errors();
					$success = FALSE;
				} else {  
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$original_path = $data['full_path'];
					$image_thumb  =$this->resized_path.'/'.$file_name;
					
					$config1['image_library']    = 'gd2';
					$config1['source_image']     = $original_path;
					$config1['new_image']        = $image_thumb;
					$config1['maintain_ratio']   = TRUE;
					$config1['height']              = 150;
					$config1['width']              = 150;
					$this->image_lib->initialize( $config1);
					$this->image_lib->resize();
					$this->image_lib->clear();									
					$result_photo = $this->vendors_model->update_photo($user_id,$file_name);
				}
			 }
		
			   if($vendor_id!=0){
					
						//Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,video_files,$file_name);
							  } 
					
						   }
						}
						
						//Digital Header Banner Files
					    $totalheadergalleryfiles= count($_FILES['header-gallery']['name']);
						
						for($i=0;$i<$totalheadergalleryfiles;$i++){
							if($_FILES['header-gallery']['name'][$i]['header_banner']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['header-gallery']['name'][$i]['header_banner'];
								$_FILES['userfile']['type']    = $_FILES['header-gallery']['type'][$i]['header_banner'];
								$_FILES['userfile']['tmp_name'] = $_FILES['header-gallery']['tmp_name'][$i]['header_banner'];
								$_FILES['userfile']['error']       = $_FILES['header-gallery']['error'][$i]['header_banner'];
								$_FILES['userfile']['size']    = $_FILES['header-gallery']['size'][$i]['header_banner'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,header_banner,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						 //Digital Footer Banner Files
					    $totalfootergalleryfiles= count($_FILES['footer-gallery']['name']);
						
						for($i=0;$i<$totalfootergalleryfiles;$i++){
							if($_FILES['footer-gallery']['name'][$i]['footer_banner']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['footer-gallery']['name'][$i]['footer_banner'];
								$_FILES['userfile']['type']    = $_FILES['footer-gallery']['type'][$i]['footer_banner'];
								$_FILES['userfile']['tmp_name'] = $_FILES['footer-gallery']['tmp_name'][$i]['footer_banner'];
								$_FILES['userfile']['error']       = $_FILES['footer-gallery']['error'][$i]['footer_banner'];
								$_FILES['userfile']['size']    = $_FILES['footer-gallery']['size'][$i]['footer_banner'];
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,footer_banner,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//Digital Popup Banner Files
					    $totalpopupgalleryfiles= count($_FILES['popup-gallery']['name']);
						
						for($i=0;$i<$totalpopupgalleryfiles;$i++){
							if($_FILES['popup-gallery']['name'][$i]['popup_banner']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['popup-gallery']['name'][$i]['popup_banner'];
								$_FILES['userfile']['type']    = $_FILES['popup-gallery']['type'][$i]['popup_banner'];
								$_FILES['userfile']['tmp_name'] = $_FILES['popup-gallery']['tmp_name'][$i]['popup_banner'];
								$_FILES['userfile']['error']       = $_FILES['popup-gallery']['error'][$i]['popup_banner'];
								$_FILES['userfile']['size']    = $_FILES['popup-gallery']['size'][$i]['popup_banner'];
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,popup_banner,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 //Digital FullPopup Banner Files
					    $totalfullpopupgalleryfiles= count($_FILES['fullpopup-gallery']['name']);
						
						for($i=0;$i<$totalfullpopupgalleryfiles;$i++){
							if($_FILES['fullpopup-gallery']['name'][$i]['full_page_popup_banner']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['fullpopup-gallery']['name'][$i]['full_page_popup_banner'];
								$_FILES['userfile']['type']    = $_FILES['fullpopup-gallery']['type'][$i]['full_page_popup_banner'];
								$_FILES['userfile']['tmp_name'] = $_FILES['fullpopup-gallery']['tmp_name'][$i]['full_page_popup_banner'];
								$_FILES['userfile']['error']       = $_FILES['fullpopup-gallery']['error'][$i]['full_page_popup_banner'];
								$_FILES['userfile']['size']    = $_FILES['fullpopup-gallery']['size'][$i]['full_page_popup_banner'];
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->vendors_model->insertDigitalMedia($user_id,full_page_popup_banner,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						
						$hours_details =array();
						 if(is_array($_POST['week_days']))
						 {
			/* 				 echo "<pre>";
							 print_r($_POST['availability']);
							 echo "</pre>";
							 die; */
							foreach($_POST['week_days'] as $key => $weekdayval) {
								if(in_array($weekdayval,$_POST['availability']))
								{
								 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
								 $availability = 'open';
								 $hoursdetails['availability']= $availability; 
								 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
								 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
								}
								else
								{
								 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
								 $availability = 'close';
								 $hoursdetails['availability']= $availability; 
								 $hoursdetails['starttime']= ''; 
								 $hoursdetails['closetime']= ''; 
								}
								$hours_details[] = $hoursdetails;
								 
							}
						 }
						  /*echo "<br>";
						  echo "<br>";
						  echo "<pre>";
						  print_r($hours_details);
						  echo "</pre>"; 
						echo "<br>";
						  echo "<br>";*/
						  if(is_array($hours_details))
						  $working_hours = json_encode($hours_details);
						  else
						  $working_hours = '';
						   
						$this->vendors_model->vendor_distance_timings($working_hours,$user_id);
						
						if(isset($_POST['vendor-beacon']))
						{
						  $GroupLists = $_POST['vendor-beacon'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['beacon_vendor_name']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'vendor_id'=>$user_id,
									'beacon_vendor_name'  => $listrow['beacon_vendor_name'],
									'beacon_unique_id'  => $listrow['beacon_unique_id'],
									'remarks'  => $listrow['beacon_remarks'],
									'created_by'  => $this->session->userdata('user_id'),
									'created_on'      => date('Y-m-d H:i:s')
								);
								$beacon_vendor_id = $this->vendors_model->insertBeacon($insert_data);
								
								$insertdata = array(
									'beacon_vendor_id'=>$beacon_vendor_id,
									'action_plan_id'  => $listrow['action_plan_id'],
									'instruction_id'     => $listrow['instruction_id'],
									'sound_file_id'     => $listrow['beacon_sound_file_id'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$beacon_action_id = $this->vendors_model->insertBeaconvendors($insertdata);
								
								/* //Beacon Images 
								$_FILES['userfile']['name']  = $_FILES['vendor-beacon']['name'][$key]['beacon_media_file'];
								$_FILES['userfile']['type']    = $_FILES['vendor-beacon']['type'][$key]['beacon_media_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['vendor-beacon']['tmp_name'][$key]['beacon_media_file'];
								$_FILES['userfile']['error']   = $_FILES['vendor-beacon']['error'][$key]['beacon_media_file'];
								$_FILES['userfile']['size']  = $_FILES['vendor-beacon']['size'][$key]['beacon_media_file'];
								
								$config['upload_path'] = $this->beacon_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$updatefield =array( 
											'media_file' => $file_name
										);	
										$unique_id = array('beacon_action_id' =>$beacon_action_id);
										$resultupdate = update_table_fields('beacon_vendor_actions',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
										$data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
										$data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  */
							  }
						   }
						}
				  }
		      if($vendor_id=='1')
				{   
				   $msg = "Profile updated successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  "There is some error , please try again";
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/vendors/view/".$this->input->post('user_id'));
		  }
		}		
		  $result =  $this->vendors_model->user_edit($user_id);
		  $data['edit_data'] = $result;
		  
		  $fields = array('vendor_id'=>$result->user_id,'is_active'=>'1');
		  $catrow = gettableinfo('vendor_categories',$fields);
		  
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  
			$catresult = gettableresult('vendor_categories',$fields,'category_id');
			if(is_array($catresult))
			{
				$category_ids=array();
				foreach($catresult as $ckey => $catval) {
				  $category_ids[] = $catval->category_id;	
				}
			  $categoryids =  implode(',',$category_ids);
			  //echo "---------------->".$category_ids;
			  //$categoryids =  "'".$categoryids."'";
			 //echo "---------------->".$categoryids;
			}else
			{
				$categoryids =  '';
			}
			
			//print_r($category_ids);					
		  $data['category_ids'] = $categoryids;
		  
		  
		  $data['country_id'] = isset($result->country_id) ? $result->country_id : 0;
		  $data['state_id'] = isset($result->state_id) ? $result->state_id : 0;
		  $data['city_id'] = isset($result->city_id) ? $result->city_id : 0;
		  $data['products'] = $products;
		  foreach($selected_product as $row){
		      $prarray[$row->product_id]=$row->product_id;
		  }
		   
		  $data['selected_products'] = $prarray;
		  $this->load->view('backoffice/vendors/edit.php', $data);
		 
	}//end of Edit functionality*/

	public function deletebeacon($beacon_vendor_id)
	{	
	     $result = $this->vendors_model->deleteLocBeacon($beacon_vendor_id);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function deletedigitalmedia($vendor_media_id)
	{	 
		
	     $result = $this->vendors_model->deleteDigitalMedia($vendor_media_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function status($user_id,$status)
	{	 // Update status  
	     $result = $this->vendors_model->update_status($user_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/vendors/view");		
		 
	}//end of Status  functionality*/ 
	
	
}	
?>