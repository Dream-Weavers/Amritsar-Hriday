<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Regusers extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/regusers_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->original_path = realpath('assets/static/reguser/original');
	   	$this->resized_path = realpath('assets/static/reguser/resized');
	}
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_users_title')."";
	    $data['main_heading'] = $this->lang->line('users_title');
	    $data['heading'] = $this->lang->line('view_users_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('user_id'))
			 $user_id = $this->input->post('user_id');
		 elseif($this->uri->segment('4'))
			 $user_id=$this->uri->segment('4');
		else
			 $user_id='0';
	
			
		if($this->input->post('search_value'))
			$search_value = trim($this->input->post('search_value'));
		elseif($this->uri->segment('5'))
			$search_value=trim($this->uri->segment('5'));
		else
			$search_value='0';
		
		
		/* if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('6'))
			 $status=$this->uri->segment('6');
		else
			 $status='0';	 */ 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/regusers/view/".$search_value."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->regusers_model->count_users($search_value,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->regusers_model->view_users($search_value,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['designation_id'] = $designation_id;
		$data['role_id'] = $role_id;
		$data['status'] = $status;
		$data['search_by'] = $search_by;	
		$data['search_value'] = $search_value;	
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/regusers/view.php', $data);
	}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_user_title')."";
		  $data['main_heading'] = $this->lang->line('users_title');
		  $data['heading'] = $this->lang->line('add_user_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('first_name', ''.$this->lang->line('user_first_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('last_name', ''.$this->lang->line('user_last_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('email', ''.$this->lang->line('user_primary_email_text').'', 'required|trim|valid_email');
		  $this->form_validation->set_rules('mobile_no1', ''.$this->lang->line('user_primary_mobile_text').'', 'required|numeric|min_length[10]');
		  $this->form_validation->set_rules('userpass', ''.$this->lang->line('user_password_text').'', 'required|trim|min_length[3]|matches[compass]');
		  $this->form_validation->set_rules('compass', ''.$this->lang->line('user_confirm_password_text').'', 'required|trim');
		 
		  $this->form_validation->set_rules('country_id', ''.$this->lang->line('user_country_text').'', 'required|trim');
		  $this->form_validation->set_rules('state_id', ''.$this->lang->line('user_state_text').'', 'required');
		  $this->form_validation->set_rules('city_id', ''.$this->lang->line('user_city_text').'', 'required');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('user_pin_code_text').'', 'trim|numeric|min_length[4]');
		  
		  $this->form_validation->set_rules('gender', ''.$this->lang->line('user_gender_text').'', 'required|trim');
		 
		  
		 if ($this->form_validation->run()) {
		  $emailfeilds = array('email' =>trim($this->input->post('email')),'user_type'=>'U');
		  $emailresult = check_unique('users',$emailfeilds);
		  
		  $mobilefeilds = array('mobile_no1' =>trim($this->input->post('mobile_no1')),'user_type'=>'U');
		  $mobileresult = check_unique('users',$mobilefeilds);
		  
		  if($emailresult==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('email'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  elseif($mobileresult==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('mobile_no1'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {
		          $user_id =  $this->regusers_model->add();				 
				  if($_FILES['user_photo']['error'] != 4){		
					  $config['upload_path'] = $this->original_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= max_file_size;
					  $config['max_width']  = '0';
					  $config['max_height']  = '0';
					  $config['overwrite'] = true;			
					  $config['file_name'] =$user_id.'-'.$_FILES['user_photo']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('user_photo')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			      else{
					 $data = $this->upload->data();
					 $file_name = $data['file_name'];
					 $original_path = $data['full_path'];
					 $image_thumb  =$this->resized_path.'/'.$file_name;
					 $config1['image_library']    = 'gd2';
					 $config1['source_image']     = $original_path;
					 $config1['new_image']        = $image_thumb;
					 $config1['maintain_ratio']   = TRUE;
					 $config1['height']              = 150;
					 $config1['width']              = 150;
					 $this->image_lib->initialize( $config1);
					 $this->image_lib->resize();
					 $this->image_lib->clear();									
					 $result_photo = $this->regusers_model->update_photo($user_id,$file_name);
			     }
		       }
			   if($user_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/regusers/view');
 		  }
	    } //end of add  functionality
			
		$data['country_id'] = isset($_POST['country_id']) ? $_POST['country_id'] : 101;
		$data['state_id'] = isset($_POST['state_id']) ? $_POST['state_id'] : 0;
		$data['city_id'] = isset($_POST['city_id']) ? $_POST['city_id'] : 0;
		  
	   $this->load->view('backoffice/regusers/add.php', $data);
	}
	
	public function edit($user_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_user_title')."";
		  $data['main_heading'] = $this->lang->line('users_title');
		  $data['heading'] = $this->lang->line('edit_user_title');
		  $data['already_msg'] = "";
		  
  		  $this->form_validation->set_rules('first_name', ''.$this->lang->line('user_first_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('last_name', ''.$this->lang->line('user_last_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('email', ''.$this->lang->line('user_primary_email_text').'', 'required|trim|valid_email');
		  $this->form_validation->set_rules('mobile_no1', ''.$this->lang->line('user_primary_mobile_text').'', 'required|numeric|min_length[10]');
		   $this->form_validation->set_rules('country_id', ''.$this->lang->line('user_country_text').'', 'required|trim');
		  $this->form_validation->set_rules('state_id', ''.$this->lang->line('user_state_text').'', 'required');
		  $this->form_validation->set_rules('city_id', ''.$this->lang->line('user_city_text').'', 'required');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('user_pin_code_text').'', 'trim|numeric|min_length[4]');
		  $this->form_validation->set_rules('gender', ''.$this->lang->line('user_gender_text').'', 'required|trim');
		 
		  
		if ($this->form_validation->run()) {
		  // Update records 
		  $email_feild = array('email' =>trim($this->input->post('email')),'user_type'=>'U');
		  $unique_id = array('user_id' =>$user_id);
		  $email_result = check_unique_edit('users',$email_feild,$unique_id);
		  
		  $mobile_feild = array('mobile_no1' =>trim($this->input->post('mobile_no1')),'user_type'=>'U');
		  $unique_id = array('user_id' =>$user_id);
		  $mobile_result = check_unique_edit('users',$mobile_feild,$unique_id);
		  if($email_result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('email'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  elseif($mobile_result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('mobile_no1'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		        $result =  $this->regusers_model->update_user($this->input->post('user_id'),$this->input->post('user_address_id'));
		        if($_FILES['user_photo']['error'] != 4){		
				  $config['upload_path'] = $this->original_path;
				  $config['allowed_types'] = 'jpeg|gif|jpg|png';
				  $config['max_size']	= '20000000000';
				  $config['max_width']  = '0';
				  $config['max_height']  = '0';
				  $config['overwrite'] = true;			
				  $config['file_name'] =$user_id.'-'.$_FILES['user_photo']['name'];
				  $this->upload->initialize($config);
				
				if ( ! $this->upload->do_upload('user_photo')){
					
					echo $data['already_msg']=$this->upload->display_errors();die;
					$success = FALSE;
				} else {  
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$original_path = $data['full_path'];
					$image_thumb  =$this->resized_path.'/'.$file_name;
					
					$config1['image_library']    = 'gd2';
					$config1['source_image']     = $original_path;
					$config1['new_image']        = $image_thumb;
					$config1['maintain_ratio']   = TRUE;
					$config1['height']              = 150;
					$config1['width']              = 150;
					$this->image_lib->initialize( $config1);
					$this->image_lib->resize();
					$this->image_lib->clear();									
					$result_photo = $this->regusers_model->update_photo($user_id,$file_name);
				}
			 }
		      if($result=='1')
				{   
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/regusers/view/".$this->input->post('user_id'));
		  }
		}		
		  $result =  $this->regusers_model->user_edit($user_id);
		  $data['edit_data'] = $result;
		  $data['country_id'] = isset($result->country_id) ? $result->country_id : 0;
		  $data['state_id'] = isset($result->state_id) ? $result->state_id : 0;
		  $data['city_id'] = isset($result->city_id) ? $result->city_id : 0;
		  
		  $this->load->view('backoffice/regusers/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	public function userroutes(){
	    $data['title'] = "Route Activities";
		$data['heading'] = "Route Activities";
		$data['already_msg']=""; 
		
		
		$getroute = $this->regusers_model->getroutes();
		
		$data['results']=json_decode($getroute->lat_lng_data);
		/* echo "<pre>";
		print_r($data['results']);
		die; */

	    $this->load->view('backoffice/regusers/routemap',$data);	
	}
	
	public function status($user_id,$status)
	{	 // Update status  
	     $result = $this->regusers_model->update_status($user_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/regusers/view");		
		 
	}//end of Status  functionality*/
	
	
}	
?>