<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Soundfiles extends CI_Controller {
public function __construct()
	{
		parent:: __construct();	
		validateAccess();
		$this->load->model('backoffice/Soundfiles_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		//$this->icon_path = realpath('images/sound_file-icons/');
		$this->soundfile_path = realpath('assets/static/locations/soundfiles');
	}

	public function index()
	{
		$data=array();
		$data['title'] = $this->lang->line('sound_files_title');
		$data['main_heading'] =$this->lang->line('sound_files_title');
		$data['heading'] = $this->lang->line('sound_files_title');
		$data['already_msg']=""; 
		$data['search_keyword'] = $this->input->post("search_keyword");	 
		$results = $this->Soundfiles_model->view_soundfiles();
	
		$data['country_id'] = 0; 
		$data['state_id'] = 0;
		$data['city_id'] = 0;
		$data['locality_id'] = 0;
		  
	
		  $this->form_validation->set_rules('soundfile_name', 'Sound file Name', 'required|trim');
	      if ($this->form_validation->run()) {
		
		   $soundfile_id =  $this->Soundfiles_model->add();
	
		   if($_FILES['sound_file']['error'] != 4){		
				  $config['upload_path'] = $this->soundfile_path;
				  $config['allowed_types'] = audo_file_extensions;
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$soundfile_id.'_'.$_FILES['sound_file']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				  if ( ! $this->upload->do_upload('sound_file')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
				  } else {
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'file_name' => $file_name
					);	
					$unique_id = array('sound_file_id' =>$soundfile_id);
					 update_table_fields('sound_files',$updatefield,$unique_id);
				 }
			}
			
			if($soundfile_id!='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
			} else {
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
			}
		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/soundfiles');  
	    } //end of add  functionality
		
 		$data['results'] = $results;

		//$num_rows = count($results);	
		//$data['num_rows'] = $num_rows; 
		

		$data['header'] = '';
		$data['title']=$this->lang->line('sound_files_title');
		$data['short_desc']=$this->lang->line('show_all_sound_files_title');
		$this->load->view('backoffice/soundfiles/view',$data);
		
    } //end of view functionality
	
	public function add()
	{
		   $data['title'] = $this->lang->line('add_sound_file_title');
		  $data['main_heading'] =$this->lang->line('sound_files_title');
		  $data['heading'] = $this->lang->line('add_sound_file_title');
		  $data['already_msg']="";
		  
	
		  $this->form_validation->set_rules('soundfile_name', 'Sound file Name', 'required|trim');
		  if ($this->form_validation->run()) {
		
		   $soundfile_id =  $this->Soundfiles_model->add();

		   if($_FILES['sound_file']['error'] != 4){		
				  $config['upload_path'] = $this->soundfile_path;
				  $config['allowed_types'] = audo_file_extensions;
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$soundfile_id.'_'.$_FILES['sound_file']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				  if ( ! $this->upload->do_upload('sound_file')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
				  } else {
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'file_name' => $file_name
					);	
					$unique_id = array('sound_file_id' =>$soundfile_id);
					 update_table_fields('sound_files',$updatefield,$unique_id);
				 }
			}
				
				
			if($soundfile_id!='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
			} else {
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
			}
		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/soundfiles/add');  
		  
			
			
	    } //end of add  functionality

		$data['header'] = '';
		$data['title']=$this->lang->line('sound_files_title');
		$data['short_desc']=$this->lang->line('sound_files_title');
		$this->load->view('backoffice/soundfiles/add',$data); 
	}

	
	public function edit($soundfile_id){
		
		  $data['title'] = $this->lang->line('edit_sound_file_title');
		  $data['main_heading'] =$this->lang->line('sound_files_title');
		  $data['heading'] = $this->lang->line('edit_sound_file_title');
          $data['already_msg']="";
		  

		  
		  $results = $this->Soundfiles_model->fetchsoundfile($soundfile_id);
		  $data['edit_data'] = $results;
			
		  $this->form_validation->set_rules('soundfile_name', 'Sound file Name', 'required|trim');
		  if ($this->form_validation->run()) {
			  // Update records 
	  
			  
			   $result =  $this->Soundfiles_model->update_soundfile($soundfile_id);
			   
			   if($_FILES['sound_file']['error'] != 4){		
				  $config['upload_path'] = $this->soundfile_path;
				  $config['allowed_types'] = audo_file_extensions;
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$soundfile_id.'_'.$_FILES['sound_file']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				  if ( ! $this->upload->do_upload('sound_file')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
				  } else {
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'file_name' => $file_name
					);	
					$unique_id = array('sound_file_id' =>$soundfile_id);
					 update_table_fields('sound_files',$updatefield,$unique_id);
				 }
			}
			
				if($result=='1') {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/soundfiles");
			  
		  }
		  
		$data['header'] = '';
		$data['title']=$this->lang->line('edit_sound_file_title');
		$data['short_desc']=$this->lang->line('edit_sound_file_title');
		$this->load->view('backoffice/soundfiles/edit',$data);
		 
	}//end of Edit functionality*/
}	
?>