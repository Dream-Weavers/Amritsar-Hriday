<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Products extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/products_model');
		$this->load->helper("file");
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->original_path = realpath('assets/products/original');
	   	$this->resized_path = realpath('assets/products/resized');
		$this->gallery_path = realpath('assets/products/gallery');
		//$this->beacon_path = realpath('assets/vendors/beacons');
	} 
	

	
	public function add()
	{
        $data=array();
        $data['title'] = "Add Product";
        $data['main_heading'] = "Products";
        $data['heading'] = "Add Product";
        $data['already_msg'] = "";
		$this->form_validation->set_rules('product_name', 'Product name', 'required');
		//$this->form_validation->set_rules('vendor_id', 'Vendor', 'required|trim');
		$this->form_validation->set_rules('product_desc', 'Product description', 'required|trim');  
		$this->form_validation->set_rules('location_category[]', 'Product category', 'required|trim');  
		 
		 
		//$vendorlist=$this->products_model->vendors_list(); 
		
		 
		if ($this->form_validation->run()) {
		
		    $user_id =  $this->products_model->add();
		    
		    
		    
		    //Digital Gallery Files
		    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
			
			for($i=0;$i<$totalgalleryfiles;$i++){
				if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
				
					$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
					$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
					$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
					$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
					$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
					
					
					$config['upload_path'] = $this->gallery_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
					$config['file_name'] =$file_name;	 
					if($_FILES['userfile']['error']!='4'){
						  /*if($_FILES['userfile']['name']!=''){
							$mediaresult = $this->products_model->insertDigitalMedia($user_id,gallery_files,$file_name);
						  }*/
						  $this->upload->initialize($config);
						  $this->upload->do_upload('userfile');
						  if ($this->upload->do_upload('userfile'))
						  {
						   $data['uploads'][$i] = $this->upload->data();
						   $file_name= $data['uploads'][$i]['file_name'];
						   	$mediaresult = $this->products_model->insertDigitalMedia($user_id,gallery_files,$file_name,1);
						  }
						  else
						  {
						   $data['upload_errors'][$i] = $this->upload->display_errors();
						  } 
					}  
				}
			 }
			 unset($_FILES['userfile']);
			 	//Digital Media Video 
			 $totalgalleryfiles= count($_FILES['digital-video']['name']);
			
			for($i=0;$i<$totalgalleryfiles;$i++){
				if($_FILES['digital-video']['name'][$i]['gallery_videos']!=''){	
				
					$_FILES['userfile']['name']=$_FILES['digital-video']['name'][$i]['gallery_videos'];
					$_FILES['userfile']['type']    = $_FILES['digital-video']['type'][$i]['gallery_videos'];
					$_FILES['userfile']['tmp_name'] = $_FILES['digital-video']['tmp_name'][$i]['gallery_videos'];
					$_FILES['userfile']['error']       = $_FILES['digital-video']['error'][$i]['gallery_videos'];
					$_FILES['userfile']['size']    = $_FILES['digital-video']['size'][$i]['gallery_videos'];
					
					
					$config['upload_path'] = $this->gallery_path;
					$config['allowed_types'] = 'wmv|mp4|avi|mov';
					$config['max_size']	= '102400';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					//$configVideo['overwrite'] = FALSE;
                    $configVideo['remove_spaces'] = TRUE;
					$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
					$config['file_name'] =$file_name;	 
					if($_FILES['userfile']['error']!='4'){
						  /*if($_FILES['userfile']['name']!=''){
							$mediaresult = $this->products_model->insertDigitalMedia($user_id,1,$file_name);
						  }*/
						  $this->upload->initialize($config);
						  $this->upload->do_upload('userfile');
						  if ($this->upload->do_upload('userfile'))
						  {
						   $data['uploads'][$i] = $this->upload->data();
						  $file_name= $data['uploads'][$i]['file_name'];
						   	$mediaresult = $this->products_model->insertDigitalMedia($user_id,1,$file_name,1);
						  }
						  else
						  {
						   $data['upload_errors'][$i] = $this->upload->display_errors();
						  } 
					}  
				}
			 }
						 
						 
			//Digital Media Video 
			/*if(isset($_POST['digital-video']))
			{
			  $GroupLists = $_POST['digital-video'];
			  foreach($GroupLists as $key=> $listrow){
				
				  if($listrow['video_url']!='') 
				  {
					$file_name = $listrow['video_url'];
					$mediaresult = $this->products_model->insertDigitalMedia($user_id,video_files,$file_name);
				  } 
		
			   }
			}*/
			
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Product added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/products/view');
		    
		    
		}
		
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
	
		
		$data['category_ids'] = $categoryids;
		
	//	$data['vendor_list']=$vendorlist;
	   $this->load->view('backoffice/product/add.php', $data);
	}
	
	public function edit($product_id)
	{
        $data=array();
        //delete_files("./assets/products/gallery/1606127358_36_image-not-available.jpg"); 
        //unlink('public_html/codeigniter/hriday/assets/products/gallery/1606127358_36_image-not-available.jpg');
        
        $data['title'] = "Edit Product";
        $data['main_heading'] = "Products";
        $data['heading'] = "Edit Product";
        $data['already_msg'] = "";
		$this->form_validation->set_rules('product_name', 'Product name', 'required');
	//	$this->form_validation->set_rules('vendor_id', 'Vendor', 'required|trim');
		$this->form_validation->set_rules('product_desc', 'Product description', 'required|trim');  
		$this->form_validation->set_rules('location_category[]', 'Product category', 'required|trim');  
		$get_product_join=$this->products_model->get_product_info($product_id);
		$data['product_info']=$get_product_join;
		 //print '<pre>';print_r($get_product_join);die;
		 
		$get_images =  $this->products_model->media_info($product_id,2,1);
		$data['media_images']=$get_images;
		
		$get_videos =  $this->products_model->media_info($product_id,1,1);
		$data['media_videos']=$get_videos;
		 
		//$vendorlist=$this->products_model->vendors_list(); 
		if ($this->form_validation->run()) {
		
		     $this->products_model->updateproduct($product_id,1);
		    //Digital Gallery Files
		    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
			
			for($i=0;$i<$totalgalleryfiles;$i++){
				if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
				
					$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
					$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
					$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
					$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
					$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
					
					
					$config['upload_path'] = $this->gallery_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					$file_name = time().'_'.$product_id.'_'.$_FILES['userfile']['name'];	
					$config['file_name'] =$file_name;	
					if($_FILES['userfile']['error']!='4'){
						  /*if($_FILES['userfile']['name']!=''){
							$mediaresult = $this->products_model->insertDigitalMedia($product_id,gallery_files,$file_name,1);
						  }*/
						  $this->upload->initialize($config);
						  $this->upload->do_upload('userfile');
						  if ($this->upload->do_upload('userfile'))
						  {
						   $data['uploads'][$i] = $this->upload->data();
						    $file_name= $data['uploads'][$i]['file_name'];
						   $mediaresult = $this->products_model->insertDigitalMedia($product_id,gallery_files,$file_name,1);
						  }
						  else
						  {
						   $data['upload_errors'][$i] = $this->upload->display_errors();
						  } 
					}  
				}
			 }
						 
			unset($_FILES['userfile']);
			 	//Digital Media Video 
			 $totalgalleryfiles= count($_FILES['digital-video']['name']);
			
			for($i=0;$i<$totalgalleryfiles;$i++){
				if($_FILES['digital-video']['name'][$i]['gallery_videos']!=''){	
				
					$_FILES['userfile']['name']=$_FILES['digital-video']['name'][$i]['gallery_videos'];
					$_FILES['userfile']['type']    = $_FILES['digital-video']['type'][$i]['gallery_videos'];
					$_FILES['userfile']['tmp_name'] = $_FILES['digital-video']['tmp_name'][$i]['gallery_videos'];
					$_FILES['userfile']['error']       = $_FILES['digital-video']['error'][$i]['gallery_videos'];
					$_FILES['userfile']['size']    = $_FILES['digital-video']['size'][$i]['gallery_videos'];
					
					
					$config['upload_path'] = $this->gallery_path;
					$config['allowed_types'] = 'wmv|mp4|avi|mov';
					$config['max_size']	= '102400';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					//$configVideo['overwrite'] = FALSE;
                    $configVideo['remove_spaces'] = TRUE;
					$file_name = time().'_'.$product_id.'_'.$_FILES['userfile']['name'];	
					$config['file_name'] =$file_name;	 
					if($_FILES['userfile']['error']!='4'){
						  /*if($_FILES['userfile']['name']!=''){
							$mediaresult = $this->products_model->insertDigitalMedia($user_id,1,$file_name);
						  }*/
						  $this->upload->initialize($config);
						  $this->upload->do_upload('userfile');
						  if ($this->upload->do_upload('userfile'))
						  {
						   $data['uploads'][$i] = $this->upload->data();
						  $file_name= $data['uploads'][$i]['file_name'];
						   	$mediaresult = $this->products_model->insertDigitalMedia($product_id,1,$file_name,1);
						  }
						  else
						  {
						   $data['upload_errors'][$i] = $this->upload->display_errors();
						  } 
					}  
				}
			 }			 
			//Digital Media Video 
			/*if(isset($_POST['digital-video']))
			{
			  $GroupLists = $_POST['digital-video'];
			  foreach($GroupLists as $key=> $listrow){
				
				  if($listrow['video_url']!='') 
				  {
					$file_name = $listrow['video_url'];
					$mediaresult = $this->products_model->insertDigitalMedia($product_id,video_files,$file_name);
				  } 
		
			   }
			}*/
			
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Product added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/products/view');
		    
		    
		}
		
			
		 
		$fields = array('product_id'=>$product_id);
		$prdcatrow = gettableinfo('product_categories',$fields);
		
		$fields = array('category_id'=>$prdcatrow->category_id);
		$catrow = gettableinfo('categories',$fields);
		$data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		
		$category_ids=array();
	    $data['product_id']=$product_id;
		$categoryids=$this->products_model->get_categorylist($product_id);
		//print '<pre>';print_r($categoryids);die;
		foreach($categoryids as $val){
		    $category_ids[$val->category_id]=$val->category_id;
		}
	    //print '<pre>';print_r($category_ids);die; 
		$data['category_ids'] = implode(",",$category_ids);
		
	//	$data['vendor_list']=$vendorlist;
	   $this->load->view('backoffice/product/edit.php', $data);
	}
	
	public function view(){	
		$data=array();
		$data['title'] = "View Products";
	    $data['main_heading'] = "Products";
	    $data['heading'] = "View Products";
		
	   //print_r($_POST);	
	    if($this->input->post('user_id'))
			 $user_id = $this->input->post('user_id');
		 elseif($this->uri->segment('4'))
			 $user_id=$this->uri->segment('4');
		else
			 $user_id='0';
	
			
		if($this->input->post('search_value'))
			$search_value = trim($this->input->post('search_value'));
		elseif($this->uri->segment('5'))
			$search_value=trim($this->uri->segment('5'));
		else
			$search_value='0';
		
		
		/* if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('6'))
			 $status=$this->uri->segment('6');
		else
			 $status='0';	 */ 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
		//$lang=$this->session->userdata('lang_id');
		$config = array();
		$config["base_url"] = base_url() . "backoffice/products/view/".$search_value."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->products_model->count_products($search_value,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->products_model->view_products($search_value,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['status'] = $status;
		$data['search_by'] = $search_by;	
		$data['search_value'] = $search_value;	
		$data['per_page'] = $per_page;
		$lang=$this->session->userdata('lang_id');
		$languageinfo=$this->products_model->language_info($lang);
		$data['cur_lang']=$lang;
		$data['lang_data']=$languageinfo;
	    $this->load->view('backoffice/product/view.php', $data);
	}
	
	public function translate_add($language_id,$product_id){
	    $get_product_join=$this->products_model->get_product_info($product_id);
		$data['product_info']=$get_product_join;
	    $data=array();
	    $languageinfo=get_language($language_id);
        $data['title'] = "Add Product | ".$get_product_join->product_name.' - ('.$languageinfo->language_name.')';
        $data['main_heading'] = "Products";
        $data['heading'] = "Add Product | ".$get_product_join->product_name.' - ('.$languageinfo->language_name.')';
        $data['already_msg'] = "";
        $data['langid']=$language_id;
        $data['productid']=$product_id;
		$this->form_validation->set_rules('product_name', 'Product name', 'required');
		$this->form_validation->set_rules('product_price', 'Product price', 'required|trim');
		$this->form_validation->set_rules('product_desc', 'Product description', 'required|trim');  
		//$this->form_validation->set_rules('location_category[]', 'Product category', 'required|trim');  
		$vendorlist=$this->products_model->vendors_list(); 
		$data['media_images']='';
		$copy_media=$this->input->post('media_type');
		$get_images =  $this->products_model->media_info($product_id,2,1);
		$data['media_images']=$get_images;
		$data['media_videos']='';
		$get_videos =  $this->products_model->media_info($product_id,1,1);
		    // print '<pre>';print_r($get_images);die;
		 $data['media_videos']=$get_videos;
		
		/*if($copy_media!=''){
		    //print $copy_media;die;
		     $get_images =  $this->products_model->media_info($product_id,2);
		     //print '<pre>';print_r($get_images);die;
		     $data['media_images']=$get_images;
		}*/
		if ($this->form_validation->run()) {
		    //print '<pre>';print_r($_POST);die;
		    $user_id =  $this->products_model->add_translate($language_id,$product_id);
		    
		    
		    if($copy_media==1){
		    
    		   //Old Digital images Files
    		   $old_digital_image_files=$this->input->post('old-digital-image');
    		   
    		   if(isset($old_digital_image_files) &&  !empty($old_digital_image_files)){
    			   foreach($old_digital_image_files as $key=>$filename){
    				   
    				   $this->products_model->insertOldDigitalMedia($product_id,$user_id, $filename['gallery_images'],$this->gallery_path,$language_id);
    				   
    			   }
    			   
    		   }
    		   
    		   
    		   $old_digital_video_files=$this->input->post('old-digital-video');
    		   
    		   if(isset($old_digital_video_files) &&  !empty($old_digital_video_files)){
    			   foreach($old_digital_video_files as $key=>$filename){
    				   
    				   $this->products_model->insertOldDigitalMedia($product_id,$user_id, $filename['gallery_videos'],$this->gallery_path,$language_id);
    				   
    			   }
    			   
    		   }
		    }
		    //Digital Gallery Files
		    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
		    //print '<pre>';print_r($_FILES);die;
			//print $totalgalleryfiles;die;
			for($i=0;$i<$totalgalleryfiles;$i++){
				if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
				
					$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
					$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
					$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
					$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
					$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
					
					
					$config['upload_path'] = $this->gallery_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					$file_name = time().'_'.$user_id.'_'.$_FILES['userfile']['name'];	
					$config['file_name'] =$file_name;	
					if($_FILES['userfile']['error']!='4'){
						  /*if($_FILES['userfile']['name']!=''){
							$mediaresult = $this->products_model->insertDigitalMedia($user_id,gallery_files,$file_name);
						  }*/
						  $this->upload->initialize($config);
						  $this->upload->do_upload('userfile');
						  if ($this->upload->do_upload('userfile'))
						  {
						   $data['uploads'][$i] = $this->upload->data();
						   $file_name= $data['uploads'][$i]['file_name'];
						   $mediaresult = $this->products_model->insertDigitalMedia($user_id,gallery_files,$file_name,$language_id);
						  }
						  else
						  {
						   $data['upload_errors'][$i] = $this->upload->display_errors();
						  } 
					}  
				}
			 }
						 
						 
			//Digital Media Video 
			unset($_FILES['userfile']);
			 	//Digital Media Video 
			 $totalgalleryfiles= count($_FILES['digital-video']['name']);
			
			for($i=0;$i<$totalgalleryfiles;$i++){
				if($_FILES['digital-video']['name'][$i]['gallery_videos']!=''){	
				
					$_FILES['userfile']['name']=$_FILES['digital-video']['name'][$i]['gallery_videos'];
					$_FILES['userfile']['type']    = $_FILES['digital-video']['type'][$i]['gallery_videos'];
					$_FILES['userfile']['tmp_name'] = $_FILES['digital-video']['tmp_name'][$i]['gallery_videos'];
					$_FILES['userfile']['error']       = $_FILES['digital-video']['error'][$i]['gallery_videos'];
					$_FILES['userfile']['size']    = $_FILES['digital-video']['size'][$i]['gallery_videos'];
					
					
					$config['upload_path'] = $this->gallery_path;
					$config['allowed_types'] = 'wmv|mp4|avi|mov';
					$config['max_size']	= '102400';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					//$configVideo['overwrite'] = FALSE;
                    $configVideo['remove_spaces'] = TRUE;
					$file_name = time().'_'.$product_id.'_'.$_FILES['userfile']['name'];	
					$config['file_name'] =$file_name;	 
					if($_FILES['userfile']['error']!='4'){
						  /*if($_FILES['userfile']['name']!=''){
							$mediaresult = $this->products_model->insertDigitalMedia($user_id,1,$file_name);
						  }*/
						  $this->upload->initialize($config);
						  $this->upload->do_upload('userfile');
						  if ($this->upload->do_upload('userfile'))
						  {
						   $data['uploads'][$i] = $this->upload->data();
						  $file_name= $data['uploads'][$i]['file_name'];
						   	$mediaresult = $this->products_model->insertDigitalMedia($product_id,1,$file_name,$language_id);
						  }
						  else
						  {
						   $data['upload_errors'][$i] = $this->upload->display_errors();
						  } 
					}  
				}
			 }
		    
			
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Product added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/products/view');
		    
		    
		}
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
	
		
		$data['category_ids'] = $categoryids;
		$data['vendor_list']=$vendorlist;
	   $this->load->view('backoffice/product/translate_add.php', $data);
	}
	
	public function edit_translate($language_id,$product_id){
	    $data=array();
        $data['title'] = "Edit Product";
        $data['main_heading'] = "Products";
        $data['heading'] = "Edit Product";
        $data['already_msg'] = "";
        $data['langid']=$language_id;
        $data['productid']=$product_id;
		$this->form_validation->set_rules('product_name', 'Product name', 'required');
		$this->form_validation->set_rules('product_price', 'Product price', 'required|trim');
		$this->form_validation->set_rules('product_desc', 'Product description', 'required|trim'); 
		$get_product_join=$this->products_model->get_product_translation($product_id,$language_id);
		//print '<pre>';print_r($get_product_join);die;
		$data['edit_product']=$get_product_join;
		$get_images =  $this->products_model->media_info($product_id,2,$language_id);
		//print '<pre>';print_r($get_images);die;
		$data['media_images']=$get_images;
		
		$get_videos =  $this->products_model->media_info($product_id,1,$language_id);
		//print '<pre>';print_r($get_images);die;
		$data['media_videos']=$get_videos;
		
		if ($this->form_validation->run()) {
		    $user_id =  $this->products_model->update_translate($language_id,$product_id);
		    
		    
		    //Old Digital images Files
    		   $old_digital_image_files=$this->input->post('old-digital-image');
    		   
    		   if(isset($old_digital_image_files) &&  !empty($old_digital_image_files)){
    			   foreach($old_digital_image_files as $key=>$filename){
    				   
    				   $this->products_model->oldmedia($product_id,$user_id, $filename['gallery_images'],$this->gallery_path,$language_id);
    				   
    			   }
    			   
    		   }
    		   
    		   
    		   $old_digital_video_files=$this->input->post('old-digital-video');
    		   
    		   if(isset($old_digital_video_files) &&  !empty($old_digital_video_files)){
    			   foreach($old_digital_video_files as $key=>$filename){
    				   
    				   $this->products_model->oldmedia($product_id,$user_id, $filename['gallery_videos'],$this->gallery_path,$language_id);
    				   
    			   }
    			   
    		   }
		    
		    
		    //Digital Gallery Files
		    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
			
			for($i=0;$i<$totalgalleryfiles;$i++){
				if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
				
					$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
					$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
					$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
					$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
					$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
					
					
					$config['upload_path'] = $this->gallery_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					$file_name = time().'_'.$product_id.'_'.$_FILES['userfile']['name'];	
					$config['file_name'] =$file_name;	
					if($_FILES['userfile']['error']!='4'){
						 /* if($_FILES['userfile']['name']!=''){
							$mediaresult = $this->products_model->insertDigitalMedia($product_id,gallery_files,$file_name,$language_id);
						  }*/
						  $this->upload->initialize($config);
						  $this->upload->do_upload('userfile');
						  if ($this->upload->do_upload('userfile'))
						  {
						   $data['uploads'][$i] = $this->upload->data();
						    $file_name= $data['uploads'][$i]['file_name'];
						   $mediaresult = $this->products_model->insertDigitalMedia($product_id,gallery_files,$file_name,$language_id);
						  }
						  else
						  {
						   $data['upload_errors'][$i] = $this->upload->display_errors();
						  } 
					}  
				}
			 }
			 
			 unset($_FILES['userfile']);
			 	//Digital Media Video 
			 $totalgalleryfiles= count($_FILES['digital-video']['name']);
			
			for($i=0;$i<$totalgalleryfiles;$i++){
				if($_FILES['digital-video']['name'][$i]['gallery_videos']!=''){	
				
					$_FILES['userfile']['name']=$_FILES['digital-video']['name'][$i]['gallery_videos'];
					$_FILES['userfile']['type']    = $_FILES['digital-video']['type'][$i]['gallery_videos'];
					$_FILES['userfile']['tmp_name'] = $_FILES['digital-video']['tmp_name'][$i]['gallery_videos'];
					$_FILES['userfile']['error']       = $_FILES['digital-video']['error'][$i]['gallery_videos'];
					$_FILES['userfile']['size']    = $_FILES['digital-video']['size'][$i]['gallery_videos'];
					
					
					$config['upload_path'] = $this->gallery_path;
					$config['allowed_types'] = 'wmv|mp4|avi|mov';
					$config['max_size']	= '102400';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					//$configVideo['overwrite'] = FALSE;
                    $configVideo['remove_spaces'] = TRUE;
					$file_name = time().'_'.$product_id.'_'.$_FILES['userfile']['name'];	
					$config['file_name'] =$file_name;	 
					if($_FILES['userfile']['error']!='4'){
						  /*if($_FILES['userfile']['name']!=''){
							$mediaresult = $this->products_model->insertDigitalMedia($user_id,1,$file_name);
						  }*/
						  $this->upload->initialize($config);
						  $this->upload->do_upload('userfile');
						  if ($this->upload->do_upload('userfile'))
						  {
						   $data['uploads'][$i] = $this->upload->data();
						  $file_name= $data['uploads'][$i]['file_name'];
						   	$mediaresult = $this->products_model->insertDigitalMedia($product_id,1,$file_name,$language_id);
						  }
						  else
						  {
						   $data['upload_errors'][$i] = $this->upload->display_errors();
						  } 
					}  
				}
			 }
						 
						 
			//Digital Media Video 
			/*if(isset($_POST['digital-video']))
			{
			  $GroupLists = $_POST['digital-video'];
			  foreach($GroupLists as $key=> $listrow){
				
				  if($listrow['video_url']!='') 
				  {
					$file_name = $listrow['video_url'];
					$mediaresult = $this->products_model->insertDigitalMedia($product_id,video_files,$file_name);
				  } 
		
			   }
			}*/
			
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Product added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/products/view');
		    
		    
			
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Product added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/products/view');
		    
		    
		}
		
		
	   $this->load->view('backoffice/product/edit_translate.php', $data);
	}
	
	
	
}	
?>