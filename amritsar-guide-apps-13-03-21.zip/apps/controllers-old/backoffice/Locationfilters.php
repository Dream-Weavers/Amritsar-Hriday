<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Locationfilters extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/locationfilters_model');
		
	}
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_locations_title')."";
	    $data['main_heading'] = $this->lang->line('locations_title');
	    $data['heading'] = $this->lang->line('view_locations_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('location_id'))
			 $location_id = $this->input->post('location_id');
		 elseif($this->uri->segment('4'))
			 $location_id=$this->uri->segment('4');
		else
			 $location_id='0';
			 
			 
	    if($this->input->post('category_type_id'))
	 		 $category_type_id = $this->input->post('category_type_id');
	    elseif($this->uri->segment('5'))
			 $category_type_id=$this->uri->segment('5');
		else
			 $category_type_id='0';
			 	 
		
	  if($this->input->post('location_name'))
			$location_name = $this->input->post('location_name');
		 elseif($this->uri->segment('6'))
			$location_name=$this->uri->segment('6');
		else
			$location_name='0';
					
	   if($this->input->post('serial_no'))
			$serial_no = $this->input->post('serial_no');
		 elseif($this->uri->segment('7'))
			$serial_no=$this->uri->segment('7');
		else
			$serial_no='0';
		
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('8'))
			 $status=$this->uri->segment('8');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('9'))
			$per_page=$this->uri->segment('9');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/locationfilters/view/".$location_id."/".$category_type_id."/".$location_name."/".$serial_no."/".$status."/".$per_page;
		$config["per_page"] = 10;
        $config["uri_segment"] = 10;
		$config["total_rows"] =$this->locationfilters_model->count_locationfilters($location_id,$category_type_id,$location_name,$serial_no,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(10)) ? $this->uri->segment(10) : 0; 
		$data['results'] = $this->locationfilters_model->view_locationfilters($location_id,$category_type_id,$location_name,$serial_no,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['location_id'] = $location_id;
		$data['category_type_id'] = $category_type_id;
		$data['location_name'] = $location_name;
		$data['serial_no'] = $serial_no;
		$data['status'] = $status;	
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/locationfilters/view.php', $data);
		}
	
	
	public function update()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('add_location_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('filter_id[]', ''.$this->lang->line('location_category_text').'', 'trim');
		  
		 if ($this->form_validation->run()) {

			 if(is_array($_POST['location_id']))
			 {
			  foreach($_POST['location_id'] as $lockey => $locval) {
				  if(isset($_POST[$locval.'_category_id']))
				  {
				  $category_ids = $_POST[$locval.'_category_id'];
				  if(is_array($category_ids))
				  {
					  foreach($category_ids as $catkey => $catval)
					  {
						   $filter_ids = $_POST[$locval.'_'.$catval.'_filter_id'];
						   if(is_array($filter_ids))
				           {
							 $fields=array('location_id'=>$locval,'category_id'=>$catval,'is_active'=>'1');
							 $filterresult=gettableresult('location_filters',$fields);
							 if(is_array($filterresult))
							 {
							  foreach($filterresult as $grow){
								 if(!in_array($grow->filterid,$filter_ids)){
								
									$data = array(
										'is_active' => '0',
									);
								  $this->db->where('location_id',$locval);
								  $this->db->where('category_id',$catval);
								  $this->db->where('filterid',$filterval);
								  $updateresult = $this->db->update('location_filters', $data);
								}
							  }
							 }
		 
		   
							   foreach($filter_ids as $filterkey => $filterval)
							   {
								    $this->db->select('location_filter_id');
									$this->db->from('location_filters');
									$this->db->where('location_id',$locval);
									$this->db->where('category_id',$catval);
									$this->db->where('filterid',$filterval);
									$this->db->order_by('location_filter_id', 'ASC');
									$filter_result = $this->db->get();
									if($filter_result->num_rows() > 0)
									{
										  $data =array( 
											'is_active' => '1'
										   );	
											  $filterrow = $filter_result->row();	
											  $location_filter_id = $filterrow->location_filter_id;
											  $this->db->where('location_filter_id', $location_filter_id);
											  $this->db->where('category_id', $catval);
											  $this->db->where('filterid',$filterval);
											  $updateresult = $this->db->update('location_filters', $data);
									}
									else
									{
										$data =array( 
											'location_id'    => $locval,
											'category_id'    => $catval,
											'filterid'    =>  $filterval,
											'created_by'    =>  $this->session->userdata('user_id'),
											'created_on'      => date('Y-m-d H:i:s')
										);
										$insertresult= $this->db->insert('location_filters',$data);
									}
								  }
							   }
						   }
				   }
				  }
			   }
			 }
			// die();
			   if($insertresult)
				{  $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg); 
				}
				else
				{ 
				   	$msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				redirect($_SERVER['HTTP_REFERER']);
 		 
	    } //end of add  functionality
	}

	
	
	
	public function status($location_id,$status)
	{	 // Update status  
	     $result = $this->locationfilters_model->update_status($location_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "employees/locations/view");		
		 
	}//end of Status  functionality*/
	
	
	public function deletedigitalmedia($location_media_id)
	{	 // Delete Digital Media  
	     $result = $this->locationfilters_model->deleteDigitalMedia($location_media_id,$this->audio_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	
	public function setdefaultmedia($location_id,$location_media_id,$media_type)
	{	 // Set Default Media  
	     $result = $this->locationfilters_model->setDefaultMedia($location_id,$location_media_id,$media_type);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('update_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	

	public function deletelocsection($location_section_id)
	{	 // Delete Section  
	     $result = $this->locationfilters_model->deleteLocSection($location_section_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function deletefacility($location_facility_id)
	{	 // Delete facility  
	     $result = $this->locationfilters_model->deleteFacility($location_facility_id,$this->facility_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/


	
	
}	
?>