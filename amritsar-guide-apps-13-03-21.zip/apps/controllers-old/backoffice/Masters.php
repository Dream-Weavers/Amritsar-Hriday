<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Masters extends CI_Controller {
public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		$this->load->model('backoffice/master_model');
	}
	
	public function add_country()
	{
		  $data['title'] = title." | ".$this->lang->line('add_country_text')."";
		  $data['main_heading'] = $this->lang->line('country_text');
		  $data['heading'] = $this->lang->line('add_country_text');
		  $data['already_exists'] = "";
		 
		 $this->form_validation->set_rules('country_name', 'Country name', 'required|trim'); 
		 if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('country_name' =>$this->input->post('country_name'));
		  $result = check_unique('country',$feilds);
		  if($result==1)
		  {
			 $data['already_exists']=$this->lang->line('already_exists_text');
		  }
		  else
		  {
				$result = $this->master_model->insert_country();
				if($result=='1')
				   $msg = "Country has been added successfully.";
				else
				   $msg="There is some error in country added.";   
				
				  $this->session->set_flashdata('success_message', $msg);
				  redirect(base_url() . 'backoffice/masters/view_countries');
			} //end of add functionality
	  }
	   $this->load->view('backoffice/masters/add_country', $data);
	}

	public function view_countries()
	{
		  $data['title'] = title." | ".$this->lang->line('view_country_text')."";
		  $data['main_heading'] = $this->lang->line('country_text');
		  $data['heading'] = $this->lang->line('view_country_text');
			 
		  $results = $this->master_model->view_counties();
		  $num_rows = count($results);	
		  $data['results'] = $results;
		  $data['num_rows'] = $num_rows;
		  $this->load->view('backoffice/masters/view_countries', $data);
		
    } //end of view functionality*/
	
	
	
	public function edit_country($country_id)
	{
		  $data['title'] = title." | ".$this->lang->line('edit_country_text')."";
		  $data['main_heading'] = $this->lang->line('country_text');
		  $data['heading'] = $this->lang->line('edit_country_text');
		  $data['already_exists'] = "";
			$this->form_validation->set_rules('country_name', 'Country name', 'required|trim|xss_clean'); 
		  if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('country_name' =>$this->input->post('country_name'),'country_id' =>$country_id);
		  $result = check_unique('country',$feilds,'0'); 
		  if($result==1)
		  {
			 $data['already_exists']='Country name already exists, Please try another.';
		  }
		 else
		  {
			  // Update records 
			  $result = $this->master_model->update_country($country_id);	
			  if($result=='1')
				   $msg = $this->lang->line('update_text_message');
				else
				   $msg=$this->lang->line('error_text_message');
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/masters/view_countries/".$country_id."");
		  }
		}
			
		  $result =  $this->master_model->country_edit($country_id);
		  $data['edit_data'] = $result;	
		  $this->load->view('backoffice/masters/edit_country', $data);
		 
	}//end of Edit functionality
	
	 public function add_state()
	 {
		  $data['title'] = title." | Add State";
		  $data['main_heading'] = "States";
		  $data['heading'] = "Add State";
		  $data['already_exists'] = "";
		 
		 $this->form_validation->set_rules('country_id', 'Country name', 'required|trim|xss_clean'); 
		  $this->form_validation->set_rules('state_name', 'State name', 'required|trim|xss_clean'); 

		 if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('state_name' =>$this->input->post('state_name'),'country_id' =>$this->input->post('country_id'));
		  $result = check_unique('state',$feilds);
		  if($result==1)
		  {
			 $data['already_exists']='State name already exists, Please try another.';
		  }
		  else
		  {
				$result = $this->master_model->insert_state();
				if($result=='1')
				   $msg = "State has been added successfully.";
				else
				   $msg="There is some error in state added.";   
				
				  $this->session->set_flashdata('success_message', $msg);
				  redirect(base_url() . 'backoffice/masters/view_states');
			} //end of add functionality
	  }
	   $this->load->view('backoffice/masters/add_state', $data);
	}
	
	
	public function view_states()
	{
		
		  $data['title'] = title." | View States";
		  $data['main_heading'] = "States";
		  $data['heading'] = "View States";
		 
		  if($this->input->post('state_id'))
			 $state_id = $this->input->post('state_id');
		  elseif($this->uri->segment('4'))
			 $state_id=$this->uri->segment('4');
		  else
			 $state_id='0';
		
		 
		  if($this->input->post('country_id'))
			 $country_id = $this->input->post('country_id');
		  elseif($this->uri->segment('5'))
			 $country_id=$this->uri->segment('5');
		  else
			 $country_id='0';
		
			 
		  $results = $this->master_model->view_states($state_id,$country_id);
		  $data['results'] = $results;
		  $num_rows = count($results);	
		  $data['num_rows'] = $num_rows;
		  $data['state_id'] = $state_id;
		  $this->load->view('backoffice/masters/view_states', $data);
		
    } //end of view functionality*/
		
		
	public function edit_state($state_id)
	{
		  $data['title'] = title." | Edit State";
		  $data['main_heading'] = "States";
		  $data['heading'] = "Edit State";
		  $data['already_exists'] = "";
			$this->form_validation->set_rules('country_id', 'Country name', 'required|trim|xss_clean'); 
		  $this->form_validation->set_rules('state_name', 'State name', 'required|trim|xss_clean'); 
		  if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('state_name' =>$this->input->post('state_name'),'state_id' =>$state_id);
		  $result = check_unique('state',$feilds,'0');
		  if($result==1)
		  {
			 $data['already_exists']='State name already exists, Please try another.';
		  }
		 else
		  {
			  // Update records 
			  $result = $this->master_model->update_state($state_id);	
			  if($result=='1')
				   $msg = "State record has been updated successfully.";
				else
				   $msg=""; 
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/masters/view_states/".$state_id."");
		  }
		}
			
		  $result =  $this->master_model->state_edit($state_id);
		  $data['edit_data'] = $result;	
		  $this->load->view('backoffice/masters/edit_state', $data);
		 
	}//end of Edit functionality
	
	

	public function add_city()
	{
		  $data['title'] = title." | Add City";
		  $data['main_heading'] = "Cities";
		  $data['heading'] = "Add City";
		  $data['already_exists'] = "";
		 
		  $this->form_validation->set_rules('state_id', 'State', 'required|trim|xss_clean');
		  $this->form_validation->set_rules('city_name', 'City name', 'required|trim|xss_clean');
		if ($this->form_validation->run()) {
			
		  $feilds = array('state_id' =>$this->input->post('state_id'),'city_name' =>$this->input->post('city_name'));
		  $result = check_unique('city',$feilds);
		  if($result==1)
		  {
			 $data['already_exists']='City name already exists, Please try another.';
		  }
		  else
		  {
        	$result = $this->master_model->insert_city();
			if($result=='1')
			   $msg = "City has been added successfully.";
			else
			   $msg="There is some error in city added.";   
			
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/masters/view_citys');
	     } //end of add  functionality
		 
		}
	   $this->load->view('backoffice/masters/add_city', $data);
	}
	
	
	public function view_citys()
	{
		  $data['title'] = title." | View Cities";
		  $data['main_heading'] = "Cities";
		  $data['heading'] = "View Cities";
		  
		  if($this->input->post('state_id'))
			 $state_id = $this->input->post('state_id');
		  elseif($this->uri->segment('4'))
			 $state_id=$this->uri->segment('4');
		  else
			 $state_id='0';
			 
		  if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		  elseif($this->uri->segment('5'))
			$per_page=$this->uri->segment('5');
		  else
			$per_page=per_page;	
			
			$config = array();
			$config["base_url"] = base_url() . "backoffice/masters/view_citys/".$state_id."/".$per_page;
			$config["per_page"] = 100;
			$config["uri_segment"] = 6;
			$config["total_rows"] =$this->master_model->count_citys($state_id);
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0; 	 
			 
		   $results = $this->master_model->view_citys($state_id,$config["per_page"],$page);
		   $data['links']   = $this->pagination->create_links();
		   $data['results'] = $results;
		   $num_rows =$config["total_rows"];
		   $data['num_rows'] = $num_rows;
		  
		   $data['state_id'] = $state_id; 
		   $this->load->view('backoffice/masters/view_citys', $data);
		
    } //end of view functionality
		
		
	public function edit_city($city_id,$s_id)
	{
		  $data['title'] = title." | Edit City";
		  $data['main_heading'] = "Cities";
		  $data['heading'] = "Edit City";
		  $data['already_exists'] = "";

		  $this->form_validation->set_rules('state_id', 'State', 'required|trim|xss_clean');
		  $this->form_validation->set_rules('city_name', 'City name', 'required|trim|xss_clean');
		 
		 if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('state_id' =>$this->input->post('state_id'),'city_name' =>$this->input->post('city_name') ,'city_id' =>$city_id);
		  $result = check_unique('city',$feilds,'0');
		  if($result==1)
		  {
			 $data['already_exists']='City name already exists, Please try another.';
		  }
		 else
		  { 
			  // Update records 
			  $result = $this->master_model->update_city($this->input->post('city_id'));	
			  if($result=='1')
				   $msg = "City record has been updated successfully.";
			   else
				   $msg=""; 
				   
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . "backoffice/masters/view_citys/".$s_id);
		  }
		}
			
		  $result =  $this->master_model->city_edit($city_id);
		  $data['edit_data'] = $result;	
		  $this->load->view('backoffice/masters/edit_city', $data);
		 
		 
	}//end of Edit functionality*/



	public function add_locality()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_locality_title')."";
		  $data['main_heading'] = $this->lang->line('locality_title');
		  $data['heading'] = $this->lang->line('add_locality_title');
		  $data['already_msg'] = "";
		 
		  $this->form_validation->set_rules('state_id', ''.$this->lang->line('locality_state_text').'', 'required|trim');
		  $this->form_validation->set_rules('city_id', ''.$this->lang->line('locality_city_text').'', 'required|trim');
		  $this->form_validation->set_rules('locality_name', ''.$this->lang->line('locality_name_text').'', 'required|trim');
		 if($this->form_validation->run()) {
		  $feilds = array('city_id' =>$this->input->post('city_id'),'locality_name' =>$this->input->post('locality_name'));
		  $result = check_unique('locality',$feilds);
		  if($result==1)
		  {
			 $already_msg_text   = str_replace("{field}", $this->input->post('locality_name'), $this->lang->line('already_exists_text'));
			 $data['already_msg']= $already_msg_text;
		  }
		  else
		  {
        	$result = $this->master_model->insert_locality();
			if($result=='1')
			{
			   $msg = $this->lang->line('success_text_message');
			   $this->session->set_flashdata('success_message', $msg);
			}
			else
			{
			   $msg=  $this->lang->line('error_text_message');
			   $this->session->set_flashdata('error_message', $msg);
			}
			  
			  redirect(base_url() . 'backoffice/masters/view_localitys');
	     } //end of add  functionality
		 
		}
		
		//print_r($data);
	   $data['country_id'] = isset($_POST['country_id']) ? $_POST['country_id'] : 101;
	   $data['state_id'] = isset($_POST['state_id']) ? $_POST['state_id'] : 0;
	   $data['city_id'] = isset($_POST['city_id']) ? $_POST['city_id'] : 0;
	   $data['locality_id'] = isset($_POST['locality_id']) ? $_POST['locality_id'] : 0;
			
	   $this->load->view('backoffice/masters/add_locality', $data);
	}
	
    
	public function view_localitys()
	{
		  $data=array();   
		  $data['title'] = title." | ".$this->lang->line('view_locality_title')."";
		  $data['main_heading'] = $this->lang->line('locality_title');
		  $data['heading'] = $this->lang->line('view_locality_title');
		  
		  if($this->input->post('city_id'))
			 $city_id = $this->input->post('city_id');
		  elseif($this->uri->segment('4'))
			 $city_id=$this->uri->segment('4');
		  else
			 $city_id='0';
			 
			 
		 if($this->input->post('locality_id'))
			 $locality_id = $this->input->post('locality_id');
		  elseif($this->uri->segment('5'))
			 $locality_id=$this->uri->segment('5');
		  else
			 $locality_id='0';	 
			 
		  if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		  elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		  else
			$per_page=per_page;	
			
			$config = array();
			$config["base_url"] = base_url() . "backoffice/masters/view_localitys/".$city_id."/".$locality_id."/".$per_page;
			$config["per_page"] = $per_page;
			$config["uri_segment"] = 7;
			$config["total_rows"] =$this->master_model->count_localitys($city_id,$locality_id);
			$this->pagination->initialize($config);
			$page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 	 
			 
		   $results = $this->master_model->view_localitys($city_id,$locality_id,$config["per_page"],$page);
		   $data['links']   = $this->pagination->create_links();
		   $data['results'] = $results;
		   $num_rows =$config["total_rows"];
		   $data['num_rows'] = $num_rows;
		  
		   $data['city_id'] = $city_id; 
		   $data['locality_id'] = $locality_id;
		   $this->load->view('backoffice/masters/view_localitys', $data);
		
    } //end of view functionality
	
	
	public function edit_locality($locality_id,$city_id)
	{
		  $data=array();
 		  $data['title'] = title." ".$this->lang->line('edit_locality_title')."";
		  $data['main_heading'] = $this->lang->line('locality_title');
		  $data['heading'] = $this->lang->line('edit_locality_title');
		  $data['already_msg'] = "";
		 
		  $this->form_validation->set_rules('state_id', ''.$this->lang->line('locality_state_text').'', 'required|trim');
		  $this->form_validation->set_rules('city_id', ''.$this->lang->line('locality_city_text').'', 'required|trim');
		  $this->form_validation->set_rules('locality_name', ''.$this->lang->line('locality_name_text').'', 'required|trim');
		 
		 if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('city_id' =>$this->input->post('city_id'),'locality_name' =>$this->input->post('locality_name'));
		  $unique_id = array('locality_id' =>$locality_id);
		  $result = check_unique_edit('locality',$feilds,$unique_id);
		  if($result==1)
		  {
			 $already_msg_text   = str_replace("{field}", $this->input->post('locality_name'), $this->lang->line('already_exists_text'));
			 $data['already_msg']= $already_msg_text;
		  }
		 else
		  { 
			  // Update records 
			  $result = $this->master_model->update_locality($this->input->post('locality_id'));	
			  if($result=='1')
			  {    $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
			  }
			  else
			  {    $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
			  }
			  redirect(base_url() . "backoffice/masters/view_localitys/".$city_id);
		  }
		}
		  $result =  $this->master_model->locality_edit($locality_id);
		  $data['edit_data'] = $result;	
		  
		  $cityrow =  get_table_info('city','city_id',$result->city_id);
		  $staterow =  get_table_info('state','state_id',$cityrow->state_id);
		  
	 	  $data['country_id'] = isset($staterow->country_id) ? $staterow->country_id : 0;
		  $data['state_id'] = isset($cityrow->state_id) ? $cityrow->state_id : 0;
		  $data['city_id'] = isset($result->city_id) ? $result->city_id : 0;
		  $data['locality_id'] = isset($result->locality_id) ? $result->locality_id : 0;
	  
		 $this->load->view('backoffice/masters/edit_locality', $data);
		 
		 
	}//end of Edit functionality*/
	
	
	public function add_role()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_role_title')."";
		  $data['main_heading'] = $this->lang->line('role_title');
		  $data['heading'] = $this->lang->line('add_role_title');
		  $data['already_msg'] = "";
		
		  $this->form_validation->set_rules('role_name', ''.$this->lang->line('role_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('description', ''.$this->lang->line('role_description_text').'', 'required|trim');
		  $this->form_validation->set_rules('role_permission[]', ''.$this->lang->line('role_permission_text').'', 'required|trim');
		  if ($this->form_validation->run()) {
		  $feilds = array('role_name' =>trim($this->input->post('role_name')));
		  $result = check_unique('roles',$feilds);
		  if($result==1)
		  {
			 $already_msg_text   = str_replace("{field}", $this->input->post('role_name'), $this->lang->line('already_exists_text'));
			 $data['already_msg']= $already_msg_text;
		  }
		  else
		  {
			$result =  $this->master_model->add_role();
			if($result=='1')
			{  $msg = $this->lang->line('success_text_message');
			   $this->session->set_flashdata('success_message', $msg);
			}
			else
			{  $msg=  $this->lang->line('error_text_message');
			   $this->session->set_flashdata('error_message', $msg);
			}
			redirect(base_url() . 'backoffice/masters/view_roles');  
		  }
			
	    } //end of add  functionality
		
	   $this->load->view('backoffice/masters/add_role.php', $data);
	}
	
	
	public function view_roles()
	{
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_role_title')."";
	    $data['main_heading'] = $this->lang->line('role_title');
	    $data['heading'] = $this->lang->line('view_role_title');
	 		 
		$results = $this->master_model->view_roles();
		  
		$data['results'] = $results;
		$num_rows = count($results);	
		$data['num_rows'] = $num_rows;
		  
		$this->load->view('backoffice/masters/view_roles', $data);
		
    } //end of view functionality
	

	public function edit_role($role_id){
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('edit_role_title')."";
		  $data['main_heading'] = $this->lang->line('role_title');
		  $data['heading'] = $this->lang->line('edit_role_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('role_name', ''.$this->lang->line('role_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('description', ''.$this->lang->line('role_description_text').'', 'required|trim');
		  $this->form_validation->set_rules('role_permission[]', ''.$this->lang->line('role_permission_text').'', 'required|trim');
		  
		if ($this->form_validation->run()) {
		  // Update records 
		  $feild = array('role_name' =>trim($this->input->post('role_name')));
		  $unique_id = array('role_id' =>$role_id);
		  $role_result = check_unique_edit('roles',$feild,$unique_id);
		  if($role_result==1)
		  {
			 $already_msg_text   = str_replace("{field}", $this->input->post('role_name'), $this->lang->line('already_exists_text'));
			 $data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		    $result =  $this->master_model->update_role($this->input->post('role_id'));
		    if($result=='1')
			{  $msg = $this->lang->line('success_text_message');
			   $this->session->set_flashdata('success_message', $msg);
			}
			else
			{  $msg=  $this->lang->line('error_text_message');
			   $this->session->set_flashdata('error_message', $msg);
			}
			  redirect(base_url() . "backoffice/masters/view_roles/".$this->input->post('role_id'));
		  }
		}
		  $result =  $this->master_model->role_edit($role_id);	
		  $data['edit_data'] = $result;
		  
		  $this->load->view('backoffice/masters/edit_role.php', $data);
		 
	}//end of Edit functionality*/
	
	
	function add_module(){
		 $data['title'] = title." ".$this->lang->line('edit_locality_title')."";
		  $data['main_heading'] = $this->lang->line('locality_title');
		  $data['heading'] = $this->lang->line('edit_locality_title');
		  $data['already_msg'] = "";
		  
		$data['title'] = title." | Add Module";
		$data['main_heading'] = "Modules";
		$data['heading'] = "Add Module";
		$data['already_msg'] = "";
		
		 if($this->input->post('user_type'))
			 $user_type = $this->input->post('user_type');
		  elseif($this->uri->segment('4'))
			 $user_type=$this->uri->segment('4');
		  else
			 $user_type='C'; 
		 
		 $this->form_validation->set_rules('user_type', 'User type', 'required|trim'); 
		 $this->form_validation->set_rules('menu_name', 'Module name', 'required|trim'); 
		 if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('user_type' =>$this->input->post('user_type'),'menu_name' =>$this->input->post('menu_name'));
		  $result = check_unique('navigation_menus',$feilds);
		  if($result==1)
		  {
			 $data['already_msg']='Module name already exists, Please try another.';
		  }
		  else
		  {
				$result = $this->master_model->add_module();
				if($result=='1')
				   $msg = "Module has been added successfully.";
				else
				   $msg="There is some error in Module added.";   
				
				  $this->session->set_flashdata('success_message', $msg);
				  redirect(base_url() . 'backoffice/masters/view_modules');
			} //end of add functionality
		}
		
		$data['user_type'] = $user_type;
		$data['module_id'] = isset($_POST['module_id']) ? $_POST['module_id'] : 0;
		$this->load->view('backoffice/modules/add_module', $data);
	}
	
	/*================ View Modules =================*/
	public function view_modules()
	{
		  $data['title'] = title." | View Modules";
		  $data['main_heading'] = "Modules";
		  $data['heading'] = "View Modules";
		  
		  if($this->input->post('user_type'))
			 $user_type = $this->input->post('user_type');
		  elseif($this->uri->segment('4'))
			 $user_type=$this->uri->segment('4');
		  else
			 $user_type='E'; 
			 
		  $results = $this->master_model->modules_tree($user_type);
		  $data['results'] = $results;
		  $num_rows = count($results);	
		  
		  $data['user_type'] = $user_type;
		  $this->load->view('backoffice/modules/view_modules', $data);
		
    } //end of view functionality*/
	
	/*============= Edit modules ==================*/
	public function edit_module($menu_id)
	{
		  $data['title'] = title." | Edit Module";
		  $data['main_heading'] = "Modules";
		  $data['heading'] = "Edit Module";
		  $data['already_msg'] = "";

		  $this->form_validation->set_rules('user_type', 'User type', 'required|trim'); 
		  $this->form_validation->set_rules('menu_name', 'Module name', 'required|trim'); 
		  $this->form_validation->set_rules('set_order', 'Set Order', 'required|trim'); 
		
		  if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('user_type' =>$this->input->post('user_type'),'menu_name' =>$this->input->post('menu_name'));
		  $unique_id = array('menu_id' =>$menu_id);
		  $result = check_unique_edit('navigation_menus',$feilds,$unique_id);
		  if($result==1)
		  {
			 $data['already_exists']='Module name already exists, Please try another.';
		  }
		 else
		  {
			  // Update records 
			  $result = $this->master_model->update_module($this->input->post('menu_id'));	
			   if($result=='1')
				   $msg = "Module record has been updated successfully.";
				else
				   $msg=""; 
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/masters/view_modules");
		  }
		}
			 
		  $result =  $this->master_model->modules_edit($menu_id);
		  $data['edit_data'] = $result;	
		  $this->load->view('backoffice/modules/edit_module', $data);
		 
	}//end of Edit functionality
	
	
}	
?>