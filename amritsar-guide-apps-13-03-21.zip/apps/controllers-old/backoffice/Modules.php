<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Modules extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/modules_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->original_path = realpath('assets/static/user_photos/original');
	   	$this->resized_path = realpath('assets/static/user_photos/resized');
	}
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." Module Listing";
	    $data['main_heading'] = "Module Listing";
	    $data['heading'] = "Module Listing";	
		
		if($this->input->post('module_name'))
			 $module_name = $this->input->post('module_name');
		 elseif($this->uri->segment('4'))
			 $module_name=$this->uri->segment('4');
		else
			 $module_name='0';
		
	  if($this->input->post('module_category'))
			$module_category = $this->input->post('module_category');
		 elseif($this->uri->segment('5'))
			$module_category=$this->uri->segment('5');
		else
			$module_category='0';
					
	   if($this->input->post('module_visibility'))
			$module_visibility = $this->input->post('module_visibility');
		 elseif($this->uri->segment('6'))
			$module_visibility=$this->uri->segment('6');
		else
			$module_visibility='0';
		
		if($this->input->post('module_type'))
			$module_type = $this->input->post('module_type');
		elseif($this->uri->segment('7'))
			$module_type=$this->uri->segment('7');
		else
			$module_type='0';
		
		if($this->input->post('module_conf_type'))
			$module_conf_type = $this->input->post('module_conf_type');
		elseif($this->uri->segment('8'))
			$module_conf_type=$this->uri->segment('8');
		else
			$module_conf_type='0';
		
		$per_page=30;
		
		$config = array();
		$config["base_url"] = base_url() . "backoffice/modules/view/".$module_name."/".$module_category."/".$module_visibility."/".$module_type."/".$module_conf_type."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 9;
		$config["total_rows"] =$this->modules_model->count_modules($module_name,$module_category,$module_visibility,$module_type,$module_conf_type);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(9)) ? $this->uri->segment(9) : 0; 
		$data['results'] = $this->modules_model->view_modules($module_name,$module_category,$module_visibility,$module_type,$module_conf_type,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['module_name'] = $module_name;
		$data['module_category'] = $module_category;
		$data['module_visibility'] = $module_visibility;
		$data['module_type'] = $module_type;	
		$data['module_conf_type'] = $module_conf_type;	
		$data['per_page'] = $per_page;
		
		
		if(isset($_POST['submit_weight'])){
			$fields_sorting=$this->modules_model->module_field_sorting('modules','module_id');
			$this->session->set_flashdata('success_message', 'Field has been updated successfully.');
			redirect(base_url() . 'backoffice/modules/view');  
		}
		
		
		$this->load->view('backoffice/modules/view.php', $data);
	}
	public function add(){	
	    
		$data=array();
		$data['title'] = "Add Module";
	    $data['main_heading'] = "Add module configuration.";
	    $data['heading'] = "Add module configuration.";	
		$data['already_msg']='';
		
		$this->form_validation->set_rules('module_name', 'Module Name', 'required|trim');
		$this->form_validation->set_rules('module_visible', 'Module visible', 'required|trim');
		$this->form_validation->set_rules('module_category', 'Module For', 'required|trim');
		$this->form_validation->set_rules('module_type', 'Module Type', 'required');
		$this->form_validation->set_rules('no_of_records', 'No of records', 'required|trim');
		$this->form_validation->set_rules('field_config', 'Field Configuration', 'required|trim');
		//print '<pre>';print_r($this->session->userdata());die;
		if ($this->form_validation->run()) {
			//print '<pre>';print_r($_POST);die;
			$mod_name=$this->input->post('module_name');
			$mod_visible=$this->input->post('module_visible');
			$module_category=$this->input->post('module_category');
			$mod_type=$this->input->post('module_type');
			$no_of_records=$this->input->post('no_of_records');
			$field_config=$this->input->post('field_config');
            $language_id=$this->input->post('lang_id');
			
			$user_id=$this->session->userdata('user_id');  // logged user id
			if($mod_type==1){
				$module_layout=2;
			}else if($mod_type==2){
				$module_layout=2;
			}else if($mod_type==3){
				$module_layout=2;
			}else if($mod_type==4){
				$module_layout=1;
			}else if($mod_type==5){
				$module_layout=7;
			}else if($mod_type==6){
				$module_layout=7;
			}else if($mod_type==7){
				$module_layout=7;
			}else if($mod_type==8){
				$module_layout=7;
			}else if($mod_type==9){
				$module_layout=7;
			}
			
			$module_table=array('language_id'=>$language_id,'module_layout'=>$module_layout,'module_name'=>$mod_name,'module_category_id'=>$module_category,'module_visibility'=>$mod_visible,'module_type'=>$mod_type,'no_of_records'=>$no_of_records,'is_latest'=>$field_config,'created_by'=>$user_id);
			$module_id=$this->modules_model->insert_in_table('modules',$module_table);
			if($module_id){
				if($field_config>1){
					$counter=1;
					if($mod_type==2){
						$text='locations';
						$chooseloc_loc=$this->input->post('chooseloc_loc');
						foreach($chooseloc_loc as $loc_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'location_id'=>$loc_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==3){
						$text='category';
						$chooseloc_cat=$this->input->post('chooseloc_cat');
						foreach($chooseloc_cat as $cat_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'category_id'=>$cat_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==1){
						$text='category type';
						$choose_cattype=$this->input->post('choose_cattype');
						foreach($choose_cattype as $cattype_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'category_type_id'=>$cattype_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==4){
						$text='Slides';
						$slideinfo=$this->input->post('slideinfo');
						foreach($slideinfo as $slide_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'slide_id'=>$slide_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==6){
						$text='Trails';
						$trailinfo=$this->input->post('chooseloc_trails');
						foreach($trailinfo as $trail_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'trail_id'=>$trail_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==7){
						$text='Vendors';
						$vendorinfo=$this->input->post('chooseloc_vendors');
						foreach($vendorinfo as $vendor_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'vendor_id'=>$vendor_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==8){
						$text='Vendors';
						$productinfo=$this->input->post('chooseloc_products');
						foreach($productinfo as $product_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'product_id'=>$product_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}
					
					//$msg = $this->lang->line('success_text_message');
					$msg = "Module and it's ".$counter." ".$text." has been added successfully. You can view it here";
					$this->session->set_flashdata('success_message', $msg);
					redirect(base_url() . 'backoffice/modules/view');
				}else{
					$msg = "Module has been added successfully. You can view it here";
					$this->session->set_flashdata('success_message', $msg);
					redirect(base_url() . 'backoffice/modules/view');
				}
			}
			//$insertin_module
			
		}
		$this->load->view('backoffice/modules/add.php', $data);
	}
	
	public function module_attributes($module_id){
		$data=array();
		$data['title'] = "Module Attributes";
	    $data['main_heading'] = "Module Attributes";
	    $data['heading'] = "Module Attributes";	
		$data['already_msg']='';
		$data['module_id']=$module_id;
		$getmodule_info=get_table_info('modules','module_id',$module_id);
		$mtype=$getmodule_info->module_type;
		$is_latest=$getmodule_info->is_latest;
		$no_of_records=$getmodule_info->no_of_records;
		if($mtype==2){
			if($is_latest!=1)
			$headers=array('Sno','Location name','State','City','Pin code','Weight','Operation');
			else
			$headers=array('Sno','Location name','State','City','Pin code');
		}else if($mtype==3){
			if($is_latest!=1)
			$headers=array('Sno','Category name','Icon','Weight','Operation');
			else
			$headers=array('Sno','Category name','Icon');
		}else if($mtype==1){
			if($is_latest!=1)
			$headers=array('Sno','Category type name','Icon','Weight','Operation');
			else
			$headers=array('Sno','Category type name','Icon');
		}else if($mtype==4){
			if($is_latest!=1)
			$headers=array('Sno','Title','Image','Operation');
			else
			$headers=array('Sno','Slide title','Slide image');
		}else if($mtype==6){
			if($is_latest!=1)
			$headers=array('Sno','Name','Image','Locations','Operation');
			else
			$headers=array('Sno','Name','Image','Locations');
		}else if($mtype==7){
			if($is_latest!=1)
			$headers=array('Sno','Name','Shop Title','Operation');
			else
			$headers=array('Sno','Name','Shop Title');
		}else if($mtype==8){
			if($is_latest!=1)
			$headers=array('Sno','Name','Price','Operation');
			else
			$headers=array('Sno','Name','Price');
		}else if($mtype==9){
			if($is_latest!=1)
			$headers=array('Sno','Name','Image','Operation');
			else
			$headers=array('Sno','Name','Image');
		}
		
		$attributes=$this->modules_model->module_attr($module_id,$mtype,$is_latest,$no_of_records);
		$count=$this->modules_model->count_module_attr($module_id,$mtype,$is_latest,$no_of_records);
		
		if(isset($_POST['submit_weight'])){
			$fields_sorting=$this->modules_model->module_field_sorting('module_interlinks','module_interlink_id');
			$this->session->set_flashdata('success_message', 'Field has been updated successfully.');
			redirect(base_url() . 'backoffice/modules/module_attributes/'.$module_id);  
		}
		
		$result=$attributes;
		$data['results']=$attributes;
		$data['num_rows'] = $count;	
		$data['headers'] = $headers;	
		$data['mtype'] = $mtype;	
		$data['is_latest'] = $is_latest;	
		
		$this->load->view('backoffice/modules/module_attr.php', $data);
	}

	public function module_attr($module_attr_id){
		//print $module_attr_id;die;
		$module_attrid=get_table_info('module_interlinks','module_interlink_id',$module_attr_id);
		$mid=$module_attrid->module_id;
		$deleted=$this->modules_model->delete_module_attr($module_attr_id);
		if($deleted){
			$msg = "This is deleted";
			$this->session->set_flashdata('success_message', $msg);
			redirect(base_url() . 'backoffice/modules/module_attributes/'.$mid);
		}else{
			$msg = "This is an error. Please try again.";
			$this->session->set_flashdata('warning_message', $msg);
			redirect(base_url() . 'backoffice/modules/module_attributes/'.$mid);
		}
	}
	
	
	public function addattributes($module_id){	
		$data=array();
		$data['title'] = "Add Module";
	    $data['main_heading'] = "Add module configuration.";
	    $data['heading'] = "Add module configuration.";	
		$data['already_msg']='';
		$data['module_id']=$module_id;
		
		$moduleinfo=get_table_info('modules','module_id',$module_id);
		$mod_type=$moduleinfo->module_type;
		$field_config=$moduleinfo->is_latest;
		$field_count=array('module_id'=>$module_id);
		$old_records=get_count_table('module_interlinks',$field_count);
		
		//print '<pre>';print_r($old_records);die;
		$data['module_info']=$moduleinfo;
		
		if($mod_type==2){
			$loc_list=$this->modules_model->loclist($module_id);
			$data['loc_list']=$loc_list;
		}else if($mod_type==1){
			$category_type_list=$this->modules_model->category_type_list($module_id);
			$data['category_type_list']=$category_type_list;
		}else if($mod_type==3){
			$category_list=$this->modules_model->category_list($module_id);
			$data['category_list']=$category_list;
		}else if($mod_type==4){
			$slide_list=$this->modules_model->slides_list($module_id);
			$data['slide_list']=$slide_list;
			//print '<pre>';print_r($slide_list);die;
		}
		
		
		$this->form_validation->set_rules('module_name', 'Module Name', 'required|trim');
		//$this->form_validation->set_rules('module_visible', 'Module visible', 'required|trim');
		//$this->form_validation->set_rules('module_category', 'Module For', 'required|trim');
		//$this->form_validation->set_rules('module_type', 'Module Type', 'required');
		//$this->form_validation->set_rules('no_of_records', 'No of records', 'required|trim');
		//$this->form_validation->set_rules('field_config', 'Field Configuration', 'required|trim');
		//print '<pre>';print_r($this->session->userdata());die;
		if ($this->form_validation->run()) {
			//print '<pre>';print_r($_POST);die;
			$mod_name=$this->input->post('module_name');
			/*$mod_visible=$this->input->post('module_visible');
			$module_category=$this->input->post('module_category');
			$mod_type=$this->input->post('module_type');
			$no_of_records=$this->input->post('no_of_records');
			$field_config=$this->input->post('field_config');*/
			
			$user_id=$this->session->userdata('user_id');  // logged user id
			
			//$module_table=array('language_id'=>1,'module_name'=>$mod_name,'module_category_id'=>$module_category,'module_visibility'=>$mod_visible,'module_type'=>$mod_type,'no_of_records'=>$no_of_records,'is_latest'=>$field_config,'created_by'=>$user_id);
			$module_id=$module_id;
			
			if($module_id){
				if($field_config>1){
					$counter=0;
					if($mod_type==2){
						$text='locations';
						$chooseloc_loc=$this->input->post('chooseloc_loc');
						foreach($chooseloc_loc as $loc_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'location_id'=>$loc_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==3){
						$text='category';
						$chooseloc_cat=$this->input->post('chooseloc_cat');
						foreach($chooseloc_cat as $cat_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'category_id'=>$cat_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==1){
						$text='category type';
						$choose_cattype=$this->input->post('choose_cattype');
						foreach($choose_cattype as $cattype_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'category_type_id'=>$cattype_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}else if($mod_type==4){
						$text='Slides';
						$slideinfo=$this->input->post('slideinfo');
						foreach($slideinfo as $slide_id){
							$mod_interlink=array('interlink_type'=>$mod_type,'module_id'=>$module_id,'slide_id'=>$slide_id,'weight'=>1,'created_by'=>$user_id);
							$module_interlink_id=$this->modules_model->insert_in_table('module_interlinks',$mod_interlink);
							if($module_interlink_id){
								$counter++;
							}
							unset($mod_interlink);
						}
					}
					
					$total_rows=$old_records+$counter;
					$mod_fields=array('module_name'=>$mod_name,'no_of_records'=>$total_rows);
					$updatewhere=array('module_id'=>$module_id);
					$update_module=$this->modules_model->update_table('modules',$mod_fields,$updatewhere);
					$msg = "Module and it's ".$counter." ".$text." has been added successfully. You can view it here";
					$this->session->set_flashdata('success_message', $msg);
					redirect(base_url() . 'backoffice/modules/view/0/'.$moduleinfo->module_category_id);
				}else{
					$msg = "Module has been added successfully. You can view it here";
					$this->session->set_flashdata('success_message', $msg);
					redirect(base_url() . 'backoffice/modules/view/0/'.$moduleinfo->module_category_id);
				}
			}
			//$insertin_module
		}
		$this->load->view('backoffice/modules/add_attribute.php', $data);
	}
	
	function deletemodule($module_id){
		
		$update_module=$this->modules_model->deletemodule_table('modules',$module_id);
		$msg = "Module deleted successfully.";
		$this->session->set_flashdata('success_message', $msg);
		redirect(base_url() . 'backoffice/modules/view');
	}
	
}	
?>