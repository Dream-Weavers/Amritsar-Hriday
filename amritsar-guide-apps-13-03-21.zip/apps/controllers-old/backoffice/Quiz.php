<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Quiz extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		//valid_logged_in(FALSE,'E');	
		//check_permissions();
		//time_zone();
		$this->load->model('backoffice/Quiz_model');	
	
	}
	public function view(){	
			
		$data=array();		
		$data['title'] = "Quizzes";
		$data['heading'] = "Quizzes";	
		$data['main_heading'] = "Quizzes";		
		
			if($this->input->post('location_id'))			
				$location_id = $this->input->post('location_id');
			elseif($this->uri->segment('5'))			
			$location_id=$this->uri->segment('5');	
			else			
				$location_id='0';

			if($this->input->post('quiz_name'))	
				$quiz_name = $this->input->post('quiz_name');
			elseif($this->uri->segment('4'))	
			$quiz_name=$this->uri->segment('4');
			else		
				$quiz_name='';		
			
			if($this->input->post('status'))	
				$status = $this->input->post('status');	
			elseif($this->uri->segment('6'))		
			$status=$this->uri->segment('6');
			else		
				$status='0';	 
			
			$data['location_id'] = $location_id;	
			$data['quiz_name'] = $quiz_name;	
			$data['status'] = $status;		
			
		$data['results'] = $this->Quiz_model->view_quiz($location_id,$quiz_name,$status);  	
		//$data['results'] = $this->Quiz_model->viewquiz();  	
		/* echo "<pre>";	
		print_r($data['results']);		
		die;	 */	
		$data['num_rows'] = count($data['results']);  	
		/* echo "<pre>";		print_r($data['results']);		die; */
	    $this->load->view('backoffice/quiz/view', $data);
		
	}
		
	public function status($quiz_id,$status)

	{	 // Update status  

	     $result = $this->Quiz_model->update_status($quiz_id,$status);

		 if($result=='1')

		 {

		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));

		 }

		 else

		 {

			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));

		 }

		 redirect(base_url() . "backoffice/quiz/view");		

		 

	}//end of Status  functionality*/
	
    public function settings()
	{
		$data['title'] = "Quiz Type Settings";
		$data['main_heading'] = "Quiz Type Settings";
		$data['heading'] = "Quiz Type Settings";
		$data['manual'] = $this->Quiz_model->fetch_quiz_type_settings(1);
		$data['auto'] = $this->Quiz_model->fetch_quiz_type_settings(2);
		$data['rapid'] = $this->Quiz_model->fetch_quiz_type_settings(3);
		//$this->form_validation->set_rules('location_id', 'Location', 'required|trim');  
		if($_POST){
			
			$this->Quiz_model->update_quiz_type_settings();
			redirect(base_url() . "backoffice/quiz/settings/s");
			
		}
		
		$this->load->view('backoffice/quiz/settings', $data);		return 1;
	}
	public function add()
	{
		  $data=array();
		  //$data['title'] = title." ".$this->lang->line('add_quiz_title')."";
		  $data['title'] = "Add Quiz";
		  //$data['main_heading'] = $this->lang->line('quiz_title');
		  $data['main_heading'] = "Quiz";
		  //$data['heading'] = $this->lang->line('add_quiz_title');
		  $data['heading'] = "Quiz";
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('location_id', 'Location', 'required|trim'); 
		  $this->form_validation->set_rules('quiz_name', 'Quiz Name', 'required|trim');
		  $this->form_validation->set_rules('quiz_status', 'Quiz Status', 'required|trim'); 
		  $this->form_validation->set_rules('audio_status', 'Audio Status', 'required|trim');  		  $this->form_validation->set_rules('manual_type_status', 'Manual Type Status', 'required|trim');  		
		  $this->form_validation->set_rules('automatic_type_status', 'Automatic Type Status', 'required|trim');  	
		  $this->form_validation->set_rules('rapid_type_status', 'Rapid Type Status', 'required|trim');  
		  if ($this->form_validation->run()) {
			
				$quiz_id=$this->Quiz_model->add_quiz_settings();
				
				if(isset($_POST['quiz-group']))
				{
				  $GroupLists = $_POST['quiz-group'];
			
					foreach($GroupLists as $key=> $listrow){
						if($listrow['option1']=='' && $listrow['answer2']!=''){
							$listrow['question1']=$listrow['question2'];
							$listrow['que_order']=$listrow['que_order2'];
							$listrow['option1']='Yes';
							$listrow['option2']='No';
							$listrow['answer']=$listrow['answer2'];
						}					
						$insert_data = array(
								'language_id'=>$this->session->userdata('lang_id'),
								'question'  => $listrow['question1'],
								'option1'  => $listrow['option1'],
								'option2'  => $listrow['option2'],
								'option3' => $listrow['option3'],
								'option4' => $listrow['option4'],
								'answer'     => $listrow['answer'],
								'que_order'     => $listrow['que_order'],
								'quiz_id'     => $quiz_id,
								'created_on'      => date('Y-m-d H:i:s')
						);
						if($listrow['answer']!=''){
							$this->Quiz_model->question_bank($insert_data);
						}	
					}						
					$this->session->unset_userdata('quiz_mode');
				}
				if($quiz_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}				
				redirect(base_url() . "backoffice/quiz/view");
				
			}
			$this->load->view('backoffice/quiz/add', $data);
	} //end of add  functionality

	public function edit($quiz_id)
	{

		  $data=array();
		  //$data['title'] = title." ".$this->lang->line('add_quiz_title')."";
		  $data['title'] = "Edit Quiz";
		  //$data['main_heading'] = $this->lang->line('quiz_title');
		  $data['main_heading'] = "Quiz";
		  //$data['heading'] = $this->lang->line('add_quiz_title');
		  $data['heading'] = "Edit Quiz";
		  $data['already_msg'] = "";
		  
		  $data['row'] = $this->Quiz_model->fetch_quiz($quiz_id); 
		  $data['results'] = $this->Quiz_model->fetch_quiz_questions($quiz_id); 
		 
		
		  
		  $this->form_validation->set_rules('quiz_status', 'Quiz Status', 'required|trim');  
		  $this->form_validation->set_rules('quiz_name', 'Quiz Name', 'required|trim');
		  $this->form_validation->set_rules('location_id', 'Location', 'required|trim');  
		  
		  $this->form_validation->set_rules('audio_status', 'Audio Status', 'required|trim');  		  $this->form_validation->set_rules('manual_type_status', 'Manual Type Status', 'required|trim');  		  
		  $this->form_validation->set_rules('automatic_type_status', 'Automatic Type Status', 'required|trim');  	
		  $this->form_validation->set_rules('rapid_type_status', 'Rapid Type Status', 'required|trim');
		  
		  if ($this->form_validation->run()) {
				/* echo "<pre>";
				print_r($_POST);
				die; */ 
				$this->Quiz_model->manage_quiz_settings($quiz_id);
				
				if(isset($_POST['quiz-group']) && !empty($_POST['quiz-group']))
				{
					
				  $GroupLists = $_POST['quiz-group'];
				 
					foreach($GroupLists as $key=> $listrow){
						if($listrow['option1']=='' && $listrow['answer2']!=''){
							$listrow['question']=$listrow['question2'];
							$listrow['que_order']=$listrow['que_order2'];
							$listrow['option1']='Yes';
							$listrow['option2']='No';
							$listrow['answer']=$listrow['answer2'];
						}					
						$update_data = array(
								'language_id'=>$this->session->userdata('lang_id'),
								'question'  => $listrow['question'],
								'option1'  => $listrow['option1'],
								'option2'  => $listrow['option2'],
								'option3' => $listrow['option3'],
								'option4' => $listrow['option4'],
								'answer'     => $listrow['answer'],
								'que_order'     => $listrow['que_order'],
								'quiz_id'     => $quiz_id,
								'created_on'      => date('Y-m-d H:i:s')
						);
						if($listrow['answer']!=''){
							$this->Quiz_model->question_bank($update_data);
						}	
					}						
				}
				 
				if(isset($_POST['old-quiz-group']) && !empty($_POST['old-quiz-group']))
				{
				  $GroupOldLists = $_POST['old-quiz-group'];
					foreach($GroupOldLists as $key=> $listrow){	
						if($listrow['option1']=='' && $listrow['answer2']!=''){
							$listrow['que_order']=$listrow['que_order2'];
							$listrow['option1']='Yes';
							$listrow['option2']='No';
							$listrow['answer']=$listrow['answer2'];
						}			
						
						$update_data = array(
								'question_id'=>$listrow['question_id'],
								'question'  => $listrow['question'],
								'option1'  => $listrow['option1'],
								'option2'  => $listrow['option2'],
								'option3' => $listrow['option3'],
								'option4' => $listrow['option4'],
								'answer'     => $listrow['answer'],
								'que_order'     => $listrow['que_order']
						);
						if($listrow['answer']!=''){ 
							$this->Quiz_model->update_question_bank($update_data);
						}	
					}						
				}	
				
				$msg = "Record Updated";
			    $this->session->set_flashdata('success_message', $msg);					
				redirect(base_url() . "backoffice/quiz/view");
				
			}
			$this->load->view('backoffice/quiz/edit', $data);
	} //end of add  functionality
	function deletequestion($quiz_id,$question_id){
		
		$result = $this->Quiz_model->deletequestion($question_id);

		 if($result=='1')

		 {

		   $this->session->set_flashdata('success_message', 'Record has been deleted');

		 }

		 else

		 {

			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));

		 }

		 redirect(base_url() . "backoffice/quiz/edit/".$quiz_id);	
	}
}	
?>