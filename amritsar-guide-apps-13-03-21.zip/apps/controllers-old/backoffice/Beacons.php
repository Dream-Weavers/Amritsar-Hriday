<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Beacons extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/beacons_model');
		$this->load->helper("file");
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->original_path = realpath('assets/beacons/original');
	}
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_beacon_title')."";
	    $data['main_heading'] = $this->lang->line('beacon_title');
	    $data['heading'] = $this->lang->line('view_beacon_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('beacon_id'))
			 $beacon_id = $this->input->post('beacon_id');
		 elseif($this->uri->segment('4'))
			 $beacon_id=$this->uri->segment('4');
		else
			 $beacon_id='0';
	
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('5'))
			 $status=$this->uri->segment('5');
		else
			 $status='0';	 
		
		$per_page=200;	
		
		/* if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=200; */	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/beacons/view/".$beacon_id."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->beacons_model->count_beacons($beacon_id,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(7)) ? $this->uri->segment(7) : 0; 
		$data['results'] = $this->beacons_model->view_beacons($beacon_id,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['beacon_id'] = $beacon_id;
		$data['status'] = $status;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/beacons/view.php', $data);
		}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_beacon_title')."";
		  $data['main_heading'] = $this->lang->line('beacon_title');
		  $data['heading'] = $this->lang->line('add_beacon_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('beacon_unique_id', ''.$this->lang->line('beacon_unique_id_text').'', 'required|trim');
		  $this->form_validation->set_rules('beacon_name', ''.$this->lang->line('beacon_name_text').'', 'required|trim');
		
		 if ($this->form_validation->run()) {
		     
            /*if (empty($_FILES['beacon_img']['name'])) {
                $this->session->set_flashdata('error_message', "Please select beacon image");
                redirect(base_url() . 'backoffice/beacons/add');
            }*/
		    
		  $feilds = array('beacon_unique_id' =>trim($this->input->post('beacon_unique_id')));
		  $result = check_unique('beacons',$feilds);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('beacon_unique_id'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {   
		      $beacon_id =  $this->beacons_model->add();
		        $beacon_img= count($_FILES['beacon_img']['name']);
			    
				if($_FILES['beacon_img']['name']!=''){	
				
					
					
					//$beacon_id=1;
					$config['upload_path'] = $this->original_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					$file_name = time().'_'.$beacon_id.'_'.$_FILES['beacon_img']['name'];	
					$config['file_name'] =$file_name;	
					//print 'dfs';die;
					if($_FILES['beacon_img']['error']!='4'){
					  $this->upload->initialize($config);
					  $this->upload->do_upload('beacon_img');
					    if(!$this->upload->do_upload('beacon_img'))
                        { 
                            $data['imageError'] =  $this->upload->display_errors();
                            //print 'dfdsf';
                        }
                        else
                        {
                            $imageDetailArray = $this->upload->data();
                            $image =  $imageDetailArray['file_name'];
                            $beacon_update =  $this->beacons_model->update_beacon_img($beacon_id,$image);
                        } 
					}  
				}
		      //die;
		      				 
			   if($beacon_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/beacons/view');
 		  }
	    } //end of add  functionality
	
	   $this->load->view('backoffice/beacons/add.php', $data);
	}
	
	public function edit($beacon_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_beacon_title')."";
		  $data['main_heading'] = $this->lang->line('beacon_title');
		  $data['heading'] = $this->lang->line('edit_beacon_title');
		  $data['already_msg'] = "";
		  
  		  $this->form_validation->set_rules('beacon_unique_id', ''.$this->lang->line('beacon_unique_id_text').'', 'required|trim');
		  $this->form_validation->set_rules('beacon_name', ''.$this->lang->line('beacon_name_text').'', 'required|trim');
	
		if ($this->form_validation->run()) {
		  // Update records 
		  $feild = array('beacon_unique_id' =>trim($this->input->post('beacon_unique_id')));
		  $unique_id = array('beacon_id' =>$beacon_id);
		  $result = check_unique_edit('beacons',$feild,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('beacon_unique_id'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		      //$result =  $this->beacons_model->update_beacon($this->input->post('beaconid'));
		      $result =  $this->beacons_model->update_beacon($beacon_id);
		      
		      if($_FILES['beacon_img']['name']!=''){	
				
					
					//$beacon_id =  $this->input->post('beaconid');
					//print $beacon_id;die;
					$config['upload_path'] = $this->original_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;
					$file_name = time().'_'.$beacon_id.'_'.$_FILES['beacon_img']['name'];	
					$config['file_name'] =$file_name;	
					//print 'dfs';die;
					if($_FILES['beacon_img']['error']!='4'){
					  $this->upload->initialize($config);
					  $this->upload->do_upload('beacon_img');
					    if(!$this->upload->do_upload('beacon_img'))
                        { 
                            $data['imageError'] =  $this->upload->display_errors();
                            //print 'dfdsf';
                        }
                        else
                        {
                            $imageDetailArray = $this->upload->data();
                            $image =  $imageDetailArray['file_name'];
                            $beacon_update =  $this->beacons_model->update_beacon_img($beacon_id,$image);
                        } 
					}  
				}
		      
		      if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/beacons/view");
		  }
		}		
		  $result =  $this->beacons_model->beacon_edit($beacon_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/beacons/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	
	public function status($beacon_id,$status)
	{	 // Update status  
	     $result = $this->beacons_model->update_status($beacon_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/beacons/view");		
		 
	}//end of Status  functionality*/
	
	
}	
?>