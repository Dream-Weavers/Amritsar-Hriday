<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Rules extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/rules_model');
		$this->load->helper('string');
	}
	
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." Rules";
	    $data['main_heading'] = "View Rules";
	    $data['heading'] = "View Rules";
		
	   //print_r($_POST);	
	    if($this->input->post('rule_id'))
			 $rule_id = $this->input->post('rule_id');
		 elseif($this->uri->segment('4'))
			 $rule_id=$this->uri->segment('4');
		else
			 $rule_id='0';
	
	
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('5'))
			$per_page=$this->uri->segment('5');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/rules/view/".$rule_id."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 6;
		$config["total_rows"] =$this->rules_model->count_rules($rule_id);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0; 
		$data['results'] = $this->rules_model->view_rules($rule_id,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['rule_id'] = $rule_id;
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/rules/view.php', $data);
		}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = title." Add Rule";
		  $data['main_heading'] = "Add Rule";
		  $data['heading'] = "Add Rule";
		  $data['already_msg'] = "";
		  
		   $this->form_validation->set_rules('rule_name', 'Rule name', 'required|trim');
		   $this->form_validation->set_rules('description', 'Description', 'trim');
		   if($this->input->post('choose_category_type')=='1')
		   $this->form_validation->set_rules('category_type_id[]', 'Category Types', 'required|trim');
		   if($this->input->post('choose_category')=='2')
		   $this->form_validation->set_rules('category_id[]', 'Categories', 'required|trim');
		  // if($this->input->post('choose_locations')=='3')
		   //$this->form_validation->set_rules('location_id[]', 'Locations', 'required|trim');
		   if($this->input->post('choose_vendors')=='4')
		   $this->form_validation->set_rules('vendor_id[]', 'Vendors', 'required|trim');
		 
		 if ($this->form_validation->run()) {
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'rule_name' =>trim($this->input->post('rule_name')));
		  $result = check_unique('rules',$feilds);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('rule_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {    $rule_id=  $this->rules_model->add();	
		  
				  if($rule_id=='0')
				  {
				    $msg = "There is some error in Save Rules Data.";
				    $this->session->set_flashdata('warning_message', $msg);
				  }
				  else  
				  {
				    $msg = "Rules have been created successfully.";
				    $this->session->set_flashdata('success_message', $msg);
				  }
				redirect(base_url() . 'backoffice/rules/view');
 		  }
	    } //end of add  functionality
	
	   $data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
	   $category_ids=array();
		if(!empty($_POST['location_category'])){
			foreach($_POST['location_category'] as $key=>$val){
				$category_ids[] = $val;
			}
			$categoryids =  implode(',',$category_ids);
		} else  {
			$categoryids =  '';
		}
		
		$data['category_ids'] = $categoryids;
	   $this->load->view('backoffice/rules/add.php', $data);
	}
	
	public function edit($rule_id){
		
		  $data=array();
		  $data['title'] = title." Edit Rule";
		  $data['main_heading'] = "Edit Rule";
		  $data['heading'] = "Edit Rule";
		  $data['already_msg'] = "";
		  
  		   $this->form_validation->set_rules('rule_name', 'Rule name', 'required|trim');
		   $this->form_validation->set_rules('description', 'Description', 'trim');
		   if($this->input->post('choose_category_type')=='1')
		   $this->form_validation->set_rules('category_type_id[]', 'Category Types', 'required|trim');
		   if($this->input->post('choose_category')=='2')
		   $this->form_validation->set_rules('category_id[]', 'Categories', 'required|trim');
		   //if($this->input->post('choose_locations')=='3')
		  // $this->form_validation->set_rules('locationid[]', 'Locations', 'required|trim');
		   if($this->input->post('choose_vendors')=='4')
		   $this->form_validation->set_rules('vendor_id[]', 'Vendors', 'required|trim');
	
		if ($this->form_validation->run()) {
		  // Update records 
		  $feilds = array('language_id' =>$this->session->userdata('lang_id'),'rule_name' =>trim($this->input->post('rule_name')));
		  $unique_id = array('rule_id' =>$rule_id);
		  $result = check_unique_edit('rules',$feilds,$unique_id);
		  if($result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('rule_name'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		      $result =  $this->rules_model->update_rule($this->input->post('rule_id'));
			  if($result=='0')
			  {
				$msg = "There is some error in Update Rules Data.";
				$this->session->set_flashdata('warning_message', $msg);
			  }
			  else  
			  {
			    $msg = "Rules records been updated successfully.";
				$this->session->set_flashdata('success_message', $msg);
			  }
				  
		     redirect(base_url() . "backoffice/rules/view/".$this->input->post('rule_id')."");
		  }
		}		
		  $result =  $this->rules_model->rule_edit($rule_id);
		  $data['edit_data'] = $result;
		 
		  $this->load->view('backoffice/rules/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	
	public function status($ad_id,$status)
	{	 // Update status  
	     $result = $this->rules_model->update_status($ad_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/rules/view");		
		 
	}//end of Status  functionality*/
	
	
	
	public function update_default_rule($rule_id)
	{	 // Update status  
	     $result = $this->rules_model->update_default_rule($rule_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', 'Default rule has been updated successfully.');
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', 'There is some error in rule updation.');
		 }
		  redirect($_SERVER['HTTP_REFERER']);
		 
	}//end of Status  functionality*/
	
	
  public function delete_rule_location($rule_interlink_id)
	{	 // Update status  
	     $result = $this->rules_model->delete_rule_location($rule_interlink_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', 'Record has been deleted successfully.');
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', 'There is some error.');
		 }
		  redirect($_SERVER['HTTP_REFERER']);
		 
	}//end of Status  functionality*/
	
	
}	
?>