<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Roles extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('backoffice/Role_model');
	}
	public function index(){
	    $data['title']        = "View Roles";
		$data['already_msg'] = "";	
		$data['main_heading'] = "Roles";	
		$data['heading']      = "View Roles";	
		/********Get Roles Records********/	
		$data['results']      = $this->Role_model->viewRoles();
		$data['num_rows']     = isset($data['results'])?count($data['results']):0;
	   $this->load->view('backoffice/roles/view',$data);	
	}//End of Index
	
	public function add($roleId=NULL){
		$this->add_edit_roles($roleId);	
	}
	
	public function edit($roleId=NULL){
		$this->add_edit_roles($roleId);	
	}
	public function add_edit_roles($roleId=NULL){
		  $data['main_heading'] = "Role";
		  $data['heading']      = ($roleId=='')? "Add Role" : "Edit Role";
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $roleAdminUserName = '';
		  $roleName          = '';
		  $description          = '';
		  $parentId          = '';
		  $user_rights     = '';
		 
		  $roleId = ($roleId!='') ? $roleId : 0;
		  $this->Role_model->roleId   = $roleId;
		  $role_records_array = array();
	      if($roleId!='0'){
	   		$role_records_array = $this->Role_model->editRoleData(); 
			/*******Assign fetched record to variables to set value of input box******/
			$roleName	= $role_records_array->role_name;
			$description	= $role_records_array->description;
			$user_rights      = $role_records_array->permission_access;
	      }
		 
		 if($this->input->post()){
			$roleName = isset($_POST['role_name'])? $_POST['role_name']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			$parentId = isset($_POST['parentId'])? $_POST['parentId']: '';
			$user_rights 		    = isset($_POST['user_rights']) 	? $_POST['user_rights']	: '';
			
			 /********Check validations************/
			  if($roleId==0){
				$this->form_validation->set_rules('role_name', 'Role Name', 'required|is_unique[roles.role_name]');
				$this->form_validation->set_rules('description', 'Description', 'required');
			  }
			  elseif($roleId!=0){
				$error_msg='';
				$this->form_validation->set_rules('role_name', 'Role Name', 'required');
				/*****Validation for unique role name*************/
				$count_name = check_unique_edit('roles','role_name',$roleName,'roleId',$roleId);
				if($count_name > '0')
				$error_msg .= 'Role Name already exists.';
			  }
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
				/*****Assign posted value to model's variable******/
				$this->Role_model->roleName      			= $roleName;
				$this->Role_model->description      			= $description;
				$this->Role_model->parentId      			= $parentId;
				$this->Role_model->user_rights 	 = implode(',',$user_rights);
				
				if($roleId==0)
					$result = $this->Role_model->addRole();
				else
					$result = $this->Role_model->editRole();

				if($roleId==0)
					$this->session->set_flashdata('success_message', 'Role has been added.');
				else
					$this->session->set_flashdata('success_message', 'Role has been updated.');
				
			      redirect(base_url() . 'backoffice/Roles');
	    } 
				else{
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
	   $data['roleId']    				= $roleId;		
	   $data['roleName']  				= $roleName;	
	   $data['description']  				= $description;	
	   $data['parentId']  				= $parentId;	
	   $data['user_rights']      = $user_rights;
	   $this->load->view('backoffice/roles/add_edit_roles',$data);	
	}
}
