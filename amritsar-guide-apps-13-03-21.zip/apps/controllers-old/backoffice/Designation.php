<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Designation extends CI_Controller {
public function __construct()
	{
		parent:: __construct();	
		validateAccess();
		$this->load->model('backoffice/Designation_model');
	}

	public function index()
	{
		$data=array();
		$data['title'] = "Designation";
		$data['main_heading'] ="Designation";
		$data['heading'] = "Designation";
		$data['already_msg']=""; 
		//$data['search_keyword'] = $this->input->post("search_keyword");	 
		$results = $this->Designation_model->view_designation();

	
		  $this->form_validation->set_rules('designation_name', 'Designation Name', 'required|trim');
	      if ($this->form_validation->run()) {
		
		   $designation_id =  $this->Designation_model->add();
	
		  
			if($designation_id!='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
			} else {
				   $msg=  "Designation already exists or some other error, please try again!";
				   $this->session->set_flashdata('error_message', $msg);
			}
		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/designation');  
	    } //end of add  functionality
		
 		$data['results'] = $results;

		//$num_rows = count($results);	
		//$data['num_rows'] = $num_rows; 
		

		$data['header'] = '';
		$data['title']="Designation";
		$data['short_desc']="Show All Designations";
		$this->load->view('backoffice/designation/view',$data);
		
    } //end of view functionality
	
	public function add()
	{
		   $data['title'] = $this->lang->line('add_designation_name');
		  $data['main_heading'] ="Designation";
		  $data['heading'] = $this->lang->line('add_designation_name');
		  $data['already_msg']="";
		  
	
		  $this->form_validation->set_rules('designation_name', 'Designation Name', 'required|trim');
		  if ($this->form_validation->run()) {
		
		   $designation_id =  $this->Designation_model->add();

		   
			if($designation_id!='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
			} else {
				   $msg=  "Designation already exists or some other error, please try again!";
				   $this->session->set_flashdata('error_message', $msg);
			}
		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/designation/add');  
		  
			
			
	    } //end of add  functionality

		$data['header'] = '';
		$data['title']="Designation";
		$data['short_desc']="Designation";
		$this->load->view('backoffice/designation/add',$data); 
	}

	
	public function edit($designation_id){
		
		  $data['title'] = "Edit Designation";
		  $data['main_heading'] ="Edt Designation";
		  $data['heading'] = "Edit Designation";
          $data['already_msg']="";
		  

		  
		  $results = $this->Designation_model->fetchdesignation($designation_id);
		  $data['edit_data'] = $results;
			
		  $this->form_validation->set_rules('designation_name', 'Designation Name', 'required|trim');
		  if ($this->form_validation->run()) {
			  // Update records 
	  
			  
			   $result =  $this->Designation_model->update_designation($designation_id);
			   
			  
				if($result=='1') {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg=  "Designation already exists or some other error, please try again!";
				   $this->session->set_flashdata('error_message', $msg);
				}
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/designation");
			  
		  }
		  
		$data['header'] = '';
		$data['title']=$this->lang->line('edit_designation_name');
		$data['short_desc']=$this->lang->line('edit_designation_name');
		$this->load->view('backoffice/designation/edit',$data);
		 
	}//end of Edit functionality*/
	
	public function status($designation_id,$status)
	{	 // Update status  
	     $result = $this->Designation_model->update_status($designation_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', "Status has been changed successfully");
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', "There is some issue, please try again!");
		 }
		  redirect(base_url() . "backoffice/designation");		
		 
	}//end of Status  functionality*/
}	
?>