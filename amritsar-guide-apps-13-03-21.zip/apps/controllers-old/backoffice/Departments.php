<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Departments extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		valid_logged_in(FALSE,'A');	
		//check_permissions();
		time_zone();
		$this->load->model('backoffice/departments_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->original_path = realpath('assets/static/user_photos/original');
	   	$this->resized_path = realpath('assets/static/user_photos/resized');
	}
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." Departments Users ";
	    $data['main_heading'] = "Departments Users";
	    $data['heading'] = "Departments Users";
		
	   //print_r($_POST);	
	    if($this->input->post('user_id'))
			 $user_id = $this->input->post('user_id');
		 elseif($this->uri->segment('4'))
			 $user_id=$this->uri->segment('4');
		else
			 $user_id='0';
		
	  if($this->input->post('designation_id'))
			$designation_id = $this->input->post('designation_id');
		 elseif($this->uri->segment('5'))
			$designation_id=$this->uri->segment('5');
		else
			$designation_id='0';
					
	   if($this->input->post('role_id'))
			$role_id = $this->input->post('role_id');
		 elseif($this->uri->segment('6'))
			$role_id=$this->uri->segment('6');
		else
			$role_id='0';
		
		if($this->input->post('search_by'))
			$search_by = $this->input->post('search_by');
		elseif($this->uri->segment('7'))
			$search_by=$this->uri->segment('7');
		else
			$search_by='0';
			
		if($this->input->post('search_value'))
			$search_value = trim($this->input->post('search_value'));
		elseif($this->uri->segment('8'))
			$search_value=trim($this->uri->segment('8'));
		else
			$search_value='0';
		
		if($this->input->post('status'))
			$status = $this->input->post('status');
		 elseif($this->uri->segment('9'))
			 $status=$this->uri->segment('9');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('10'))
			$per_page=$this->uri->segment('10');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "backoffice/departments/view/".$designation_id."/".$role_id."/".$search_by."/".$search_value."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 11;
		$config["total_rows"] =$this->departments_model->count_departments($designation_id,$role_id,$search_by,$search_value,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(11)) ? $this->uri->segment(11) : 0; 
		$data['results'] = $this->departments_model->view_departments($designation_id,$role_id,$search_by,$search_value,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['designation_id'] = $designation_id;
		$data['role_id'] = $role_id;
		$data['status'] = $status;
		$data['search_by'] = $search_by;	
		$data['search_value'] = $search_value;	
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('backoffice/departments/view.php', $data);
		}
	
	
	public function add()
	{
		  $data=array();
		  $data['title'] = title." Create Department User";
		  $data['main_heading'] = "Department Users";
		  $data['heading'] = " Create Department User";
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('department_id',''.$this->lang->line('user_department_text').'', 'trim|required');
		  $this->form_validation->set_rules('first_name', ''.$this->lang->line('user_first_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('last_name', ''.$this->lang->line('user_last_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('email', ''.$this->lang->line('user_primary_email_text').'', 'required|trim|valid_email');
		  $this->form_validation->set_rules('role_id',''.$this->lang->line('user_role_text').'', 'trim|required');
		  $this->form_validation->set_rules('mobile_no1', ''.$this->lang->line('user_primary_mobile_text').'', 'required|numeric|min_length[10]');
		  $this->form_validation->set_rules('userpass', ''.$this->lang->line('user_password_text').'', 'required|trim|min_length[3]|matches[compass]');
		  $this->form_validation->set_rules('compass', ''.$this->lang->line('user_confirm_password_text').'', 'required|trim');
		  $this->form_validation->set_rules('expiry_date', ''.$this->lang->line('user_valid_upto_text').'', 'required|trim');
		  $this->form_validation->set_rules('country_id', ''.$this->lang->line('user_country_text').'', 'required|trim');
		  $this->form_validation->set_rules('state_id', ''.$this->lang->line('user_state_text').'', 'required');
		  $this->form_validation->set_rules('city_id', ''.$this->lang->line('user_city_text').'', 'required');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('user_pin_code_text').'', 'trim|numeric|min_length[4]');
		  $this->form_validation->set_rules('alternate_email', ''.$this->lang->line('user_alternate_email_text').'', 'trim|valid_email');
		  $this->form_validation->set_rules('mobile_no2', ''.$this->lang->line('user_primary_mobile_text').'', 'numeric|min_length[10]');
		  $this->form_validation->set_rules('landline_no', ''.$this->lang->line('user_landline_text').'', 'trim|min_length[6]');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('user_address_text').'', 'trim');
		   
		  if($this->input->post('designation_id')=='1')
		  $this->form_validation->set_rules('designation_name',''.$this->lang->line('user_other_designation_text').'', 'trim|required');
		  if($this->input->post('designation_id')=='1')
		  $this->form_validation->set_rules('department_name',''.$this->lang->line('user_other_department_text').'', 'trim|required');
		  
		 if ($this->form_validation->run()) {
		  $emailfeilds = array('email' =>trim($this->input->post('email')),'user_type'=>'E');
		  $emailresult = check_unique('users',$emailfeilds);
		  
		  $mobilefeilds = array('mobile_no1' =>trim($this->input->post('mobile_no1')),'user_type'=>'E');
		  $mobileresult = check_unique('users',$mobilefeilds);
		  
		  if($emailresult==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('email'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  elseif($mobileresult==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('mobile_no1'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  else
		  {
		          $user_id =  $this->departments_model->add();				 
				  if($_FILES['user_photo']['error'] != 4){		
					  $config['upload_path'] = $this->original_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  $config['max_width']  = '0';
					  $config['max_height']  = '0';
					  $config['overwrite'] = true;			
					  $config['file_name'] =$user_id.'-'.$_FILES['user_photo']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('user_photo')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			      else{
					 $data = $this->upload->data();
					 $file_name = $data['file_name'];
					 $original_path = $data['full_path'];
					 $image_thumb  =$this->resized_path.'/'.$file_name;
					 $config1['image_library']    = 'gd2';
					 $config1['source_image']     = $original_path;
					 $config1['new_image']        = $image_thumb;
					 $config1['maintain_ratio']   = TRUE;
					 $config1['height']              = 150;
					 $config1['width']              = 150;
					 $this->image_lib->initialize( $config1);
					 $this->image_lib->resize();
					 $this->image_lib->clear();									
					 $result_photo = $this->departments_model->update_photo($user_id,$file_name);
			     }
		       }
			   if($user_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/departments/view');
 		  }
	    } //end of add  functionality
			
		$data['country_id'] = isset($_POST['country_id']) ? $_POST['country_id'] : 101;
		$data['state_id'] = isset($_POST['state_id']) ? $_POST['state_id'] : 0;
		$data['city_id'] = isset($_POST['city_id']) ? $_POST['city_id'] : 0;
		  
	   $this->load->view('backoffice/departments/add.php', $data);
	}
	
	public function edit($user_id){
		
		  $data['title'] = title." Edit Department User ";
		  $data['main_heading'] = "Department Users";
		  $data['heading'] = " Edit Department User ";
		  $data['already_msg'] = "";
		  
  		  $this->form_validation->set_rules('department_id',''.$this->lang->line('user_department_text').'', 'trim|required');
		  $this->form_validation->set_rules('first_name', ''.$this->lang->line('user_first_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('last_name', ''.$this->lang->line('user_last_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('email', ''.$this->lang->line('user_primary_email_text').'', 'required|trim|valid_email');
		  $this->form_validation->set_rules('role_id',''.$this->lang->line('user_role_text').'', 'trim|required');
		  $this->form_validation->set_rules('mobile_no1', ''.$this->lang->line('user_primary_mobile_text').'', 'required|numeric|min_length[10]');
		  $this->form_validation->set_rules('userpass', ''.$this->lang->line('user_password_text').'', 'required|trim|min_length[3]|matches[compass]');
		  $this->form_validation->set_rules('compass', ''.$this->lang->line('user_confirm_password_text').'', 'required|trim');
		  $this->form_validation->set_rules('expiry_date', ''.$this->lang->line('user_valid_upto_text').'', 'required|trim');
		  $this->form_validation->set_rules('country_id', ''.$this->lang->line('user_country_text').'', 'required|trim');
		  $this->form_validation->set_rules('state_id', ''.$this->lang->line('user_state_text').'', 'required');
		  $this->form_validation->set_rules('city_id', ''.$this->lang->line('user_city_text').'', 'required');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('user_pin_code_text').'', 'trim|numeric|min_length[4]');
		  $this->form_validation->set_rules('alternate_email', ''.$this->lang->line('user_alternate_email_text').'', 'trim|valid_email');
		  $this->form_validation->set_rules('mobile_no2', ''.$this->lang->line('user_primary_mobile_text').'', 'numeric|min_length[10]');
		  $this->form_validation->set_rules('landline_no', ''.$this->lang->line('user_landline_text').'', 'trim|min_length[6]');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('user_address_text').'', 'trim');
		   
		  if($this->input->post('designation_id')=='1')
		  $this->form_validation->set_rules('designation_name',''.$this->lang->line('user_other_designation_text').'', 'trim|required');
		  if($this->input->post('designation_id')=='1')
		  $this->form_validation->set_rules('department_name',''.$this->lang->line('user_other_department_text').'', 'trim|required');
		  
		if ($this->form_validation->run()) {
		  // Update records 
		  $email_feild = array('email' =>trim($this->input->post('email')),'user_type'=>'E');
		  $unique_id = array('user_id' =>$user_id);
		  $email_result = check_unique_edit('users',$email_feild,$unique_id);
		  
		  $mobile_feild = array('mobile_no1' =>trim($this->input->post('mobile_no1')),'user_type'=>'E');
		  $unique_id = array('user_id' =>$user_id);
		  $mobile_result = check_unique_edit('users',$mobile_feild,$unique_id);
		  if($email_result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('email'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		  elseif($mobile_result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('mobile_no1'), $this->lang->line('already_exists_text'));
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		        $result =  $this->departments_model->update_user($this->input->post('user_id'),$this->input->post('user_address_id'));
		        if($_FILES['user_photo']['error'] != 4){		
				  $config['upload_path'] = $this->original_path;
				  $config['allowed_types'] = 'jpeg|gif|jpg|png';
				  $config['max_size']	= '20000000000';
				  $config['max_width']  = '0';
				  $config['max_height']  = '0';
				  $config['overwrite'] = true;			
				  $config['file_name'] =$user_id.'-'.$_FILES['user_photo']['name'];
				  $this->upload->initialize($config);
				
				if ( ! $this->upload->do_upload('user_photo')){
					
					echo $data['already_msg']=$this->upload->display_errors();die;
					$success = FALSE;
				} else {  
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$original_path = $data['full_path'];
					$image_thumb  =$this->resized_path.'/'.$file_name;
					
					$config1['image_library']    = 'gd2';
					$config1['source_image']     = $original_path;
					$config1['new_image']        = $image_thumb;
					$config1['maintain_ratio']   = TRUE;
					$config1['height']              = 150;
					$config1['width']              = 150;
					$this->image_lib->initialize( $config1);
					$this->image_lib->resize();
					$this->image_lib->clear();									
					$result_photo = $this->departments_model->update_photo($user_id,$file_name);
				}
			 }
		      if($result=='1')
				{   
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "backoffice/departments/view/".$this->input->post('user_id'));
		  }
		}		
		  $result =  $this->departments_model->user_edit($user_id);
		  $data['edit_data'] = $result;
		  $data['country_id'] = isset($result->country_id) ? $result->country_id : 0;
		  $data['state_id'] = isset($result->state_id) ? $result->state_id : 0;
		  $data['city_id'] = isset($result->city_id) ? $result->city_id : 0;
		  
		  $this->load->view('backoffice/departments/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	
	public function status($user_id,$status)
	{	 // Update status  
	     $result = $this->departments_model->update_status($user_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		  redirect(base_url() . "backoffice/departments/view");		
		 
	}//end of Status  functionality*/
	
	
}	
?>