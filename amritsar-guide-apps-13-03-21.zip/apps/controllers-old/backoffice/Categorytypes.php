<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categorytypes extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('backoffice/Categorytype_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->icon_path = realpath('images/categorytype-icons/');
	}
	public function index(){
	    $data['title'] = $this->lang->line('category_types_title');
		$data['main_heading'] =$this->lang->line('show_all_category_types_title');
		$data['heading'] = $this->lang->line('category_types_title');
		$data['already_msg']=""; 
		/********Get CategoryTypes Records********/	
		$data['results']      = $this->Categorytype_model->viewCategoryTypes();
		$data['num_rows']     = isset($data['results'])?count($data['results']):0;
		$lang=$this->session->userdata('lang_id');
		$languageinfo=$this->Categorytype_model->language_info($lang);
		$data['cur_lang']=$lang;
		$data['lang_data']=$languageinfo;
	   $this->load->view('backoffice/category-types/view',$data);	
	}//End of Index
	
	public function add($category_type_id=NULL){
		$this->add_edit_categorytypes($category_type_id);	
	}
	
	public function edit($category_type_id=NULL){
		$this->add_edit_categorytypes($category_type_id);	
	}
	
	public function cropped_image532()

    {
        $data = $_POST['image'];

     

        list($type, $data) = explode(';', $data);

        list(, $data)      = explode(',', $data);

     

        $data = base64_decode($data);
		$_SESSION['cropped_image532']=$data;
        //$imageName = time().'.png';

       // file_put_contents('upload/'.$imageName, $data);

     

        echo 'done';

    }
	
	public function cropped_image1600()

    {
        $data = $_POST['image'];

     

        list($type, $data) = explode(';', $data);

        list(, $data)      = explode(',', $data);

     

        $data = base64_decode($data);
		$_SESSION['cropped_image1600']=$data;
        //$imageName = time().'.png';

       // file_put_contents('upload/'.$imageName, $data);

     

        echo 'done';

    }
	
	public function add_edit_categorytypes($category_type_id=NULL){
		  $data['main_heading'] = $this->lang->line('category_types_title');
		  $data['heading']      = ($category_type_id=='')? $this->lang->line('add_category_type_title'): $this->lang->line('edit_category_type_title');
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $project_id = '';
		  $category_type = '';
		  $description = '';
		  $picture_min_limit = '';
		  $video_min_limit = '';
		  $panorama_min_limit = '';
		  $audio_min_limit = '';
		  $picture_max_limit = '';
		  $video_max_limit = '';
		  $panorama_max_limit = '';
		  $audio_max_limit  = '';
		 
		  $category_type_id = ($category_type_id!='') ? $category_type_id : 0;
		  $this->Categorytype_model->category_type_id   = $category_type_id;
		  $categorytype_records_array = array();
	      if($category_type_id!='0'){
	   		$categorytype_records_array = $this->Categorytype_model->editCategoryTypeData(); 
			
			/*******Assign fetched record to variables to set value of input box******/
			$project_id	= $categorytype_records_array->project_id;
			$category_type	= $categorytype_records_array->category_type;
			$icon	= $categorytype_records_array->icon;
			$w_image532	= $categorytype_records_array->w_image532;
			$w_image1600	= $categorytype_records_array->w_image1600;
			$description	= $categorytype_records_array->description;
			$picture_min_limit	= $categorytype_records_array->picture_min_limit;
			$video_min_limit	= $categorytype_records_array->video_min_limit;
			$panorama_min_limit	= $categorytype_records_array->panorama_min_limit;
			$audio_min_limit	= $categorytype_records_array->audio_min_limit;
			$picture_max_limit	= $categorytype_records_array->picture_max_limit;
			$video_max_limit	= $categorytype_records_array->video_max_limit;
			$panorama_max_limit	= $categorytype_records_array->panorama_max_limit;
			$audio_max_limit	= $categorytype_records_array->audio_max_limit;
	      }
		 
		 if($this->input->post()){
			
			$project_id = isset($_POST['project_id'])? $_POST['project_id']: '';
			$category_type = isset($_POST['category_type'])? $_POST['category_type']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			$picture_min_limit = isset($_POST['picture_min_limit'])? $_POST['picture_min_limit']: '';
			$video_min_limit = isset($_POST['video_min_limit'])? $_POST['video_min_limit']: '';
			$audio_min_limit = isset($_POST['audio_min_limit'])? $_POST['audio_min_limit']: '';
			$panorama_min_limit = isset($_POST['panorama_min_limit'])? $_POST['panorama_min_limit']: '';
			$picture_max_limit = isset($_POST['picture_max_limit'])? $_POST['picture_max_limit']: '';
			$video_max_limit = isset($_POST['video_max_limit'])? $_POST['video_max_limit']: '';
			$audio_max_limit = isset($_POST['audio_max_limit'])? $_POST['audio_max_limit']: '';
			$panorama_max_limit = isset($_POST['panorama_max_limit'])? $_POST['panorama_max_limit']: '';
			
			
			 /********Check validations************/
			  if($category_type_id==0){
				$this->form_validation->set_rules('category_type',''.$this->lang->line('category_type_name_text').'', 'required|is_unique[category_types.category_type]');

			  }
			  elseif($category_type_id!=0){
				$this->form_validation->set_rules('category_type',''.$this->lang->line('category_type_name_text').'', 'required');
			  }
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
				/*****Assign posted value to model's variable******/
				$this->Categorytype_model->project_id = $project_id;
				$this->Categorytype_model->category_type = $category_type;
				$this->Categorytype_model->description = $description;
				$this->Categorytype_model->picture_min_limit = $picture_min_limit;
				$this->Categorytype_model->video_min_limit = $video_min_limit;
				$this->Categorytype_model->audio_min_limit = $audio_min_limit;
				$this->Categorytype_model->panorama_min_limit = $panorama_min_limit;
				$this->Categorytype_model->picture_max_limit = $picture_max_limit;
				$this->Categorytype_model->video_max_limit = $video_max_limit;
				$this->Categorytype_model->audio_max_limit = $audio_max_limit;
				$this->Categorytype_model->panorama_max_limit = $panorama_max_limit;
				
				if($category_type_id==0)
					$cat_type_id = $this->Categorytype_model->addCategoryType();
				else
					$cat_type_id = $this->Categorytype_model->editCategoryType();
				
				
				if($_FILES['categorytype_icon']){	
					$config['upload_path'] = $this->icon_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['categorytype_icon']['error']!='4'){
						  if($_FILES['categorytype_icon']['name']!=''){
							$image_id = $this->Categorytype_model->add_icon($cat_type_id,$_FILES['categorytype_icon']['name']);	
						  }
						  $config['file_name'] =$cat_type_id.'_'.$_FILES['categorytype_icon']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('categorytype_icon');
					
						 
						 
					}  
				}
				
				if($_FILES['w_image1600']){		
					if($_FILES['w_image1600']['error']!='4'){
						 

 						  $file_name =$cat_type_id.'_'.$_FILES['w_image1600']['name'];
						  
						  
						  if($_SESSION['cropped_image1600']!='' && $_FILES['w_image1600']['name']!=''){
							  file_put_contents('images/categorytype-icons/1600x740/'.$file_name, $_SESSION['cropped_image1600']);
							  unset($_SESSION['cropped_image1600']);
							  $this->Categorytype_model->update_image($cat_type_id,$_FILES['w_image1600']['name'],'w_image1600');	
						  }
					}
				}
				
				if($_FILES['w_image532']){		
					if($_FILES['w_image532']['error']!='4'){
						 

 						  $file_name =$cat_type_id.'_'.$_FILES['w_image532']['name'];
						  
						  
						  if($_SESSION['cropped_image532']!='' && $_FILES['w_image532']['name']!=''){
							  file_put_contents('images/categorytype-icons/532x460/'.$file_name, $_SESSION['cropped_image532']);
							  unset($_SESSION['cropped_image532']);
							  $this->Categorytype_model->update_image($cat_type_id,$_FILES['w_image532']['name'],'w_image532');	
						  }
					}
				}
				
			    if($category_type_id=='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
			
			      redirect(base_url() . 'backoffice/Categorytypes');
				} 
				else {
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
		
		  $data['category_type_id']= $category_type_id;		
		  $data['project_id']= $project_id;		
		  $data['category_type']=$category_type;
		  $data['icon']=$icon;
		  $data['w_image532']=$w_image532;
		  $data['w_image1600']=$w_image1600;
		  $data['description']=$description ;
		  $data['picture_min_limit']=$picture_min_limit;
		  $data['video_min_limit']=$video_min_limit;
		  $data['panorama_min_limit']=$panorama_min_limit;
		  $data['audio_min_limit']=$audio_min_limit;
		  $data['picture_max_limit']=$picture_max_limit;
		  $data['video_max_limit']=$video_max_limit;
		  $data['panorama_max_limit']=$panorama_max_limit ;
		  $data['audio_max_limit']=$audio_max_limit;
		  
		  $resultnterlinks =  $this->Categorytype_model->edit_category_types_interlinks($category_type_id);
		  $data['edit_data'] = $resultnterlinks;
		 
		/*  print_r($_POST);
		  die();*/
		  
	   $this->load->view('backoffice/category-types/add_edit_category_types',$data);	
	}
	
	function translate_add($language_id,$cat_type_id){
	     $data=array(); 
	    $get_category_type_join=$this->Categorytype_model->get_category_type_info($cat_type_id,$language_id);
	    //print '<pre>';print_r($get_category_type_join);die;
		$data['categorytype_info']=$get_category_type_join;
	   
	    $languageinfo=get_language($language_id);
        $data['title'] = "Add Cayegory Type | ".$get_category_type_join->category_type.' - ('.$languageinfo->language_name.')';
        $data['main_heading'] = "Cayegory Type";
        $data['heading'] = "Add Cayegory Type| ".$get_category_type_join->category_type.' - ('.$languageinfo->language_name.')';
        $data['already_msg'] = "";
        $data['langid']=$language_id;
        $data['productid']=$product_id;
        $data['language_id']=$language_id;
        $data['cat_type_id']=$cat_type_id;
        
        
		$this->form_validation->set_rules('category_type', 'Category type', 'required');
		//$this->form_validation->set_rules('media_copy', 'Media Type', 'required|trim');
		if ($this->form_validation->run()) {
		    //print '<pre>';print_r($_POST);die;
		    
		    
		    
		    $user_id =  $this->Categorytype_model->add_translate($language_id,$cat_type_id);
		   /* if($this->input->post("media_copy")==1){
		        //print 'dsfds';die;
		          $this->Categorytype_model->insertOldDigitalMedia($cat_type_id,$user_id, $get_category_type_join->icon,$this->icon_path);
		    }*/
		    
		    /*if($_FILES['categorytype_icon']){	
					$config['upload_path'] = $this->icon_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['categorytype_icon']['error']!='4'){
						 
						  $config['file_name'] =$user_id.'_'.$_FILES['categorytype_icon']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('categorytype_icon');
						  
						   if ($this->upload->do_upload('categorytype_icon'))
						  {
						   $data['uploads'] = $this->upload->data();
						   $file_name= $data['uploads']['file_name'];
						   	$image_id = $this->Categorytype_model->add_icon($user_id,$file_name);	
						  }
						  
						  
						  
					}  
				}*/
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Category type added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/categorytypes');
		    
		    
		}
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
	
		
        $data['category_ids'] = $categoryids;
        $data['vendor_list']=$vendorlist;
        $this->load->view('backoffice/category-types/translate_add.php', $data);
	    
	}
	
	function edit_translate($language_id,$cat_type_id){
	     $data=array(); 
	    $get_category_type_join=$this->Categorytype_model->get_category_type_info($cat_type_id,$language_id);
	   // print '<pre>';print_r($get_category_type_join);die;
		$data['categorytype_info']=$get_category_type_join;
	   
	    $languageinfo=get_language($language_id);
        $data['title'] = "Edit Category Type | ".$get_category_type_join->category_type.' - ('.$languageinfo->language_name.')';
        $data['main_heading'] = "Category Type";
        $data['heading'] = "Edit Category Type| ".$get_category_type_join->category_type.' - ('.$languageinfo->language_name.')';
        $data['already_msg'] = "";
        $data['langid']=$language_id;
        $data['productid']=$product_id;
        $data['language_id']=$language_id;
        $data['cat_type_id']=$cat_type_id;
        
        
		$this->form_validation->set_rules('category_type', 'Category type', 'required');
		//$this->form_validation->set_rules('media_copy', 'Media Type', 'required|trim');
		if ($this->form_validation->run()) {
		    //print '<pre>';print_r($_POST);die;
		    
		    
		    
		    $user_id =  $this->Categorytype_model->update_translate($cat_type_id,$language_id);
		    
		    /*if($_FILES['categorytype_icon']){	
				$config['upload_path'] = $this->icon_path;
				$config['allowed_types'] = 'jpeg|gif|jpg|png';
				$config['max_size']	= '5120';
				$config['max_width']  = '0';
				$config['max_height']  = '0';
				$config['overwrite'] = true;	
				if($_FILES['categorytype_icon']['error']!='4'){
					  if($_FILES['categorytype_icon']['name']!=''){
						$image_id = $this->Categorytype_model->add_icon($cat_type_id,$_FILES['categorytype_icon']['name']);	
					  }
					  $config['file_name'] =$cat_type_id.'_'.$_FILES['categorytype_icon']['name'];
					  $this->upload->initialize($config);
					  $this->upload->do_upload('categorytype_icon');
					  if ($this->upload->do_upload('categorytype_icon'))
						  {
						   $data['uploads'] = $this->upload->data();
						   $file_name= $data['uploads']['file_name'];
						   	$image_id = $this->Categorytype_model->add_icon($user_id,$file_name);	
						  }
				}  
			}*/
		    
		 
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Category type added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/categorytypes');
		    
		    
		}
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
	
		
        $data['category_ids'] = $categoryids;
        $data['vendor_list']=$vendorlist;
        $this->load->view('backoffice/category-types/edit_translate.php', $data);
	    
	}
}
