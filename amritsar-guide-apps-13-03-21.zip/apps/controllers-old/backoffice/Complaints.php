<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Complaints extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('backoffice/Complaint_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->image_path = realpath('images/complaints/');
	}
	public function index(){
	    $data['pagetitle'] = "Complaints/Feedbacks";
		$data['main_heading'] ="View All";
		$data['heading'] = "Complaints/Feedbacks";
		$data['already_msg']=""; 
		
		if($this->input->post('complaint_type'))
			 $complaint_type = $this->input->post('complaint_type');
		 elseif($this->uri->segment('4'))
			 $complaint_type=$this->uri->segment('4');
		 else
			 $complaint_type='0';
			 
		if($this->input->post('department_id'))
			 $department_id = $this->input->post('department_id');
		 elseif($this->uri->segment('5'))
			 $department_id=$this->uri->segment('5');
		 else
			 $department_id='0';	
		
		if($this->input->post('complaint_status'))
			 $complaint_status = $this->input->post('complaint_status');
		 elseif($this->uri->segment('6'))
			 $complaint_status=$this->uri->segment('6');
		 else
			 $complaint_status='0';	  
		
	    if($this->input->post('title'))
			$title = $this->input->post('title');
		 elseif($this->uri->segment('7'))
			$title=$this->uri->segment('7');
		 else
			$title='0';
		
		
		/********Get Complaints Records********/	
		$per_page=100;	
		$config = array();
		$config["base_url"] = base_url() . "backoffice/complaints/index/".$complaint_type."/".$department_id."/".$complaint_status."/".$title."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 8;
		
        $page = ($this->uri->segment(8)) ? $this->uri->segment(8) : 0;  
		$data['results'] = $this->Complaint_model->viewComplaints($complaint_type,$department_id,$complaint_status,$title,$config['per_page'], $page);
		$config["total_rows"] =count($data['results']);
		$this->pagination->initialize($config);
		
		$data['links']   = $this->pagination->create_links();
		
		
		$data['num_rows'] = $config["total_rows"];
		$data['complaint_type'] = $complaint_type;
		$data['department_id'] = $department_id;
		$data['complaint_status'] = $complaint_status;
		$data['title'] = $title;
	    $this->load->view('backoffice/complaints/view',$data);	
	}//End of Index
	
	
	public function approval(){
	    $data['title'] = "User Submitted Complaints";
		$data['heading'] = "User Submitted Complaints";
		$data['already_msg']=""; 
		
		if($this->input->post('complaint_id'))
			 $complaint_id = $this->input->post('complaint_id');
		 elseif($this->uri->segment('4'))
			 $complaint_id=$this->uri->segment('4');
		 else
			 $complaint_id='0';
			 
			 	 
		
	    if($this->input->post('title'))
			$title = $this->input->post('title');
		 elseif($this->uri->segment('5'))
			$title=$this->uri->segment('5');
		 else
			$title='';
		
		
		/********Get Complaints Records********/	
		$per_page=per_page;	
		$config = array();
		$config["base_url"] = base_url() . "backoffice/complaints/approval/".$complaint_id."/".$title."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		
        $page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;  
		$data['results'] = $this->Complaint_model->viewUserComplaints($complaint_id,$title,$config['per_page'], $page);
		$config["total_rows"] =count($data['results']);
		//$this->Complaint_model->countusercomplaintrecords();
		$this->pagination->initialize($config);
		
		$data['links']   = $this->pagination->create_links();
		
		
		$data['num_rows'] = $config["total_rows"];
	    $this->load->view('backoffice/complaints/approval',$data);	
	}//End of Index
	
	public function status($complaint_id,$status)
	{	 // Update status  
	     $result = $this->Complaint_model->update_status($complaint_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		 redirect(base_url() . "backoffice/complaints");		
		 
	}//end of Status  functionality*/
	
	public function publish($complaint_id,$status)
	{	 
			// Update status  
			$result = $this->Complaint_model->update_publish($complaint_id,$status);
	
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', 'Record has been successfully published.');
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		 redirect(base_url() . "backoffice/complaints/approval");		
		 
	}
	
	public function reject($complaint_id,$status)
	{	
		// Update status  
		$result = $this->Complaint_model->reject_status($complaint_id,$status,$this->input->post('rejection_status_remarks'));
		 
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', 'Record has been rejected');
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		 redirect(base_url() . "backoffice/complaints/approval");		
		 
	}
	
	public function add($complaint_id=NULL){
		$this->add_edit_complaints($complaint_id);	
	}
	
	public function edit($complaint_id=NULL){
		$this->add_edit_complaints($complaint_id);	
	}
	public function add_edit_complaints($complaint_id=NULL){
		  if($complaint_id==0){
				 $data['heading'] = "Add Complaint";
			  } elseif($complaint_id!=0){
				 $data['heading'] = "Edit Complaint";
			  }  
		 
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $complaint_id = '';
		  $title = '';
		  $description = '';
		  $vide_ = '';
		  $video_url = '';
		 
		 
		  $complaint_id = ($complaint_id!='') ? $complaint_id : 0;
		  $this->Complaint_model->complaint_id   = $complaint_id;
		  $categorytype_records_array = array();
	      if($complaint_id!='0'){
	   		$categorytype_records_array = $this->Complaint_model->editComplaintData(); 
			/*******Assign fetched record to variables to set value of input box******/
			$complaint_id	= $categorytype_records_array->complaint_id;
			$title	= $categorytype_records_array->title;
			$description	= $categorytype_records_array->description;
			$video_url	= $categorytype_records_array->video_url;
			
	      }
		 
		 if($this->input->post()){
			
			$complaint_id = isset($_POST['complaint_id'])? $_POST['complaint_id']: '';
			$title = isset($_POST['title'])? $_POST['title']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			
			$video_url = isset($_POST['video_url'])? $_POST['video_url']: '';
			
			
			
			 /********Check validations************/
			  if($complaint_id==0){
				$this->form_validation->set_rules('title','Title', 'required|is_unique[complaints.title]');
				$this->form_validation->set_rules('description','Description', 'required');
			  } elseif($complaint_id!=0){
				$this->form_validation->set_rules('title','Title', 'required');
				$this->form_validation->set_rules('description','Description', 'required');
			  }  
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
				
				/*****Assign posted value to model's variable******/
				$this->Complaint_model->complaint_id = $complaint_id;
				$this->Complaint_model->title = $title;
				$this->Complaint_model->description = $description;
				$this->Complaint_model->video_url = $video_url;
				
				
				
				
				if($complaint_id==0)
					$complaint_id = $this->Complaint_model->addComplaint();
				else
					$complaint_id = $this->Complaint_model->editComplaint();
				
				
				if($_FILES['featured_image']){	
					$config['upload_path'] = $this->image_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= max_file_size;
					//$config['max_width']  = '0';
					//$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['featured_image']['error']!='4'){
						  if($_FILES['featured_image']['name']!=''){
							$image_id = $this->Complaint_model->add_icon($complaint_id,$_FILES['featured_image']['name']);	
						  }
						  $config['file_name'] =time().'_'.$complaint_id.'_'.$_FILES['featured_image']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('featured_image');
					}  
				}
			
			    if($complaint_id=='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
			
			      redirect(base_url() . 'backoffice/complaints');
				} 
				else {
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
		
		  $data['complaint_id']= $complaint_id;		
		  $data['complaint_id']= $complaint_id;		
		  $data['title']=$title;
		  $data['description']=$description;
		  $data['video_url']=$video_url;
		 
		  
		  
	   $this->load->view('backoffice/complaints/add_edit_complaints',$data);	
	}
	
	public function approvalcomplaint($complaint_id=NULL){
		
		  $data['heading'] = "Check Complaint";
	 
		 
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $complaint_id = '';
		  $title = '';
		  $description = '';
		  $vide_ = '';
		  $video_url = '';
	
		  $this->Complaint_model->complaint_id   = $complaint_id;
		  $categorytype_records_array = array();

	   		$categorytype_records_array = $this->Complaint_model->editComplaintData(); 
			/*******Assign fetched record to variables to set value of input box******/
			$complaint_id	= $categorytype_records_array->complaint_id;
			$title	= $categorytype_records_array->title;
			$description	= $categorytype_records_array->description;
			$video_url	= $categorytype_records_array->video_url;
			
	      
		 
		 if($this->input->post()){
			
			$complaint_id = isset($_POST['complaint_id'])? $_POST['complaint_id']: '';
			$title = isset($_POST['title'])? $_POST['title']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			
			$video_url = isset($_POST['video_url'])? $_POST['video_url']: '';
			
			
			
			 /********Check validations************/
				$this->form_validation->set_rules('title','Title', 'required');
				$this->form_validation->set_rules('description','Description', 'required');
			  
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
				
				/*****Assign posted value to model's variable******/
				$this->Complaint_model->complaint_id = $complaint_id;
				$this->Complaint_model->title = $title;
				$this->Complaint_model->description = $description;
				$this->Complaint_model->video_url = $video_url;
				
				
				$complaint_id = $this->Complaint_model->editComplaint();
				
				
				if($_FILES['featured_image']){	
					$config['upload_path'] = $this->image_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= max_file_size;
					//$config['max_width']  = '0';
					//$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['featured_image']['error']!='4'){
						  if($_FILES['featured_image']['name']!=''){
							$image_id = $this->Complaint_model->add_icon($complaint_id,$_FILES['featured_image']['name']);	
						  }
						  $config['file_name'] =time().'_'.$complaint_id.'_'.$_FILES['featured_image']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('featured_image');
					}  
				}
			
				  $msg = $this->lang->line('update_text_message');
				  $this->session->set_flashdata('success_message', $msg);
				
					
				
				
					
			     redirect(base_url() . 'backoffice/complaints/approval');
				  
				  
				} 
				else {
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
		
		  $data['complaint_id']= $complaint_id;		
		  $data['complaint_id']= $complaint_id;		
		  $data['title']=$title;
		  $data['description']=$description;
		  $data['video_url']=$video_url;
		 
		  
		  
	   $this->load->view('backoffice/complaints/check_approval_complaint',$data);	
	}
	
}
