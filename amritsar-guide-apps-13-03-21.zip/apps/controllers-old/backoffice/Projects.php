<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Projects extends CI_Controller {
public function __construct()
	{
		parent:: __construct();	
		validateAccess();
		$this->load->model('backoffice/Project_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->icon_path = realpath('images/project-icons/');
	}

	public function index()
	{
		$data=array();
		$data['title'] = "Projects";
		$data['main_heading'] ="Projects";
		$data['heading'] = "Projects";
		$data['already_msg']="";
		$data['search_keyword'] = $this->input->post("search_keyword");	 
		$results = $this->Project_model->view_projects();
	
		$data['country_id'] = 0; 
		$data['state_id'] = 0;
		$data['city_id'] = 0;
		$data['locality_id'] = 0;
		  
	
		  $this->form_validation->set_rules('project_name', 'Project Name', 'required|trim');
		  $this->form_validation->set_rules('description', 'Description', 'required|trim');
		  $this->form_validation->set_rules('country_id', 'Country', 'required');
		  $this->form_validation->set_rules('state_id', 'State', 'required');
		  $this->form_validation->set_rules('city_id', 'City', 'required');
		  $this->form_validation->set_rules('locality_id', 'Locality', 'required');
	      if ($this->form_validation->run()) {
		
		   $project_id =  $this->Project_model->add();
	
		   if($_FILES['project_icon']){	
				$config['upload_path'] = $this->icon_path;
				$config['allowed_types'] = 'jpeg|gif|jpg|png';
				$config['max_size']	= '5120';
				$config['max_width']  = '0';
				$config['max_height']  = '0';
				$config['overwrite'] = true;	
				if($_FILES['project_icon']['error']!='4'){
					  if($_FILES['project_icon']['name']!=''){
						$image_id = $this->Project_model->add_icon($project_id,$_FILES['project_icon']['name']);	
					  }
					  $config['file_name'] =$project_id.'_'.$_FILES['project_icon']['name'];
					  $this->upload->initialize($config);
					  $this->upload->do_upload('project_icon');
				}  
		    }

			if($project_id!='0')
			  $msg = "Record has been added successfully.";
			else
			  $msg="There is some error in adding record."; 
		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/projects');  
	    } //end of add  functionality
		
 		$data['results'] = $results;

		//$num_rows = count($results);	
		//$data['num_rows'] = $num_rows; 
		

		$data['header'] = '';
		$data['title']='Projects';
		$data['short_desc']='Show All Projects';
		$this->load->view('backoffice/projects/view',$data);
		
    } //end of view functionality
	
	public function ratings()
	{
		$data=array();
		$data['title'] = "Projects";
		$data['main_heading'] ="Project Ratings";
		$data['heading'] = "Ratings";
			 
		$results = $this->Project_model->fetch_tutor_ratings();
		$data['view_name'] = '';
		$data['short_desc']='Project Ratings';
		$this->load->view('backoffice/tutor-ratings/view',$data);
		
    } //end of view functionality


	public function add()
	{
		  $data['title'] = "Add Project";
		  $data['main_heading'] = "Projects";
		  $data['heading'] = "Add Project";
		  $data['already_msg']="";

		  $data['country_id'] = 0; 
		  $data['state_id'] = 0;
		  $data['city_id'] = 0;
		  $data['locality_id'] = 0;
		  
	
		  $this->form_validation->set_rules('project_name', 'Project Name', 'required|trim');
		  if ($this->form_validation->run()) {
		
		  $project_id =  $this->Project_model->add();
		  //$project_id =  3;
		  
		  
			if($_FILES['project_icon']){	
					$config['upload_path'] = $this->icon_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['project_icon']['error']!='4'){
						  if($_FILES['project_icon']['name']!=''){
							$image_id = $this->Project_model->add_icon($project_id,$_FILES['project_icon']['name']);	
						  }
						  $config['file_name'] =$project_id.'_'.$_FILES['project_icon']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('project_icon');
					}  
		    }

			if($project_id!='0')
			  $msg = "Record has been updated successfully.";
			else
			  $msg="There is some error in updating record."; 
		  
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/projects/add');  
		  
			
			
	    } //end of add  functionality

		$data['header'] = '';
		$data['title']='Projects';
		$data['short_desc']='Projects';
		$this->load->view('backoffice/projects/add',$data); 
	}
	
	public function change_status($project_id, $status_id){
		
		  
			   $result =  $this->Project_model->update_status($project_id,$status_id);
			   
			   
			   if($result=='1')
				   $msg = "Status has been updated successfully.";
				else
				   $msg="There is some error in updating status."; 
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/projects");
			   
	}
	
	public function edit($project_id){
		
		  $data['title'] = "Edit Project";
		  $data['main_heading'] = "Edit Project";
		  $data['heading'] = "Edit Project";
          $data['already_msg']="";
		  

		  
		  $results = $this->Project_model->fetchproject($project_id);
		  $data['edit_data'] = $results;
			
			$this->form_validation->set_rules('project_name', 'Project Name', 'required|trim');
		  if ($this->form_validation->run()) {
			  // Update records 
	  
			  
			   $result =  $this->Project_model->update_project($project_id);
			   
			   if($_FILES['project_icon']){	
					$config['upload_path'] = $this->icon_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['project_icon']['error']!='4'){
						  if($_FILES['project_icon']['name']!=''){
							$image_id = $this->Project_model->add_icon($project_id,$_FILES['project_icon']['name']);	
						  }
						  $config['file_name'] =$project_id.'_'.$_FILES['project_icon']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('project_icon');
					}  
		       }
			
			   if($result=='1')
				   $msg = "Record has been updated successfully.";
				else
				   $msg="There is some error in updating record."; 
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/projects");
			  
		  }
		  
		$data['header'] = '';
		$data['title']='Edit Project';
		$data['short_desc']='Edit Project';
		$this->load->view('backoffice/projects/edit',$data);
		 
	}//end of Edit functionality*/
}	
?>