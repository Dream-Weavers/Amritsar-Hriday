<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('backoffice/login_model');
	}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$emailid=NULL;
		$password=NULL;
		$this->form_validation->set_rules('emailid', 'Email ID', 'required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'required|trim');
		if($this->session->userdata('admin')){
			$users_data=unserialize($this->session->userdata('admin'));
			$user_id=$users_data->user_id;
			if($user_id){
				redirect(base_url() . 'backoffice/dashboard');
			}
		}
		
		if ($this->form_validation->run()){
			$emailid=$this->input->post("emailid");
			$password=$this->input->post("password");
			$login_process=$this->login_model->login_process();
			if($login_process){
				$resultobj=$login_process;
				$user_id=$resultobj->user_id;
				
				//$this->session->set_userdata('session_designation_id',$resultobj->designation_id);
				$this->session->set_userdata('user_id',$resultobj->user_id);
				
				//Roles Rights Fetch
				/* $fields_roles=array('user_id'=>$user_id);
				$roles_data=gettableresult('user_role',$fields_roles);
				if($roles_data!='0'){
					foreach($roles_data as $roles){
						$role_id=$roles->role_id;
						$get_roles=get_table_info('roles','role_id',$role_id);
						$role_info[]=json_decode($get_roles->role_rights,true);
					}
					$result = call_user_func_array("array_merge", $role_info);
					//print '<pre>'; print_r(array_unique($result)); die;
					$this->session->set_userdata('roles',array_unique($result));
				} */
				
				
				$is_status=$resultobj->user_status;
			    $delete_status=$resultobj->delete_id;
				if($is_status==1 && $delete_status==0){
					$user_details=user_details($user_id);
					setSession('admin', serialize($user_details));
					$this->session->set_flashdata('success', 'Welcome, you are logged in now');
					redirect("backoffice/dashboard");
				}else{
					$this->session->set_flashdata('error', 'Your account is deactivated by Admin.');
				}
				
			}else{
				$data['emailid'] =$emailid;
				$data['password'] = $password;
				$this->session->set_flashdata('error', 'Invalid Username or Password');
			}
		}
		$data = array();
		$data['view_name'] = 'backoffice/login';
		$data['header'] = '';
		$data['emailid'] =$emailid;
		$data['password'] = $password;
		$data['title']='User';
		$data['short_desc']='Login';
		$this->load->view('backoffice/layout/layout',$data);
	}
	public function logout()
	{
		//$this->Userloginhistory->uid = getsuperadminUid();
		$this->session->sess_destroy();
		redirect('/backoffice/login');
	}
}
