<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Users extends CI_Controller {
public function __construct()
	{
		parent:: __construct();	
		validateAccess();
		$this->load->model('backoffice/User_model');
		$this->load->library('email');
	}

	public function index()
	{
		$data=array();
		$data['title'] = "Users";
		$data['main_heading'] ="Users";
		$data['heading'] = "Users";
		$data['already_msg']="";
		$data['search_keyword'] = $this->input->post("search_keyword");	 
		$results = $this->User_model->view_users();
		
		 $this->form_validation->set_rules('user_name', 'User Name', 'required|trim');	
		 if($this->input->post("email")=='' && $this->input->post("mobile")==''){
			  $this->form_validation->set_rules('email', 'Email or mobile', 'required|valid_email');
	     } else if($this->input->post("email")!='' && $this->input->post("mobile")==''){
			  $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
	     } else if($this->input->post("email")=='' && $this->input->post("mobile")!=''){
			  $this->form_validation->set_rules('mobile', 'Mobile', 'required|regex_match[/^[0-9]{10}$/]'); //{10} for 10 digits number
	     }

		if ($this->form_validation->run()) {
		
		  $fields = array('email' => strtolower($this->input->post('email')));
		  $result = check_unique('users',$fields);
		  if($result==1)
		  {
			$data['already_msg']=''.$this->input->post('email').' already exists, Please try another.';
		  }
		  else
		  {
			$user_id =  $this->User_model->add();
			
			if($user_id=='0' || $user_id=='2')
			   $msg = "There is some error.";
			 else  
			  //$msg = "Email has been sent.";
			  $msg = "User has been added successfully";
			 
			  $this->session->set_flashdata('success_message', $msg);
			  redirect(base_url() . 'backoffice/users');  
		  }
		} //end of add  functionality
		
 		$data['results'] = $results;

		//$num_rows = count($results);	
		//$data['num_rows'] = $num_rows; 
		
		$data['header'] = '';
		$data['title']='Users';
		$data['short_desc']='Show All Users';
		$this->load->view('backoffice/users/view',$data);
		
    } //end of view functionality
	
	/* public function add()
	{
		
		  $data['title'] = "Add User";
		  $data['main_heading'] = "Users";
		  $data['heading'] = "Add User";
		  $data['already_msg']="";

			
		  $data['state_id'] = 0;
		  $data['city_id'] =  0;
		  		
		 
		
		$data['view_name'] = 'backoffice/users/view';
		$data['header'] = '';
		$data['title']='Users';
		$data['short_desc']='Users';
		$this->load->view('backoffice/layout/layout',$data); 
	} */
	
	public function delete($user_id){
		$return_id =  $this->User_model->delete_record($user_id);
			
		if($return_id=='0')
		   $msg = "There is some error.";
		 else  
		  $msg = "User has been deleted successfully.";
		 
		$this->session->set_flashdata('success_message', $msg);
		redirect(base_url() . 'backoffice/users');  
	}
	public function edit($user_id){
		
		  $data['title'] = "Edit User";
		  $data['main_heading'] = "Edit User";
		  $data['heading'] = "Edit User";
          $data['already_msg']="";
		  
		  $results = $this->User_model->fetchuser($user_id);
		
		 $this->form_validation->set_rules('user_name', 'User Name', 'required|trim');	
		 if($this->input->post("email")=='' && $this->input->post("mobile")==''){
			  $this->form_validation->set_rules('email', 'Email or mobile', 'required|valid_email');
	     } else if($this->input->post("email")!='' && $this->input->post("mobile")==''){
			  $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
	     } else if($this->input->post("email")=='' && $this->input->post("mobile")!=''){
			  $this->form_validation->set_rules('mobile', 'Mobile', 'required|regex_match[/^[0-9]{10}$/]'); //{10} for 10 digits number
	     }
		  if ($this->form_validation->run()) {
			  // Update records 
	  
			  $edit_field = array('email' =>strtolower($this->input->post('email')));
			  $unique_id = array('user_id' =>$user_id);
			  
			  $user_result = check_unique_edit_params('users',$edit_field,$unique_id);
			  if($user_result==1)
			  {
				 $data['already_msg']=$this->input->post('email').' already exists, Please try another.';
			  }
			 else
			  {
			   $result =  $this->User_model->update_users($user_id);
			   
			   
			   if($result=='1')
				   $msg = "Record has been updated successfully.";
				else
				   $msg="There is some error in updating record."; 
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/users");
			  }
		  }
		  $result =  $this->User_model->user_edit($user_id);
		  $data['edit_data'] = $result;



		$data['header'] = '';
		$data['title']='Edit User';
		$data['short_desc']='Edit User';
		$this->load->view('backoffice/users/edit',$data);
		 
	}//end of Edit functionality*/
	
	public function change_status($user_id, $status_id){
		
		  
			   $result =  $this->User_model->update_status($user_id,$status_id);
			   
			   if($result=='1')
				   $msg = "User has been verified successfully.";
				else
				   $msg="There is some error in updating status."; 
				   
			   $this->session->set_flashdata('success_message', $msg);
			   redirect(base_url() . "backoffice/users");
			   
	}
}	
?>