<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboard extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		is_logged_in();  
		$this->load->model('api/Surveyor_model');
		$this->load->model('backoffice/Dashboard_model');
	}
	function login_details()
	{
       
		$data = $this->Surveyor_model->getRecords($this->session->userdata('user_id'));
		echo "<pre>";
		print_r($data);
		die; 
	}  
	function index()
	{
		if($this->session->userdata('is_master')=='0')
		 redirect(base_url() . 'backoffice/modules/view');
		
		 
		$data=array();
		$data['title'] = title." | Dashboard";
		$data['heading'] = title." | Dashboard";
		$data["count_users"] =$this->Dashboard_model->count_users();
	
		$data["count_employees"] =$this->Dashboard_model->count_employees();
		$data["count_areas"] =$this->Dashboard_model->count_areas();
		$data["count_soundfiles"] =$this->Dashboard_model->count_soundfiles();
		$data["count_filters"] =$this->Dashboard_model->count_filters();
		$data["count_locations"] =$this->Dashboard_model->count_locations();
		$data["countLocationCategoryTypes"] =$this->Dashboard_model->countLocationCategoryTypes();
		$data["countLocationCategories"] =$this->Dashboard_model->countLocationCategories();
		$data["count_quiz"] =$this->Dashboard_model->count_quiz();
		$data["countBlogs"] =$this->Dashboard_model->countBlogs();
			
		$data["countBlogCategories"] =$this->Dashboard_model->countBlogCategories();
		
		//$data["count_beacons"] =$this->Dashboard_model->count_beacons();
	
	//	$data["countTours"] =$this->Dashboard_model->countTours();
		$data["countdepartment"] =$this->Dashboard_model->countdepartment();
		 
		$data["countdesignation"] =$this->Dashboard_model->countdesignation();
		
		$data["totalcomplaints"] =$this->Dashboard_model->countcomplaints_feedback();
		
		$this->load->view('backoffice/dashboard',$data);
	}
	
		
	public function login_as_shadow($user_id){
		 // Login as user 
	     $this->Dashboard_model->login_as_shadow_user($user_id);	
	}//end of  functionality*/
	
	
	public function login_as()	{
		 // Login as user 
	     $this->Dashboard_model->login_as_user();				 
	 }//end of  functionality*/

}	
?>