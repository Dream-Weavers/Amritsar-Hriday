<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Permissions extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('backoffice/Permission_model');
	}
	public function index(){
	    $data['title']        = "View Permissions";
		$data['already_msg'] = "";	
		$data['main_heading'] = "Permissions";	
		$data['heading']      = "View Permissions";	
		/********Get Permissions Records********/	
		$data['results']      = $this->Permission_model->viewPermissions();
		$data['num_rows']     = isset($data['results'])?count($data['results']):0;
	   $this->load->view('backoffice/permissions/view',$data);	
	}//End of Index
	
	public function add($permissionId=NULL){
		$this->add_edit_permissions($permissionId);	
	}
	
	public function edit($permissionId=NULL){
		$this->add_edit_permissions($permissionId);	
	}
	public function add_edit_permissions($permissionId=NULL){
		  $data['main_heading'] = "Permission";
		  $data['heading']      = ($permissionId=='')? "Add Permission" : "Edit Permission";
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $permissionAdminUserName = '';
		  $permissionName          = '';
		  $permissionPath          = '';
		  $parentId          = '';
		  $permissionPassword      = '';
		 
		  $permissionId = ($permissionId!='') ? $permissionId : 0;
		  $this->Permission_model->permissionId   = $permissionId;
		  $permission_records_array = array();
	      if($permissionId!='0'){
	   		$permission_records_array = $this->Permission_model->editPermissionData(); 
			/*******Assign fetched record to variables to set value of input box******/
			$permissionName	= $permission_records_array->per_name;
			$permissionPath	= $permission_records_array->path;
			$parentId = $permission_records_array->is_parent;
	      }
		 
		 if($this->input->post()){
			
			$permissionName = isset($_POST['per_name'])? $_POST['per_name']: '';
			$permissionPath = isset($_POST['per_path'])? $_POST['per_path']: '';
			$parentId = isset($_POST['parentId'])? $_POST['parentId']: '';
			
			 /********Check validations************/
			  if($permissionId==0){
				$this->form_validation->set_rules('per_name', 'Permission Name', 'required|is_unique[permissions.per_name]');
				$this->form_validation->set_rules('per_path', 'Path', 'required');
			  }
			  elseif($permissionId!=0){
				$error_msg='';
				$this->form_validation->set_rules('per_name', 'Permission Name', 'required');
				/*****Validation for unique permission name*************/
				$count_name = check_unique_edit('permissions','per_name',$permissionName,'permissionId',$permissionId);
				if($count_name > '0')
				$error_msg .= 'Permission Name already exists.';
			  }
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
				/*****Assign posted value to model's variable******/
				$this->Permission_model->permissionName      			= $permissionName;
				$this->Permission_model->permissionPath      			= $permissionPath;
				$this->Permission_model->parentId      			= $parentId;
				
				if($permissionId==0)
					$result = $this->Permission_model->addPermission();
				else
					$result = $this->Permission_model->editPermission();

				if($permissionId==0)
					$this->session->set_flashdata('success_message', 'Permission has been added.');
				else
					$this->session->set_flashdata('success_message', 'Permission has been updated.');
				
			      redirect(base_url() . 'backoffice/Permissions');
	    } 
				else{
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
	   $data['permissionId']    				= $permissionId;		
	   $data['permissionName']  				= $permissionName;	
	   $data['permissionPath']  				= $permissionPath;	
	   $data['parentId']  				= $parentId;	
	   $this->load->view('backoffice/permissions/add_edit_permissions',$data);	
	}
}
