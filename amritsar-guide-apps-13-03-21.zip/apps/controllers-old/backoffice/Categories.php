<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Categories extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('backoffice/Categories_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->icon_path = realpath('images/category-icons/');
	}
	public function index(){
	    $data['title'] = $this->lang->line('categories_title');
		$data['main_heading'] =$this->lang->line('show_all_categories_title');
		$data['heading'] = $this->lang->line('categories_title');
		$data['already_msg']=""; 
		/********Get Categories Records********/	
		$data['results']      = $this->Categories_model->viewCategories();
		$data['num_rows']     = isset($data['results'])?count($data['results']):0;
		$lang=$this->session->userdata('lang_id');
		$languageinfo=$this->Categories_model->language_info($lang);
		$data['cur_lang']=$lang;
		$data['lang_data']=$languageinfo;
	   $this->load->view('backoffice/categories/view',$data);	
	}//End of Index
	
	public function add($category_id=NULL){
		$this->add_edit_categories($category_id);	
	}
	
	public function edit($category_id=NULL){
		$this->add_edit_categories($category_id);	
	}
	public function add_edit_categories($category_id=NULL){
		  $data['main_heading'] = $this->lang->line('categories_title');
		  $data['heading']      = ($category_id=='')? $this->lang->line('add_category_title'): $this->lang->line('edit_category_title');
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $category_type_id = '';
		  $category_parent_id = '';
		  $category_name = '';
		  $description = '';
		 
		  $category_id = ($category_id!='') ? $category_id : 0;
		  $this->Categories_model->category_id   = $category_id;
		  $category_records_array = array();
	      if($category_id!='0'){
	   		$category_records_array = $this->Categories_model->editCategoriesData(); 
			/*******Assign fetched record to variables to set value of input box******/
			$category_name	= $category_records_array->category_name;
			$category_parent_id	= $category_records_array->category_parent_id;
			$category_type_id	= $category_records_array->category_type_id;
			$description	= $category_records_array->description;
	      }
		 
		 if($this->input->post()){
			$category_name	= isset($_POST['category_name'])? $_POST['category_name']: '';
			$category_type_id = isset($_POST['category_type_id'])? $_POST['category_type_id']: '';
			$category_parent_id = isset($_POST['category_parent_id'])? $_POST['category_parent_id']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			
			
			
			 /********Check validations************/
			  $this->form_validation->set_rules('category_type_id',''.$this->lang->line('category_name_text').'', 'required|is_unique[categories.category_name]');

			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
				/*****Assign posted value to model's variable******/
				$this->Categories_model->category_name = $category_name;
				$this->Categories_model->category_parent_id = $category_parent_id;
				$this->Categories_model->category_type_id = $category_type_id;
				$this->Categories_model->description = $description;
				
				if($category_id==0)
					$cat_type_id = $this->Categories_model->addCategories();
				else
					$cat_type_id = $this->Categories_model->editCategories();
				
				/* echo "<pre>";
				print_r($_FILES);
				die; */
				if($_FILES['category_icon']){	
					$config['upload_path'] = $this->icon_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['category_icon']['error']!='4'){
						  if($_FILES['category_icon']['name']!=''){
							$image_id = $this->Categories_model->add_icon($cat_type_id,$_FILES['category_icon']['name']);	
						  }
						  $config['file_name'] =$cat_type_id.'_'.$_FILES['category_icon']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('category_icon');
	
					}  
				}
			
			
			
				 if($category_id=='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				
			      redirect(base_url() . 'backoffice/Categories');
	    } 
				else{ 
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
		
		  $data['category_id']= $category_id;			
		  $data['category_type_id']=$category_type_id;
		  $data['category_parent_id']=$category_parent_id;
		  $data['category_name']=$category_name;
		  $data['description']=$description;
		  
		  $this->load->view('backoffice/categories/add_edit_categories',$data);	
	}
	function translate_add($language_id,$cat_type_id){
	     $data=array(); 
	    $get_category_type_join=$this->Categories_model->get_cat_info($cat_type_id);
	    //print '<pre>';print_r($get_category_type_join);die;
		$data['categorytype_info']=$get_category_type_join;
	   
	    $languageinfo=get_language($language_id);
        $data['title'] = "Add Category | ".$get_category_type_join->category_name.' - ('.$languageinfo->language_name.')';
        $data['main_heading'] = "Category";
        $data['heading'] = "Add Category| ".$get_category_type_join->category_name.' - ('.$languageinfo->language_name.')';
        $data['already_msg'] = "";
        $data['langid']=$language_id;
        $data['productid']=$product_id;
        $data['language_id']=$language_id;
        $data['cat_type_id']=$cat_type_id;
        
        
		$this->form_validation->set_rules('category_name', 'Category name', 'required');
		//$this->form_validation->set_rules('media_copy', 'Media Type', 'required|trim');
		if ($this->form_validation->run()) {
		    //print '<pre>';print_r($_POST);die;
		    
		    
		    
		    $user_id =  $this->Categories_model->add_translate($language_id,$cat_type_id);
		   
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Category type added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/categories');
		    
		    
		}
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
	
		
        $data['category_ids'] = $categoryids;
        $data['vendor_list']=$vendorlist;
        $this->load->view('backoffice/categories/translate_add.php', $data);
	    
	}
	
    function edit_translate($language_id,$cat_id){
	     $data=array(); 
	    $get_category_join=$this->Categories_model->get_category_info($cat_id,$language_id);
	   //print '<pre>';print_r($get_category_join);die;
		$data['categorytype_info']=$get_category_join;
	   
	    $languageinfo=get_language($language_id);
        $data['title'] = "Edit Category  | ".$get_category_join->category_type.' - ('.$languageinfo->language_name.')';
        $data['main_heading'] = "Category ";
        $data['heading'] = "Edit Category | ".$get_category_join->category_type.' - ('.$languageinfo->language_name.')';
        $data['already_msg'] = "";
        $data['langid']=$language_id;
        $data['productid']=$product_id;
        $data['language_id']=$language_id;
        $data['cat_id']=$cat_id;
        
        
		$this->form_validation->set_rules('category_name', 'Category name', 'required');
		//$this->form_validation->set_rules('media_copy', 'Media Type', 'required|trim');
		if ($this->form_validation->run()) {
		    //print '<pre>';print_r($_POST);die;
		    
		    
		    
		    $user_id =  $this->Categories_model->update_translate($cat_id,$language_id);
		 
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Category name added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'backoffice/categories');
		    
		    
		}
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
	
		
        $data['category_ids'] = $categoryids;
        $data['vendor_list']=$vendorlist;
        $this->load->view('backoffice/categories/edit_translate.php', $data);
	    
	}	
	
	function get_categories_list1(){
	    $report=get_categories_list_rec(0,1,'');
	    print '<pre>';print_r($report);
	}
	
}
