<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Profile extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		//check_permissions();
		time_zone();
		$this->load->model('profile_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->original_path = realpath('assets/static/user_photos/original');
	   	$this->resized_path = realpath('assets/static/user_photos/resized');
	}
	
	
	
	public function index(){
		  $data['title'] = "Manage Profile";
		  $data['main_heading'] = "Manage Profile";
		  $data['heading'] = "Manage Profile";
		  $data['already_msg'] = "";
		  
  		  $this->form_validation->set_rules('first_name', 'First Name', 'required|trim');
		  $this->form_validation->set_rules('last_name', 'Last Name', 'required|trim');
		  $this->form_validation->set_rules('mobile_no1', 'Mobile Number', 'required|numeric|min_length[10]');
		 $this->form_validation->set_rules('country_id', 'Country', 'required|trim');
		  $this->form_validation->set_rules('state_id', 'State', 'required');
		  $this->form_validation->set_rules('city_id', 'City', 'required');
		  $this->form_validation->set_rules('pin_code', 'Pincode', 'trim|numeric|min_length[4]');
		  $this->form_validation->set_rules('alternate_email', 'Alternate Email', 'trim|valid_email');
		  $this->form_validation->set_rules('mobile_no2', 'Alternate Mobile Number', 'numeric|min_length[10]');
		  $this->form_validation->set_rules('landline_no', 'Landline Number', 'trim|min_length[6]');
		  $this->form_validation->set_rules('date_of_birth', 'Date of Birth', 'trim');
		  $this->form_validation->set_rules('address', 'Address', 'trim');

		if ($this->form_validation->run()) {
		  // Update records 

		  $mobile_feild = array('mobile_no1' =>trim($this->input->post('mobile_no1')));
		  $unique_id = array('user_id' =>$this->session->userdata('user_id'));
		  $mobile_result = check_unique_edit('users',$mobile_feild,$unique_id);

		  if($mobile_result==1)
		  {
			$already_msg_text   = str_replace("{field}", $this->input->post('mobile_no1'), "Mobile Number already exists");
			$data['already_msg']= $already_msg_text;
		  }
		 else
		  {
		        $result =  $this->profile_model->update_user($this->input->post('user_id'),$this->input->post('user_address_id'));
		        if($_FILES['user_photo']['error'] != 4){		
				  $config['upload_path'] = $this->original_path;
				  $config['allowed_types'] = 'jpeg|gif|jpg|png';
				  $config['max_size']	= '20000000000';
				  $config['max_width']  = '0';
				  $config['max_height']  = '0';
				  $config['overwrite'] = true;			
				  $config['file_name'] =$this->session->userdata('user_id').'-'.$_FILES['user_photo']['name'];
				  $this->upload->initialize($config);
				
				if ( ! $this->upload->do_upload('user_photo')){
					
					echo $data['already_msg']=$this->upload->display_errors();die;
					$success = FALSE;
				} else {  
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$original_path = $data['full_path'];
					$image_thumb  =$this->resized_path.'/'.$file_name;
					
					$config1['image_library']    = 'gd2';
					$config1['source_image']     = $original_path;
					$config1['new_image']        = $image_thumb;
					$config1['maintain_ratio']   = TRUE;
					$config1['height']              = 150;
					$config1['width']              = 150;
					$this->image_lib->initialize( $config1);
					$this->image_lib->resize();
					$this->image_lib->clear();									
					$result_photo = $this->profile_model->update_photo($this->session->userdata('user_id'),$file_name);
				}
			 }
		      if($result=='1')
				{   
				   $msg = "Profile updated";
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  "There was some issue, please try again!";
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "profile/");
		  }
		}		
		  $result =  $this->profile_model->user_edit($this->session->userdata('user_id'));
		  $data['edit_data'] = $result;
		  $data['country_id'] = isset($result->country_id) ? $result->country_id : 0;
		  $data['state_id'] = isset($result->state_id) ? $result->state_id : 0;
		  $data['city_id'] = isset($result->city_id) ? $result->city_id : 0;
		  
		  $this->load->view('profile_manage', $data);
		 
	}//end of Edit functionality*/
	
	
	
	
}	
?>