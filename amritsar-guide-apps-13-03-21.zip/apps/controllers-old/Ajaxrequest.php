<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ajaxrequest extends CI_Controller {

public function __construct()
	{
		parent:: __construct();
		$this->load->model('ajaxrequestmodel');
	}
	
	/*========== Get States list ============*/
	function get_states($country_id=null){
		$result = $this->ajaxrequestmodel->get_states($country_id);
		 echo $result;
	}
	
	/*=========== Get Cities ==============*/
	public function get_cities($state_id=NULL)
	{
		 $result = $this->ajaxrequestmodel->get_cities($state_id);
		 echo $result;
	} 
	
	/*=========== Get Locations ==============*/
	public function get_location($category_id=NULL)
	{
		 $result = $this->ajaxrequestmodel->get_location($category_id);
		 echo $result;
	}

	/*=========== Get All Locations Filteration==============*/
	public function get_all_locations($category_type_id=NULL,$category_id=NULL,$location_id=NULL)
	{
		 $result = $this->ajaxrequestmodel->get_all_locations($category_type_id,$category_id,$location_id);
		 echo $result;
	} 
	/*=========== Get Localities ==============*/
	public function get_localities($city_id=NULL)
	{
		 $result = $this->ajaxrequestmodel->get_localities($city_id);
		 echo $result;
	} 
	
	/*=========== Get Category ==============*/
	public function get_category($category_type_id=NULL)
	{
		 $result = $this->ajaxrequestmodel->get_category($category_type_id);
		 echo $result;
	} 
	
	/*=========== Get Category ==============*/
	public function get_Category_List($category_type_id=NULL,$default_opt=NULL)
	{
	   if($default_opt==NULL)
	   {
		 $default_opt =array();
		// echo "----Hello";
	   }
		else
		{
		   $default_opt = explode(',',$default_opt);	
		  /* echo "<pre>";
			print_r($default_opt);	
			echo "</pre>"; 
			die();*/
		}
		 $result = $this->ajaxrequestmodel->get_Category_List($category_type_id,$default_opt);
		 echo $result;
	} 
	
	//For frontend
	public function get_categories_list($category_type_id=NULL)
	{
	   
		 $result = $this->ajaxrequestmodel->get_categories_list($category_type_id);
		 echo $result;
		 
	} 
	public function get_CategoryLanguage_List($category_type_id=NULL,$default_opt=NULL)
	{
	   if($default_opt==NULL)
	   {
		 $default_opt =array();
		// echo "----Hello";
	   }
		else
		{
		   $default_opt = explode(',',$default_opt);	
		  /* echo "<pre>";
			print_r($default_opt);	
			echo "</pre>"; 
			die();*/
		}
		 $result = $this->ajaxrequestmodel->get_CategoryLanguage_List($category_type_id,$default_opt);
		 echo $result;
	} 
	
	/*=========== Get Kiosk Category ==============*/
	public function get_Kioskcategory_list($kiosk_category_id,$default_opt)
	{   
	   if($default_opt==NULL)
	   {
		 $default_opt =array();
	   }
		else
		{
		   $default_opt = explode(',',$default_opt);	
		}
		 $result = $this->ajaxrequestmodel->get_Kioskcategorylist($kiosk_category_id,$default_opt);
		 echo $result;
	} 
	
	/*=========== Get Kiosk Category ==============*/
	public function getKioskcategorylist($kiosk_category_id,$default_opt)
	{   
	   if($default_opt==NULL)
	   {
		 $default_opt =array();
	   }
		else
		{
		   $default_opt = explode(',',$default_opt);	
		}
		 $result = $this->ajaxrequestmodel->getKioskcategorylist($kiosk_category_id,$default_opt);
		 echo $result;
	} 
	
	
	/*=========== Get Already Updated Kiosk Category ==============*/
	public function getalreadyupdatedKiosklist()
	{   
	   if($default_opt==NULL)
	   {
		 $default_opt =array();
	   }
		else
		{
		   $default_opt = explode(',',$default_opt);	
		}
		 $result = $this->ajaxrequestmodel->getalreadyupdatedKiosklist();
		 echo $result;
	} 
	
	
	/*========== Get Kiosks list ============*/
	function get_kiosks($kiosk_category_id=null){
		$result = $this->ajaxrequestmodel->get_kiosks($kiosk_category_id);
		 echo $result;
	}
	
	public function get_credentials()
	{
		$email=$_POST['email'];
		$pass=$_POST['userpass'];
		$result = $this->ajaxrequestmodel->get_credentials($email,$pass);
		echo $result;
	}

	public function delete_survey_collection($survey_gal_id=NULL)
	{
		// $result = $this->ajaxrequestmodel->delete_survey_collection_record($survey_gal_id);
		 $this->ajaxrequestmodel->delete_survey_collection_record($survey_gal_id);
		 //echo $result;
	} 
	
	public function get_locations(){
		$search_text=$_GET['name'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_locations($search_text,$language_id);
		 echo $result;
	}
	public function get_category_hierarchy(){
	    $language_id=$_GET['language_id'];
		$parent_category_array =  get_group_categories_list_module('0','1','0','0','',$language_id);
		echo $parent_category_array;
		
	}
	public function get_trails_selection(){
	    $language_id=$_GET['language_id'];
		$parent_category_array =  $this->ajaxrequestmodel->get_all_trails($language_id);
		echo $parent_category_array;
		
	}
	
	public function get_locations_category(){
		$search_text=$_GET['category_id'];
		$parent_category_array = $this->ajaxrequestmodel->get_locations_category($search_text);
		echo $parent_category_array;
		
	}
	
	function get_locations_limit(){
		$limit_rec=$_GET['limit_rec'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_locations_limit($limit_rec,$language_id);
		echo $result;
	}
	
	function get_category_limit(){
		$limit_rec=$_GET['limit_rec'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_categories_limit($limit_rec,$language_id);
		echo $result;
	}
	
	function get_locations_modulewise(){
		$module_id=$_GET['module_id'];
		$result = $this->ajaxrequestmodel->get_locations_modulewise($module_id);
		echo $result;
	}
	function get_locations_category_modulewise(){
		$module_id=$_GET['module_id'];
		$category_id=$_GET['category_id'];
		$result = $this->ajaxrequestmodel->get_category_locations_modulewise($module_id,$category_id);
		echo $result;
	}
	function change_content_language($language_id=NULL){
		$this->session->set_userdata('lang_id',$language_id);
	}
	function get_categorytypes(){
		//$module_id=$_GET['module_id'];
			$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_categorytypes($language_id);
		echo $result;
	}
	function get_category_type_limit(){
		$limit_rec=$_GET['limit_rec'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_category_type_limit($limit_rec,$language_id);
		echo $result;
	}
	
	function get_slides_limit(){
		$limit_rec=$_GET['limit_rec'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_slides_limit($limit_rec,$language_id);
		echo $result;
	}
	function get_slides(){
	    $language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_slides($language_id);
		echo $result;
	}
	
	function getfield_configuration()
	{
		$category_id=$_GET['category_id'];
		$result = $this->ajaxrequestmodel->fieldconfig_types($category_id);
		echo $result;
	}
	function moduletype_configuration()
	{
		$category_id=$_GET['category_id'];
		$module_type=$_GET['module_type'];
		$result = $this->ajaxrequestmodel->fielmodule_types($category_id,$module_type);
		echo $result;
	}
	
	//function getmoduletype_configuration($category_id){
	function getmoduletype_configuration(){
		$category_id=$_GET['category_id'];
		$result = $this->ajaxrequestmodel->getmodule_types($category_id);
		echo $result;
	}
	function post_modulelayout(){
		$layoutid=$_POST['layoutid'];
		$module_id=$_POST['module_id'];
		$result = $this->ajaxrequestmodel->post_moduleLayout($module_id,$layoutid);
		if($result){
			return True;
		}else{
			return false;
		}
	}
	function load_digitalmedia($entity,$content_id){
	    $entity=$_GET['entity'];
	    $content_id=$_GET['content_id'];
		$result = $this->ajaxrequestmodel->load_digital_media($entity,$content_id);
		if($result){
			echo $result;
		}else{
			echo false;
		}
	}
	function delete_product(){
	    $product_id=$_POST['product_id'];
	    //echo $product_id;
	    $result = $this->ajaxrequestmodel->product_delete($product_id);
	    echo true;
	}
	
	function get_productcategory_id(){
	    $category_id=$_GET['category_id'];
	    //echo $product_id;
	    $result = $this->ajaxrequestmodel->get_product_listing($category_id);
	    echo $result;
	}
	
	function get_trails_info_limit(){
		$limit_rec=$_GET['limit_rec'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_trails_limit($limit_rec,$language_id);
		echo $result;
	}
	
	function get_vendor_info_limit(){
	    $limit_rec=$_GET['limit_rec'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_latest_vendors_limit($limit_rec,$language_id);
		echo $result;
	}
	function get_product_info_limit(){
	    $limit_rec=$_GET['limit_rec'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_latest_products_limit($limit_rec,$language_id);
		echo $result;
	}
	public function get_vendors_selection(){
	    //$language_id=$_GET['language_id'];
		$parent_category_array =  $this->ajaxrequestmodel->get_all_vendors();
		echo $parent_category_array;
		
	}
	public function get_products_selection(){
	    //$language_id=$_GET['language_id'];
		$parent_category_array =  $this->ajaxrequestmodel->get_all_products();
		echo $parent_category_array;
		
	}
	function get_blog_info_limit(){
	    $limit_rec=$_GET['limit_rec'];
		$language_id=$_GET['language_id'];
		$result = $this->ajaxrequestmodel->get_latest_blogs_limit($limit_rec,$language_id);
		echo $result;
	}
	
	function synchronise(){
	    //echo $product_id;
	    $result = $this->ajaxrequestmodel->update_version($category_id);
	    echo $result;
	}
	
	
}

