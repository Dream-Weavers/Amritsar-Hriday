<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Events extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		is_logged_in(); 
		valid_logged_in(FALSE,'D');	
		time_zone();
		$this->load->model('departments/events_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		
		$this->location_path = realpath('assets/static/locations');
		$this->icons_path = realpath('assets/static/locations/icons');
		$this->gallery_path = realpath('assets/static/locations/gallery');
	}
	
	public function status($location_id,$status)
	{	 // Update status  
	     $result = $this->events_model->update_status($location_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		 redirect(base_url() . "departments/events/view");		
		 
	}//end of Status  functionality*/
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_locations_title')."";
	    $data['main_heading'] = $this->lang->line('events_title');
	    $data['heading'] = $this->lang->line('view_events_title');	
	  
		
	   //print_r($_POST);	
	    if($this->input->post('location_id'))
			 $location_id = $this->input->post('location_id');
		 elseif($this->uri->segment('4'))
			 $location_id=$this->uri->segment('4');
		 else
			 $location_id='0';
			 
			 
	    if($this->input->post('category_type_id'))
	 		 $category_type_id = $this->input->post('category_type_id');
	    elseif($this->uri->segment('5'))
			 $category_type_id=$this->uri->segment('5');
		else
			 $category_type_id='0';
			 	 
		
	    if($this->input->post('locality_id'))
			$locality_id = $this->input->post('locality_id');
		 elseif($this->uri->segment('6'))
			$locality_id=$this->uri->segment('6');
		 else
			$locality_id='0';
					
	   if($this->input->post('serial_no'))
			$serial_no = $this->input->post('serial_no');
		elseif($this->uri->segment('7'))
			$serial_no=$this->uri->segment('7');
		else
			$serial_no='0';
		
	   if($this->input->post('status'))
			$status = $this->input->post('status');
		elseif($this->uri->segment('8'))
			 $status=$this->uri->segment('8');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('9'))
			$per_page=$this->uri->segment('9');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "departments/events/view/".$location_id."/".$category_type_id."/".$locality_id."/".$serial_no."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 10;
		$config["total_rows"] =$this->events_model->count_locations($location_id,$category_type_id,$locality_id,$serial_no,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(10)) ? $this->uri->segment(10) : 0; 
		$data['results'] = $this->events_model->view_locations($location_id,$category_type_id,$locality_id,$serial_no,$status,$config['per_page'], $page);
		
		
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['location_id'] = $location_id;
		$data['category_type_id'] = $category_type_id;
		$data['locality_id'] = $locality_id;
		$data['serial_no'] = $serial_no;
		$data['status'] = $status;	
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('departments/events/view.php', $data);
		}
	
	
	public function add()
	{
		
		  $data=array();
		 // $data['main_heading'] = $this->lang->line('locations_title');
		  $data['main_heading'] = "Events";
		  //$data['heading'] = $this->lang->line('add_location_title');
		  $data['heading'] =  "Events";
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('location_name', 'Event', 'required|trim');

		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  $this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		 
		  
		 if ($this->form_validation->run()) {
	
			 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
/* 				 echo "<pre>";
				 print_r($_POST['availability']);
				 echo "</pre>";
				 die; */
				foreach($_POST['week_days'] as $key => $weekdayval) {
					if(in_array($weekdayval,$_POST['availability']))
					{
					 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
					 $availability = 'open';
					 $hoursdetails['availability']= $availability; 
					 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
					 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
					}
					else
					{
					 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
					 $availability = 'close';
					 $hoursdetails['availability']= $availability; 
					 $hoursdetails['starttime']= ''; 
					 $hoursdetails['closetime']= ''; 
					}
					$hours_details[] = $hoursdetails;
					 
			    }
			 }
			 
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			  
			   //echo "------------------->".$json;
			  //die(); 
			  
			  
		      $location_id =  $this->events_model->add($working_hours);	
			   
			   //Icons	 
			   if($_FILES['map_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['map_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('map_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'map_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				if($_FILES['web_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $config['file_name'] =time().'_'.$location_id.'-'.$_FILES['web_icon_file']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('web_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$updatefield =array( 
						'web_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				if($_FILES['app_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['app_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('app_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'app_icon ' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				//Insert Digital Media
			   if($location_id!=0){
					    
						//Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->events_model->insertDigitalMedia($location_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->events_model->insertDigitalMedia($location_id,video_files,$file_name);
							  } 
					
						   }
						}
						
				}	
	
			   if($location_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'departments/events/view');
 		 
	    } //end of add  functionality
			
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$data['category_id'] = isset($_POST['category_id']) ? $_POST['category_id'] : '';
		  
	   $this->load->view('departments/events/add.php', $data);
	}
	
	public function edit($location_id){
		
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('edit_event_title')."";
		  $data['main_heading'] = $this->lang->line('events_title');
		  $data['heading'] = $this->lang->line('edit_event_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		 $this->form_validation->set_rules('location_name',''.$this->lang->line('location_event_text').'',  'required|trim');
		 
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  //$this->form_validation->set_rules('state_name', ''.$this->lang->line('location_state_text').'', 'required|trim');
		  $this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		 
		  //$this->form_validation->set_rules('location_entry_ticket', ''.$this->lang->line('location_entry_ticket_text').'', 'required|trim');
		  /* if($this->input->post('location_entry_ticket')=='pa')
		  {
			$this->form_validation->set_rules('adult_fee', ''.$this->lang->line('location_adult_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('child_fee', ''.$this->lang->line('location_child_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('senior_citizen_fee', ''.$this->lang->line('location_senior_citizen_fee_text').'', 'required|trim|integer');  
		  } */
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		 
		  
		if ($this->form_validation->run()) {
			 		
		 	 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
			  foreach($_POST['week_days'] as $key => $weekdayval) {
			  if(in_array($weekdayval,$_POST['availability']))
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			  }
			 }
			 /*echo "<br>";
			  echo "<br>";
			  echo "<pre>";
			  print_r($hours_details);
			  echo "</pre>"; 
			  echo "<br>";
			  echo "<br>";
			  die();*/
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			
			   $result =  $this->events_model->update_location($this->input->post('location_id'),$working_hours);
			 
		 	  
				 
			    //Icons	 
			    if($_FILES['map_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['map_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('map_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'map_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				 if($_FILES['web_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $config['file_name'] =time().'_'.$location_id.'-'.$_FILES['web_icon_file']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('web_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$updatefield =array( 
						'web_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				 if($_FILES['app_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['app_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('app_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'app_icon ' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				//  echo $result;
			  // die();
			   	//Insert Digital Media
			   if($location_id!=0){
					  /* echo "<pre>";
					   print_r($_FILES);
					    echo "</pre>";
						die();*/
						 //Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->events_model->insertDigitalMedia($location_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->events_model->insertDigitalMedia($location_id,video_files,$file_name);
							  } 
					
						   }
						}
						 
							 
					}	
		        
			   if($result=='1')
				{   
					$msg = $this->lang->line('update_text_message');
				    $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		     
				redirect(base_url() . "departments/events/view/".$this->input->post('location_id'));
	}		
		  $result =  $this->events_model->location_edit($location_id);
		  $data['edit_data'] = $result;
		  $fields = array('location_id'=>$result->location_id,'is_active'=>'1');
		  $catrow = gettableinfo('location_categories',$fields);
		  
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  
	       $fields = array('location_id'=>$result->location_id,'language_id'=>$this->session->userdata('lang_id'),'is_active'=>'1');
	       $deptrow = gettableinfo('location_departments',$fields);
	       $deptrow = gettableinfowithfields('location_departments',$fields,'department_id');
		   
		    $data['department_id'] = isset($deptrow->department_id) ? $deptrow->department_id : 0;
		  
		    $fields = array('location_id'=>$location_id,'is_active'=>'1');
			$catresult = gettableresult('location_categories',$fields,'category_id');
			if(is_array($catresult))
			{
				$category_ids=array();
				foreach($catresult as $ckey => $catval) {
				  $category_ids[] = $catval->category_id;	
				}
			  $categoryids =  implode(',',$category_ids);
			  //echo "---------------->".$category_ids;
			  //$categoryids =  "'".$categoryids."'";
			 //echo "---------------->".$categoryids;
			}else
			{
				$categoryids =  '';
			}
			
			//print_r($category_ids);					
		  $data['category_ids'] = $categoryids;
		  
		 
		  $this->load->view('departments/events/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	public function deletedigitalmedia($location_media_id)
	{	 // Delete Digital Media  
		
	     $result = $this->events_model->deleteDigitalMedia($location_media_id,$this->audio_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	
	public function setdefaultmedia($location_id,$location_media_id,$media_type)
	{	 // Set Default Media  
	     $result = $this->events_model->setDefaultMedia($location_id,$location_media_id,$media_type);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('update_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/

	
  public function details()
    {
		 if($this->uri->segment('4'))
			$location_id=$this->uri->segment('4');
		 else
			$location_id='0';
			
		  $data['title'] = title." | Location Details";
		  $data['main_heading'] = "Locations";
		  $data['heading'] = "Location Details";
		  $result = $this->events_model->location_details($location_id);
		  $categoryresult = $this->events_model->location_categories($location_id);
		  $data['row'] = $result;
		  $data['rowz'] = $result;
		  
		  $fields = array('location_id'=>$result->location_id,'is_active'=>'1');
		  $catrow = gettableinfo('location_categories',$fields);
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  
		  $data['categoryresult'] = $categoryresult;
		  
		  if($location_id!='0')
		  $this->load->view('departments/events/details', $data);
		  else
		  redirect(base_url() . 'departments/events/view');
		
    } //end of view Details functionality


	
	
}	
?>