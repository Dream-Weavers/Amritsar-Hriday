<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Locations extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		//is_logged_in();  
		valid_logged_in(FALSE,'D');	
		//check_permissions();
		time_zone();
		$this->load->model('departments/locations_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->load->library('ciqrcode');
		
		$this->location_path = realpath('assets/static/locations');
		$this->icons_path = realpath('assets/static/locations/icons');
		$this->gallery_path = realpath('assets/static/locations/gallery');
		$this->audio_path = realpath('assets/static/locations/audio');
	   	$this->vr_path = realpath('assets/static/locations/vr');
		$this->map2d_path = realpath('assets/static/locations/2dmap');
		$this->panorama_path = realpath('assets/static/locations/panorama');
		$this->video360_path = realpath('assets/static/locations/360video');
		$this->vt_path = realpath('assets/static/locations/vt');
		$this->facility_path = realpath('assets/static/locations/facility');
		$this->beacon_path = realpath('assets/static/locations/beacons');
	}
	
	public function status($location_id,$status)
	{	 // Update status  
	     $result = $this->locations_model->update_status($location_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		 redirect(base_url() . "departments/locations/view");		
		 
	}//end of Status  functionality*/
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_locations_title')."";
	    $data['main_heading'] = $this->lang->line('locations_title');
	    $data['heading'] = $this->lang->line('view_locations_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('location_id'))
			 $location_id = $this->input->post('location_id');
		 elseif($this->uri->segment('4'))
			 $location_id=$this->uri->segment('4');
		 else
			 $location_id='0';
			 
			 
	    if($this->input->post('category_type_id'))
	 		 $category_type_id = $this->input->post('category_type_id');
	    elseif($this->uri->segment('5'))
			 $category_type_id=$this->uri->segment('5');
		else
			 $category_type_id='0';
			 	 
		
	    if($this->input->post('locality_id'))
			$locality_id = $this->input->post('locality_id');
		 elseif($this->uri->segment('6'))
			$locality_id=$this->uri->segment('6');
		 else
			$locality_id='0';
					
	   if($this->input->post('serial_no'))
			$serial_no = $this->input->post('serial_no');
		elseif($this->uri->segment('7'))
			$serial_no=$this->uri->segment('7');
		else
			$serial_no='0';
		
	   if($this->input->post('status'))
			$status = $this->input->post('status');
		elseif($this->uri->segment('8'))
			 $status=$this->uri->segment('8');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('9'))
			$per_page=$this->uri->segment('9');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "departments/locations/view/".$location_id."/".$category_type_id."/".$locality_id."/".$serial_no."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 10;
		$config["total_rows"] =$this->locations_model->count_locations($location_id,$category_type_id,$locality_id,$serial_no,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(10)) ? $this->uri->segment(10) : 0; 
		$data['results'] = $this->locations_model->view_locations($location_id,$category_type_id,$locality_id,$serial_no,$status,$config['per_page'], $page);
		
		
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['location_id'] = $location_id;
		$data['category_type_id'] = $category_type_id;
		$data['locality_id'] = $locality_id;
		$data['serial_no'] = $serial_no;
		$data['status'] = $status;	
		$data['per_page'] = $per_page;
		
		
		$lang=$this->session->userdata('lang_id');
		$languageinfo=$this->locations_model->language_info($lang);
		$data['cur_lang']=$lang;
		$data['lang_data']=$languageinfo;
		  	  
	    $this->load->view('departments/locations/view.php', $data);
		}

	
}	
?>