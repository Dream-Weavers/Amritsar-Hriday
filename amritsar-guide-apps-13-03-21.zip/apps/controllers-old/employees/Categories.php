<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Categories extends CI_Controller {
public function __construct()
	{
		parent:: __construct();
		//valid_logged_in(FALSE,'U');	
		is_logged_in(); 
		time_zone();
		$this->load->model('employees/category_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->icon_path = realpath('images/category-icons/');
	}
	
	
	public function add()
	{
		  $data['title'] = title." | Add Category";
		  $data['main_heading'] = "Categories";
		  $data['heading'] = "Add Category";
		  $data['already_msg']="";
		  
		  $this->form_validation->set_rules('category_name', 'Category name', 'required|trim');
		  $this->form_validation->set_rules('parent_id', 'Parent', 'trim');	
		  $this->form_validation->set_rules('description', 'Description', 'trim');	
		if ($this->form_validation->run()) {
			
		 	$category_id =  $this->category_model->add();
			
			if($_FILES['category_icon']){	
					$config['upload_path'] = $this->icon_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['category_icon']['error']!='4'){
						  if($_FILES['category_icon']['name']!=''){
							$image_id = $this->category_model->add_icon($category_id,$_FILES['category_icon']['name']);	
						  }
						  $config['file_name'] =$category_id.'_'.$_FILES['category_icon']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('category_icon');
	
					}  
				}
				
				
			if($result=='0')
			   $msg = "There is some error in Save Category Data.";
			 else  
			   $msg = "Category have been created successfully.";
			 
			  $this->session->set_flashdata('success_message', $msg);
			 redirect(base_url() . 'employees/categories/view');  
			
	    } //end of add  functionality
		
	   $this->load->view('employees/category/add.php', $data);
	}
	
	
	public function view()
	{
		$data=array();
		$data['title'] = title." | View Categories";
		$data['main_heading'] ="Categories";
		$data['heading'] = "View Categories";
		
		 if($this->input->post('category_id'))
		     $category_id = $this->input->post('category_id');
	     elseif($this->uri->segment('4'))
			 $category_id=$this->uri->segment('4');
		 else
			 $category_id='0';
		
		$results = $this->category_model->view_categories($category_id);
		  
		$data['results'] = $results;
		$num_rows = count($results);	
		$data['num_rows'] = $num_rows;
	
		$this->load->view('employees/category/view', $data);
		
    } //end of view functionality
	
	
		public function edit($category_id){
		
		  $data['title'] = title." | Edit Category";
		  $data['main_heading'] = "Categories";
		  $data['heading'] = "Edit Category";
          $data['already_msg']="";
		  
		  $this->form_validation->set_rules('category_name', 'Category name', 'required|trim');
		  $this->form_validation->set_rules('parent_id', 'Parent', 'trim');	
		  $this->form_validation->set_rules('description', 'Description', 'trim');	
		 if ($this->form_validation->run()) {
		  // Update records 
		    $result =  $this->category_model->update_category($this->input->post('category_id'));
			if($_FILES['category_icon']){	
					$config['upload_path'] = $this->icon_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= '5120';
					$config['max_width']  = '0';
					$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['category_icon']['error']!='4'){
						  if($_FILES['category_icon']['name']!=''){
							$image_id = $this->category_model->add_icon($this->input->post('category_id'),$_FILES['category_icon']['name']);	
						  }
						  $config['file_name'] =$this->input->post('category_id').'_'.$_FILES['category_icon']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('category_icon');
					}  
				}
					
		   if($result=='1')
			   $msg = "Category record has been updated successfully.";
			else
			   $msg="There is some error in update record."; 
			   
		  $this->session->set_flashdata('success_message', $msg);
		  redirect(base_url() . "employees/categories/view/".$this->input->post('category_id'));
		  
		  }
		
		  $result =  $this->category_model->category_edit($category_id);	
		  $data['edit_data'] = $result;
		  
		  $this->load->view('employees/category/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	public function status($category_id,$status)
	{
		 // Update status  
	     $result = $this->category_model->update_status($category_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', 'Status has been updated successfully.');
           redirect(base_url() . "employees/categories/view");		
		 }
		 
	}//end of Status  functionality*/
	
}	
?>