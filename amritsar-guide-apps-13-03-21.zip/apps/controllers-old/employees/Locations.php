<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Locations extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		is_logged_in();  
		//valid_logged_in(FALSE,'E');	
		//check_permissions();
		time_zone();
		$this->load->model('employees/locations_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->load->library('ciqrcode');
		
		$this->location_path = realpath('assets/static/locations');
		$this->gps_path = realpath('assets/static/locations/gps_path');
		$this->icons_path = realpath('assets/static/locations/icons');
		$this->gallery_path = realpath('assets/static/locations/gallery');
		$this->audio_path = realpath('assets/static/locations/audio');
	   	$this->vr_path = realpath('assets/static/locations/vr');
		$this->map2d_path = realpath('assets/static/locations/2dmap');
		$this->panorama_path = realpath('assets/static/locations/panorama');
		$this->video360_path = realpath('assets/static/locations/360video');
		$this->vt_path = realpath('assets/static/locations/vt');
		$this->facility_path = realpath('assets/static/locations/facility');
		$this->beacon_path = realpath('assets/static/locations/beacons');
		$this->banner_images_path = realpath('assets/static/locations/banner');
		$this->quiz_images_path = realpath('assets/static/locations/quiz');
	}
	
	
	function location_beacons($id){
	    $data=array();
		$data['title'] = title." Locations";
	    $data['main_heading'] = 'Locations';
	    $data['heading'] = 'Locations';	
	    $data['all_vendors']=$this->locations_model->all_vendors();
	    $data['all_locations']=$this->locations_model->all_locations();
	    if($id!=''){
    	    $data['id']=$id;
    	    $data['basic']=$this->locations_model->basic_beacons($id);
    	    $data['advanced']=$this->locations_model->advanced_beacons($id);
	    }   
	    
	    $this->load->view('employees/locations/location_beacons_add.php', $data);  
	} 
	
function location_beacons_update($id){
	    
	    $basic=$this->locations_model->basic_beacons($id);
	    $advanced=$this->locations_model->advanced_beacons($id);
	    
        $decode_advanced=json_decode($advanced->beacon_actions,true);
        //print $id;
        if($id!=''){
            $counter=count($decode_advanced);
        }else{
            $counter=0;
        }
        
	    $assgined_to=$this->input->post('assign_to');
	    if($assgined_to=='L'){
	        $tid=$this->input->post('all_locations');
	        $type='L';
	    }
	    if($assgined_to=='V'){
	        $tid=$this->input->post('all_vendors');
	        $type='V';
	    }
	    $beac_id=$this->input->post('beacon_unique_id');
	    $array_post=$_POST['location-beacon'];
	    /*$beac_array=array();
	    foreach($array_post as $row){
	        $beacon_id=$row['beacon_unique_id'];
	        $beacon_name=$row['beacon_location_name'];
	        $beac_array[$beacon_id]=$beacon_name;
	    }*/
	    
	    $arraypost['POST']=$_POST;
	    $arraypost['FILES']=$_FILES;
	    
	    $action_listing=$_POST['location-beacon'];
	    $actions_array=array();
	    //print '<pre>';print_r($_POST['instruction_id'][$id]);die;
	    if($id!=''){
	        $this_counter=0;
	        foreach($_POST['instruction_id'][$id] as $inst_id=>$inst_val){
	            //foreach($inst_array as $inst_id=>$inst_val)
	            $action_no=$_POST['action_plan_id'][$id][$inst_id];
	            $choose_opt=$_POST['choose_inst_options'][$id][$inst_id];
	            $beacon_address=$_POST['beacon_address'][$id][$inst_id];
	            $beacon_remarks=$_POST['beacon_remarks'][$id][$inst_id];
	            $actions_array[$inst_id]['action_id']=$action_no;
	            $actions_array[$inst_id]['instruction_id']=$inst_val;
	            if($inst_val==1 || $inst_val==7)
	            $actions_array[$inst_id]['choose_opt']=$choose_opt;
	            else
	            $actions_array[$inst_id]['choose_opt']=NULL;
	            $actions_array[$inst_id]['beacon_address']=$beacon_address;
	            $actions_array[$inst_id]['beacon_remarks']=$beacon_remarks;
	            $instruction_id=$inst_val;
	            if($instruction_id==1 && $choose_opt=='upload_file'){
	                if($_FILES['beacon_audio_file']['name'][$id][$inst_id]!=''){
                        $_FILES['userfile']['name']= $_FILES['beacon_audio_file']['name'][$id][$inst_id];
                        $_FILES['userfile']['type']    = $_FILES['beacon_audio_file']['type'][$id][$inst_id];
                        $_FILES['userfile']['tmp_name'] = $_FILES['beacon_audio_file']['tmp_name'][$id][$inst_id];
                        $_FILES['userfile']['error']       = $_FILES['beacon_audio_file']['error'][$id][$inst_id];
                        $_FILES['userfile']['size']    = $_FILES['beacon_audio_file']['size'][$id][$inst_id];
                        
                        $config['upload_path'] = $this->beacon_path;
                        $config['allowed_types'] = 'jpeg|gif|jpg|png|mp3|mpeg';
                        $config['max_size']	= '5120';
                        $config['max_width']  = '0';
                        $config['max_height']  = '0';
                        $config['overwrite'] = true;
                        $file_name = time().'_'.$id.'_'.$_FILES['userfile']['name'];	
                        $config['file_name'] =$file_name;		
                        if($_FILES['userfile']['error']!='4'){
                          $this->upload->initialize($config);
                          $this->upload->do_upload('userfile');
                          if ($this->upload->do_upload('userfile'))
                          {
                           $data['uploads'][$inst_id] = $this->upload->data();
                           
                           $file_name= $data['uploads'][$inst_id]['file_name'];
                           $actions_array[$inst_id]['files']=$file_name;
                          }
                          else
                          {
                           $data['upload_errors'][$inst_id] = $this->upload->display_errors();
                           
                          } 
                        }
	                    
	                }else{
	                    $file_name= $decode_advanced[$inst_id]['files'];
	                    
	                    $actions_array[$this_counter]['files']=$file_name;
	                }
	            }
	            
	            //print '<pre>';print_r($actions_array);die;
	            
	            if($instruction_id==7 && $choose_opt=='upload_file'){
	                if($_FILES['beacon_audio_file']['name'][$id][$inst_id]!=''){
                        $_FILES['userfile']['name']= $_FILES['beacon_audio_file']['name'][$id][$inst_id];
                        $_FILES['userfile']['type']    = $_FILES['beacon_audio_file']['type'][$id][$inst_id];
                        $_FILES['userfile']['tmp_name'] = $_FILES['beacon_audio_file']['tmp_name'][$id][$inst_id];
                        $_FILES['userfile']['error']       = $_FILES['beacon_audio_file']['error'][$id][$inst_id];
                        $_FILES['userfile']['size']    = $_FILES['beacon_audio_file']['size'][$id][$inst_id];
                        
                        $config['upload_path'] = $this->beacon_path;
                        $config['allowed_types'] = 'jpeg|gif|jpg|png|mp3|mpeg';
                        $config['max_size']	= '5120';
                        $config['max_width']  = '0';
                        $config['max_height']  = '0';
                        $config['overwrite'] = true;
                        $file_name = time().'_'.$id.'_'.$_FILES['userfile']['name'];	
                        $config['file_name'] =$file_name;		
                        if($_FILES['userfile']['error']!='4'){
                          $this->upload->initialize($config);
                          $this->upload->do_upload('userfile');
                          if ($this->upload->do_upload('userfile'))
                          {
                           $data['uploads'][$inst_id] = $this->upload->data();
                           $file_name= $data['uploads'][$inst_id]['file_name'];
                           $actions_array[$inst_id]['files']=$file_name;
                          }
                          else
                          {
                           $data['upload_errors'][$inst_id] = $this->upload->display_errors();
                          } 
                        }
	                    
	                }else{
	                    $file_name= $decode_advanced[$inst_id]['files'];
	                    $actions_array[$this_counter]['files']=$file_name;
	                }
	                
	            }
	            if($instruction_id==2){
        			if($_FILES['beacon_media_file']['name'][$id][$inst_id]!=''){	
        			
        				$_FILES['userfile']['name']= $_FILES['beacon_media_file']['name'][$id][$inst_id];
                        $_FILES['userfile']['type']    = $_FILES['beacon_media_file']['type'][$id][$inst_id];
                        $_FILES['userfile']['tmp_name'] = $_FILES['beacon_media_file']['tmp_name'][$id][$inst_id];
                        $_FILES['userfile']['error']       = $_FILES['beacon_media_file']['error'][$id][$inst_id];
                        $_FILES['userfile']['size']    = $_FILES['beacon_media_file']['size'][$id][$inst_id];
        				
        				$config['upload_path'] = $this->beacon_path;
        				$config['allowed_types'] = 'jpeg|gif|jpg|png|mp3|mpeg';
        				$config['max_size']	= '5120';
        				$config['max_width']  = '0';
        				$config['max_height']  = '0';
        				$config['overwrite'] = true;
        				$file_name = time().'_'.$id.'_'.$_FILES['userfile']['name'];	
        				$config['file_name'] =$file_name;		
        				if($_FILES['userfile']['error']!='4'){
        					  $this->upload->initialize($config);
        					  $this->upload->do_upload('userfile');
        					  if ($this->upload->do_upload('userfile'))
        					  {
        					   $data['uploads'][$inst_id] = $this->upload->data();
        					   $file_name= $data['uploads'][$inst_id]['file_name'];
        					   $actions_array[$inst_id]['files']=$file_name;
        					  }
        					  else
        					  {
        					   $data['upload_errors'][$inst_id] = $this->upload->display_errors();
        					  } 
        				}  
        			}else{
                        $file_name= $decode_advanced[$inst_id]['files'];
                         $actions_array[$this_counter]['files']=$file_name;
                    }
	            }
	            if($instruction_id==3){
    	            $videourl=$_POST['beacon_video_url'][$id][$inst_id];
    	            $videotitle=$_POST['beacon_video_title'][$id][$inst_id];
    	            $actions_array[$inst_id]['video_url']=$videourl;
    	            $actions_array[$inst_id]['video_title']=$videotitle;
    	        }
    	        if($instruction_id==7 && $choose_opt=='text_to_speech'){
    	            $text_to_speech=$_POST['text_to_speech_description'][$id][$inst_id];
    	            $actions_array[$inst_id]['text_to_speech_description']=$text_to_speech;
    	        }
    	        if($instruction_id==1 && $choose_opt=='text_to_speech'){
    	            $text_to_speech=$_POST['text_to_speech_description'][$id][$inst_id];
    	            $actions_array[$inst_id]['text_to_speech_description']=$text_to_speech;
    	        }
	            $this_counter++;
	        }
	       
	    }
	     //print '<pre>';print_R($action_listing);die; 
	     //print $action_listing[0]['action_plan_id'];die;
	    if($action_listing[0]['action_plan_id']>0){
	        foreach($action_listing as $key=>$rows){
    	        $action_no=$rows['action_plan_id'];
    	        $instruction_id=$rows['instruction_id'];
    	        $choose_opt=$rows['choose_inst_options'];
    	        $beacon_address=$rows['beacon_address'];
    	        $beacon_remarks=$rows['beacon_remarks'];
    	        $actions_array[$counter]['action_id']=$action_no;
    	        $actions_array[$counter]['instruction_id']=$instruction_id;
    	        $actions_array[$counter]['choose_opt']=$choose_opt;
    	        $actions_array[$counter]['beacon_address']=$beacon_address;
    	        $actions_array[$counter]['beacon_remarks']=$beacon_remarks;
    	        $file_name='';
    	        if($instruction_id==1 && $choose_opt=='upload_file'){
        			if($_FILES['location-beacon']['name'][$key]['beacon_audio_file']!=''){	
        			
        				$_FILES['userfile']['name']= $_FILES['location-beacon']['name'][$key]['beacon_audio_file'];
        				$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_audio_file'];
        				$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_audio_file'];
        				$_FILES['userfile']['error']       = $_FILES['location-beacon']['error'][$key]['beacon_audio_file'];
        				$_FILES['userfile']['size']    = $_FILES['location-beacon']['size'][$key]['beacon_audio_file'];
        				
        				$config['upload_path'] = $this->beacon_path;
        				$config['allowed_types'] = 'jpeg|gif|jpg|png|mp3|mpeg';
        				$config['max_size']	= '5120';
        				$config['max_width']  = '0';
        				$config['max_height']  = '0';
        				$config['overwrite'] = true;
        				$file_name = time().'_'.$id.'_'.$_FILES['userfile']['name'];	
        				$config['file_name'] =$file_name;		
        				if($_FILES['userfile']['error']!='4'){
        					  $this->upload->initialize($config);
        					  $this->upload->do_upload('userfile');
        					  if ($this->upload->do_upload('userfile'))
        					  {
        					   $data['uploads'][$key] = $this->upload->data();
        					   $file_name= $data['uploads'][$key]['file_name'];
        					  }
        					  else
        					  {
        					   $data['upload_errors'][$key] = $this->upload->display_errors();
        					  } 
        				}  
        			}
    	        }
    	        if($instruction_id==7 && $choose_opt=='upload_file'){
        			if($_FILES['location-beacon']['name'][$key]['beacon_audio_file']!=''){	
        			
        				$_FILES['userfile']['name']= $_FILES['location-beacon']['name'][$key]['beacon_audio_file'];
        				$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_audio_file'];
        				$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_audio_file'];
        				$_FILES['userfile']['error']       = $_FILES['location-beacon']['error'][$key]['beacon_audio_file'];
        				$_FILES['userfile']['size']    = $_FILES['location-beacon']['size'][$key]['beacon_audio_file'];
        				
        				$config['upload_path'] = $this->beacon_path;
        				$config['allowed_types'] = 'jpeg|gif|jpg|png|mp3|mpeg';
        				$config['max_size']	= '5120';
        				$config['max_width']  = '0';
        				$config['max_height']  = '0';
        				$config['overwrite'] = true;
        				$file_name = time().'_'.$id.'_'.$_FILES['userfile']['name'];	
        				$config['file_name'] =$file_name;		
        				if($_FILES['userfile']['error']!='4'){
        					  $this->upload->initialize($config);
        					  $this->upload->do_upload('userfile');
        					  if ($this->upload->do_upload('userfile'))
        					  {
        					   $data['uploads'][$key] = $this->upload->data();
        					   $file_name= $data['uploads'][$key]['file_name'];
        					  }
        					  else
        					  {
        					   $data['upload_errors'][$key] = $this->upload->display_errors();
        					  } 
        				}  
        			}
    	        }
    	        if($instruction_id==2){
        			if($_FILES['location-beacon']['name'][$key]['beacon_media_file']!=''){	
        			
        				$_FILES['userfile']['name']= $_FILES['location-beacon']['name'][$key]['beacon_media_file'];
        				$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_media_file'];
        				$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_media_file'];
        				$_FILES['userfile']['error']       = $_FILES['location-beacon']['error'][$key]['beacon_media_file'];
        				$_FILES['userfile']['size']    = $_FILES['location-beacon']['size'][$key]['beacon_media_file'];
        				
        				$config['upload_path'] = $this->beacon_path;
        				$config['allowed_types'] = 'jpeg|gif|jpg|png|mp3|mpeg';
        				$config['max_size']	= '5120';
        				$config['max_width']  = '0';
        				$config['max_height']  = '0';
        				$config['overwrite'] = true;
        				$file_name = time().'_'.$id.'_'.$_FILES['userfile']['name'];	
        				$config['file_name'] =$file_name;		
        				if($_FILES['userfile']['error']!='4'){
        					  $this->upload->initialize($config);
        					  $this->upload->do_upload('userfile');
        					  if ($this->upload->do_upload('userfile'))
        					  {
        					   $data['uploads'][$key] = $this->upload->data();
        					   $file_name= $data['uploads'][$key]['file_name'];
        					  }
        					  else
        					  {
        					   $data['upload_errors'][$key] = $this->upload->display_errors();
        					  } 
        				}  
        			}
    	        }
    	        if($instruction_id==3){
    	            $videourl=$rows['beacon_video_url'];
    	            $videotitle=$rows['beacon_video_title'];
    	            $actions_array[$counter]['video_url']=$videourl;
    	            $actions_array[$counter]['video_title']=$videotitle;
    	        }
    	        if($instruction_id==7 && $choose_opt=='text_to_speech'){
    	            $text_to_speech=$rows['text_to_speech_description'];
    	            $actions_array[$counter]['text_to_speech_description']=$text_to_speech;
    	        }
    	        if($instruction_id==1 && $choose_opt=='text_to_speech'){
    	            $text_to_speech=$rows['text_to_speech_description'];
    	            $actions_array[$counter]['text_to_speech_description']=$text_to_speech;
    	        }
    			$actions_array[$counter]['files']=$file_name;
    	        
    	        
    	        $counter++;
    	        //$actions_array['files']
	        } 
        }
        if($id==''){
    	    $assign_beacons=$this->locations_model->assign_beac($type,$tid,$beac_id); 
    	    $actionsinfo=$this->locations_model->beacon_actions($assign_beacons,$actions_array); 
        }else{
            $assign_beacons=$this->locations_model->update_beac($id,$type,$tid,$beac_id); 
    	    $actionsinfo=$this->locations_model->update_beacon_actions($id,$actions_array);
        }
	      $this->session->set_flashdata('success_message', 'Beacon assigned successfully.'); 
	    redirect(base_url() . "backoffice/beacons/view");	
	}   
	
	public function status($location_id,$status)
	{	 // Update status  
	     $result = $this->locations_model->update_status($location_id,$status);
		 if($result=='1')
		 { 
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		 redirect(base_url() . "employees/locations/view");		
		 
	}//end of Status  functionality*/
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_locations_title')."";
	    $data['main_heading'] = $this->lang->line('locations_title');
	    $data['heading'] = $this->lang->line('view_locations_title');	
		
	   //print_r($_POST);	
	    if($this->input->post('location_id'))
			 $location_id = $this->input->post('location_id');
		 elseif($this->uri->segment('4'))
			 $location_id=$this->uri->segment('4');
		 else
			 $location_id='0';
			 
			 
	    if($this->input->post('category_type_id'))
	 		 $category_type_id = $this->input->post('category_type_id');
	    elseif($this->uri->segment('5'))
			 $category_type_id=$this->uri->segment('5');
		else
			 $category_type_id='0';
			 	 
		
	    if($this->input->post('locality_id'))
			$locality_id = $this->input->post('locality_id');
		 elseif($this->uri->segment('6'))
			$locality_id=$this->uri->segment('6');
		 else
			$locality_id='0';
					
	   if($this->input->post('serial_no'))
			$serial_no = $this->input->post('serial_no');
		elseif($this->uri->segment('7'))
			$serial_no=$this->uri->segment('7');
		else
			$serial_no='0';
		
	   if($this->input->post('status'))
			$status = $this->input->post('status');
		elseif($this->uri->segment('8'))
			 $status=$this->uri->segment('8');
		else
			 $status='0';	 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('9'))
			$per_page=$this->uri->segment('9');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "employees/locations/view/".$location_id."/".$category_type_id."/".$locality_id."/".$serial_no."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 10;
		$config["total_rows"] =$this->locations_model->count_locations($location_id,$category_type_id,$locality_id,$serial_no,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(10)) ? $this->uri->segment(10) : 0; 
		$data['results'] = $this->locations_model->view_locations($location_id,$category_type_id,$locality_id,$serial_no,$status,$config['per_page'], $page);
		
		
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['location_id'] = $location_id;
		$data['category_type_id'] = $category_type_id;
		$data['locality_id'] = $locality_id;
		$data['serial_no'] = $serial_no;
		$data['status'] = $status;	
		$data['per_page'] = $per_page;
		
		
		$lang=$this->session->userdata('lang_id');
		$languageinfo=$this->locations_model->language_info($lang);
		$data['cur_lang']=$lang;
		$data['lang_data']=$languageinfo;
		  	  
	    $this->load->view('employees/locations/view.php', $data);
		}
	
	
	public function add()
	{
		// $beacon_array = $this->locations_model->get_beacons_dropdown();
		 /*echo "<pre>";
		 print_r($beacon_array);
		 echo "</pre>";
		*/
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('add_location_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('location_name', ''.$this->lang->line('location_location_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_name', ''.$this->lang->line('location_short_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_description', ''.$this->lang->line('location_short_description_text').'', 'required|trim');
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  //$this->form_validation->set_rules('state_name', ''.$this->lang->line('location_state_text').'', 'required|trim');
		  //$this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		  $this->form_validation->set_rules('estimated_visit_time', ''.$this->lang->line('location_estimated_visit_time_text').'', 'required|trim'); 
		  /* $this->form_validation->set_rules('location_entry_ticket', ''.$this->lang->line('location_entry_ticket_text').'', 'required|trim');
		  if($this->input->post('location_entry_ticket')=='pa')
		  {
			$this->form_validation->set_rules('adult_fee', ''.$this->lang->line('location_adult_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('child_fee', ''.$this->lang->line('location_child_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('senior_citizen_fee', ''.$this->lang->line('location_senior_citizen_fee_text').'', 'required|trim|integer');  
		  } */
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('alert1_distance', ''.$this->lang->line('location_alert1_distance_text').'', 'trim');
		  /*$this->form_validation->set_rules('alert2_distance', ''.$this->lang->line('location_alert2_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert3_distance', ''.$this->lang->line('location_alert3_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert4_distance', ''.$this->lang->line('location_alert4_distance_text').'', 'trim');*/
		  
		  $this->form_validation->set_rules('alert1_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  /*$this->form_validation->set_rules('alert2_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert3_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert4_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');*/
		  
		  $this->form_validation->set_rules('north_area', ''.$this->lang->line('location_north_text').'', 'trim');
		  $this->form_validation->set_rules('north_area_title', ''.$this->lang->line('location_north_title_text').'', 'trim');
		  $this->form_validation->set_rules('south_area', ''.$this->lang->line('location_south_text').'', 'trim');
		  $this->form_validation->set_rules('south_area_title', ''.$this->lang->line('location_south_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area_title', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('west_area', ''.$this->lang->line('location_west_text').'', 'trim');
		  $this->form_validation->set_rules('west_area_title', ''.$this->lang->line('location_west_title_text').'', 'trim');
		  
		 if ($this->form_validation->run()) {
			 
		 
			 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
/* 				 echo "<pre>";
				 print_r($_POST['availability']);
				 echo "</pre>";
				 die; */
				foreach($_POST['week_days'] as $key => $weekdayval) {
					if(in_array($weekdayval,$_POST['availability']))
					{
					 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
					 $availability = 'open';
					 $hoursdetails['availability']= $availability; 
					 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
					 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
					}
					else
					{
					 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
					 $availability = 'close';
					 $hoursdetails['availability']= $availability; 
					 $hoursdetails['starttime']= ''; 
					 $hoursdetails['closetime']= ''; 
					}
					$hours_details[] = $hoursdetails;
					 
			    }
			 }
			  /*echo "<br>";
			  echo "<br>";
			  echo "<pre>";
			  print_r($hours_details);
			  echo "</pre>"; 
			echo "<br>";
			  echo "<br>";*/
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			  
			   //echo "------------------->".$json;
			  //die(); 
			  
			  //Get Directions Json
			  $direction_locations =array();
			  
			  $direction_locations['northstartpointlongitude']= $_POST['northstartpointlongitude']; 	
			  $direction_locations['northstartpointlatitude']= $_POST['northstartpointlatitude']; 	
			  $direction_locations['northendpointlongitude']= $_POST['northendpointlongitude']; 	
			  $direction_locations['northendpointlatitude']= $_POST['northendpointlatitude']; 	
			  
			  $direction_locations['southstartpointlongitude']= $_POST['southstartpointlongitude']; 	
			  $direction_locations['southstartpointlatitude']= $_POST['southstartpointlatitude']; 	
			  $direction_locations['southendpointlongitude']= $_POST['southendpointlongitude']; 	
			  $direction_locations['southendpointlatitude']= $_POST['southendpointlatitude'];
			  
			  $direction_locations['eaststartpointlongitude']= $_POST['eaststartpointlongitude']; 	
			  $direction_locations['eaststartpointlatitude']= $_POST['eaststartpointlatitude']; 	
			  $direction_locations['eastendpointlongitude']= $_POST['eastendpointlongitude']; 	
			  $direction_locations['eastendpointlatitude']= $_POST['eastendpointlatitude'];
			  
			  $direction_locations['weststartpointlongitude']= $_POST['weststartpointlongitude']; 	
			  $direction_locations['weststartpointlatitude']= $_POST['weststartpointlatitude']; 	
			  $direction_locations['westendpointlongitude']= $_POST['westendpointlongitude']; 	
			  $direction_locations['westendpointlatitude']= $_POST['westendpointlatitude'];
			  
			  $directionlocations = json_encode($direction_locations);

		      $location_id =  $this->locations_model->add($working_hours,$directionlocations);	
		      
		      
		      
		      // GPS info
		   
            $lid= $location_id;
            //$gps_spot= $this->input->post('gps_onspot');
            $gps_enabled= $this->input->post('gps_enabled');
            $gps_notification= $this->input->post('gps_notification');	//
            $alert1_distance= $this->input->post('alert1_distance');
            $alert1_sound_file_id= $this->input->post('alert1_sound_file_id');
            $gps_video_link= $this->input->post('gps_video_link');
            $gps_video_title= $this->input->post('gps_video_title');
			 // GPS info 
			 
			$details_gps=json_decode($gps_info->location_gps_info,true);
			 $initial_file_name='';
		    if($_FILES['gps_audio_file_initial']['error'] != 4){		
				  $config['upload_path'] = $this->gps_path;
				  $config['allowed_types'] = audo_file_extensions;
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$lid.'_'.$_FILES['gps_audio_file_initial']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				    if ( ! $this->upload->do_upload('gps_audio_file_initial')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
					} else {
						$data = $this->upload->data();
						$initial_file_name = $data['file_name'];
						//die();
					}
	        }else{
	            $initial_file_name=$details_gps['initial'];
	        }
	        $popup_file_name='';
	        if($_FILES['gps_audio_file_popup']['error'] != 4){		
				  $config['upload_path'] = $this->gps_path;
				  $config['allowed_types'] = audo_file_extensions;
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$lid.'_'.$_FILES['gps_audio_file_popup']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				    if ( ! $this->upload->do_upload('gps_audio_file_popup')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
					} else {
						$data = $this->upload->data();
						$popup_file_name = $data['file_name'];
						//die();
					}
	        }else{
	            $popup_file_name=$details_gps['popup_audio'];
	        }
	        
	        $media_file_name='';
	        if($_FILES['gps_media_file_popup']['error'] != 4){		
				  $config['upload_path'] = $this->gps_path;
				  $config['allowed_types'] = 'jpeg|gif|jpg|png';
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$lid.'_'.$_FILES['gps_media_file_popup']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				    if ( ! $this->upload->do_upload('gps_media_file_popup')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
					} else {
						$data = $this->upload->data();
						$media_file_name = $data['file_name'];
						//die();
					}
	        }else{
	            $media_file_name=$details_gps['media_file'];
	        }
	        $alert1dist=$this->input->post('alert1_distance');
	        $alert1_sound_file_id=$this->input->post('alert1_sound_file_id');
			 $gps_info_array=array('initial'=>$initial_file_name,'popup_audio'=>$popup_file_name,'media_file'=>$media_file_name,'video_link'=>$gps_video_link,'video_title'=>$gps_video_title,'alert1_distance'=>$alert1dist,'alert1_sound'=>$alert1_sound_file_id);
			 //$unique_id = array('location_id' =>$location_id,'language_id'=>1);
			 $updatefield=json_encode($gps_info_array);
			 $insertgps_info=$this->locations_model->insert_gps_info($lid,1,$updatefield);
			 //gps end here 
		      
		      
		      
			   //North Area Sound File 
			   if($_FILES['north_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					  //$config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['north_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('north_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'north_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
			   //South Area Sound File 
			   if($_FILES['south_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					  //$config['max_width']  = '50';
					 //$config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['south_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('south_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'south_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
			   //East Area Sound File 
			   if($_FILES['east_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $file_name = time().'_'.$location_id.'_'.$_FILES['east_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
						
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('east_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'east_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				//West Area Sound File 
			   if($_FILES['west_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;		
					  $file_name = time().'_'.$location_id.'_'.$_FILES['west_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('west_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'west_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
			// Banner & Quiz Images
			   if($_FILES['quiz_image']['error'] != 4){		
					  $config['upload_path'] = $this->quiz_images_path;
					   $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					  //$config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['quiz_image']['name'];	
					  $config['file_name'] =$file_name;
					  $this->upload->initialize($config);
			  if ( ! $this->upload->do_upload('quiz_image')){
					$data['already_msg']=$this->upload->display_errors();
					$success = FALSE;
				}
			    else{
					$data = $this->upload->data();
					$updatefield =array( 
						'quiz_image' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
			   
			    if($_FILES['banner_image']['error'] != 4){		
					  $config['upload_path'] = $this->banner_images_path;
					   $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					  //$config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['banner_image']['name'];	
					  $config['file_name'] =$file_name;
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('banner_image')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$updatefield =array( 
						'banner_image' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
			   //Icons	 
			   if($_FILES['map_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['map_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('map_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'map_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				if($_FILES['web_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $config['file_name'] =time().'_'.$location_id.'-'.$_FILES['web_icon_file']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('web_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$updatefield =array( 
						'web_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				if($_FILES['app_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['app_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('app_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'app_icon ' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				//Insert Digital Media
			   if($location_id!=0){
					    //Digital Audio File
					    $totalaudiofiles= count($_FILES['digital-audio']['name']);
						for($i=0;$i<$totalaudiofiles;$i++){
							if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = audo_file_extensions;
								$config['max_size']	= max_file_size;
								//$config['max_width']  = '0';
								//$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,audio_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 //Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->locations_model->insertDigitalMedia($location_id,video_files,$file_name);
							  } 
					
						   }
						}
						 
						 
						//Digital Vr Files
					    $totalvrfiles= count($_FILES['digital-vr']['name']);
						for($i=0;$i<$totalvrfiles;$i++){
							if($_FILES['digital-vr']['name'][$i]['vr_files']!=''){	
							
								$_FILES['userfile']['name']= $_FILES['digital-vr']['name'][$i]['vr_files'];
								$_FILES['userfile']['type']    = $_FILES['digital-vr']['type'][$i]['vr_files'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-vr']['tmp_name'][$i]['vr_files'];
								$_FILES['userfile']['error']       = $_FILES['digital-vr']['error'][$i]['vr_files'];
								$_FILES['userfile']['size']    = $_FILES['digital-vr']['size'][$i]['vr_files'];
								
								$config['upload_path'] = $this->vr_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,vr_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Digital map2d Files
					    $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
						for($i=0;$i<$total2dmapfiles;$i++){
							if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
							
								$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
								
								$config['upload_path'] = $this->map2d_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,map2d_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Digital panorama Files
					    $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
						for($i=0;$i<$totalpanoramafiles;$i++){
							if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
								
								$config['upload_path'] = $this->panorama_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,panorama_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						 //Digital Video 360
						if(isset($_POST['digital-video360']))
						{
						  $GroupLists = $_POST['digital-video360'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video360_url']!='') 
							  {
								$file_name = $listrow['video360_url'];
								$mediaresult = $this->locations_model->insertDigitalMedia($location_id,video360_files,$file_name);
							  } 
					
						   }
						}
						 
						//Digital VT Files
					    $totalvtfiles= count($_FILES['digital-vt']['name']);
						for($i=0;$i<$totalvtfiles;$i++){
							if($_FILES['digital-vt']['name'][$i]['vt_files']!=''){	
							
								$_FILES['userfile']['name']     =  $_FILES['digital-vt']['name'][$i]['vt_files'];
								$_FILES['userfile']['type']     = $_FILES['digital-vt']['type'][$i]['vt_files'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-vt']['tmp_name'][$i]['vt_files'];
								$_FILES['userfile']['error']    = $_FILES['digital-vt']['error'][$i]['vt_files'];
								$_FILES['userfile']['size']     = $_FILES['digital-vt']['size'][$i]['vt_files'];
								
								$config['upload_path'] = $this->vt_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,vt_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						
					
					
			       //*********************************Location Section*********************//
				    //Location Section
					
					 
					   
					   
					if(isset($_POST['location-section']))
					{
					  $GroupLists = $_POST['location-section'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['section_title']!='') 
						  {
						  $insert_data = array(
								'language_id'=>$this->session->userdata('lang_id'),
								'location_id'=>$location_id,
								'section_title'     => $listrow['section_title'],
								'section_description'     => $listrow['section_description'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_section_id = $this->locations_model->insertLocationSection($insert_data);
						  }
					   }
					}
								
				  //*********************************Facilities Section*********************//
				//Facilities Washroom Group
				if(isset($_POST['washroom-group']))
				{
				  $GroupLists = $_POST['washroom-group'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['washroom_longitude']!='') 
					  {
					  $washroom_availability =  implode(",",$listrow['washroom_availability']);	
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_name_no'  => $listrow['washroom_no'],
							'facility_description'  => $listrow['washroom_description'],
							'facility_type'  =>washroom_facility_type,
							'washroom_availability' => $washroom_availability,
							'longitude'     => $listrow['washroom_longitude'],
							'latitude'     => $listrow['washroom_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Washroom Images 
						$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_images'];
						$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_images'];
						$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_images'];
						$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Washroom 2dmap 
						$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'map2d' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
						
				      }
				   }
			    }
				
				if(isset($_POST['parking-group']))
				{
				  $GroupLists = $_POST['parking-group'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['parking_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_name_no'  => $listrow['parking_no'],
							'facility_description'  => $listrow['parking_description'],
							'facility_type'  => parking_facility_type,
							'parking_type' => $listrow['parking_entry_ticket'],
							'parking_fee' => $listrow['parking_fees_amt'],
							'longitude'     => $listrow['parking_longitude'],
							'latitude'     => $listrow['parking_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Parking Images 
						$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_images'];
						$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_images'];
						$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_images'];
						$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Washroom 2dmap 
						$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'map2d' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
						 
						
				      }
				   }
			    }
				
				
				if(isset($_POST['group-dispensary']))
				{
				  $GroupLists = $_POST['group-dispensary'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['dispensary_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_name_no'  => $listrow['dispensary_no'],
							'facility_description'  => $listrow['dispensary_description'],
							'facility_type'  => dispensary_facility_type,
							'longitude'     => $listrow['dispensary_longitude'],
							'latitude'     => $listrow['dispensary_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Dispensary Images 
						$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_images'];
						$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_images'];
						$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_images'];
						$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Dispensary 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'map2d' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-police-booth']))
				{
				  $GroupLists = $_POST['group-police-booth'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['police_booth_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_name_no'  => $listrow['police_booth_no'],
							'facility_description'  => $listrow['police_booth_description'],
							'facility_type'  => police_booth_facility_type,
							'longitude'     => $listrow['police_booth_longitude'],
							'latitude'     => $listrow['police_booth_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_images'];
						$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_images'];
						$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_images'];
						$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'map2d' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				if(isset($_POST['group-shoe']))
				{
				  $GroupLists = $_POST['group-shoe'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['shoe_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_name_no'  => $listrow['shoe_no'],
							'facility_description'  => $listrow['shoe_description'],
							'facility_type'  => shoe_facility_type,
							'longitude'     => $listrow['shoe_longitude'],
							'latitude'     => $listrow['shoe_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_images'];
						$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_images'];
						$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_images'];
						$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'map2d' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				if(isset($_POST['group-luggage']))
				{
				  $GroupLists = $_POST['group-luggage'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['luggage_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_name_no'  => $listrow['luggage_no'],
							'facility_description'  => $listrow['luggage_description'],
							'facility_type'  => luggage_facility_type,
							'longitude'     => $listrow['luggage_longitude'],
							'latitude'     => $listrow['luggage_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_images'];
						$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_images'];
						$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_images'];
						$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'map2d' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				if(isset($_POST['group-langar']))
				{
				  $GroupLists = $_POST['group-langar'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['langar_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_name_no'  => $listrow['langar_no'],
							'facility_description'  => $listrow['langar_description'],
							'facility_type'  => langar_facility_type,
							'longitude'     => $listrow['langar_longitude'],
							'latitude'     => $listrow['langar_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_images'];
						$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_images'];
						$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_images'];
						$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'map2d' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-ticketcounter']))
				{
				  $GroupLists = $_POST['group-ticketcounter'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['ticketcounter_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => ticketcounter_facility_type,
							'facility_name_no'  => $listrow['ticketcounter_no'],
							'facility_description'  => $listrow['ticketcounter_description'],
							'longitude'     => $listrow['ticketcounter_longitude'],
							'latitude'     => $listrow['ticketcounter_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_images'];
						$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_images'];
						$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_images'];
						$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-enquiry']))
				{
				  $GroupLists = $_POST['group-enquiry'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['enquiry_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => enquiry_facility_type,
							'facility_name_no'  => $listrow['enquiry_no'],
							'facility_description'  => $listrow['enquiry_description'],
							'longitude'     => $listrow['enquiry_longitude'],
							'latitude'     => $listrow['enquiry_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_images'];
						$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_images'];
						$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_images'];
						$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				
				
				if(isset($_POST['group-resthouse']))
				{
				  $GroupLists = $_POST['group-resthouse'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['resthouse_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => resthouse_facility_type,
							'facility_name_no'  => $listrow['resthouse_no'],
							'facility_description'  => $listrow['resthouse_description'],
							'longitude'     => $listrow['resthouse_longitude'],
							'latitude'     => $listrow['resthouse_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_images'];
						$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_images'];
						$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_images'];
						$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				
				if(isset($_POST['group-loccontacts']))
				{
				  $GroupLists = $_POST['group-loccontacts'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['loc_contact_name']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => loccontacts_facility_type,
							'facility_name_no'  => $listrow['loc_contact_name'],
							'facility_description'  => $listrow['loc_contact_details'],
							'contact_mobile_no'     => $listrow['loc_contact_mobile_no'],
							'contact_landline_no'     => $listrow['loc_contact_landline_no'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-loccontacts']['name'][$key]['loccontact_images'];
						$_FILES['userfile']['type']    = $_FILES['group-loccontacts']['type'][$key]['loccontact_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-loccontacts']['tmp_name'][$key]['loccontact_images'];
						$_FILES['userfile']['error']   = $_FILES['group-loccontacts']['error'][$key]['loccontact_images'];
						$_FILES['userfile']['size']  = $_FILES['group-loccontacts']['size'][$key]['loccontact_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
				      }
				   }
			    }
				
				
			/*	if(isset($_POST['location-beacon']))
				{
				  $GroupLists = $_POST['location-beacon'];
				  foreach($GroupLists as $key=> $listrow){
					  if($listrow['beacon_location_name']!='') 
					  {
					    $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'beacon_location_name'  => $listrow['beacon_location_name'],
							'beacon_address'  => $listrow['beacon_address'],
							'beacon_latitude'  => $listrow['beacon_latitude'],
							'beacon_longitude'  => $listrow['beacon_longitude'],
							'beacon_unique_id'  => $listrow['beacon_unique_id'],
							'remarks'  => $listrow['beacon_remarks'],
							'created_by'  => $this->session->userdata('user_id'),
							'created_on'      => date('Y-m-d H:i:s')
						);
						$beacon_location_id = $this->locations_model->insertBeacon($insert_data);
						
						$insertdata = array(
							'beacon_location_id'=>$beacon_location_id,
							'action_plan_id'  => $listrow['action_plan_id'],
							'instruction_id'     => $listrow['instruction_id'],
							'instruction_option_selection'     => $listrow['choose_inst_options'],
							'text_to_speech_description'     => $listrow['text_to_speech_description'],
							'video_url'     => $listrow['beacon_video_url'],
						
							'created_on'      => date('Y-m-d H:i:s')
						);
						$beacon_action_id = $this->locations_model->insertBeaconlocations($insertdata);
						 
						 //Beacon Image
						 
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'beacon_image' => $file_name
								);	
								$unique_id = array('beacon_location_id' =>$beacon_location_id);
								$resultupdate = update_table_fields('beacon_locations',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 
						 //Audio File
				
						$_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_audio_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_audio_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_audio_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_audio_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_audio_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = audo_file_extensions;
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  
							  if($_FILES['userfile']['name']!=''){
								
								$updatefield =array( 
									'beacon_audio_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
							  }
							
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
								  
							    $data['uploads'][$key] = $this->upload->data();
							
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 //Media File
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_media_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_media_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_media_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_media_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_media_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'media_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 //Video File
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_video_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_video_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_video_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_video_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_video_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = video_file_extensions;
						$config['max_size']	= max_file_size;
				
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							
							  if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'beacon_video_file' => $file_name
								);	
								
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id); 
							  }
							 
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
								
							  } 
						 }
				      }
				   }
			    }*/
				
				
				
			}	
				
		/*	  echo "<pre>";
		  print_r($_FILES);
		  echo "</pre>";
		  echo "<br><br><br>";
		  echo "<pre>";
		  print_r($_POST);
		  echo "</pre>";
		  die();*/
		  
			   if($location_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'employees/locations/view');
 		 
	    } //end of add  functionality
			
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$data['kiosk_category_id'] = isset($_POST['kiosk_category_id']) ? $_POST['kiosk_category_id'] : 0;
		$fields = array('language_id'=>$this->session->userdata('lang_id'),'is_active'=>'1');
		$kioskresult = gettableresult('kiosks',$fields,'kiosk_id');
		if($kioskresult!='0')
		{
			$kiosk_ids=array();
			foreach($kioskresult as $kkey => $kival) {
			  $kiosk_ids[] = $kival->kiosk_id;	
			}
		  $kioskids =  implode(',',$kiosk_ids);
		}else
		{
			$kioskids =  '';
		}
		$data['kioskids'] = $kioskids;
		
		$category_ids=array();
		if(!empty($_POST['location_category'])){
			foreach($_POST['location_category'] as $key=>$val){
				$category_ids[] = $val;
			}
			$categoryids =  implode(',',$category_ids);
		} else  {
			$categoryids =  '';
		}
		
		$data['category_ids'] = $categoryids;
		
		/*  $fields = array('location_id'=>$location_id,'is_active'=>'1');
			$catresult = gettableresult('location_categories',$fields,'category_id');
			if(is_array($catresult))
			{
				$category_ids=array();
				foreach($catresult as $ckey => $catval) {
				  $category_ids[] = $catval->category_id;	
				}
			  $categoryids =  implode(',',$category_ids);
			  //echo "---------------->".$category_ids;
			  //$categoryids =  "'".$categoryids."'";
			 //echo "---------------->".$categoryids;
			}else
			{
				$categoryids =  '';
			}
			
			//print_r($category_ids);					
		  $data['category_ids'] = $categoryids; */
		  
	   $this->load->view('employees/locations/add.php', $data);
	}
	
	public function edit($location_id,$last_copy_segment=null){
		
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('edit_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('edit_location_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('location_name', ''.$this->lang->line('location_location_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_name', ''.$this->lang->line('location_short_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_description', ''.$this->lang->line('location_short_description_text').'', 'required|trim');
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  //$this->form_validation->set_rules('state_name', ''.$this->lang->line('location_state_text').'', 'required|trim');
		  $this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		  $this->form_validation->set_rules('estimated_visit_time', ''.$this->lang->line('location_estimated_visit_time_text').'', 'trim');
		  //$this->form_validation->set_rules('location_entry_ticket', ''.$this->lang->line('location_entry_ticket_text').'', 'required|trim');
		  /* if($this->input->post('location_entry_ticket')=='pa')
		  {
			$this->form_validation->set_rules('adult_fee', ''.$this->lang->line('location_adult_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('child_fee', ''.$this->lang->line('location_child_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('senior_citizen_fee', ''.$this->lang->line('location_senior_citizen_fee_text').'', 'required|trim|integer');  
		  } */
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('alert1_distance', ''.$this->lang->line('location_alert1_distance_text').'', 'trim');
		  /*$this->form_validation->set_rules('alert2_distance', ''.$this->lang->line('location_alert2_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert3_distance', ''.$this->lang->line('location_alert3_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert4_distance', ''.$this->lang->line('location_alert4_distance_text').'', 'trim');*/
		  
		  $this->form_validation->set_rules('alert1_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  /*$this->form_validation->set_rules('alert2_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert3_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert4_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');*/
		  
		  $this->form_validation->set_rules('north_area', ''.$this->lang->line('location_north_text').'', 'trim');
		  $this->form_validation->set_rules('north_area_title', ''.$this->lang->line('location_north_title_text').'', 'trim');
		  $this->form_validation->set_rules('south_area', ''.$this->lang->line('location_south_text').'', 'trim');
		  $this->form_validation->set_rules('south_area_title', ''.$this->lang->line('location_south_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area_title', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('west_area', ''.$this->lang->line('location_west_text').'', 'trim');
		  $this->form_validation->set_rules('west_area_title', ''.$this->lang->line('location_west_title_text').'', 'trim');
		  $gps_info=  $this->locations_model->gps_info($location_id,1);
		  $data['gpsinfo']=$gps_info;
		  
		  //print '<pre>';print_r($gps_info);die;
		if ($this->form_validation->run()) {
		    // GPS info
		   
            $lid= $this->input->post('location_id');
            //$gps_spot= $this->input->post('gps_onspot');
            $gps_enabled= $this->input->post('gps_enabled');
            $gps_notification= $this->input->post('gps_notification');	//
            $alert1_distance= $this->input->post('alert1_distance');
            $alert1_sound_file_id= $this->input->post('alert1_sound_file_id');
            $gps_video_link= $this->input->post('gps_video_link');
            $gps_video_title= $this->input->post('gps_video_title');
			 // GPS info 
			 
			$details_gps=json_decode($gps_info->location_gps_info,true);
			 $initial_file_name='';
		    if($_FILES['gps_audio_file_initial']['error'] != 4){		
				  $config['upload_path'] = $this->gps_path;
				  $config['allowed_types'] = audo_file_extensions;
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$lid.'_'.$_FILES['gps_audio_file_initial']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				    if ( ! $this->upload->do_upload('gps_audio_file_initial')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
					} else {
						$data = $this->upload->data();
						$initial_file_name = $data['file_name'];
						//die();
					}
	        }else{
	            $initial_file_name=$details_gps['initial'];
	        }
	        $popup_file_name='';
	        if($_FILES['gps_audio_file_popup']['error'] != 4){		
				  $config['upload_path'] = $this->gps_path;
				  $config['allowed_types'] = audo_file_extensions;
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$lid.'_'.$_FILES['gps_audio_file_popup']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				    if ( ! $this->upload->do_upload('gps_audio_file_popup')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
					} else {
						$data = $this->upload->data();
						$popup_file_name = $data['file_name'];
						//die();
					}
	        }else{
	            $popup_file_name=$details_gps['popup_audio'];
	        }
	        
	        $media_file_name='';
	        if($_FILES['gps_media_file_popup']['error'] != 4){		
				  $config['upload_path'] = $this->gps_path;
				  $config['allowed_types'] = 'jpeg|gif|jpg|png';
				  $config['max_size']	= max_file_size;
				 // $config['max_width']  = '50';
				  //$config['max_height']  = '50';
				  $config['overwrite'] = true;	
				  $file_name = time().'_'.$lid.'_'.$_FILES['gps_media_file_popup']['name'];	
				  $config['file_name'] =$file_name;
				  $this->upload->initialize($config);
				    if ( ! $this->upload->do_upload('gps_media_file_popup')){
						$data['already_msg']=$this->upload->display_errors();
						$success = FALSE;
					} else {
						$data = $this->upload->data();
						$media_file_name = $data['file_name'];
						//die();
					}
	        }else{
	            $media_file_name=$details_gps['media_file'];
	        }
	        $alert1dist=$this->input->post('alert1_distance');
	        $alert1_sound_file_id=$this->input->post('alert1_sound_file_id');
			 $gps_info_array=array('initial'=>$initial_file_name,'popup_audio'=>$popup_file_name,'media_file'=>$media_file_name,'video_link'=>$gps_video_link,'video_title'=>$gps_video_title,'alert1_distance'=>$alert1dist,'alert1_sound'=>$alert1_sound_file_id);
			$check_record=$this->locations_model->checkrecord_exists_gps($lid,1);
			if($check_record==0){
			    $insertrec=$this->locations_model->insert_gps_info($location_id,1,json_encode($gps_info_array));
    			
			}else{
			     $unique_id = array('location_id' =>$location_id,'language_id'=>1);
    			 $updatefield=array('location_gps_info'=>json_encode($gps_info_array));
    			 $updategps_info=update_table_fields('locations_gps_info',$updatefield,$unique_id);
			}
			 //gps end here 
			 
			 
		 	 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
			     //print '<pre>';print_R($_POST['availability']);die;
			  foreach($_POST['week_days'] as $key => $weekdayval) {
			  if(in_array($weekdayval,$_POST['availability']))
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			  }
			 }
			 /*echo "<br>";
			  echo "<br>";
			  echo "<pre>";
			  print_r($hours_details);
			  echo "</pre>"; 
			  echo "<br>";
			  echo "<br>";
			  die();*/
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			  
			 //Get Directions Json
			  $direction_locations =array();
			  
			  $direction_locations['northstartpointlongitude']= $_POST['northstartpointlongitude']; 	
			  $direction_locations['northstartpointlatitude']= $_POST['northstartpointlatitude']; 	
			  $direction_locations['northendpointlongitude']= $_POST['northendpointlongitude']; 	
			  $direction_locations['northendpointlatitude']= $_POST['northendpointlatitude']; 	
			  
			  $direction_locations['southstartpointlongitude']= $_POST['southstartpointlongitude']; 	
			  $direction_locations['southstartpointlatitude']= $_POST['southstartpointlatitude']; 	
			  $direction_locations['southendpointlongitude']= $_POST['southendpointlongitude']; 	
			  $direction_locations['southendpointlatitude']= $_POST['southendpointlatitude'];
			  
			  $direction_locations['eaststartpointlongitude']= $_POST['eaststartpointlongitude']; 	
			  $direction_locations['eaststartpointlatitude']= $_POST['eaststartpointlatitude']; 	
			  $direction_locations['eastendpointlongitude']= $_POST['eastendpointlongitude']; 	
			  $direction_locations['eastendpointlatitude']= $_POST['eastendpointlatitude'];
			  
			  $direction_locations['weststartpointlongitude']= $_POST['weststartpointlongitude']; 	
			  $direction_locations['weststartpointlatitude']= $_POST['weststartpointlatitude']; 	
			  $direction_locations['westendpointlongitude']= $_POST['westendpointlongitude']; 	
			  $direction_locations['westendpointlatitude']= $_POST['westendpointlatitude'];
			  
			  $directionlocations = json_encode($direction_locations);
			
			   if($last_copy_segment!='c'){
				   $result =  $this->locations_model->update_location($this->input->post('location_id'),$working_hours,$directionlocations);
			   } else {
				   $location_id =  $this->locations_model->add($working_hours,$directionlocations);
					//$main_location_id = $this->locations_model->new_record_copy_media($this->input->post('location_id'),$location_id);
				   //$this->locations_model->update_status($location_id,'1');
				   $result=1;
			   }
		 	   
			 
			   
			   
			     //North Area Sound File 
			   if($_FILES['north_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					  //$config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['north_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;
					  $this->upload->initialize($config);
					    if ( ! $this->upload->do_upload('north_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						} else {
							$data = $this->upload->data();
							$updatefield =array( 
								'north_area_sound_file' => $file_name,
							);	
							$unique_id = array('location_id' =>$location_id);
							$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
							//die();
						}
		         }
				
				
			   //South Area Sound File 
			    if($_FILES['south_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					  //$config['max_width']  = '50';
					 //$config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['south_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('south_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'south_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				//East Area Sound File 
			    if($_FILES['east_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $file_name = time().'_'.$location_id.'_'.$_FILES['east_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
						
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('east_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'east_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				//West Area Sound File 
			    if($_FILES['west_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;		
					  $file_name = time().'_'.$location_id.'_'.$_FILES['west_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('west_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'west_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				// Banner & Quiz Images
			   if($_FILES['quiz_image']['error'] != 4){		
					  $config['upload_path'] = $this->quiz_images_path;
					   $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					  //$config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['quiz_image']['name'];	
					  $config['file_name'] =$file_name;
					  $this->upload->initialize($config);
			  if ( ! $this->upload->do_upload('quiz_image')){
					$data['already_msg']=$this->upload->display_errors();
					$success = FALSE;
				}
			    else{
					$data = $this->upload->data();
					$updatefield =array( 
						'quiz_image' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
			   
			    if($_FILES['banner_image']['error'] != 4){		
					  $config['upload_path'] = $this->banner_images_path;
					   $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					  //$config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['banner_image']['name'];	
					  $config['file_name'] =$file_name;
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('banner_image')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$updatefield =array( 
						'banner_image' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
			    //Icons	 
			    if($_FILES['map_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['map_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('map_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'map_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				 if($_FILES['web_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $config['file_name'] =time().'_'.$location_id.'-'.$_FILES['web_icon_file']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('web_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$updatefield =array( 
						'web_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				 if($_FILES['app_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['app_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('app_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'app_icon ' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				//  echo $result;
			  // die();
			   	//Insert Digital Media
			   if($location_id!=0){
					    //Digital Audio File
					    $totalaudiofiles= count($_FILES['digital-audio']['name']);
						for($i=0;$i<$totalaudiofiles;$i++){
							if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = audo_file_extensions;
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,audio_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 //Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->locations_model->insertDigitalMedia($location_id,video_files,$file_name);
							  } 
					
						   }
						}
						 
						 
						//Digital Vr Files
					    $totalvrfiles= count($_FILES['digital-vr']['name']);
						for($i=0;$i<$totalvrfiles;$i++){
							if($_FILES['digital-vr']['name'][$i]['vr_files']!=''){	
							
								$_FILES['userfile']['name']= $_FILES['digital-vr']['name'][$i]['vr_files'];
								$_FILES['userfile']['type']    = $_FILES['digital-vr']['type'][$i]['vr_files'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-vr']['tmp_name'][$i]['vr_files'];
								$_FILES['userfile']['error']       = $_FILES['digital-vr']['error'][$i]['vr_files'];
								$_FILES['userfile']['size']    = $_FILES['digital-vr']['size'][$i]['vr_files'];
								
								$config['upload_path'] = $this->vr_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,vr_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Digital 2dMap Files
					    $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
						for($i=0;$i<$total2dmapfiles;$i++){
							if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
							
								$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
								
								$config['upload_path'] = $this->map2d_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,map2d_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Digital panorama Files
					    $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
						for($i=0;$i<$totalpanoramafiles;$i++){
							if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
								
								$config['upload_path'] = $this->panorama_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,panorama_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						 //Digital Video 360
						if(isset($_POST['digital-video360']))
						{
						  $GroupLists = $_POST['digital-video360'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video360_url']!='') 
							  {
								$file_name = $listrow['video360_url'];
								$mediaresult = $this->locations_model->insertDigitalMedia($location_id,video360_files,$file_name);
							  } 
					
						   }
						}
						 
						//Digital VT Files
					    $totalvtfiles= count($_FILES['digital-vt']['name']);
						for($i=0;$i<$totalvtfiles;$i++){
							if($_FILES['digital-vt']['name'][$i]['vt_files']!=''){	
							
								$_FILES['userfile']['name']     =  $_FILES['digital-vt']['name'][$i]['vt_files'];
								$_FILES['userfile']['type']     = $_FILES['digital-vt']['type'][$i]['vt_files'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-vt']['tmp_name'][$i]['vt_files'];
								$_FILES['userfile']['error']    = $_FILES['digital-vt']['error'][$i]['vt_files'];
								$_FILES['userfile']['size']     = $_FILES['digital-vt']['size'][$i]['vt_files'];
								
								$config['upload_path'] = $this->vt_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertDigitalMedia($location_id,vt_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//*********************************Location Section*********************//
						 //Location Section
						if(isset($_POST['location-section']))
						{
						  $GroupLists = $_POST['location-section'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['section_title']!='') 
							  {
							  $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'section_title'     => $listrow['section_title'],
									'section_description'     => $listrow['section_description'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_section_id = $this->locations_model->insertLocationSection($insert_data);
							  }
						   }
						}
					 
						 //*********************************Facilities*********************//
						 //Facilities Washroom Group
						//Old
						
					   $old_washroom_group=$this->input->post('old-washroom-group');
					   
					   if(isset($old_washroom_group) &&  !empty($old_washroom_group)){
						   foreach($old_washroom_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'], $content['washroom_no'], $content['washroom_description'], $content['washroom_longitude'], $content['washroom_latitude']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['washroom-group']))
						{
						  $GroupLists = $_POST['washroom-group'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['washroom_longitude']!='') 
							  {
							  $washroom_availability =  implode(",",$listrow['washroom_availability']);	
							   //$washroom_availability =  $listrow['washroom_availability'];	
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['washroom_no'],
									'facility_description'  => $listrow['washroom_description'],
									'facility_type'  => washroom_facility_type,
									'washroom_availability' => $washroom_availability,
									'longitude'     => $listrow['washroom_longitude'],
									'latitude'     => $listrow['washroom_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Washroom Images 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_images'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_images'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_images'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								
							  }
						   }
						}
						
						$old_parking_group=$this->input->post('old-parking-group');
						
						if(isset($old_parking_group) &&  !empty($old_parking_group)){
						   foreach($old_parking_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'], $content['parking_no'], $content['parking_description'], $content['parking_longitude'], $content['parking_latitude'], $content['parking_entry_ticket']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['parking-group']))
						{
						  $GroupLists = $_POST['parking-group'];
						  foreach($GroupLists as $key=> $listrow){
							  /*echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";
							  die();*/
							  if($listrow['parking_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['parking_no'],
									'facility_description'  => $listrow['parking_description'],
									'facility_type'  => parking_facility_type,
									'parking_type' => $listrow['parking_entry_ticket'],
									'parking_fee' => $listrow['parking_fees_amt'],
									'longitude'     => $listrow['parking_longitude'],
									'latitude'     => $listrow['parking_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Parking Images 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_images'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_images'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_images'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								 
								
							  }
						   }
						}
						
						$old_dispensary_group=$this->input->post('old-group-dispensary');
						
						if(isset($old_dispensary_group) &&  !empty($old_dispensary_group)){
						   foreach($old_dispensary_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'], $content['dispensary_no'], $content['dispensary_description'], $content['dispensary_longitude'], $content['dispensary_latitude']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-dispensary']))
						{
						  $GroupLists = $_POST['group-dispensary'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['dispensary_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['dispensary_no'],
									'facility_description'  => $listrow['dispensary_description'],
									'facility_type'  => dispensary_facility_type,
									'longitude'     => $listrow['dispensary_longitude'],
									'latitude'     => $listrow['dispensary_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Dispensary Images 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_images'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_images'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_images'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Dispensary 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_police_booth_group=$this->input->post('old-group-police-booth');
						
						if(isset($old_police_booth_group) &&  !empty($old_police_booth_group)){
						   foreach($old_police_booth_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'], $content['police_booth_no'], $content['police_booth_description'], $content['police_booth_longitude'], $content['police_booth_latitude']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-police-booth']))
						{
						  $GroupLists = $_POST['group-police-booth'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['police_booth_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['police_booth_no'],
									'facility_description'  => $listrow['police_booth_description'],
									'facility_type'  => police_booth_facility_type,
									'longitude'     => $listrow['police_booth_longitude'],
									'latitude'     => $listrow['police_booth_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_images'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_images'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_images'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_shoe_group=$this->input->post('old-group-shoe');
						
						if(isset($old_shoe_group) &&  !empty($old_shoe_group)){
						   foreach($old_shoe_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'],$content['shoe_no'], $content['shoe_description'], $content['shoe_longitude'], $content['shoe_latitude']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-shoe']))
						{
						  $GroupLists = $_POST['group-shoe'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['shoe_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['shoe_no'],
									'facility_description'  => $listrow['shoe_description'],
									'facility_type'  => shoe_facility_type,
									'longitude'     => $listrow['shoe_longitude'],
									'latitude'     => $listrow['shoe_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_images'];
								$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_images'];
								$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_images'];
								$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_luggage_group=$this->input->post('old-group-luggage');
						
						if(isset($old_luggage_group) &&  !empty($old_luggage_group)){
						   foreach($old_luggage_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'], $content['luggage_no'], $content['luggage_description'], $content['luggage_longitude'], $content['luggage_latitude']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-luggage']))
						{
						  $GroupLists = $_POST['group-luggage'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['luggage_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['luggage_no'],
									'facility_description'  => $listrow['luggage_description'],
									'facility_type'  => luggage_facility_type,
									'longitude'     => $listrow['luggage_longitude'],
									'latitude'     => $listrow['luggage_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_images'];
								$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_images'];
								$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_images'];
								$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_langar_group=$this->input->post('old-group-langar');
						
						if(isset($old_langar_group) &&  !empty($old_langar_group)){
						   foreach($old_langar_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'], $content['langar_no'], $content['langar_description'], $content['langar_longitude'], $content['langar_latitude']);
							   
						   }
						   
					   }
						if(isset($_POST['group-langar']))
						{
						  $GroupLists = $_POST['group-langar'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['langar_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['langar_no'],
									'facility_description'  => $listrow['langar_description'],
									'facility_type'  => langar_facility_type,
									'longitude'     => $listrow['langar_longitude'],
									'latitude'     => $listrow['langar_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_images'];
								$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_images'];
								$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_images'];
								$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_ticketcounter_group=$this->input->post('old-group-ticketcounter');
						
						if(isset($old_ticketcounter_group) &&  !empty($old_ticketcounter_group)){
						   foreach($old_ticketcounter_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'],$content['ticketcounter_no'], $content['ticketcounter_description'], $content['ticketcounter_longitude'], $content['ticketcounter_latitude']);
							   
						   }
						   
					   }
						
				 if(isset($_POST['group-ticketcounter']))
					{
					  $GroupLists = $_POST['group-ticketcounter'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['ticketcounter_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('lang_id'),
								'location_id'=>$location_id,
								'facility_type'  => ticketcounter_facility_type,
								'facility_name_no'  => $listrow['ticketcounter_no'],
								'facility_description'  => $listrow['ticketcounter_description'],
								'longitude'     => $listrow['ticketcounter_longitude'],
								'latitude'     => $listrow['ticketcounter_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->locations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_images'];
							$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_images'];
							$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_images'];
							$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							 
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					
					$old_enquiry_group=$this->input->post('old-group-enquiry');
					
					if(isset($old_enquiry_group) &&  !empty($old_enquiry_group)){
						   foreach($old_enquiry_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'], $content['enquiry_no'], $content['enquiry_description'], $content['enquiry_longitude'], $content['enquiry_latitude']);
							   
						   }
						   
					   }
					
					if(isset($_POST['group-enquiry']))
					{
					  $GroupLists = $_POST['group-enquiry'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['enquiry_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('lang_id'),
								'location_id'=>$location_id,
								'facility_type'  => enquiry_facility_type,
								'facility_name_no'  => $listrow['enquiry_no'],
								'facility_description'  => $listrow['enquiry_description'],
								'longitude'     => $listrow['enquiry_longitude'],
								'latitude'     => $listrow['enquiry_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->locations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_images'];
							$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_images'];
							$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_images'];
							$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							 
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					$old_resthouse_group=$this->input->post('old-group-resthouse');
					if(isset($old_resthouse_group) &&  !empty($old_resthouse_group)){
						   foreach($old_resthouse_group as $content){
							   
							   $this->locations_model->editOldFacilities($content['location_facility_id'], $content['resthouse_no'], $content['resthouse_description'], $content['resthouse_longitude'], $content['resthouse_latitude']);
							   
						   }
						   
					   }
					
					
					if(isset($_POST['group-resthouse']))
					{
					  $GroupLists = $_POST['group-resthouse'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>"; 
						  echo "<br>";*/
						  if($listrow['resthouse_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('lang_id'),
								'location_id'=>$location_id,
								'facility_type'  => resthouse_facility_type,
								'facility_name_no'  => $listrow['resthouse_no'],
								'facility_description'  => $listrow['resthouse_description'],
								'longitude'     => $listrow['resthouse_longitude'],
								'latitude'     => $listrow['resthouse_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->locations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_images'];
							$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_images'];
							$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_images'];
							$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							 
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					
					if(isset($_POST['group-loccontacts']))
				    {
				    $GroupLists = $_POST['group-loccontacts'];
				    foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['loc_contact_name']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => loccontacts_facility_type,
							'facility_name_no'  => $listrow['loc_contact_name'],
							'facility_description'  => $listrow['loc_contact_details'],
							'contact_mobile_no'     => $listrow['loc_contact_mobile_no'],
							'contact_landline_no'     => $listrow['loc_contact_landline_no'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Location Contacts Images 
						$_FILES['userfile']['name']  = $_FILES['group-loccontacts']['name'][$key]['loccontact_images'];
						$_FILES['userfile']['type']    = $_FILES['group-loccontacts']['type'][$key]['loccontact_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-loccontacts']['tmp_name'][$key]['loccontact_images'];
						$_FILES['userfile']['error']   = $_FILES['group-loccontacts']['error'][$key]['loccontact_images'];
						$_FILES['userfile']['size']  = $_FILES['group-loccontacts']['size'][$key]['loccontact_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
				      }
				   }
			    }
				
				/*if(isset($_POST['location-beacon']))
				{
				  $GroupLists = $_POST['location-beacon'];
				  foreach($GroupLists as $key=> $listrow){
				
					  if($listrow['beacon_location_name']!='') 
					  {
					    $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'beacon_location_name'  => $listrow['beacon_location_name'],
							'beacon_address'  => $listrow['beacon_address'],
							'beacon_latitude'  => $listrow['beacon_latitude'],
							'beacon_longitude'  => $listrow['beacon_longitude'],
							'beacon_unique_id'  => $listrow['beacon_unique_id'],
							'remarks'  => $listrow['beacon_remarks'],
							'created_by'  => $this->session->userdata('user_id'),
							'created_on'      => date('Y-m-d H:i:s')
						);
						$beacon_location_id = $this->locations_model->insertBeacon($insert_data);
						
						$insertdata = array(
							'beacon_location_id'=>$beacon_location_id,
							'action_plan_id'  => $listrow['action_plan_id'],
							'instruction_id'     => $listrow['instruction_id'],
							'instruction_option_selection'     => $listrow['choose_inst_options'],
							'text_to_speech_description'     => $listrow['text_to_speech_description'],
							'video_url'     => $listrow['beacon_video_url'],
						
							'created_on'      => date('Y-m-d H:i:s')
						);
						$beacon_action_id = $this->locations_model->insertBeaconlocations($insertdata);
						 
						 //Beacon Image
						 
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'beacon_image' => $file_name
								);	
								$unique_id = array('beacon_location_id' =>$beacon_location_id);
								$resultupdate = update_table_fields('beacon_locations',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 
						 //Audio File
				
						$_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_audio_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_audio_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_audio_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_audio_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_audio_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = audo_file_extensions;
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  
							  if($_FILES['userfile']['name']!=''){
								
								$updatefield =array( 
									'beacon_audio_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
							  }
							
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
								  
							    $data['uploads'][$key] = $this->upload->data();
							
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 //Media File
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_media_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_media_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_media_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_media_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_media_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'media_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 //Video File
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_video_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_video_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_video_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_video_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_video_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = video_file_extensions;
						$config['max_size']	= max_file_size;
				
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							
							  if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'beacon_video_file' => $file_name
								);	
								
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id); 
							  }
							 
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    $data['uploads'][$key] = $this->upload->data();
								
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							
							  } 
						 }
				      }
				   }
			    }*/
					
					
				}	
		        
		  
	
		
		      if($result=='1')
				{   
				   if($last_copy_segment!='c'){
					   $msg = $this->lang->line('update_text_message');
				   } else {
					   $msg = $this->lang->line('copy_success_text_message');
				   }
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        if($last_copy_segment!='c'){
					redirect(base_url() . "employees/locations/view/".$this->input->post('location_id'));
				} else {
					redirect(base_url() . "employees/locations/view/");
				}
		
		}		
		  $result =  $this->locations_model->location_edit($location_id);
		  $data['edit_data'] = $result;
		  $fields = array('location_id'=>$result->location_id,'is_active'=>'1');
		  $catrow = gettableinfo('location_categories',$fields);
		  
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  
		   $fields = array('location_id'=>$result->location_id,'language_id'=>$this->session->userdata('lang_id'),'is_active'=>'1');
		   $deptrow = gettableinfo('location_departments',$fields);
		   $deptrow = gettableinfowithfields('location_departments',$fields,'department_id');
		   
		   $data['department_id'] = isset($deptrow->department_id) ? $deptrow->department_id : 0;
		 
		  $kioskresults =  $this->locations_model->location_kioskedit($location_id);
		  $data['kiosk_category_id'] = isset($_POST['kiosk_category_id']) ? $_POST['kiosk_category_id'] :0;
		  if(is_array($kioskresults))
		  {
			$kiosk_ids=array();
			foreach($kioskresults as $kkey => $kival) {
			  $kiosk_ids[] = $kival->kiosk_id;	
			}
		   $kioskids =  implode(',',$kiosk_ids);
		  }else
		  {
			$kioskids =  '';
		  }
		  
		 // echo "---------------->".$kioskids;
	 	 $data['kioskids'] = $kioskids;
	
		    $fields = array('location_id'=>$location_id,'is_active'=>'1');
			$catresult = gettableresult('location_categories',$fields,'category_id');
			if($catresult!='0'){
    			if(is_array($catresult))
    			{
    				$category_ids=array();
    				foreach($catresult as $ckey => $catval) {
    				  $category_ids[] = $catval->category_id;	
    				}
    			  $categoryids =  implode(',',$category_ids);
    			  //echo "---------------->".$category_ids;
    			  //$categoryids =  "'".$categoryids."'";
    			 //echo "---------------->".$categoryids;
    			}else
    			{
    				$categoryids =  '';
    			}
	        }else
    			{
    				$categoryids =  '';
    			}
			
			//print_r($category_ids);					
		  $data['category_ids'] = $categoryids;
		
		  
		    $qr_filename=$result->location_name;
			$qr_filename_id=$result->location_id;
			//print '<pre>';print_r($result);die;
			/* QR Code starts from here ===*/
			$params['data'] = $qr_filename."_".$qr_filename_id;
			$params['level'] = 'H';
			$params['size'] = 10;
			$params['savename'] = FCPATH.'/qr_code/'.$qr_filename_id.'.png';
			$this->ciqrcode->generate($params);
			/* QR Code end from here ===*/
			$qrcode=$qr_filename_id.'.png';
			$data['qrimg']=$qrcode;
		  
		  $this->load->view('employees/locations/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	
	public function reccpy($location_id){
/* 		   echo "<pre>";
		  print_r($this->input->post());
		  die; */
		  
		  //Set Sessions
		  if($this->input->post('content_language_id')!=''){
			  $this->session->set_userdata('content_language_id', $this->input->post('content_language_id'));
		  } 
		 
 		  if($this->input->post('content_digital_media')!=''){
			  $this->session->set_userdata('content_digital_media', $this->input->post('content_digital_media'));
		  } else {
			  $this->session->set_userdata('content_digital_media', '0');
		  } 
		  
		  if($this->input->post('content_facilities')){
			  $this->session->set_userdata('content_facilities', $this->input->post('content_facilities'));
		  } else {
			  $this->session->set_userdata('content_facilities', '0');
		  } 
		  
		  $old_location_id=$location_id;
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('edit_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('edit_location_title');
		  $data['already_msg'] = "";
		  
		 /*  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim'); */
		  
		  $this->form_validation->set_rules('location_name', ''.$this->lang->line('location_location_name_text').'', 'required|trim');
		  /* $this->form_validation->set_rules('short_name', ''.$this->lang->line('location_short_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_description', ''.$this->lang->line('location_short_description_text').'', 'required|trim');
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  $this->form_validation->set_rules('state_name', ''.$this->lang->line('location_state_text').'', 'required|trim');
		  $this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		  $this->form_validation->set_rules('estimated_visit_time', ''.$this->lang->line('location_estimated_visit_time_text').'', 'trim');
		  $this->form_validation->set_rules('location_entry_ticket', ''.$this->lang->line('location_entry_ticket_text').'', 'required|trim');
		  if($this->input->post('location_entry_ticket')=='pa')
		  {
			$this->form_validation->set_rules('adult_fee', ''.$this->lang->line('location_adult_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('child_fee', ''.$this->lang->line('location_child_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('senior_citizen_fee', ''.$this->lang->line('location_senior_citizen_fee_text').'', 'required|trim|integer');  
		  }
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('alert1_distance', ''.$this->lang->line('location_alert1_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert2_distance', ''.$this->lang->line('location_alert2_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert3_distance', ''.$this->lang->line('location_alert3_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert4_distance', ''.$this->lang->line('location_alert4_distance_text').'', 'trim');
		  
		  $this->form_validation->set_rules('alert1_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert2_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert3_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert4_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  
		  $this->form_validation->set_rules('north_area', ''.$this->lang->line('location_north_text').'', 'trim');
		  $this->form_validation->set_rules('north_area_title', ''.$this->lang->line('location_north_title_text').'', 'trim');
		  $this->form_validation->set_rules('south_area', ''.$this->lang->line('location_south_text').'', 'trim');
		  $this->form_validation->set_rules('south_area_title', ''.$this->lang->line('location_south_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area_title', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('west_area', ''.$this->lang->line('location_west_text').'', 'trim');
		  $this->form_validation->set_rules('west_area_title', ''.$this->lang->line('location_west_title_text').'', 'trim'); */
		  
		if ($this->form_validation->run()) {
			 $ip=$_SERVER['REMOTE_ADDR'];
			 if($ip=='103.17.97.1811'){
			   echo "<pre>";
			   print_r($this->input->post());
			   //print_r($_FILES);
			   die;	 
			 }
		 	 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
			  foreach($_POST['week_days'] as $key => $weekdayval) {
			  if(in_array($weekdayval,$_POST['availability']))
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			  }
			 }
			 /*echo "<br>";
			  echo "<br>";
			  echo "<pre>";
			  print_r($hours_details);
			  echo "</pre>"; 
			  echo "<br>";
			  echo "<br>";
			  die();*/
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			  
			 //Get Directions Json
			  $direction_locations =array();
			  
			  $direction_locations['northstartpointlongitude']= $_POST['northstartpointlongitude']; 	
			  $direction_locations['northstartpointlatitude']= $_POST['northstartpointlatitude']; 	
			  $direction_locations['northendpointlongitude']= $_POST['northendpointlongitude']; 	
			  $direction_locations['northendpointlatitude']= $_POST['northendpointlatitude']; 	
			  
			  $direction_locations['southstartpointlongitude']= $_POST['southstartpointlongitude']; 	
			  $direction_locations['southstartpointlatitude']= $_POST['southstartpointlatitude']; 	
			  $direction_locations['southendpointlongitude']= $_POST['southendpointlongitude']; 	
			  $direction_locations['southendpointlatitude']= $_POST['southendpointlatitude'];
			  
			  $direction_locations['eaststartpointlongitude']= $_POST['eaststartpointlongitude']; 	
			  $direction_locations['eaststartpointlatitude']= $_POST['eaststartpointlatitude']; 	
			  $direction_locations['eastendpointlongitude']= $_POST['eastendpointlongitude']; 	
			  $direction_locations['eastendpointlatitude']= $_POST['eastendpointlatitude'];
			  
			  $direction_locations['weststartpointlongitude']= $_POST['weststartpointlongitude']; 	
			  $direction_locations['weststartpointlatitude']= $_POST['weststartpointlatitude']; 	
			  $direction_locations['westendpointlongitude']= $_POST['westendpointlongitude']; 	
			  $direction_locations['westendpointlatitude']= $_POST['westendpointlatitude'];
			  
			  $directionlocations = json_encode($direction_locations);
			  
						 
			
			   //copy
			   
			   $location_id =  $this->locations_model->addContent($working_hours,$directionlocations);
			   //$location_id='108';
				//$main_location_id = $this->locations_model->new_record_copy_media($this->input->post('location_id'),$location_id);
			   //$this->locations_model->update_status($location_id,'1');
			   $result=1;
			   
		 	   
			 
			   
			   
			     //North Area Sound File 
			   if($_FILES['north_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					  //$config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['north_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;
					  $this->upload->initialize($config);
					    if ( ! $this->upload->do_upload('north_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						} else {
							$data = $this->upload->data();
							$updatefield =array( 
								'north_area_sound_file' => $file_name,
							);	
							$unique_id = array('location_id' =>$location_id);
							$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
							//die();
						}
		         }
				
				
			   //South Area Sound File 
			    if($_FILES['south_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					  //$config['max_width']  = '50';
					 //$config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['south_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('south_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'south_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				//East Area Sound File 
			    if($_FILES['east_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $file_name = time().'_'.$location_id.'_'.$_FILES['east_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
						
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('east_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'east_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				//West Area Sound File 
			    if($_FILES['west_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = audo_file_extensions;
					  $config['max_size']	= max_file_size;
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;		
					  $file_name = time().'_'.$location_id.'_'.$_FILES['west_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('west_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'west_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				 
			    //Icons	 
			    if($_FILES['map_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['map_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('map_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'map_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				 if($_FILES['web_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $config['file_name'] =time().'_'.$location_id.'-'.$_FILES['web_icon_file']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('web_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$updatefield =array( 
						'web_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				 if($_FILES['app_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '5120';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['app_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('app_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'app_icon ' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				//  echo $result;
			  // die();
			   	//Insert Digital Media
			   if($location_id!=0){
				   
				   
					   //Old Digital Audio Files
					   $old_digital_audio_files=$this->input->post('old-digital-audio');
					   
					   if(isset($old_digital_audio_files) &&  !empty($old_digital_audio_files)){
						   foreach($old_digital_audio_files as $filename){
							   
							   $this->locations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['audio_file'],$this->audio_path);
							   
						   }
						   
					   }
					   
					   
					    //Digital Audio File
					    $totalaudiofiles= count($_FILES['digital-audio']['name']);
						for($i=0;$i<$totalaudiofiles;$i++){
							if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = audo_file_extensions;
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertContentDigitalMedia($location_id,audio_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
					  
					   //Old Digital Gallery Files
					   $old_digital_gallery_files=$this->input->post('old-digital-gallery');
					   
					   if(isset($old_digital_gallery_files) &&  !empty($old_digital_gallery_files)){
						   foreach($old_digital_gallery_files as $filename){
							   
							   $this->locations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['gallery_images'],$this->gallery_path);
							   
						   }
						   
					   }
						
							   
					   //Digital Gallery Files
						$totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertContentDigitalMedia($location_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							} 
						 }
						 
					   //Old Digital Video Files
					   $old_digital_video_files=$this->input->post('old-digital-video');
					   
					   if(isset($old_digital_video_files) &&  !empty($old_digital_video_files)){
						   foreach($old_digital_video_files as $filename){
							   
							   $this->locations_model->insertOldDigitalMedia($old_location_id, $location_id, $filename['video_url']);
							   
						   }
					   }
					   
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->locations_model->insertContentDigitalMedia($location_id,video_files,$file_name);
							  } 
					
						   }
						}
						 
					   //Old Digital Vr Files
					   $old_digital_vr_files=$this->input->post('old-digital-vr');
					   
					   if(isset($old_digital_vr_files) &&  !empty($old_digital_vr_files)){
						   foreach($old_digital_vr_files as $filename){
							   
							   $this->locations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['vr_files'],$this->vr_path);
							   
						   }
					   }
					   
						//Digital Vr Files
					    $totalvrfiles= count($_FILES['digital-vr']['name']);
						for($i=0;$i<$totalvrfiles;$i++){
							if($_FILES['digital-vr']['name'][$i]['vr_files']!=''){	
							
								$_FILES['userfile']['name']= $_FILES['digital-vr']['name'][$i]['vr_files'];
								$_FILES['userfile']['type']    = $_FILES['digital-vr']['type'][$i]['vr_files'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-vr']['tmp_name'][$i]['vr_files'];
								$_FILES['userfile']['error']       = $_FILES['digital-vr']['error'][$i]['vr_files'];
								$_FILES['userfile']['size']    = $_FILES['digital-vr']['size'][$i]['vr_files'];
								
								$config['upload_path'] = $this->vr_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertContentDigitalMedia($location_id,vr_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						 //Old 2dMap Files
					   $old_digital_2dmap_files=$this->input->post('old-digital-2dmap');
					   
					   if(isset($old_digital_2dmap_files) &&  !empty($old_digital_2dmap_files)){
						   foreach($old_digital_2dmap_files as $filename){
							   
							   $this->locations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['2dmap_file'],$this->map2d_path);
							   
						   }
					   }
					   
						//Digital 2dMap Files
					    $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
						for($i=0;$i<$total2dmapfiles;$i++){
							if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
							
								$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
								
								$config['upload_path'] = $this->map2d_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertContentDigitalMedia($location_id,map2d_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Old panorama Files
					   $old_digital_panorama_files=$this->input->post('old-digital-panorama');
					   
					   if(isset($old_digital_panorama_files) &&  !empty($old_digital_panorama_files)){
						   foreach($old_digital_panorama_files as $filename){
							   
							   $this->locations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['panorama_images'],$this->panorama_path);
							   
						   }
					   }
					   
						//Digital panorama Files
					    $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
						for($i=0;$i<$totalpanoramafiles;$i++){
							if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
								
								$config['upload_path'] = $this->panorama_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertContentDigitalMedia($location_id,panorama_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						 //Old Video 360 Files
					   $old_digital_video360_files=$this->input->post('old-digital-video360');
					   
					   if(isset($old_digital_video360_files) &&  !empty($old_digital_video360_files)){
						   foreach($old_digital_video360_files as $filename){
							   
							   $this->locations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['video360_url']);
							   
						   }
					   }
					   
						 //Digital Video 360
						if(isset($_POST['digital-video360']))
						{
						  $GroupLists = $_POST['digital-video360'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video360_url']!='') 
							  {
								$file_name = $listrow['video360_url'];
								$mediaresult = $this->locations_model->insertContentDigitalMedia($location_id,video360_files,$file_name);
							  } 
					
						   }
						}
						
						//Old Video VT Files
					   $old_digital_vt_files=$this->input->post('old-digital-vt');
					   
					   if(isset($old_digital_vt_files) &&  !empty($old_digital_vt_files)){
						   foreach($old_digital_vt_files as $filename){
							   
							   $this->locations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['vt_files'],$this->vt_path);
							   
						   }
					   }
					   
						//Digital VT Files
					    $totalvtfiles= count($_FILES['digital-vt']['name']);
						for($i=0;$i<$totalvtfiles;$i++){
							if($_FILES['digital-vt']['name'][$i]['vt_files']!=''){	
							
								$_FILES['userfile']['name']     =  $_FILES['digital-vt']['name'][$i]['vt_files'];
								$_FILES['userfile']['type']     = $_FILES['digital-vt']['type'][$i]['vt_files'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-vt']['tmp_name'][$i]['vt_files'];
								$_FILES['userfile']['error']    = $_FILES['digital-vt']['error'][$i]['vt_files'];
								$_FILES['userfile']['size']     = $_FILES['digital-vt']['size'][$i]['vt_files'];
								
								$config['upload_path'] = $this->vt_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->locations_model->insertContentDigitalMedia($location_id,vt_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						//*********************************Location Section*********************//
						 //Location Section
					
					   $old_locsec_files=$this->input->post('old-location-section');
					   
					   if(isset($old_locsec_files) &&  !empty($old_locsec_files)){
						   foreach($old_locsec_files as $listrow){
							   
							   if($listrow['section_title']!='') 
								  {
									$insert_data = array(
										'language_id'=>$this->session->userdata('content_language_id'),
										'location_id'=>$location_id,
										'section_title'     => $listrow['section_title'],
										'section_description'     => $listrow['section_description'],
										'created_on'      => date('Y-m-d H:i:s')
									);
									$location_section_id = $this->locations_model->insertLocationSection($insert_data);
								  }
							   
						   }
						   
					   }
					   
					   
						if(isset($_POST['location-section']))
						{
						  $GroupLists = $_POST['location-section'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['section_title']!='') 
							  {
							  $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'section_title'     => $listrow['section_title'],
									'section_description'     => $listrow['section_description'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_section_id = $this->locations_model->insertLocationSection($insert_data);
							  }
						   }
						}
					 
						 //*********************************Facilities*********************//
						 //Facilities Washroom Group
						
					//Old
						
					   $old_washroom_group=$this->input->post('old-washroom-group');
					   
					   if(isset($old_washroom_group) &&  !empty($old_washroom_group)){
						   foreach($old_washroom_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id, $location_id, $content['washroom_no'], $content['washroom_description'], $content['washroom_longitude'], $content['washroom_latitude'], $content['washroom_images'], $content['washroom_2dmap'],'1','',$content['washroom_availability']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['washroom-group']))
						{
						  $GroupLists = $_POST['washroom-group'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['washroom_longitude']!='') 
							  {
							  $washroom_availability =  implode(",",$listrow['washroom_availability']);	
							   //$washroom_availability =  $listrow['washroom_availability'];	
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['washroom_no'],
									'facility_description'  => $listrow['washroom_description'],
									'facility_type'  => washroom_facility_type,
									'washroom_availability' => $washroom_availability,
									'longitude'     => $listrow['washroom_longitude'],
									'latitude'     => $listrow['washroom_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Washroom Images 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_images'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_images'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_images'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								
							  }
						   }
						}
						
						$old_parking_group=$this->input->post('old-parking-group');
						
						if(isset($old_parking_group) &&  !empty($old_parking_group)){
						   foreach($old_parking_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['parking_no'], $content['parking_description'], $content['parking_longitude'], $content['parking_latitude'], $content['parking_images'], $content['parking_2dmap'],'2', $content['parking_entry_ticket']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['parking-group']))
						{
						  $GroupLists = $_POST['parking-group'];
						  foreach($GroupLists as $key=> $listrow){
							  /*echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";
							  die();*/
							  if($listrow['parking_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['parking_no'],
									'facility_description'  => $listrow['parking_description'],
									'facility_type'  => parking_facility_type,
									'parking_type' => $listrow['parking_entry_ticket'],
									'parking_fee' => $listrow['parking_fees_amt'],
									'longitude'     => $listrow['parking_longitude'],
									'latitude'     => $listrow['parking_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Parking Images 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_images'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_images'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_images'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								 
								
							  }
						   }
						}
						
						$old_dispensary_group=$this->input->post('old-group-dispensary');
						
						if(isset($old_dispensary_group) &&  !empty($old_dispensary_group)){
						   foreach($old_dispensary_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['dispensary_no'], $content['dispensary_description'], $content['dispensary_longitude'], $content['dispensary_latitude'], $content['dispensary_images'], $content['dispensary_2dmap'],'3');
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-dispensary']))
						{
						  $GroupLists = $_POST['group-dispensary'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['dispensary_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['dispensary_no'],
									'facility_description'  => $listrow['dispensary_description'],
									'facility_type'  => dispensary_facility_type,
									'longitude'     => $listrow['dispensary_longitude'],
									'latitude'     => $listrow['dispensary_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Dispensary Images 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_images'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_images'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_images'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Dispensary 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_police_booth_group=$this->input->post('old-group-police-booth');
						
						if(isset($old_police_booth_group) &&  !empty($old_police_booth_group)){
						   foreach($old_police_booth_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['police_booth_no'], $content['police_booth_description'], $content['police_booth_longitude'], $content['police_booth_latitude'], $content['police_booth_images'], $content['police_booth_2dmap'],'4');
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-police-booth']))
						{
						  $GroupLists = $_POST['group-police-booth'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['police_booth_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['police_booth_no'],
									'facility_description'  => $listrow['police_booth_description'],
									'facility_type'  => police_booth_facility_type,
									'longitude'     => $listrow['police_booth_longitude'],
									'latitude'     => $listrow['police_booth_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_images'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_images'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_images'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_shoe_group=$this->input->post('old-group-shoe');
						
						if(isset($old_shoe_group) &&  !empty($old_shoe_group)){
						   foreach($old_shoe_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['shoe_no'], $content['shoe_description'], $content['shoe_longitude'], $content['shoe_latitude'], $content['shoe_images'], $content['shoe_2dmap'],'5');
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-shoe']))
						{
						  $GroupLists = $_POST['group-shoe'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['shoe_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['shoe_no'],
									'facility_description'  => $listrow['shoe_description'],
									'facility_type'  => shoe_facility_type,
									'longitude'     => $listrow['shoe_longitude'],
									'latitude'     => $listrow['shoe_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_images'];
								$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_images'];
								$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_images'];
								$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_luggage_group=$this->input->post('old-group-luggage');
						
						if(isset($old_luggage_group) &&  !empty($old_luggage_group)){
						   foreach($old_luggage_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['luggage_no'], $content['luggage_description'], $content['luggage_longitude'], $content['luggage_latitude'], $content['luggage_images'], $content['luggage_2dmap'],'6');
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-luggage']))
						{
						  $GroupLists = $_POST['group-luggage'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['luggage_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['luggage_no'],
									'facility_description'  => $listrow['luggage_description'],
									'facility_type'  => luggage_facility_type,
									'longitude'     => $listrow['luggage_longitude'],
									'latitude'     => $listrow['luggage_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_images'];
								$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_images'];
								$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_images'];
								$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_langar_group=$this->input->post('old-group-langar');
						
						if(isset($old_langar_group) &&  !empty($old_langar_group)){
						   foreach($old_langar_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['langar_no'], $content['langar_description'], $content['langar_longitude'], $content['langar_latitude'], $content['langar_images'], $content['langar_2dmap'],'7');
							   
						   }
						   
					   }
						if(isset($_POST['group-langar']))
						{
						  $GroupLists = $_POST['group-langar'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['langar_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['langar_no'],
									'facility_description'  => $listrow['langar_description'],
									'facility_type'  => langar_facility_type,
									'longitude'     => $listrow['langar_longitude'],
									'latitude'     => $listrow['langar_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->locations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_images'];
								$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_images'];
								$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_images'];
								$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_ticketcounter_group=$this->input->post('old-group-ticketcounter');
						
						if(isset($old_ticketcounter_group) &&  !empty($old_ticketcounter_group)){
						   foreach($old_ticketcounter_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['ticketcounter_no'], $content['ticketcounter_description'], $content['ticketcounter_longitude'], $content['ticketcounter_latitude'], $content['ticketcounter_images'], $content['ticketcounter_2dmap'],'8');
							   
						   }
						   
					   }
						
				 if(isset($_POST['group-ticketcounter']))
					{
					  $GroupLists = $_POST['group-ticketcounter'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['ticketcounter_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('content_language_id'),
								'location_id'=>$location_id,
								'facility_type'  => ticketcounter_facility_type,
								'facility_name_no'  => $listrow['ticketcounter_no'],
								'facility_description'  => $listrow['ticketcounter_description'],
								'longitude'     => $listrow['ticketcounter_longitude'],
								'latitude'     => $listrow['ticketcounter_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->locations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_images'];
							$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_images'];
							$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_images'];
							$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							 
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					
					$old_enquiry_group=$this->input->post('old-group-enquiry');
					
					if(isset($old_enquiry_group) &&  !empty($old_enquiry_group)){
						   foreach($old_enquiry_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['enquiry_no'], $content['enquiry_description'], $content['enquiry_longitude'], $content['enquiry_latitude'], $content['enquiry_images'], $content['enquiry_2dmap'],'9');
							   
						   }
						   
					   }
					
					if(isset($_POST['group-enquiry']))
					{
					  $GroupLists = $_POST['group-enquiry'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['enquiry_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('content_language_id'),
								'location_id'=>$location_id,
								'facility_type'  => enquiry_facility_type,
								'facility_name_no'  => $listrow['enquiry_no'],
								'facility_description'  => $listrow['enquiry_description'],
								'longitude'     => $listrow['enquiry_longitude'],
								'latitude'     => $listrow['enquiry_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->locations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_images'];
							$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_images'];
							$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_images'];
							$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							  
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					$old_resthouse_group=$this->input->post('old-group-resthouse');
					if(isset($old_resthouse_group) &&  !empty($old_resthouse_group)){
						   foreach($old_resthouse_group as $content){
							   
							   $this->locations_model->insertOldFacilities($old_location_id,$location_id, $content['resthouse_no'], $content['resthouse_description'], $content['resthouse_longitude'], $content['resthouse_latitude'], $content['resthouse_images'], $content['resthouse_2dmap'],'10');
							   
						   }
						   
					   }
					
					
					if(isset($_POST['group-resthouse']))
					{
					  $GroupLists = $_POST['group-resthouse'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['resthouse_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('content_language_id'),
								'location_id'=>$location_id,
								'facility_type'  => resthouse_facility_type,
								'facility_name_no'  => $listrow['resthouse_no'],
								'facility_description'  => $listrow['resthouse_description'],
								'longitude'     => $listrow['resthouse_longitude'],
								'latitude'     => $listrow['resthouse_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->locations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_images'];
							$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_images'];
							$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_images'];
							$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							 
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					
					if(isset($_POST['group-loccontacts']))
				    {
				    $GroupLists = $_POST['group-loccontacts'];
				    foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['loc_contact_name']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('content_language_id'),
							'location_id'=>$location_id,
							'facility_type'  => loccontacts_facility_type,
							'facility_name_no'  => $listrow['loc_contact_name'],
							'facility_description'  => $listrow['loc_contact_details'],
							'contact_mobile_no'     => $listrow['loc_contact_mobile_no'],
							'contact_landline_no'     => $listrow['loc_contact_landline_no'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->locations_model->insertFacility($insert_data);
						
						//Location Contacts Images 
						$_FILES['userfile']['name']  = $_FILES['group-loccontacts']['name'][$key]['loccontact_images'];
						$_FILES['userfile']['type']    = $_FILES['group-loccontacts']['type'][$key]['loccontact_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-loccontacts']['tmp_name'][$key]['loccontact_images'];
						$_FILES['userfile']['error']   = $_FILES['group-loccontacts']['error'][$key]['loccontact_images'];
						$_FILES['userfile']['size']  = $_FILES['group-loccontacts']['size'][$key]['loccontact_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
				      }
				   }
			    }
				
					if(isset($_POST['location-beacon']))
					{
					  $GroupLists = $_POST['location-beacon'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['beacon_location_name']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('content_language_id'),
								'location_id'=>$location_id,
								'beacon_location_name'  => $listrow['beacon_location_name'],
								'beacon_unique_id'  => $listrow['beacon_unique_id'],
								'remarks'  => $listrow['beacon_remarks'],
								'created_by'  => $this->session->userdata('user_id'),
								'created_on'      => date('Y-m-d H:i:s')
							);
							$beacon_location_id = $this->locations_model->insertBeacon($insert_data);
							
							$insertdata = array(
								'beacon_location_id'=>$beacon_location_id,
								'action_plan_id'  => $listrow['action_plan_id'],
								'instruction_id'     => $listrow['instruction_id'],
								'sound_file_id'     => $listrow['beacon_sound_file_id'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$beacon_action_id = $this->locations_model->insertBeaconlocations($insertdata);
							
							//Beacon Images 
							$_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_audio_file'];
							$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_audio_file'];
							$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_audio_file'];
							$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_audio_file'];
							$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_audio_file'];
							
							$config['upload_path'] = $this->beacon_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									$updatefield =array( 
										'media_file' => $file_name
									);	
									$unique_id = array('beacon_action_id' =>$beacon_action_id);
									$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
									$data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
									$data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
						  }
					   }
					}
					
					
					
				}	
		        
		  
			
				
		
		      if($result=='1')
				{   
						//Copy
					   $msg = $this->lang->line('copy_success_text_message');
					   $this->session->set_flashdata('success_message', $msg);
					   
					   //Unset Sessions
		   
						$this->session->unset_userdata('content_language_id');
						$this->session->unset_userdata('content_digital_media');
						$this->session->unset_userdata('content_facilities');
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        //Copy
				redirect(base_url() . "employees/locations/view/");
				
		
		}		
		  $result =  $this->locations_model->location_edit($location_id);
		  $data['edit_data'] = $result;
		  $fields = array('location_id'=>$result->location_id,'is_active'=>'1');
		  $catrow = gettableinfo('location_categories',$fields);
		  
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  
		    $fields = array('location_id'=>$location_id,'is_active'=>'1');
			$catresult = gettableresult('location_categories',$fields,'category_id');
			if(is_array($catresult))
			{
				$category_ids=array();
				foreach($catresult as $ckey => $catval) {
				  $category_ids[] = $catval->category_id;	
				}
			  $categoryids =  implode(',',$category_ids);
			  //echo "---------------->".$category_ids;
			  //$categoryids =  "'".$categoryids."'";
			 //echo "---------------->".$categoryids;
			}else
			{
				$categoryids =  '';
			}
			
			//print_r($category_ids);					
		  $data['category_ids'] = $categoryids;
		  
		  $this->load->view('employees/locations/copy.php', $data);
		 
	}//end of Copy functionality*/
	
	public function copyrecord($location_id)
	{	 // Update status  
	     $main_location_id = $this->locations_model->copy_status($location_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('copy_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('copy_error_text_message'));
		 }
		 redirect(base_url() . "employees/locations/edit/".$main_location_id);		
		 
	}//end of Status  functionality*/
	
	
	
	public function deletedigitalmedia($location_media_id)
	{	 // Delete Digital Media  
		
	     $result = $this->locations_model->deleteDigitalMedia($location_media_id,$this->audio_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	
	public function setdefaultmedia($location_id,$location_media_id,$media_type)
	{	 // Set Default Media  
	     $result = $this->locations_model->setDefaultMedia($location_id,$location_media_id,$media_type);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('update_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	

	public function deletelocsection($location_section_id)
	{	 // Delete Section  
	     $result = $this->locations_model->deleteLocSection($location_section_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function deletefacility($location_facility_id)
	{	 // Delete facility  
	     $result = $this->locations_model->deleteFacility($location_facility_id,$this->facility_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	
	public function deletebeacon($beacon_location_id,$location_id)
	{	 // Delete Location Beacon  
	     $result = $this->locations_model->deleteLocBeacon($beacon_location_id,$location_id);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function deletequestion($question_id)
	{	
	     $result = $this->locations_model->deletequestion($question_id);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}
	
  public function details()
    {
		 if($this->uri->segment('4'))
			$location_id=$this->uri->segment('4');
		 else
			$location_id='0';
			
		  $data['title'] = title." | Location Details";
		  $data['main_heading'] = "Locations";
		  $data['heading'] = "Location Details";
		  $result = $this->locations_model->location_details($location_id);
		  $categoryresult = $this->locations_model->location_categories($location_id);
		  $data['row'] = $result;
		  $data['rowz'] = $result;
		  
		  $fields = array('location_id'=>$result->location_id,'is_active'=>'1');
		  $catrow = gettableinfo('location_categories',$fields);
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  
		  $data['categoryresult'] = $categoryresult;
		  
		  if($location_id!='0')
		  $this->load->view('employees/locations/details', $data);
		  else
		  redirect(base_url() . 'employees/locations/view');
		
    } //end of view Details functionality
    
     
    
    function translate_add($language_id,$loc_id){
	     $data=array(); 
	    $get_loc_join=$this->locations_model->get_location_type_info($loc_id);
	    //print '<pre>';print_r($get_loc_join);die;
		$data['categorytype_info']=$get_loc_join;
	   
	    $languageinfo=get_language($language_id);
        $data['title'] = "Edit Location | ".$get_loc_join->location_name.' - ('.$languageinfo->language_name.')'; 
        $data['main_heading'] = "Location";
        $data['heading'] = "Add Location| ".$get_loc_join->location_name.' - ('.$languageinfo->language_name.')';
        $data['already_msg'] = "";
        $data['langid']=$language_id;
        $data['productid']=$product_id;
        $data['language_id']=$language_id;
        $data['loc_id']=$loc_id;
        
        
        $data['media_audio']='';
        $data['media_videos']='';
        $data['media_images']='';
        $data['media_vr']='';
        $data['media_2dmap']='';
        $data['media_panorama']='';
        $data['media_video360']='';
        $data['media_vt']='';
        
		$get_audio =  $this->locations_model->media_info($loc_id,1,1);
		$data['media_audio']=$get_audio;
		
		$get_images =  $this->locations_model->media_info($loc_id,2,1);
		$data['media_images']=$get_images;
		
		$get_video =  $this->locations_model->media_info($loc_id,3,1);
		$data['media_videos']=$get_video;
		
		$get_vr =  $this->locations_model->media_info($loc_id,4,1);
		$data['media_vr']=$get_vr;
		
		$get_2dmap =  $this->locations_model->media_info($loc_id,5,1);
		$data['media_2dmap']=$get_2dmap;
		
		$get_panorama =  $this->locations_model->media_info($loc_id,6,1);
		$data['media_panorama']=$get_panorama;
		
		$get_video360 =  $this->locations_model->media_info($loc_id,7,1);
		$data['media_video360']=$get_video360;
		
		$get_vt =  $this->locations_model->media_info($loc_id,8,1);
		$data['media_vt']=$get_vt;
        
		$this->form_validation->set_rules('location_name', 'Location name', 'required');
		$this->form_validation->set_rules('short_name', 'Alias', 'required');
		$this->form_validation->set_rules('short_description', 'Short description', 'required');
		$this->form_validation->set_rules('address', 'Address', 'required');
		if ($this->form_validation->run()) {
		    
		    
		    $copy_media=$this->input->post('media_copy');
		    
		    if($copy_media==1){
		        
		         //Old Digital audio Files
    		   $old_digital_audio_files=$this->input->post('old-digital-audio');
    		   
    		   if(isset($old_digital_audio_files) &&  !empty($old_digital_audio_files)){
    			   foreach($old_digital_audio_files as $key=>$filename){
    				   //print '<pre>';print_r($filename);die;
    				   $this->locations_model->insertOldDigitalMedia_intranslate($loc_id, $filename['gallery_audio'],$this->audio_path,$language_id,1,1);
    				   
    			   }
    			   
    		   }
		    
    		   //Old Digital images Files
    		   $old_digital_image_files=$this->input->post('old-digital-image');
    		   if(isset($old_digital_image_files) &&  !empty($old_digital_image_files)){
    			   foreach($old_digital_image_files as $key=>$filename){
    				   $this->locations_model->insertOldDigitalMedia_intranslate($loc_id, $filename['gallery_image'],$this->gallery_path,$language_id,1,2);
    			   }
    		   }
    		   
    		   
    		   $old_digital_video_files=$this->input->post('old-digital-video');
    		   if(isset($old_digital_video_files) &&  !empty($old_digital_video_files)){
    			   foreach($old_digital_video_files as $key=>$filename){
    				   $this->locations_model->insertOldDigitalMedia_intranslate($loc_id, $filename['gallery_video'],'',$language_id,1,3);
    			   }
    			   
    		   }
    		   
    		   $old_digital_vr_files=$this->input->post('old-digital-vr');
    		   if(isset($old_digital_vr_files) &&  !empty($old_digital_vr_files)){
    			   foreach($old_digital_vr_files as $key=>$filename){
    				   $this->locations_model->insertOldDigitalMedia_intranslate($loc_id, $filename['gallery_vr'],$this->vr_path,$language_id,1,4);
    			   }
    			   
    		   }
    		   
    		   $old_digital_2d_files=$this->input->post('old-digital-2d');
    		   if(isset($old_digital_2d_files) &&  !empty($old_digital_2d_files)){
    			   foreach($old_digital_2d_files as $key=>$filename){
    				   $this->locations_model->insertOldDigitalMedia_intranslate($loc_id, $filename['gallery_2d'],$this->map2d_path,$language_id,1,5);
    			   }
    			   
    		   }
    		   
    		   $old_digital_panorama_files=$this->input->post('old-digital-panorama');
    		   if(isset($old_digital_panorama_files) &&  !empty($old_digital_panorama_files)){
    			   foreach($old_digital_panorama_files as $key=>$filename){
    				   $this->locations_model->insertOldDigitalMedia_intranslate($loc_id, $filename['gallery_panorama'],$this->panorama_path,$language_id,1,6);
    			   }
    		   }
    		   
    		   $old_digital_video360_files=$this->input->post('old-digital-video360');
    		   if(isset($old_digital_video360_files) &&  !empty($old_digital_video360_files)){
    			   foreach($old_digital_video360_files as $key=>$filename){
    				   $this->locations_model->insertOldDigitalMedia_intranslate($loc_id, $filename['gallery_video360'],'',$language_id,1,7);
    			   }
    		   }
    		   $old_digital_vt_files=$this->input->post('old-digital-vt');
    		   if(isset($old_digital_vt_files) &&  !empty($old_digital_vt_files)){
    			   foreach($old_digital_vt_files as $key=>$filename){
    				   $this->locations_model->insertOldDigitalMedia_intranslate($loc_id, $filename['gallery_vt'],$this->vt_path,$language_id,1,8);
    			   }
    		   }
    		   
		    }
		   $user_id =  $this->locations_model->add_translate($language_id,$loc_id);
		   if($user_id!=''){
		       //Digital Audio File
                $totalaudiofiles= count($_FILES['digital-audio']['name']);
                for($i=0;$i<$totalaudiofiles;$i++){
                	if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
                	
                		$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
                		$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
                		$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
                		$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
                		
                		$config['upload_path'] = $this->audio_path;
                		$config['allowed_types'] = audo_file_extensions;
                		$config['max_size']	= max_file_size;
                		//$config['max_width']  = '0';
                		//$config['max_height']  = '0';
                		$config['overwrite'] = true;	
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,audio_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						        $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,audio_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                 //Digital Gallery Files
                $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
                for($i=0;$i<$totalgalleryfiles;$i++){
                	if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
                		$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
                		$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
                		$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
                		$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
                		
                		$config['upload_path'] = $this->gallery_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= '5120';
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;	
                		if($_FILES['userfile']['error']!='4'){
                			 /* if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,gallery_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						        $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,gallery_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                //Digital Media Video 
                if(isset($_POST['digital-video']))
                {
                  $GroupLists = $_POST['digital-video'];
                  foreach($GroupLists as $key=> $listrow){
                	  if($listrow['video_url']!='') 
                	  {
                		$file_name = $listrow['video_url'];
                		$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,video_files,$file_name,$language_id);
                	  } 
                   }
                }
                //Digital Vr Files
                $totalvrfiles= count($_FILES['digital-vr']['name']);
                for($i=0;$i<$totalvrfiles;$i++){
                	if($_FILES['digital-vr']['name'][$i]['vr_files']!=''){	
                	
                		$_FILES['userfile']['name']= $_FILES['digital-vr']['name'][$i]['vr_files'];
                		$_FILES['userfile']['type']    = $_FILES['digital-vr']['type'][$i]['vr_files'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-vr']['tmp_name'][$i]['vr_files'];
                		$_FILES['userfile']['error']       = $_FILES['digital-vr']['error'][$i]['vr_files'];
                		$_FILES['userfile']['size']    = $_FILES['digital-vr']['size'][$i]['vr_files'];
                		
                		$config['upload_path'] = $this->vr_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= '5120';
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;		
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,vr_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						        $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,vr_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                //Digital map2d Files
                $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
                for($i=0;$i<$total2dmapfiles;$i++){
                	if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
                	
                		$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
                		$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
                		$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
                		$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
                		
                		$config['upload_path'] = $this->map2d_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= max_file_size;
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;		
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,map2d_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						        $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,map2d_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                
                //Digital panorama Files
                $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
                for($i=0;$i<$totalpanoramafiles;$i++){
                	if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
                	
                		$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
                		$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
                		$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
                		$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
                		
                		$config['upload_path'] = $this->panorama_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= max_file_size;
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;		
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,panorama_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						        $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,panorama_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                //Digital Video 360
                if(isset($_POST['digital-video360']))
                {
                  $GroupLists = $_POST['digital-video360'];
                  foreach($GroupLists as $key=> $listrow){
                	
                	  if($listrow['video360_url']!='') 
                	  {
                		$file_name = $listrow['video360_url'];
                		$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,video360_files,$file_name,$language_id);
                	  } 
                
                   }
                }
                //Digital VT Files
                $totalvtfiles= count($_FILES['digital-vt']['name']);
                for($i=0;$i<$totalvtfiles;$i++){
                	if($_FILES['digital-vt']['name'][$i]['vt_files']!=''){	
                	
                		$_FILES['userfile']['name']     =  $_FILES['digital-vt']['name'][$i]['vt_files'];
                		$_FILES['userfile']['type']     = $_FILES['digital-vt']['type'][$i]['vt_files'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-vt']['tmp_name'][$i]['vt_files'];
                		$_FILES['userfile']['error']    = $_FILES['digital-vt']['error'][$i]['vt_files'];
                		$_FILES['userfile']['size']     = $_FILES['digital-vt']['size'][$i]['vt_files'];
                		
                		$config['upload_path'] = $this->vt_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= '5120';
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;	
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;	
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,vt_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						        $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,vt_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                
                // Beacon settings start here
                if(isset($_POST['location-beacon']))
				{
				  $GroupLists = $_POST['location-beacon'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['beacon_location_name']!='') 
					  {
					    $insert_data = array(
							'language_id'=>$language_id,
							'location_id'=>$location_id,
							'beacon_location_name'  => $listrow['beacon_location_name'],
							'beacon_address'  => $listrow['beacon_address'],
							'beacon_latitude'  => $listrow['beacon_latitude'],
							'beacon_longitude'  => $listrow['beacon_longitude'],
							'beacon_unique_id'  => $listrow['beacon_unique_id'],
							'remarks'  => $listrow['beacon_remarks'],
							'created_by'  => $this->session->userdata('user_id'),
							'created_on'      => date('Y-m-d H:i:s')
						);
						$beacon_location_id = $this->locations_model->insertBeacon($insert_data);
						
						$insertdata = array(
							'beacon_location_id'=>$beacon_location_id,
							'action_plan_id'  => $listrow['action_plan_id'],
							'instruction_id'     => $listrow['instruction_id'],
							'instruction_option_selection'     => $listrow['choose_inst_options'],
							'text_to_speech_description'     => $listrow['text_to_speech_description'],
							'video_url'     => $listrow['beacon_video_url'],
							/* 'sound_file_id'     => $listrow['beacon_sound_file_id'], */
							'created_on'      => date('Y-m-d H:i:s')
						);
						$beacon_action_id = $this->locations_model->insertBeaconlocations($insertdata);
						 
						 //Beacon Image
						 
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  /*if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'beacon_image' => $file_name
								);	
								$unique_id = array('beacon_location_id' =>$beacon_location_id);
								$resultupdate = update_table_fields('beacon_locations',$updatefield,$unique_id);
							  }*/
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    //$data['uploads'][$key] = $this->upload->data();
							    
							    $data['uploads'][$key] = $this->upload->data();
                                $file_name= $data['uploads'][$key]['file_name'];
                                $updatefield =array( 
									'beacon_image' => $file_name
								);	
								$unique_id = array('beacon_location_id' =>$beacon_location_id);
								$resultupdate = update_table_fields('beacon_locations',$updatefield,$unique_id);
                                //$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,panorama_files,$file_name,$language_id);
							    
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 
						 //Audio File
				
						$_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_audio_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_audio_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_audio_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_audio_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_audio_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = audo_file_extensions;
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  
							  /*if($_FILES['userfile']['name']!=''){
								
								$updatefield =array( 
									'beacon_audio_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
							  }*/
							
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
								  
							    //$data['uploads'][$key] = $this->upload->data();
							    
							    $data['uploads'][$key] = $this->upload->data();
                                $file_name= $data['uploads'][$key]['file_name'];
                                $updatefield =array( 
									'beacon_audio_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
							
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 //Media File
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_media_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_media_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_media_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_media_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_media_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= max_file_size;
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  /*if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'media_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
							  }*/
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    //$data['uploads'][$key] = $this->upload->data();
							    
							    $data['uploads'][$key] = $this->upload->data();
                                $file_name= $data['uploads'][$key]['file_name'];
                                $updatefield =array( 
									'media_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
							    
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }
						 
						 //Video File
						 $_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_video_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_video_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_video_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_video_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_video_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = video_file_extensions;
						$config['max_size']	= max_file_size;
				
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							
							 /*if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'beacon_video_file' => $file_name
								);	
								
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id); 
							  }*/
							 
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    $data['uploads'][$key] = $this->upload->data();
								/* echo "error<pre>";
								print_r($data['uploads']);
								die; */
								
								$data['uploads'][$key] = $this->upload->data();
                                $file_name= $data['uploads'][$key]['file_name'];
                                $updatefield =array( 
									'beacon_video_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('beacon_location_actions',$updatefield,$unique_id);
								
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
								/* echo "error<pre>";
								print_r($data['upload_errors']);
								die; */
							  } 
						 }
				      }
				   }
			    }
                //beacon settings ends here
                
                
		   }
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "location added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'employees/locations/view');
		    
		    
		}
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
	
		
        $data['category_ids'] = $categoryids;
        $data['vendor_list']=$vendorlist;
        $this->load->view('employees/locations/translate_add.php', $data);
	    
	}
	
	function edit_translate($language_id,$loc_id){
	     $data=array(); 
	    $get_location_join=$this->locations_model->get_location_info($loc_id,$language_id);
	   //print '<pre>';print_r($get_category_join);die;
		$data['location_info']=$get_location_join;
	   
	    $languageinfo=get_language($language_id);
        $data['title'] = "Edit Location  | ".$get_location_join->location_name.' - ('.$languageinfo->language_name.')';
        $data['main_heading'] = "Location ";
        $data['heading'] = "Edit Location | ".$get_location_join->location_name.' - ('.$languageinfo->language_name.')';
        $data['already_msg'] = "";
        $data['langid']=$language_id;
        $data['language_id']=$language_id;
        $data['loc_id']=$loc_id;
        
        $data['media_audio']='';
        $data['media_videos']='';
        $data['media_images']='';
        $data['media_vr']='';
        $data['media_2dmap']='';
        $data['media_panorama']='';
        $data['media_video360']='';
        $data['media_vt']='';
        
		$get_audio =  $this->locations_model->media_info($loc_id,1,$language_id);
		$data['media_audio']=$get_audio;
		
		$get_images =  $this->locations_model->media_info($loc_id,2,$language_id);
		$data['media_images']=$get_images;
		
		$get_video =  $this->locations_model->media_info($loc_id,3,$language_id);
		$data['media_videos']=$get_video;
		
		$get_vr =  $this->locations_model->media_info($loc_id,4,$language_id);
		$data['media_vr']=$get_vr;
		
		$get_2dmap =  $this->locations_model->media_info($loc_id,5,$language_id);
		$data['media_2dmap']=$get_2dmap;
		
		$get_panorama =  $this->locations_model->media_info($loc_id,6,$language_id);
		$data['media_panorama']=$get_panorama;
		
		$get_video360 =  $this->locations_model->media_info($loc_id,7,$language_id);
		$data['media_video360']=$get_video360;
		
		$get_vt =  $this->locations_model->media_info($loc_id,8,$language_id);
		$data['media_vt']=$get_vt;
        
        
		$this->form_validation->set_rules('location_name', 'Location name', 'required');
		//$this->form_validation->set_rules('media_copy', 'Media Type', 'required|trim');
		if ($this->form_validation->run()) {
		    //print '<pre>';print_r($_POST);die;
		    
		    
		    
		    $user_id =  $this->locations_model->update_translate($loc_id,$language_id);
		    //print $user_id;die;
		    if($user_id!=''){
    		    //Digital Audio File
    		   $location_id= $loc_id;
                $totalaudiofiles= count($_FILES['digital-audio']['name']);
                for($i=0;$i<$totalaudiofiles;$i++){
                	if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
                	
                		$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
                		$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
                		$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
                		$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
                		
                		$config['upload_path'] = $this->audio_path;
                		$config['allowed_types'] = audo_file_extensions;
                		$config['max_size']	= max_file_size;
                		//$config['max_width']  = '0';
                		//$config['max_height']  = '0';
                		$config['overwrite'] = true;	
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,audio_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						        $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,audio_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                 //Digital Gallery Files
                $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
                for($i=0;$i<$totalgalleryfiles;$i++){
                	if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
                		$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
                		$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
                		$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
                		$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
                		
                		$config['upload_path'] = $this->gallery_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= '5120';
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;	
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,gallery_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						       $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,gallery_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                //Digital Media Video 
                if(isset($_POST['digital-video']))
                {
                  $GroupLists = $_POST['digital-video'];
                  foreach($GroupLists as $key=> $listrow){
                	  if($listrow['video_url']!='') 
                	  {
                		$file_name = $listrow['video_url'];
                		$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,video_files,$file_name,$language_id);
                	  } 
                   }
                }
                //Digital Vr Files
                $totalvrfiles= count($_FILES['digital-vr']['name']);
                for($i=0;$i<$totalvrfiles;$i++){
                	if($_FILES['digital-vr']['name'][$i]['vr_files']!=''){	
                	
                		$_FILES['userfile']['name']= $_FILES['digital-vr']['name'][$i]['vr_files'];
                		$_FILES['userfile']['type']    = $_FILES['digital-vr']['type'][$i]['vr_files'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-vr']['tmp_name'][$i]['vr_files'];
                		$_FILES['userfile']['error']       = $_FILES['digital-vr']['error'][$i]['vr_files'];
                		$_FILES['userfile']['size']    = $_FILES['digital-vr']['size'][$i]['vr_files'];
                		
                		$config['upload_path'] = $this->vr_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= '5120';
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;		
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,vr_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						       $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,vr_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                //Digital map2d Files
                $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
                for($i=0;$i<$total2dmapfiles;$i++){
                	if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
                	
                		$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
                		$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
                		$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
                		$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
                		
                		$config['upload_path'] = $this->map2d_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= max_file_size;
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;		
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,map2d_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						       $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,map2d_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                
                //Digital panorama Files
                $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
                for($i=0;$i<$totalpanoramafiles;$i++){
                	if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
                	
                		$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
                		$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
                		$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
                		$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
                		
                		$config['upload_path'] = $this->panorama_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= max_file_size;
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;		
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,panorama_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						       $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,panorama_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                //Digital Video 360
                if(isset($_POST['digital-video360']))
                {
                  $GroupLists = $_POST['digital-video360'];
                  foreach($GroupLists as $key=> $listrow){
                	
                	  if($listrow['video360_url']!='') 
                	  {
                		$file_name = $listrow['video360_url'];
                		$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,video360_files,$file_name,$language_id);
                	  } 
                
                   }
                }
                //Digital VT Files
                $totalvtfiles= count($_FILES['digital-vt']['name']);
                for($i=0;$i<$totalvtfiles;$i++){
                	if($_FILES['digital-vt']['name'][$i]['vt_files']!=''){	
                	
                		$_FILES['userfile']['name']     =  $_FILES['digital-vt']['name'][$i]['vt_files'];
                		$_FILES['userfile']['type']     = $_FILES['digital-vt']['type'][$i]['vt_files'];
                		$_FILES['userfile']['tmp_name'] = $_FILES['digital-vt']['tmp_name'][$i]['vt_files'];
                		$_FILES['userfile']['error']    = $_FILES['digital-vt']['error'][$i]['vt_files'];
                		$_FILES['userfile']['size']     = $_FILES['digital-vt']['size'][$i]['vt_files'];
                		
                		$config['upload_path'] = $this->vt_path;
                		$config['allowed_types'] = 'jpeg|gif|jpg|png';
                		$config['max_size']	= '5120';
                		$config['max_width']  = '0';
                		$config['max_height']  = '0';
                		$config['overwrite'] = true;	
                		$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
                		$config['file_name'] =$file_name;	
                		if($_FILES['userfile']['error']!='4'){
                			  /*if($_FILES['userfile']['name']!=''){
                				$mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,vt_files,$file_name,$language_id);
                			  }*/
                			  $this->upload->initialize($config);
                			  $this->upload->do_upload('userfile');
                			  if ($this->upload->do_upload('userfile'))
                			  {
                			   $data['uploads'][$i] = $this->upload->data();
                			   $file_name= $data['uploads'][$i]['file_name'];
						       $mediaresult = $this->locations_model->insertDigitalMedia_translate($location_id,vt_files,$file_name,$language_id);
                			  }
                			  else
                			  {
                			   $data['upload_errors'][$i] = $this->upload->display_errors();
                			  } 
                		}  
                	}
                }
                
                
                
                
                
		    }
		    
		 
			if($user_id=='0')
				{   $msg=  "There is some error , please try again";
					$this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = "Location added successfully";
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'employees/locations/view');
		    
		    
		}
        $this->load->view('employees/locations/edit_translate.php', $data);
	    
	}


	
	
}	
?>