<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Slocations extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		//valid_logged_in(FALSE,'E');	
		//check_permissions();
		time_zone();
		$this->load->model('employees/slocations_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->location_path = realpath('assets/static/locations');
		$this->icons_path = realpath('assets/static/locations/icons');
		$this->gallery_path = realpath('assets/static/locations/gallery');
		$this->audio_path = realpath('assets/static/locations/audio');
		$this->video_path = realpath('assets/static/locations/video');
		$this->map2d_path = realpath('assets/static/locations/2dmap');
		$this->panorama_path = realpath('assets/static/locations/panorama');
		$this->facility_path = realpath('assets/static/locations/facility');
		$this->beacon_path = realpath('assets/static/locations/beacons');
		
	}
	
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_locations_title')."";
	    $data['main_heading'] = $this->lang->line('locations_title');
	    $data['heading'] = $this->lang->line('view_locations_title');	
		
	    if($this->input->post('location_id'))
			 $location_id = $this->input->post('location_id');
		 elseif($this->uri->segment('4'))
			 $location_id=$this->uri->segment('4');
		 else
			 $location_id='0';
			 
			 	 
		
	    if($this->input->post('locality_id'))
			$locality_id = $this->input->post('locality_id');
		 elseif($this->uri->segment('5'))
			$locality_id=$this->uri->segment('5');
		 else
			$locality_id='0';
					 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "employees/slocations/view/".$location_id."/".$category_type_id."/".$locality_id."/".$serial_no."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		$config["total_rows"] =$this->slocations_model->count_locations($location_id,$locality_id);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;  
		$data['results'] = $this->slocations_model->view_locations($location_id,$locality_id,$config['per_page'], $page);
		
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['location_id'] = $location_id;
		
		$data['locality_id'] = $locality_id;
		
		$data['per_page'] = $per_page;
		  	  
	    $this->load->view('employees/slocations/view.php', $data);
	}
	
	public function approval($category_type_id=NULL){	
	 
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_locations_title')."";
	    $data['main_heading'] = $this->lang->line('locations_title');
	    $data['heading'] = $this->lang->line('view_locations_title');	
		
	    if($this->input->post('location'))
			 $location = $this->input->post('location');
		 elseif($this->uri->segment('5'))
			 $location=$this->uri->segment('5');
		 else
			 $location='';
 
			
		if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('6'))
			$per_page=$this->uri->segment('6');
		else
			$per_page=per_page;	
			
		$config = array();
		$config["base_url"] = base_url() . "employees/slocations/approval/".$location."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
	
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;  
		$data['results'] = $this->slocations_model->approved_locations($category_type_id, $location,$config['per_page'], $page);
		
		$data['links']   = $this->pagination->create_links();
		$config["total_rows"] =count($data['results']);
		$data['num_rows'] = $config['total_rows'];	
		
		$data['location'] = $location;	
		$data['per_page'] = $per_page;
		$data['category_type_id'] = $category_type_id;
		  	  
	    $this->load->view('employees/slocations/approval.php', $data);
	}

	public function submitforward($location_id){
		$this->slocations_model->submitforward($location_id);
		$msg = "Record has been sent for approval";
	    $this->session->set_flashdata('success_message', $msg);
		
		redirect(base_url() . 'employees/slocations/view');
	}
	public function requestforward($location_id,$category_type_id=NULL){
		$this->slocations_model->submitforward($location_id);
		$msg = "Record has been approved";
	    $this->session->set_flashdata('success_message', $msg);
		
		redirect(base_url() . 'employees/slocations/approval/'.$category_type_id);
	}
	
	public function rejectrecord($location_id,$category_type_id=NULL){
		$this->slocations_model->rejectrecord($location_id);
		$msg = "Record has been rejected";
	    $this->session->set_flashdata('warning_message', $msg);
		
		redirect(base_url() . 'employees/slocations/approval/'.$category_type_id);
	}
	public function add()
	{
		 
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('add_location_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('location_name', ''.$this->lang->line('location_location_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_name', ''.$this->lang->line('location_short_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  //$this->form_validation->set_rules('state_name', ''.$this->lang->line('location_state_text').'', 'required|trim');
		  //$this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		  $this->form_validation->set_rules('estimated_visit_time', ''.$this->lang->line('location_estimated_visit_time_text').'', 'required|trim');
		
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		 
		  $this->form_validation->set_rules('north_area', ''.$this->lang->line('location_north_text').'', 'trim');
		  $this->form_validation->set_rules('north_area_title', ''.$this->lang->line('location_north_title_text').'', 'trim');
		  $this->form_validation->set_rules('south_area', ''.$this->lang->line('location_south_text').'', 'trim');
		  $this->form_validation->set_rules('south_area_title', ''.$this->lang->line('location_south_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area_title', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('west_area', ''.$this->lang->line('location_west_text').'', 'trim');
		  $this->form_validation->set_rules('west_area_title', ''.$this->lang->line('location_west_title_text').'', 'trim');
		  
		 if ($this->form_validation->run()) {
			/*   echo "<pre>";
		  print_r($_POST);
		  die; */
		/*  echo "<pre>";
		  print_r($_FILES);
		  echo "</pre>";
		  echo "<br><br><br>";*/
		/*  echo "<pre>";
		  print_r($_POST);
		  echo "</pre>";*/
		 // die();
		    /*  echo "<pre>";
			  print_r($_POST);
			  echo "</pre>"; 
			  
			  echo "<pre>";
			  print_r($_FILES);
			  echo "</pre>";
			  echo "<br><br><br>";*/
			 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
			  foreach($_POST['week_days'] as $key => $weekdayval) {
			  if(in_array($weekdayval,$_POST['availability']))
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			  }
			 }
			/*   echo "<br>";
			  echo "<br>";
			  echo "<pre>";
			  print_r($hours_details);
			  echo "</pre>"; 
			echo "<br>";
			  echo "<br>"; */
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			  
			  //Get Directions Json
			  $direction_locations =array();
			  
			  $direction_locations['northstartpointlongitude']= $_POST['northstartpointlongitude']; 	
			  $direction_locations['northstartpointlatitude']= $_POST['northstartpointlatitude']; 	
			  $direction_locations['northendpointlongitude']= $_POST['northendpointlongitude']; 	
			  $direction_locations['northendpointlatitude']= $_POST['northendpointlatitude']; 	
			  
			  $direction_locations['southstartpointlongitude']= $_POST['southstartpointlongitude']; 	
			  $direction_locations['southstartpointlatitude']= $_POST['southstartpointlatitude']; 	
			  $direction_locations['southendpointlongitude']= $_POST['southendpointlongitude']; 	
			  $direction_locations['southendpointlatitude']= $_POST['southendpointlatitude'];
			  
			  $direction_locations['eaststartpointlongitude']= $_POST['eaststartpointlongitude']; 	
			  $direction_locations['eaststartpointlatitude']= $_POST['eaststartpointlatitude']; 	
			  $direction_locations['eastendpointlongitude']= $_POST['eastendpointlongitude']; 	
			  $direction_locations['eastendpointlatitude']= $_POST['eastendpointlatitude'];
			  
			  $direction_locations['weststartpointlongitude']= $_POST['weststartpointlongitude']; 	
			  $direction_locations['weststartpointlatitude']= $_POST['weststartpointlatitude']; 	
			  $direction_locations['westendpointlongitude']= $_POST['westendpointlongitude']; 	
			  $direction_locations['westendpointlatitude']= $_POST['westendpointlatitude'];
			  
			  $directionlocations = json_encode($direction_locations);

		      $location_id =  $this->slocations_model->add($working_hours,$directionlocations);
			  
				
				//Insert Digital Media
				
			    if($location_id!=0){
					    //Digital Audio File
					    $totalaudiofiles= count($_FILES['digital-audio']['name']);
						for($i=0;$i<$totalaudiofiles;$i++){
							if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = audo_file_extensions;
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertDigitalMedia($location_id,audio_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 //Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertDigitalMedia($location_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						
						 
						//Digital Video File
					    /* $totalvideofiles= count($_FILES['digital-video']['name']);
						for($i=0;$i<$totalvideofiles;$i++){
							if($_FILES['digital-video']['name'][$i]['video_url']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-video']['name'][$i]['video_url'];
								$_FILES['userfile']['type']    = $_FILES['digital-video']['type'][$i]['video_url'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-video']['tmp_name'][$i]['video_url'];
								$_FILES['userfile']['error']       = $_FILES['digital-video']['error'][$i]['video_url'];
								$_FILES['userfile']['size']    = $_FILES['digital-video']['size'][$i]['video_url'];
								
								$config['upload_path'] = $this->video_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertDigitalMedia($location_id,video_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }  */
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->slocations_model->insertDigitalMedia($location_id,video_files,$file_name);
							  } 
					
						   }
						}
						
						//Digital 2dMap Files
					    $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
						for($i=0;$i<$total2dmapfiles;$i++){
							if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
							
								$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
								
								$config['upload_path'] = $this->map2d_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertDigitalMedia($location_id,map2d_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Digital panorama Files
					    $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
						for($i=0;$i<$totalpanoramafiles;$i++){
							if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
								
								$config['upload_path'] = $this->panorama_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertDigitalMedia($location_id,panorama_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
				}	
				
				//Text Group
				/* if(isset($_post['group-section']))
				{
					$grouplists = $_post['group-section'];
					foreach($grouplists as $key=> $listrow){
						$insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'section_title'  => $listrow['section_title'],
							'section_description ' => $listrow['section_description'],
							'is_active'     => 1,
							'created_on'      => date('y-m-d h:i:s')
						);
						$this->slocations_model->insertloctext($insert_data);
					}
				} */
				
				//Facilities Washroom Group
				if(isset($_POST['washroom-group']))
				{
				  $GroupLists = $_POST['washroom-group'];
				  foreach($GroupLists as $key=> $listrow){
					  /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";die; */
					  if($listrow['washroom_longitude']!='') 
					  {
					  $washroom_availability =  implode(",",$listrow['washroom_availability']);	
					   //$washroom_availability =  $listrow['washroom_availability'];	
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_name_no'  => $listrow['washroom_no'],
							'facility_description'  => $listrow['washroom_description'],
							'facility_type'  => washroom_facility_type,
							'washroom_availability' => $washroom_availability,
							'longitude'     => $listrow['washroom_longitude'],
							'latitude'     => $listrow['washroom_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Washroom Images 
						$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_images'];
						$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_images'];
						$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_images'];
						$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Washroom 2dmap 
						$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
						
				      }
				   }
			    }
				
				if(isset($_POST['parking-group']))
				{
				  $GroupLists = $_POST['parking-group'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['parking_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => parking_facility_type,
							'facility_name_no'  => $listrow['parking_no'],
							'facility_description'  => $listrow['parking_description'],
							'parking_type' => $listrow['parking_entry_ticket'],
							'parking_fee' => $listrow['parking_fees_amt'],
							'longitude'     => $listrow['parking_longitude'],
							'latitude'     => $listrow['parking_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Parking Images 
						$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_images'];
						$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_images'];
						$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_images'];
						$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Washroom 2dmap 
						$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
						 
						
				      }
				   }
			    }
				
				
				if(isset($_POST['group-dispensary']))
				{
				  $GroupLists = $_POST['group-dispensary'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['dispensary_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => dispensary_facility_type,
							'facility_name_no'  => $listrow['dispensary_no'],
							'facility_description'  => $listrow['dispensary_description'],
							'longitude'     => $listrow['dispensary_longitude'],
							'latitude'     => $listrow['dispensary_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Dispensary Images 
						$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_images'];
						$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_images'];
						$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_images'];
						$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Dispensary 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else 
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-police-booth']))
				{
				  $GroupLists = $_POST['group-police-booth'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['police_booth_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => police_booth_facility_type,
							'facility_name_no'  => $listrow['police_booth_no'],
							'facility_description'  => $listrow['police_booth_description'],
							'longitude'     => $listrow['police_booth_longitude'],
							'latitude'     => $listrow['police_booth_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_images'];
						$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_images'];
						$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_images'];
						$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-shoe']))
				{
				  $GroupLists = $_POST['group-shoe'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['shoe_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => shoe_facility_type,
							'facility_name_no'  => $listrow['shoe_no'],
							'facility_description'  => $listrow['shoe_description'],
							'longitude'     => $listrow['shoe_longitude'],
							'latitude'     => $listrow['shoe_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_images'];
						$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_images'];
						$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_images'];
						$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['police_booth_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-luggage']))
				{
				  $GroupLists = $_POST['group-luggage'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['luggage_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => luggage_facility_type,
							'facility_name_no'  => $listrow['luggage_no'],
							'facility_description'  => $listrow['luggage_description'],
							'longitude'     => $listrow['luggage_longitude'],
							'latitude'     => $listrow['luggage_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_images'];
						$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_images'];
						$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_images'];
						$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-langar']))
				{
				  $GroupLists = $_POST['group-langar'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['langar_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => langar_facility_type,
							'facility_name_no'  => $listrow['langar_no'],
							'facility_description'  => $listrow['langar_description'],
							'longitude'     => $listrow['langar_longitude'],
							'latitude'     => $listrow['langar_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_images'];
						$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_images'];
						$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_images'];
						$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-ticketcounter']))
				{
				  $GroupLists = $_POST['group-ticketcounter'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['ticketcounter_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => ticketcounter_facility_type,
							'facility_name_no'  => $listrow['ticketcounter_no'],
							'facility_description'  => $listrow['ticketcounter_description'],
							'longitude'     => $listrow['ticketcounter_longitude'],
							'latitude'     => $listrow['ticketcounter_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_images'];
						$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_images'];
						$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_images'];
						$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['group-enquiry']))
				{
				  $GroupLists = $_POST['group-enquiry'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['enquiry_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => enquiry_facility_type,
							'facility_name_no'  => $listrow['enquiry_no'],
							'facility_description'  => $listrow['enquiry_description'],
							'longitude'     => $listrow['enquiry_longitude'],
							'latitude'     => $listrow['enquiry_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_images'];
						$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_images'];
						$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_images'];
						$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				
				
				if(isset($_POST['group-resthouse']))
				{
				  $GroupLists = $_POST['group-resthouse'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['resthouse_longitude']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'facility_type'  => resthouse_facility_type,
							'facility_name_no'  => $listrow['resthouse_no'],
							'facility_description'  => $listrow['resthouse_description'],
							'longitude'     => $listrow['resthouse_longitude'],
							'latitude'     => $listrow['resthouse_latitude'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$location_facility_id = $this->slocations_model->insertFacility($insert_data);
						
						//Police Booth Images 
						$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_images'];
						$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_images'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_images'];
						$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_images'];
						$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_images'];
						
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'photo_name' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						//Police Booth 2dmap 
						$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_2dmap'];
						$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_2dmap'];
						$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_2dmap'];
						$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_2dmap'];
						$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_2dmap'];
					
						$config['upload_path'] = $this->facility_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '200000000';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								  
								$updatefield =array( 
									'2dmap' => $file_name
								);	
								$unique_id = array('location_facility_id' =>$location_facility_id);
								$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							   $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							   $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 }  
				      }
				   }
			    }
				
				if(isset($_POST['location-beacon']))
				{
				  $GroupLists = $_POST['location-beacon'];
				  foreach($GroupLists as $key=> $listrow){
					 /* echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";*/
					  if($listrow['beacon_location_name']!='') 
					  {
					   $insert_data = array(
							'language_id'=>$this->session->userdata('lang_id'),
							'location_id'=>$location_id,
							'beacon_location_name'  => $listrow['beacon_location_name'],
							'beacon_address'  => $listrow['beacon_address'],
							'beacon_latitude'  => $listrow['beacon_latitude'],
							'beacon_longitude'  => $listrow['beacon_longitude'],
							'beacon_unique_id'  => $listrow['beacon_unique_id'],
							'remarks'  => $listrow['beacon_remarks'],
							'created_by'  => $this->session->userdata('user_id'),
							'created_on'      => date('Y-m-d H:i:s')
						);
						$beacon_location_id = $this->slocations_model->insertBeacon($insert_data);
						
						$insertdata = array(
							'beacon_location_id'=>$beacon_location_id,
							'action_plan_id'  => $listrow['action_plan_id'],
							'instruction_id'     => $listrow['instruction_id'],
							'sound_file_id'     => $listrow['beacon_sound_file_id'],
							'created_on'      => date('Y-m-d H:i:s')
						);
						$beacon_action_id = $this->slocations_model->insertBeaconlocations($insertdata);
						
						//Beacon Images 
						$_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_media_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_media_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_media_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_media_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_media_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'media_file' => $file_name
								);	
								$unique_id = array('beacon_action_id' =>$beacon_action_id);
								$resultupdate = update_table_fields('sbeacon_location_actions',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
						 
						 //Beacon Image
						$_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_file'];
						$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_file'];
						$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_file'];
						$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_file'];
						$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_file'];
						
						$config['upload_path'] = $this->beacon_path;
						$config['allowed_types'] = 'jpeg|gif|jpg|png';
						$config['max_size']	= '5120';
						$config['max_width']  = '0';
						$config['max_height']  = '0';
						$config['overwrite'] = true;
						$file_name = time().'_'.$beacon_location_id.'_'.$_FILES['userfile']['name'];	
						$config['file_name'] =$file_name;	
						if($_FILES['userfile']['error']!='4'){
							  if($_FILES['userfile']['name']!=''){
								$updatefield =array( 
									'beacon_file' => $file_name
								);	
								$unique_id = array('beacon_location_id' =>$beacon_location_id);
								$resultupdate = update_table_fields('sbeacon_locations',$updatefield,$unique_id);
							  }
							  $config['file_name'] =$file_name;
							  $this->upload->initialize($config);
							  $this->upload->do_upload('userfile');
							  if ($this->upload->do_upload('userfile'))
							  {
							    $data['uploads'][$key] = $this->upload->data();
							  }
							  else
							  {
							    $data['upload_errors'][$key] = $this->upload->display_errors();
							  } 
						 } 
				      }
				   }
			    }
				
				//Facilities		
				/*if(isset($_POST['facility-group']))
				{
				  $GroupLists = $_POST['facility-group'];
				  foreach($GroupLists as $key=> $listrow){
					  echo "<pre>";
					  print_r($listrow);
					  echo "</pre>";
					  echo "<br>";
					  echo "<br>";
					  if($listrow['washroom_map_location']!='') 
					  {
						
					//  echo "----------------->listrow". $key;			
					  echo "-----washroom_availability-----1------->".$washroom_availability =  implode(",",$listrow['washroom_availability']);	
					  echo "-----washroom_map_location-----3------->".$listrow['washroom_map_location'];	
					//  echo "-----audio_file-----2------->".$file_name = $listrow[$listrow]['audio_file'];		
					  echo "<br>";
					  echo "<br>";
				
	  	         }	
				}*/
				
		/*	  echo "<pre>";
		  print_r($_FILES);
		  echo "</pre>";
		  echo "<br><br><br>";
		  echo "<pre>";
		  print_r($_POST);
		  echo "</pre>";
		  die();*/
		  
			   if($location_id=='0')
				{   $msg=  $this->lang->line('error_text_message');
				    $this->session->set_flashdata('error_message', $msg);
				}
				else
				{ 
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				redirect(base_url() . 'employees/slocations/view');
 		 
	    } //end of add  functionality
			
		$data['category_type_id'] = isset($_POST['category_type_id']) ? $_POST['category_type_id'] : 0;
		$category_ids=array();
		if(!empty($_POST['location_category'])){
			foreach($_POST['location_category'] as $key=>$val){
				$category_ids[] = $val;
			}
			$categoryids =  implode(',',$category_ids);
		} else  {
			$categoryids =  '';
		}
		
		$data['category_ids'] = $categoryids;
		  
	   $this->load->view('employees/slocations/add.php', $data);
	}
	
	/* public function edit($location_id){
		
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('edit_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('edit_location_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('category_id', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('location_name', ''.$this->lang->line('location_location_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_name', ''.$this->lang->line('location_short_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  $this->form_validation->set_rules('state_name', ''.$this->lang->line('location_state_text').'', 'required|trim');
		  $this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		  $this->form_validation->set_rules('estimated_visit_time', ''.$this->lang->line('location_estimated_visit_time_text').'', 'trim');
		  $this->form_validation->set_rules('location_entry_ticket', ''.$this->lang->line('location_entry_ticket_text').'', 'required|trim');
		  if($this->input->post('location_entry_ticket')=='pa')
		  {
			$this->form_validation->set_rules('adult_fee', ''.$this->lang->line('location_adult_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('child_fee', ''.$this->lang->line('location_child_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('senior_citizen_fee', ''.$this->lang->line('location_senior_citizen_fee_text').'', 'required|trim|integer');  
		  }
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('alert1_distance', ''.$this->lang->line('location_alert1_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert2_distance', ''.$this->lang->line('location_alert2_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert3_distance', ''.$this->lang->line('location_alert3_distance_text').'', 'trim');
		  $this->form_validation->set_rules('alert4_distance', ''.$this->lang->line('location_alert4_distance_text').'', 'trim');
		  
		  $this->form_validation->set_rules('alert1_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert2_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert3_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  $this->form_validation->set_rules('alert4_sound_file_id', ''.$this->lang->line('location_sound_file_text').'', 'trim');
		  
		  $this->form_validation->set_rules('north_area', ''.$this->lang->line('location_north_text').'', 'trim');
		  $this->form_validation->set_rules('north_area_title', ''.$this->lang->line('location_north_title_text').'', 'trim');
		  $this->form_validation->set_rules('south_area', ''.$this->lang->line('location_south_text').'', 'trim');
		  $this->form_validation->set_rules('south_area_title', ''.$this->lang->line('location_south_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area_title', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('west_area', ''.$this->lang->line('location_west_text').'', 'trim');
		  $this->form_validation->set_rules('west_area_title', ''.$this->lang->line('location_west_title_text').'', 'trim');
		  
		if ($this->form_validation->run()) {
			
		 	 $hours_details =array();
			 foreach($_POST['week_days'] as $key => $weekdayval) {
			
				if($_POST['availability'][$key]=='on')
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			 }
			  /*echo "<br>";
			  echo "<br>";
			  echo "<pre>";
			  print_r($hours_details);
			  echo "</pre>"; 
			echo "<br>";
			  echo "<br>";
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			  
			  
			  //North Area Sound File 
			   if($_FILES['north_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '200000000';
					 // $config['max_width']  = '50';
					  //$config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['north_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('north_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'north_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
			   //South Area Sound File 
			   if($_FILES['south_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '200000000';
					  //$config['max_width']  = '50';
					 //$config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['south_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('south_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'south_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				//East Area Sound File 
			   if($_FILES['east_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '200000000';
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $file_name = time().'_'.$location_id.'_'.$_FILES['east_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
						
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('east_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'east_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				//West Area Sound File 
			   if($_FILES['west_area_sound_file']['error'] != 4){		
					  $config['upload_path'] = $this->location_path;
					  $config['allowed_types'] = '*';
					  $config['max_size']	= '200000000';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;		
					  $file_name = time().'_'.$location_id.'_'.$_FILES['west_area_sound_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('west_area_sound_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'west_area_sound_file' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				 
			   //Icons	 
			   if($_FILES['map_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '200000000';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;	
					  $file_name = time().'_'.$location_id.'_'.$_FILES['map_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('map_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'map_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				
				if($_FILES['web_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '200000000';
					 // $config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;			
					  $config['file_name'] =time().'_'.$location_id.'-'.$_FILES['web_icon_file']['name'];
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('web_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $data['file_name'];
					$updatefield =array( 
						'web_icon' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				
				if($_FILES['app_icon_file']['error'] != 4){		
					  $config['upload_path'] = $this->icons_path;
					  $config['allowed_types'] = 'jpeg|gif|jpg|png';
					  $config['max_size']	= '200000000';
					  //$config['max_width']  = '50';
					 // $config['max_height']  = '50';
					  $config['overwrite'] = true;
					  $file_name = time().'_'.$location_id.'_'.$_FILES['app_icon_file']['name'];	
					  $config['file_name'] =$file_name;	
					  $this->upload->initialize($config);
					  if ( ! $this->upload->do_upload('app_icon_file')){
							$data['already_msg']=$this->upload->display_errors();
							$success = FALSE;
						}
			    else{
					$data = $this->upload->data();
					$file_name = $file_name;
					$updatefield =array( 
						'app_icon ' => $file_name
					);	
			 		$unique_id = array('location_id' =>$location_id);
					$resultupdate = update_table_fields('locations',$updatefield,$unique_id);
			     }
		        }
				 
		 	   $result =  $this->slocations_model->update_location($this->input->post('location_id'),$working_hours);
		        
		  
		
	
		
		      if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        redirect(base_url() . "employees/slocations/view/".$this->input->post('location_id'));
		
		}		
		  $result =  $this->slocations_model->location_edit($location_id);
		  $data['edit_data'] = $result;
		  $data['category_type_id'] = isset($result->category_type_id) ? $result->category_type_id : 0;
		  $data['category_id'] = isset($result->category_id) ? $result->category_id : 0;
		  
		  $this->load->view('employees/slocations/edit.php', $data);
		 
	}//end of Edit functionality*/ 
	
	public function edit($location_id,$copy=null){
		 $old_location_id=$location_id;

		  $data=array();
		  $data['title'] = title." ".$this->lang->line('edit_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('edit_location_title');
		  $data['already_msg'] = "";
		  
		  $this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  $this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('location_name', ''.$this->lang->line('location_location_name_text').'', 'required|trim');
		  $this->form_validation->set_rules('short_name', ''.$this->lang->line('location_short_name_text').'', 'required|trim');
	
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		  $this->form_validation->set_rules('address', ''.$this->lang->line('location_address_text').'', 'required|trim');
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  //$this->form_validation->set_rules('state_name', ''.$this->lang->line('location_state_text').'', 'required|trim');
		  $this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		  $this->form_validation->set_rules('estimated_visit_time', ''.$this->lang->line('location_estimated_visit_time_text').'', 'trim');
		  /* $this->form_validation->set_rules('location_entry_ticket', ''.$this->lang->line('location_entry_ticket_text').'', 'required|trim');
		  if($this->input->post('location_entry_ticket')=='pa')
		  {
			$this->form_validation->set_rules('adult_fee', ''.$this->lang->line('location_adult_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('child_fee', ''.$this->lang->line('location_child_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('senior_citizen_fee', ''.$this->lang->line('location_senior_citizen_fee_text').'', 'required|trim|integer');  
		  } */
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		  
		  $this->form_validation->set_rules('north_area', ''.$this->lang->line('location_north_text').'', 'trim');
		  $this->form_validation->set_rules('north_area_title', ''.$this->lang->line('location_north_title_text').'', 'trim');
		  $this->form_validation->set_rules('south_area', ''.$this->lang->line('location_south_text').'', 'trim');
		  $this->form_validation->set_rules('south_area_title', ''.$this->lang->line('location_south_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area_title', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('west_area', ''.$this->lang->line('location_west_text').'', 'trim');
		  $this->form_validation->set_rules('west_area_title', ''.$this->lang->line('location_west_title_text').'', 'trim');
		  
			
	if ($this->form_validation->run()) {
	
			 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
			  foreach($_POST['week_days'] as $key => $weekdayval) {
			  if(in_array($weekdayval,$_POST['availability']))
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			  }
			 }
			 /*echo "<br>";
			  echo "<br>";
			  echo "<pre>";
			  print_r($hours_details);
			  echo "</pre>"; 
			  echo "<br>";
			  echo "<br>";
			  die();*/
			  
			  if(is_array($hours_details)) {
				$location_new_data['working_hours'] = $hours_details;
				$working_hours = json_encode($hours_details);
			  } else {
				  $working_hours = '';
			  }
			  
			  //Get Directions Json
			  $direction_locations =array();
			  
			  $direction_locations['northstartpointlongitude']= $_POST['northstartpointlongitude']; 	
			  $direction_locations['northstartpointlatitude']= $_POST['northstartpointlatitude']; 	
			  $direction_locations['northendpointlongitude']= $_POST['northendpointlongitude']; 	
			  $direction_locations['northendpointlatitude']= $_POST['northendpointlatitude']; 	
			  
			  $direction_locations['southstartpointlongitude']= $_POST['southstartpointlongitude']; 	
			  $direction_locations['southstartpointlatitude']= $_POST['southstartpointlatitude']; 	
			  $direction_locations['southendpointlongitude']= $_POST['southendpointlongitude']; 	
			  $direction_locations['southendpointlatitude']= $_POST['southendpointlatitude'];
			  
			  $direction_locations['eaststartpointlongitude']= $_POST['eaststartpointlongitude']; 	
			  $direction_locations['eaststartpointlatitude']= $_POST['eaststartpointlatitude']; 	
			  $direction_locations['eastendpointlongitude']= $_POST['eastendpointlongitude']; 	
			  $direction_locations['eastendpointlatitude']= $_POST['eastendpointlatitude'];
			  
			  $direction_locations['weststartpointlongitude']= $_POST['weststartpointlongitude']; 	
			  $direction_locations['weststartpointlatitude']= $_POST['weststartpointlatitude']; 	
			  $direction_locations['westendpointlongitude']= $_POST['westendpointlongitude']; 	
			  $direction_locations['westendpointlatitude']= $_POST['westendpointlatitude'];
			  
			  $location_new_data['directionlocations'] = $direction_locations;
			  
			  $directionlocations = json_encode($direction_locations);
			  
			  
			  
			  
			 
		
				   $location_new_data =  $this->slocations_model->update_location($this->input->post('location_id'),$working_hours,$directionlocations,$location_new_data);
			   
				 
			    
			   	//Insert Digital Media
			   if($location_id!=0){
					    //Digital Audio File
					    $totalaudiofiles= count($_FILES['digital-audio']['name']);
						for($i=0;$i<$totalaudiofiles;$i++){
							if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data = $this->slocations_model->insertDigitalMedia($location_id,audio_files,$file_name,$location_new_data);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 //Digital Gallery Files
					    $totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data = $this->slocations_model->insertDigitalMedia($location_id,gallery_files,$file_name,$location_new_data);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
						 
						/* //Digital Video File
					    $totalvideofiles= count($_FILES['digital-video']['name']);
						for($i=0;$i<$totalvideofiles;$i++){
							if($_FILES['digital-video']['name'][$i]['video_file']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-video']['name'][$i]['video_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-video']['type'][$i]['video_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-video']['tmp_name'][$i]['video_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-video']['error'][$i]['video_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-video']['size'][$i]['video_file'];
								
								$config['upload_path'] = $this->video_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertDigitalMedia($location_id,video_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } */
						 
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
							
								$location_new_data = $this->slocations_model->insertDigitalMedia($location_id,video_files,$file_name,$location_new_data);
							  } 
					
						   }
						}
						
						 
						//Digital 2dMap Files
					    $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
						for($i=0;$i<$total2dmapfiles;$i++){
							if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
							
								$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
								
								$config['upload_path'] = $this->map2d_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										
										$location_new_data = $this->slocations_model->insertDigitalMedia($location_id,map2d_files,$file_name,$location_new_data);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Digital panorama Files
					    $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
						for($i=0;$i<$totalpanoramafiles;$i++){
							if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
								
								$config['upload_path'] = $this->panorama_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
									
										$location_new_data = $this->slocations_model->insertDigitalMedia($location_id,panorama_files,$file_name,$location_new_data);
										
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						
						 //*********************************Location Section*********************//
						 //Location Section
						/* if(isset($_POST['location-section']))
						{
						  $GroupLists = $_POST['location-section'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";
							  if($listrow['section_title']!='') 
							  {
							  $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'section_title'     => $listrow['section_title'],
									'section_description'     => $listrow['section_description'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_section_id = $this->slocations_model->insertLocationSection($insert_data);
							  }
						   }
						} */
					 
						 //*********************************Facilities*********************//
						 //Facilities Washroom Group
						if(isset($_POST['washroom-group']))
						{
						  $GroupLists = $_POST['washroom-group'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['washroom_longitude']!='') 
							  {
							  $washroom_availability =  implode(",",$listrow['washroom_availability']);	
							   //$washroom_availability =  $listrow['washroom_availability'];	
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_type'  => washroom_facility_type,
									'facility_name_no'  => $listrow['washroom_no'],
									'facility_description'  => $listrow['washroom_description'],
									'washroom_availability' => $washroom_availability,
									'longitude'     => $listrow['washroom_longitude'],
									'latitude'     => $listrow['washroom_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								
								$location_new_data['facilities']['washroom']['facility_name_no'][] = $listrow['washroom_no'];
								$location_new_data['facilities']['washroom']['facility_description'][] = $listrow['washroom_description'];
								$location_new_data['facilities']['washroom']['washroom_availability'][] = $washroom_availability;
								$location_new_data['facilities']['washroom']['longitude'][] = $listrow['washroom_longitude'];
								$location_new_data['facilities']['washroom']['latitude'][] = $listrow['washroom_latitude'];
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Washroom Images 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_images'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_images'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_images'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['washroom']['photo_name'][] = $file_name;
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['washroom']['map2d'][] = $file_name; 
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								
							  }
						   }
						}
						
						if(isset($_POST['parking-group']))
						{
						  $GroupLists = $_POST['parking-group'];
						  foreach($GroupLists as $key=> $listrow){
							  /*echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";
							  die();*/
							  if($listrow['parking_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									
									'facility_name_no'  => $listrow['parking_no'],
									'facility_description'  => $listrow['parking_description'],
									'facility_type'  => parking_facility_type,
									'parking_type' => $listrow['parking_entry_ticket'],
									'parking_fee' => $listrow['parking_fees_amt'],
									'longitude'     => $listrow['parking_longitude'],
									'latitude'     => $listrow['parking_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								
								$location_new_data['facilities']['parking']['facility_name_no'][] = $listrow['parking_no'];
								$location_new_data['facilities']['parking']['facility_description'][] = $listrow['parking_description'];
								$location_new_data['facilities']['parking']['parking_type'][] = $listrow['parking_entry_ticket'];
								$location_new_data['facilities']['parking']['parking_fee'][] = $listrow['parking_fees_amt'];
								$location_new_data['facilities']['parking']['longitude'][] = $listrow['parking_longitude'];
								$location_new_data['facilities']['parking']['latitude'][] = $listrow['parking_latitude'];
								
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Parking Images 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_images'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_images'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_images'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['parking']['photo_name'][] = $file_name;   
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['parking']['map2d'][] = $file_name;  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								 
								
							  }
						   }
						}
						
						
						if(isset($_POST['group-dispensary']))
						{
						  $GroupLists = $_POST['group-dispensary'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['dispensary_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['dispensary_no'],
									'facility_description'  => $listrow['dispensary_description'],
									'facility_type'  => dispensary_facility_type,
									'longitude'     => $listrow['dispensary_longitude'],
									'latitude'     => $listrow['dispensary_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								
								$location_new_data['facilities']['dispensary']['facility_name_no'][] = $listrow['dispensary_no'];
								$location_new_data['facilities']['dispensary']['facility_description'][] = $listrow['dispensary_description'];
								$location_new_data['facilities']['dispensary']['longitude'][] = $listrow['dispensary_longitude'];
								$location_new_data['facilities']['dispensary']['latitude'][] = $listrow['dispensary_latitude'];
								
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Dispensary Images 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_images'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_images'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_images'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['dispensary']['photo_name'][] = $file_name;  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Dispensary 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['dispensary']['map2d'][] = $file_name;  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-police-booth']))
						{
						  $GroupLists = $_POST['group-police-booth'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['police_booth_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'facility_name_no'  => $listrow['police_booth_no'],
									'facility_description'  => $listrow['police_booth_description'],
									'location_id'=>$location_id,
									'facility_type'  => police_booth_facility_type,
									'longitude'     => $listrow['police_booth_longitude'],
									'latitude'     => $listrow['police_booth_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								
								$location_new_data['facilities']['police_booth']['facility_name_no'][] = $listrow['police_booth_no'];
								$location_new_data['facilities']['police_booth']['facility_description'][] = $listrow['police_booth_description'];
								$location_new_data['facilities']['police_booth']['longitude'][] = $listrow['police_booth_longitude'];
								$location_new_data['facilities']['police_booth']['latitude'][] = $listrow['police_booth_latitude'];
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_images'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_images'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_images'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['police_booth']['photo_name'][] = $file_name;  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['police_booth']['map2d'][] = $file_name;  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-shoe']))
						{
						  $GroupLists = $_POST['group-shoe'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['shoe_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'facility_name_no'  => $listrow['shoe_no'],
									'facility_description'  => $listrow['shoe_description'],
									'location_id'=>$location_id,
									'facility_type'  => shoe_facility_type,
									'longitude'     => $listrow['shoe_longitude'],
									'latitude'     => $listrow['shoe_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								
								$location_new_data['facilities']['shoe']['facility_name_no'][] = $listrow['shoe_no'];
								$location_new_data['facilities']['shoe']['facility_description'][] = $listrow['shoe_description'];
								$location_new_data['facilities']['shoe']['longitude'][] = $listrow['shoe_longitude'];
								$location_new_data['facilities']['shoe']['latitude'][] = $listrow['shoe_latitude'];
								
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_images'];
								$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_images'];
								$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_images'];
								$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['shoe']['photo_name'][] = $file_name;  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['shoe']['map2d'][] = $file_name;  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-luggage']))
						{
						  $GroupLists = $_POST['group-luggage'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['luggage_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'facility_name_no'  => $listrow['luggage_no'],
									'facility_description'  => $listrow['luggage_description'],
									'location_id'=>$location_id,
									'facility_type'  => luggage_facility_type,
									'longitude'     => $listrow['luggage_longitude'],
									'latitude'     => $listrow['luggage_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								
								$location_new_data['facilities']['luggage']['facility_name_no'][] = $listrow['luggage_no'];
								$location_new_data['facilities']['luggage']['facility_description'][] = $listrow['luggage_description'];
								$location_new_data['facilities']['luggage']['longitude'][] = $listrow['luggage_longitude'];
								$location_new_data['facilities']['luggage']['latitude'][] = $listrow['luggage_latitude'];
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_images'];
								$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_images'];
								$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_images'];
								$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['luggage']['photo_name'][] = $file_name;  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['luggage']['map2d'][] = $file_name;  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-langar']))
						{
						  $GroupLists = $_POST['group-langar'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['langar_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'facility_name_no'  => $listrow['langar_no'],
									'facility_description'  => $listrow['langar_description'],
									'location_id'=>$location_id,
									'facility_type'  => langar_facility_type,
									'longitude'     => $listrow['langar_longitude'],
									'latitude'     => $listrow['langar_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								
								$location_new_data['facilities']['langar']['facility_name_no'][] = $listrow['langar_no'];
								$location_new_data['facilities']['langar']['facility_description'][] = $listrow['langar_description'];
								$location_new_data['facilities']['langar']['longitude'][] = $listrow['langar_longitude'];
								$location_new_data['facilities']['langar']['latitude'][] = $listrow['langar_latitude'];
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_images'];
								$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_images'];
								$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_images'];
								$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['langar']['photo_name'][] = $file_name;  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['langar']['photo_name'][] = $file_name;  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-ticketcounter']))
						{
						  $GroupLists = $_POST['group-ticketcounter'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['ticketcounter_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_type'  => ticketcounter_facility_type,
									'facility_name_no'  => $listrow['ticketcounter_no'],
									'facility_description'  => $listrow['ticketcounter_description'],
									'longitude'     => $listrow['ticketcounter_longitude'],
									'latitude'     => $listrow['ticketcounter_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								
								$location_new_data['facilities']['ticketcounter']['facility_name_no'][] = $listrow['ticketcounter_no'];
								$location_new_data['facilities']['ticketcounter']['facility_description'][] = $listrow['ticketcounter_description'];
								$location_new_data['facilities']['ticketcounter']['longitude'][] = $listrow['ticketcounter_longitude'];
								$location_new_data['facilities']['ticketcounter']['latitude'][] = $listrow['ticketcounter_latitude'];
								
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_images'];
								$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_images'];
								$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_images'];
								$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										 $location_new_data['facilities']['ticketcounter']['photo_name'][] = $file_name; 
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['ticketcounter']['2dmap'][] = $file_name;  
										$updatefield =array( 
											'2dmap' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						if(isset($_POST['group-enquiry']))
						{
						  $GroupLists = $_POST['group-enquiry'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['enquiry_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_type'  => enquiry_facility_type,
									'facility_name_no'  => $listrow['enquiry_no'],
									'facility_description'  => $listrow['enquiry_description'],
									'longitude'     => $listrow['enquiry_longitude'],
									'latitude'     => $listrow['enquiry_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_new_data['facilities']['enquiry']['facility_name_no'][] = $listrow['enquiry_no'];
								$location_new_data['facilities']['enquiry']['facility_description'][] = $listrow['enquiry_description'];
								$location_new_data['facilities']['enquiry']['longitude'][] = $listrow['enquiry_longitude'];
								$location_new_data['facilities']['enquiry']['latitude'][] = $listrow['enquiry_latitude'];
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_images'];
								$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_images'];
								$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_images'];
								$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['enquiry']['photo_name'][] = $file_name;  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['enquiry']['2dmap'][] = $file_name;  
										$updatefield =array( 
											'2dmap' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						
						
						if(isset($_POST['group-resthouse']))
						{
						  $GroupLists = $_POST['group-resthouse'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['resthouse_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'facility_type'  => resthouse_facility_type,
									'facility_name_no'  => $listrow['resthouse_no'],
									'facility_description'  => $listrow['resthouse_description'],
									'longitude'     => $listrow['resthouse_longitude'],
									'latitude'     => $listrow['resthouse_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_new_data['facilities']['resthouse']['facility_name_no'][] = $listrow['resthouse_no'];
								$location_new_data['facilities']['resthouse']['facility_description'][] = $listrow['resthouse_description'];
								$location_new_data['facilities']['resthouse']['longitude'][] = $listrow['resthouse_longitude'];
								$location_new_data['facilities']['resthouse']['latitude'][] = $listrow['resthouse_latitude'];
								
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_images'];
								$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_images'];
								$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_images'];
								$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['resthouse']['photo_name'][] = $file_name;  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '200000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$location_new_data['facilities']['resthouse']['2dmap'][] = $file_name;  
										$updatefield =array( 
											'2dmap' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
					   /*  $old_beacon_group=$this->input->post('old-beacon-group');
					   
					   if(isset($old_beacon_group) &&  !empty($old_beacon_group)){
						   foreach($old_beacon_group as $content){
							   
							    $this->locations_model->editOldFacilities($content['beacon_location_id'], $content['washroom_no'], $content['washroom_description'], $content['washroom_longitude'], $content['washroom_latitude']);
							   
						   }
						   
					   } */
					   
						if(isset($_POST['location-beacon']))
						{
						  $GroupLists = $_POST['location-beacon'];
	
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['beacon_location_name']!='') 
							  {
							  
								$insert_data = array(
									'language_id'=>$this->session->userdata('lang_id'),
									'location_id'=>$location_id,
									'beacon_location_name'  => $listrow['beacon_location_name'],
									'beacon_address'  => $listrow['beacon_address'],
									'beacon_latitude'  => $listrow['beacon_latitude'],
									'beacon_longitude'  => $listrow['beacon_longitude'],
									'beacon_unique_id'  => $listrow['beacon_unique_id'],
									'remarks'  => $listrow['beacon_remarks'],
									'created_by'  => $this->session->userdata('user_id'),
									'created_on'      => date('Y-m-d H:i:s')
								);
						
								$beacon_location_id = $this->slocations_model->insertBeacon($insert_data);
								
								$insertdata = array(
									'beacon_location_id'=>$beacon_location_id,
									'action_plan_id'  => $listrow['action_plan_id'],
									'instruction_id'     => $listrow['instruction_id'],
									'sound_file_id'     => $listrow['beacon_sound_file_id'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$beacon_action_id = $this->slocations_model->insertBeaconlocations($insertdata);
								
								//Beacon Images 
								$_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_media_file'];
								$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_media_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_media_file'];
								$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_media_file'];
								$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_media_file'];
								
								$config['upload_path'] = $this->beacon_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$beacon_action_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$updatefield =array( 
											'media_file' => $file_name
										);	
										$unique_id = array('beacon_action_id' =>$beacon_action_id);
										$resultupdate = update_table_fields('sbeacon_location_actions',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
										$data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
										$data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								 //Beacon Image 
								$_FILES['userfile']['name']  = $_FILES['location-beacon']['name'][$key]['beacon_file'];
								$_FILES['userfile']['type']    = $_FILES['location-beacon']['type'][$key]['beacon_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['location-beacon']['tmp_name'][$key]['beacon_file'];
								$_FILES['userfile']['error']   = $_FILES['location-beacon']['error'][$key]['beacon_file'];
								$_FILES['userfile']['size']  = $_FILES['location-beacon']['size'][$key]['beacon_file'];
								
								$config['upload_path'] = $this->beacon_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$beacon_location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$updatefield =array( 
											'beacon_file' => $file_name
										);	
										$unique_id = array('beacon_location_id' =>$beacon_location_id);
										$resultupdate = update_table_fields('sbeacon_locations',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
										$data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
										$data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
							  }
						   }
						}
					   
					    //Old Digital Audio Files
					   $old_digital_audio_files=$this->input->post('old-digital-audio');
					   
					   if(isset($old_digital_audio_files) &&  !empty($old_digital_audio_files)){
						   if(!empty($this->session->userdata('location_media_id'))){
							  foreach($old_digital_audio_files as $filename){
									   if (!in_array($filename['location_media_id'], $this->session->userdata('location_media_id')))
									   {
										$location_new_data['OldDigitalMedia']['audio']['default_media'][] = $filename['default_media'];
										$location_new_data['OldDigitalMedia']['audio']['media_file_name'][] = $filename['audio_file'];
									   }
				   
							   }
							} else {
							   foreach($old_digital_audio_files as $filename){
								  $location_new_data['OldDigitalMedia']['audio']['default_media'][] = $filename['default_media'];
								  $location_new_data['OldDigitalMedia']['audio']['media_file_name'][] = $filename['audio_file'];
							
								   
							   }
							} 
					   }
					   
					   
					   
					    //Old Digital Gallery Files
					   $old_digital_gallery_files=$this->input->post('old-digital-gallery');
					   
					   if(isset($old_digital_gallery_files) &&  !empty($old_digital_gallery_files)){
						   if(!empty($this->session->userdata('location_media_id'))){
							  foreach($old_digital_gallery_files as $filename){
									   if (!in_array($filename['location_media_id'], $this->session->userdata('location_media_id')))
									   {
										$location_new_data['OldDigitalMedia']['gallery']['default_media'][] = $filename['default_media'];
										$location_new_data['OldDigitalMedia']['gallery']['media_file_name'][] = $filename['gallery_images'];
									   }
				   
							   }
							} else {
							   foreach($old_digital_gallery_files as $filename){
								   $location_new_data['OldDigitalMedia']['gallery']['default_media'][] = $filename['default_media'];
								   $location_new_data['OldDigitalMedia']['gallery']['media_file_name'][] = $filename['gallery_images'];
								  
								   
							   }
							}
						}
					   
					    //Old Digital Video Files
					   $old_digital_video_files=$this->input->post('old-digital-video');
					   
					   if(isset($old_digital_video_files) &&  !empty($old_digital_video_files)){
						    if(!empty($this->session->userdata('location_media_id'))){
							  foreach($old_digital_video_files as $filename){
									   if (!in_array($filename['location_media_id'], $this->session->userdata('location_media_id')))
									   {
										$location_new_data['OldDigitalMedia']['video']['default_media'][] = $filename['default_media'];
										$location_new_data['OldDigitalMedia']['video']['media_file_name'][] = $filename['video_url'];
									   }
				   
							   }
							} else {
							   foreach($old_digital_video_files as $filename){
								   $location_new_data['OldDigitalMedia']['video']['default_media'][] = $filename['default_media'];
								   $location_new_data['OldDigitalMedia']['video']['media_file_name'][] = $filename['video_url'];
								 
								   
							   }
							}
							
					   }
					   
					    //Old 2dMap Files
					   $old_digital_2dmap_files=$this->input->post('old-digital-2dmap');
					   
					   if(isset($old_digital_2dmap_files) &&  !empty($old_digital_2dmap_files)){
						   
						    if(!empty($this->session->userdata('location_media_id'))){
							  foreach($old_digital_2dmap_files as $filename){
									   if (!in_array($filename['location_media_id'], $this->session->userdata('location_media_id')))
									   {
										$location_new_data['OldDigitalMedia']['map2d']['default_media'][] = $filename['default_media'];
										$location_new_data['OldDigitalMedia']['map2d']['media_file_name'][] = $filename['2dmap_file'];
									   }
				   
							   }
							} else {
							   foreach($old_digital_2dmap_files as $filename){
								   $location_new_data['OldDigitalMedia']['map2d']['default_media'][] = $filename['default_media'];
								   $location_new_data['OldDigitalMedia']['map2d']['media_file_name'][] = $filename['2dmap_file'];
							
								   
							   }
							}
					   }
					   
					   //Old panorama Files
					   $old_digital_panorama_files=$this->input->post('old-digital-panorama');
					   
					   if(isset($old_digital_panorama_files) &&  !empty($old_digital_panorama_files)){
						    if(!empty($this->session->userdata('location_media_id'))){
							  foreach($old_digital_panorama_files as $filename){
									   if (!in_array($filename['location_media_id'], $this->session->userdata('location_media_id')))
									   {
										$location_new_data['OldDigitalMedia']['panorama']['default_media'][] = $filename['default_media'];
										$location_new_data['OldDigitalMedia']['panorama']['media_file_name'][] = $filename['panorama_images'];
									   }
				   
							   }
							} else {
							   foreach($old_digital_panorama_files as $filename){
									$location_new_data['OldDigitalMedia']['panorama']['default_media'][] = $filename['default_media'];
								   $location_new_data['OldDigitalMedia']['panorama']['media_file_name'][] = $filename['panorama_images'];
								   
							   }
							}
							
							
					   }
					   
					   
						
					   $old_washroom_group=$this->input->post('old-washroom-group');
					   
					   if(isset($old_washroom_group) &&  !empty($old_washroom_group)){
						   foreach($old_washroom_group as $content){
							   
							   $location_new_data['oldfacilities']['washroom']['facility_name_no'][] = $content['washroom_no'];
								$location_new_data['oldfacilities']['washroom']['facility_description'][] = $content['washroom_description'];
								$location_new_data['oldfacilities']['washroom']['washroom_availability'][] = $content['washroom_availability'];
								$location_new_data['oldfacilities']['washroom']['longitude'][] = $content['washroom_longitude'];
								$location_new_data['oldfacilities']['washroom']['latitude'][] = $content['washroom_latitude'];

							   $location_new_data['oldfacilities']['washroom']['photo_name'][] = $content['washroom_images'];
							   $location_new_data['oldfacilities']['washroom']['map2d'][] = $content['washroom_2dmap']; 
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'], $content['washroom_no'], $content['washroom_description'], $content['washroom_longitude'], $content['washroom_latitude']);
							   
						   }
						   
					   }
					   
					   $old_parking_group=$this->input->post('old-parking-group');
						
						if(isset($old_parking_group) &&  !empty($old_parking_group)){
						   foreach($old_parking_group as $content){
							   $location_new_data['oldfacilities']['parking']['facility_name_no'][] = $content['parking_no'];
								$location_new_data['oldfacilities']['parking']['facility_description'][] = $content['parking_description'];
								$location_new_data['oldfacilities']['parking']['parking_type'][] = $content['parking_entry_ticket'];
								$location_new_data['oldfacilities']['parking']['parking_fee'][] = $content['parking_fees_amt'];
								$location_new_data['oldfacilities']['parking']['longitude'][] = $content['parking_longitude'];
								$location_new_data['oldfacilities']['parking']['latitude'][] = $content['parking_latitude'];
								
								$location_new_data['oldfacilities']['parking']['photo_name'][] = $content['parking_images'];
							   $location_new_data['oldfacilities']['parking']['map2d'][] = $content['parking_2dmap'];
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'], $content['parking_no'], $content['parking_description'], $content['parking_longitude'], $content['parking_latitude'], $content['parking_entry_ticket']);
							   
						   }
						   
					   }
					   
					   $old_dispensary_group=$this->input->post('old-group-dispensary');
						
						if(isset($old_dispensary_group) &&  !empty($old_dispensary_group)){
						   foreach($old_dispensary_group as $content){
							   $location_new_data['oldfacilities']['dispensary']['facility_name_no'][] = $content['dispensary_no'];
								$location_new_data['oldfacilities']['dispensary']['facility_description'][] = $content['dispensary_description'];
								$location_new_data['oldfacilities']['dispensary']['longitude'][] = $content['dispensary_longitude'];
								$location_new_data['oldfacilities']['dispensary']['latitude'][] = $content['dispensary_latitude'];
								$location_new_data['oldfacilities']['dispensary']['photo_name'][] = $content['dispensary_images'];
							   $location_new_data['oldfacilities']['dispensary']['map2d'][] = $content['dispensary_2dmap'];
							   
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'], $content['dispensary_no'], $content['dispensary_description'], $content['dispensary_longitude'], $content['dispensary_latitude']);
							   
						   }
						   
					   }
					   
					   $old_police_booth_group=$this->input->post('old-group-police-booth');
						
						if(isset($old_police_booth_group) &&  !empty($old_police_booth_group)){
						   foreach($old_police_booth_group as $content){
							   $location_new_data['oldfacilities']['police_booth']['facility_name_no'][] = $content['police_booth_no'];
								$location_new_data['oldfacilities']['police_booth']['facility_description'][] = $content['police_booth_description'];
								$location_new_data['oldfacilities']['police_booth']['longitude'][] = $content['police_booth_longitude'];
								$location_new_data['oldfacilities']['police_booth']['latitude'][] = $content['police_booth_latitude'];
								$location_new_data['oldfacilities']['police_booth']['photo_name'][] = $content['police_booth_images'];
							   $location_new_data['oldfacilities']['police_booth']['map2d'][] = $content['police_booth_2dmap'];
							   
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'], $content['police_booth_no'], $content['police_booth_description'], $content['police_booth_longitude'], $content['police_booth_latitude']);
							   
						   }
						   
					   }
					   
					   $old_shoe_group=$this->input->post('old-group-shoe');
						
						if(isset($old_shoe_group) &&  !empty($old_shoe_group)){
						   foreach($old_shoe_group as $content){
							  $location_new_data['oldfacilities']['shoe']['facility_name_no'][] = $content['shoe_no'];
								$location_new_data['oldfacilities']['shoe']['facility_description'][] = $content['shoe_description'];
								$location_new_data['oldfacilities']['shoe']['longitude'][] = $content['shoe_longitude'];
								$location_new_data['oldfacilities']['shoe']['latitude'][] = $content['shoe_latitude'];
								$location_new_data['oldfacilities']['shoe']['photo_name'][] = $content['shoe_images'];
							   $location_new_data['oldfacilities']['shoe']['map2d'][] = $content['shoe_2dmap'];
							   
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'],$content['shoe_no'], $content['shoe_description'], $content['shoe_longitude'], $content['shoe_latitude']);
							   
						   }
						   
					   }
					   
					   $old_luggage_group=$this->input->post('old-group-luggage');
						
						if(isset($old_luggage_group) &&  !empty($old_luggage_group)){
						   foreach($old_luggage_group as $content){
							  $location_new_data['oldfacilities']['luggage']['facility_name_no'][] = $content['luggage_no'];
								$location_new_data['oldfacilities']['luggage']['facility_description'][] = $content['luggage_description'];
								$location_new_data['oldfacilities']['luggage']['longitude'][] = $content['luggage_longitude'];
								$location_new_data['oldfacilities']['luggage']['latitude'][] = $content['luggage_latitude'];
								$location_new_data['oldfacilities']['luggage']['photo_name'][] = $content['luggage_images'];
							   $location_new_data['oldfacilities']['luggage']['map2d'][] = $content['luggage_2dmap'];
							   
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'], $content['luggage_no'], $content['luggage_description'], $content['luggage_longitude'], $content['luggage_latitude']);
							   
						   }
						   
					   }
					   
					   $old_langar_group=$this->input->post('old-group-langar');
						
						if(isset($old_langar_group) &&  !empty($old_langar_group)){
						   foreach($old_langar_group as $content){
							  $location_new_data['oldfacilities']['langar']['facility_name_no'][] = $content['langar_no'];
								$location_new_data['oldfacilities']['langar']['facility_description'][] = $content['langar_description'];
								$location_new_data['oldfacilities']['langar']['longitude'][] = $content['langar_longitude'];
								$location_new_data['oldfacilities']['langar']['latitude'][] = $content['langar_latitude'];
								$location_new_data['oldfacilities']['langar']['photo_name'][] = $content['langar_images'];
							   $location_new_data['oldfacilities']['langar']['map2d'][] = $content['langar_2dmap'];
							   
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'], $content['langar_no'], $content['langar_description'], $content['langar_longitude'], $content['langar_latitude']);
							   
						   }
						   
					   }
					   
					   $old_ticketcounter_group=$this->input->post('old-group-ticketcounter');
						
						if(isset($old_ticketcounter_group) &&  !empty($old_ticketcounter_group)){
						   foreach($old_ticketcounter_group as $content){
							   $location_new_data['oldfacilities']['ticketcounter']['facility_name_no'][] = $content['ticketcounter_no'];
								$location_new_data['oldfacilities']['ticketcounter']['facility_description'][] = $content['ticketcounter_description'];
								$location_new_data['oldfacilities']['ticketcounter']['longitude'][] = $content['ticketcounter_longitude'];
								$location_new_data['oldfacilities']['ticketcounter']['latitude'][] = $content['ticketcounter_latitude'];
								$location_new_data['oldfacilities']['ticketcounter']['photo_name'][] = $content['ticketcounter_images'];
							   $location_new_data['oldfacilities']['ticketcounter']['map2d'][] = $content['ticketcounter_2dmap'];
							   
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'],$content['ticketcounter_no'], $content['ticketcounter_description'], $content['ticketcounter_longitude'], $content['ticketcounter_latitude']);
							   
						   }
						   
					   }
					   
					   $old_enquiry_group=$this->input->post('old-group-enquiry');
					
					if(isset($old_enquiry_group) &&  !empty($old_enquiry_group)){
					   foreach($old_enquiry_group as $content){
						   $location_new_data['oldfacilities']['enquiry']['facility_name_no'][] = $content['enquiry_no'];
							$location_new_data['oldfacilities']['enquiry']['facility_description'][] = $content['enquiry_description'];
							$location_new_data['oldfacilities']['enquiry']['longitude'][] = $content['enquiry_longitude'];
							$location_new_data['oldfacilities']['enquiry']['latitude'][] = $content['enquiry_latitude'];
							$location_new_data['oldfacilities']['enquiry']['photo_name'][] = $content['enquiry_images'];
						   $location_new_data['oldfacilities']['enquiry']['map2d'][] = $content['enquiry_2dmap'];
							   
							   
						   $this->slocations_model->editOldFacilities($content['location_facility_id'], $content['enquiry_no'], $content['enquiry_description'], $content['enquiry_longitude'], $content['enquiry_latitude']);
						   
					   }
					   
				   }
				   
				   $old_resthouse_group=$this->input->post('old-group-resthouse');
					if(isset($old_resthouse_group) &&  !empty($old_resthouse_group)){
						   foreach($old_resthouse_group as $content){
							   $location_new_data['oldfacilities']['resthouse']['facility_name_no'][] = $content['resthouse_no'];
								$location_new_data['oldfacilities']['resthouse']['facility_description'][] = $content['resthouse_description'];
								$location_new_data['oldfacilities']['resthouse']['longitude'][] = $content['resthouse_longitude'];
								$location_new_data['oldfacilities']['resthouse']['latitude'][] = $content['resthouse_latitude'];
								$location_new_data['oldfacilities']['resthouse']['photo_name'][] = $content['resthouse_images'];
							   $location_new_data['oldfacilities']['resthouse']['map2d'][] = $content['resthouse_2dmap'];
							   
							   
							   $this->slocations_model->editOldFacilities($content['location_facility_id'], $content['resthouse_no'], $content['resthouse_description'], $content['resthouse_longitude'], $content['resthouse_latitude']);
							   
						   }
						   
					   }
				
					   
				}	
				
				$location_old_data=$this->input->post('location_old_data');
				
				//Log Location
				 $this->slocations_model->locationLog($location_id,$location_old_data,$location_new_data);
		  
			   /*  $ip=$_SERVER['REMOTE_ADDR'];
			    if($ip=='103.17.97.181'){
					echo "<pre>";
					print_r($location_new_data);
					die;
				 }  */ 
				
				if(!empty($this->session->userdata('location_media_id'))){
					foreach($this->session->userdata('location_media_id') as $value){
					
						$this->slocations_model->deleteDigitalMedia($value);
					}
					 $this->session->unset_userdata('location_media_id');
			
					
				}
				
				if(!empty($this->session->userdata('facilities_ids'))){
					foreach($this->session->userdata('facilities_ids') as $value){
					
						$this->slocations_model->deletefacilities($value);
					}
					 $this->session->unset_userdata('facilities_ids');
			
					
				}
				
		       // if($result=='1')
				//{   
				   $msg = "Record has been updated";
				   $this->session->set_flashdata('success_message', $msg);
				/* }
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				} */
		       
				redirect(base_url() . "employees/slocations/view/");
		
		}		
		  $result =  $this->slocations_model->location_edit($location_id);
	
		  $data['edit_data'] = $result;
		  
		  
		  
		  $fields = array('location_id'=>$result->location_id,'is_active'=>'1');
		  $catrow = gettableinfo('slocation_categories',$fields);
		  	
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  //$location_old_data->category_type_id=$data['category_type_id'];
		    $fields = array('location_id'=>$location_id,'is_active'=>'1');
			$catresult = gettableresult('slocation_categories',$fields,'category_id');
			if(is_array($catresult))
			{
				$category_ids=array();
				foreach($catresult as $ckey => $catval) {
				  $category_ids[] = $catval->category_id;	
				}
			  $categoryids =  implode(',',$category_ids);
			  //echo "---------------->".$category_ids;
			  //$categoryids =  "'".$categoryids."'";
			 //echo "---------------->".$categoryids;
			}else
			{
				$categoryids =  '';
			}
			
			
		  $data['category_ids'] = $categoryids;
		  //$location_old_data->category_id=$data['category_ids'];
		  /* echo "<pre>";
		  print_r($location_old_data);
		  print_r($location_new_data);
		  die;  */
		  $this->load->view('employees/slocations/edit.php', $data);
		 
	}//end of Edit functionality*/
	
	public function status($location_id,$status)
	{	 // Update status  
	     $result = $this->slocations_model->update_status($location_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('status_success_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('status_error_text_message'));
		 }
		 redirect(base_url() . "employees/slocations/view");		
		 
	}//end of Status  functionality*/
	
	public function deletedigitalmedia($location_media_id)
	{	 // Delete Digital Media  
	     /* $result = $this->slocations_model->deleteDigitalMedia($location_media_id,$this->audio_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']); */
		

		$_SESSION['location_media_id'][]=$location_media_id;
		 
	}//end of Status  functionality*/
	public function deletefacilities($facilities_id)
	{	 // Delete Digital Media  
	     $_SESSION['facilities_ids'][]=$facilities_id;
		 
	}//end of Status  functionality*/
	
	public function setdefaultmedia($location_id,$location_media_id,$media_type)
	{	 // Set Default Media  
	     $result = $this->slocations_model->setDefaultMedia($location_id,$location_media_id,$media_type);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('update_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	

	public function deletelocsection($location_section_id)
	{	 // Delete Section  
	     $result = $this->slocations_model->deleteLocSection($location_section_id);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function deletefacility($location_facility_id)
	{	 // Delete facility  
	     $result = $this->slocations_model->deleteFacility($location_facility_id,$this->facility_path);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function deletebeacon($beacon_location_id,$location_id)
	{	 // Delete Location Beacon  
	     $result = $this->slocations_model->deleteLocBeacon($beacon_location_id,$location_id);
		 if($result=='1')
		 {
		     $this->session->set_flashdata('success_message', $this->lang->line('delete_text_message'));
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', $this->lang->line('error_text_message'));
		 }
		  redirect($_SERVER['HTTP_REFERER']);		
		 
	}//end of Status  functionality*/
	
	public function reccpy($location_id){
    	  
		  
		  //Set Sessions
		  if($this->input->post('content_language_id')!=''){
			  $this->session->set_userdata('content_language_id', $this->input->post('content_language_id'));
		  } 
		 
 		  if($this->input->post('content_digital_media')!=''){
			  $this->session->set_userdata('content_digital_media', $this->input->post('content_digital_media'));
		  } else {
			  $this->session->set_userdata('content_digital_media', '0');
		  } 
		  
		  if($this->input->post('content_facilities')){
			  $this->session->set_userdata('content_facilities', $this->input->post('content_facilities'));
		  } else {
			  $this->session->set_userdata('content_facilities', '0');
		  } 
		  
		  $old_location_id=$location_id;
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('edit_location_title')."";
		  $data['main_heading'] = $this->lang->line('locations_title');
		  $data['heading'] = $this->lang->line('edit_location_title');
		  $data['already_msg'] = "";
		  
		  //$this->form_validation->set_rules('category_type_id', ''.$this->lang->line('location_category_type_text').'', 'required|trim');
		  //$this->form_validation->set_rules('location_category[]', ''.$this->lang->line('location_category_text').'', 'required|trim');
		  
		  $this->form_validation->set_rules('location_name', ''.$this->lang->line('location_location_name_text').'', 'required|trim');
		  /* $this->form_validation->set_rules('short_name', ''.$this->lang->line('location_short_name_text').'', 'required|trim');
	
		  $this->form_validation->set_rules('description', ''.$this->lang->line('location_description_text').'', 'trim');
		
		  $this->form_validation->set_rules('pin_code', ''.$this->lang->line('location_pin_code_text').'', 'trim|numeric|min_length[4]');
		  
		  $this->form_validation->set_rules('website_url', ''.$this->lang->line('location_website_url_text').'', 'trim|valid_url');
		  $this->form_validation->set_rules('estimated_visit_time', ''.$this->lang->line('location_estimated_visit_time_text').'', 'trim');
		  /* $this->form_validation->set_rules('location_entry_ticket', ''.$this->lang->line('location_entry_ticket_text').'', 'required|trim');
		  if($this->input->post('location_entry_ticket')=='pa')
		  {
			$this->form_validation->set_rules('adult_fee', ''.$this->lang->line('location_adult_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('child_fee', ''.$this->lang->line('location_child_fee_text').'', 'required|trim|integer');  
			$this->form_validation->set_rules('senior_citizen_fee', ''.$this->lang->line('location_senior_citizen_fee_text').'', 'required|trim|integer');  
		  } 
		  
		  //Physical Location
		  $this->form_validation->set_rules('longitude', ''.$this->lang->line('location_longitude_text').'', 'required|trim');
		  $this->form_validation->set_rules('latitude', ''.$this->lang->line('location_latitude_text').'', 'required|trim');
		  
		  
		  $this->form_validation->set_rules('north_area', ''.$this->lang->line('location_north_text').'', 'trim');
		  $this->form_validation->set_rules('north_area_title', ''.$this->lang->line('location_north_title_text').'', 'trim');
		  $this->form_validation->set_rules('south_area', ''.$this->lang->line('location_south_text').'', 'trim');
		  $this->form_validation->set_rules('south_area_title', ''.$this->lang->line('location_south_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('east_area_title', ''.$this->lang->line('location_east_title_text').'', 'trim');
		  $this->form_validation->set_rules('west_area', ''.$this->lang->line('location_west_text').'', 'trim');
		  $this->form_validation->set_rules('west_area_title', ''.$this->lang->line('location_west_title_text').'', 'trim'); */
		  
		if ($this->form_validation->run()) {
			 /* $ip=$_SERVER['REMOTE_ADDR'];
			 if($ip=='103.17.97.1811'){
			   echo "<pre>";
			   print_r($this->input->post());
			   //print_r($_FILES);
			   die;	 
			 } */
		 	 $hours_details =array();
			 if(is_array($_POST['week_days']))
			 {
			  foreach($_POST['week_days'] as $key => $weekdayval) {
			  if(in_array($weekdayval,$_POST['availability']))
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'open';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= $_POST['starttime'][$key]; 
				 $hoursdetails['closetime']= $_POST['closetime'][$key]; 
				}
				else
				{
				 $hoursdetails['week_days']= $_POST['week_days'][$key]; 	
				 $availability = 'close';
				 $hoursdetails['availability']= $availability; 
				 $hoursdetails['starttime']= ''; 
				 $hoursdetails['closetime']= ''; 
				}
				$hours_details[] = $hoursdetails;
				 
			  }
			 }
			 /*echo "<br>";
			  echo "<br>";
			  echo "<pre>";
			  print_r($hours_details);
			  echo "</pre>"; 
			  echo "<br>";
			  echo "<br>";
			  die();*/
			  if(is_array($hours_details))
			  $working_hours = json_encode($hours_details);
			  else
			  $working_hours = '';
			  
			 //Get Directions Json
			  $direction_locations =array();
			  
			  $direction_locations['northstartpointlongitude']= $_POST['northstartpointlongitude']; 	
			  $direction_locations['northstartpointlatitude']= $_POST['northstartpointlatitude']; 	
			  $direction_locations['northendpointlongitude']= $_POST['northendpointlongitude']; 	
			  $direction_locations['northendpointlatitude']= $_POST['northendpointlatitude']; 	
			  
			  $direction_locations['southstartpointlongitude']= $_POST['southstartpointlongitude']; 	
			  $direction_locations['southstartpointlatitude']= $_POST['southstartpointlatitude']; 	
			  $direction_locations['southendpointlongitude']= $_POST['southendpointlongitude']; 	
			  $direction_locations['southendpointlatitude']= $_POST['southendpointlatitude'];
			  
			  $direction_locations['eaststartpointlongitude']= $_POST['eaststartpointlongitude']; 	
			  $direction_locations['eaststartpointlatitude']= $_POST['eaststartpointlatitude']; 	
			  $direction_locations['eastendpointlongitude']= $_POST['eastendpointlongitude']; 	
			  $direction_locations['eastendpointlatitude']= $_POST['eastendpointlatitude'];
			  
			  $direction_locations['weststartpointlongitude']= $_POST['weststartpointlongitude']; 	
			  $direction_locations['weststartpointlatitude']= $_POST['weststartpointlatitude']; 	
			  $direction_locations['westendpointlongitude']= $_POST['westendpointlongitude']; 	
			  $direction_locations['westendpointlatitude']= $_POST['westendpointlatitude'];
			  
			  $directionlocations = json_encode($direction_locations);
			  
						 
			
			   //copy
			   
			   $location_id =  $this->slocations_model->addContent($working_hours,$directionlocations);
			   //$location_id='108';
				//$main_location_id = $this->slocations_model->new_record_copy_media($this->input->post('location_id'),$location_id);
			   //$this->slocations_model->update_status($location_id,'1');
			   $result=1;
			   
		 	   
			 
			   
			   
			    
			   	//Insert Digital Media
			   if($location_id!=0){
				   
				   
					   //Old Digital Audio Files
					   $old_digital_audio_files=$this->input->post('old-digital-audio');
					   
					   if(isset($old_digital_audio_files) &&  !empty($old_digital_audio_files)){
						   foreach($old_digital_audio_files as $filename){
							   
							   $this->slocations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['audio_file'],$this->audio_path);
							   
						   }
						   
					   }
					   
					   
					    //Digital Audio File
					    $totalaudiofiles= count($_FILES['digital-audio']['name']);
						for($i=0;$i<$totalaudiofiles;$i++){
							if($_FILES['digital-audio']['name'][$i]['audio_file']!=''){	
							
								$_FILES['userfile']['name'] = $_FILES['digital-audio']['name'][$i]['audio_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-audio']['type'][$i]['audio_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-audio']['tmp_name'][$i]['audio_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-audio']['error'][$i]['audio_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-audio']['size'][$i]['audio_file'];
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = audo_file_extensions;
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertContentDigitalMedia($location_id,audio_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 }
						 
					  
					   //Old Digital Gallery Files
					   $old_digital_gallery_files=$this->input->post('old-digital-gallery');
					   
					   if(isset($old_digital_gallery_files) &&  !empty($old_digital_gallery_files)){
						   foreach($old_digital_gallery_files as $filename){
							   
							   $this->slocations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['gallery_images'],$this->gallery_path);
							   
						   }
						   
					   }
						
							   
					   //Digital Gallery Files
						$totalgalleryfiles= count($_FILES['digital-gallery']['name']);
						for($i=0;$i<$totalgalleryfiles;$i++){
							if($_FILES['digital-gallery']['name'][$i]['gallery_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-gallery']['name'][$i]['gallery_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-gallery']['type'][$i]['gallery_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-gallery']['tmp_name'][$i]['gallery_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-gallery']['error'][$i]['gallery_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-gallery']['size'][$i]['gallery_images'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertContentDigitalMedia($location_id,gallery_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							} 
						 }
						 
					   //Old Digital Video Files
					   $old_digital_video_files=$this->input->post('old-digital-video');
					   
					   if(isset($old_digital_video_files) &&  !empty($old_digital_video_files)){
						   foreach($old_digital_video_files as $filename){
							   
							   $this->slocations_model->insertOldDigitalMedia($old_location_id, $location_id, $filename['video_url']);
							   
						   }
					   }
					   
						//Digital Media Video 
						if(isset($_POST['digital-video']))
						{
						  $GroupLists = $_POST['digital-video'];
						  foreach($GroupLists as $key=> $listrow){
							
							  if($listrow['video_url']!='') 
							  {
								$file_name = $listrow['video_url'];
								$mediaresult = $this->slocations_model->insertContentDigitalMedia($location_id,video_files,$file_name);
							  } 
					
						   }
						}
						 
					  
						 
						 //Old 2dMap Files
					   $old_digital_2dmap_files=$this->input->post('old-digital-2dmap');
					   
					   if(isset($old_digital_2dmap_files) &&  !empty($old_digital_2dmap_files)){
						   foreach($old_digital_2dmap_files as $filename){
							   
							   $this->slocations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['2dmap_file'],$this->map2d_path);
							   
						   }
					   }
					   
						//Digital 2dMap Files
					    $total2dmapfiles= count($_FILES['digital-2dmap']['name']);
						for($i=0;$i<$total2dmapfiles;$i++){
							if($_FILES['digital-2dmap']['name'][$i]['2dmap_file']!=''){	
							
								$_FILES['userfile']['name']  =$_FILES['digital-2dmap']['name'][$i]['2dmap_file'];
								$_FILES['userfile']['type']    = $_FILES['digital-2dmap']['type'][$i]['2dmap_file'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-2dmap']['tmp_name'][$i]['2dmap_file'];
								$_FILES['userfile']['error']       = $_FILES['digital-2dmap']['error'][$i]['2dmap_file'];
								$_FILES['userfile']['size']    = $_FILES['digital-2dmap']['size'][$i]['2dmap_file'];
								
								$config['upload_path'] = $this->map2d_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertContentDigitalMedia($location_id,map2d_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						//Old panorama Files
					   $old_digital_panorama_files=$this->input->post('old-digital-panorama');
					   
					   if(isset($old_digital_panorama_files) &&  !empty($old_digital_panorama_files)){
						   foreach($old_digital_panorama_files as $filename){
							   
							   $this->slocations_model->insertOldDigitalMedia($old_location_id,$location_id, $filename['panorama_images'],$this->panorama_path);
							   
						   }
					   }
					   
						//Digital panorama Files
					    $totalpanoramafiles= count($_FILES['digital-panorama']['name']);
						for($i=0;$i<$totalpanoramafiles;$i++){
							if($_FILES['digital-panorama']['name'][$i]['panorama_images']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['digital-panorama']['name'][$i]['panorama_images'];
								$_FILES['userfile']['type']    = $_FILES['digital-panorama']['type'][$i]['panorama_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['digital-panorama']['tmp_name'][$i]['panorama_images'];
								$_FILES['userfile']['error']       = $_FILES['digital-panorama']['error'][$i]['panorama_images'];
								$_FILES['userfile']['size']    = $_FILES['digital-panorama']['size'][$i]['panorama_images'];
								
								$config['upload_path'] = $this->panorama_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;		
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$mediaresult = $this->slocations_model->insertContentDigitalMedia($location_id,panorama_files,$file_name);
									  }
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$i] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									  } 
								}  
							}
						 } 
						 
						
						 
						 
						
					 
						 //*********************************Facilities*********************//
						 //Facilities Washroom Group
						
						
						//Old
						
					   $old_washroom_group=$this->input->post('old-washroom-group');
					   
					   if(isset($old_washroom_group) &&  !empty($old_washroom_group)){
						   foreach($old_washroom_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id, $location_id, $content['washroom_no'], $content['washroom_description'], $content['washroom_longitude'], $content['washroom_latitude'], $content['washroom_images'], $content['washroom_2dmap'],'1','',$content['washroom_availability']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['washroom-group']))
						{
						  $GroupLists = $_POST['washroom-group'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['washroom_longitude']!='') 
							  {
							  $washroom_availability =  implode(",",$listrow['washroom_availability']);	
							   //$washroom_availability =  $listrow['washroom_availability'];	
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['washroom_no'],
									'facility_description'  => $listrow['washroom_description'],
									'facility_type'  => washroom_facility_type,
									'washroom_availability' => $washroom_availability,
									'longitude'     => $listrow['washroom_longitude'],
									'latitude'     => $listrow['washroom_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Washroom Images 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_images'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_images'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_images'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['washroom-group']['name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['washroom-group']['type'][$key]['washroom_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['washroom-group']['tmp_name'][$key]['washroom_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['washroom-group']['error'][$key]['washroom_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['washroom-group']['size'][$key]['washroom_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								
							  }
						   }
						}
						
						$old_parking_group=$this->input->post('old-parking-group');
						
						if(isset($old_parking_group) &&  !empty($old_parking_group)){
						   foreach($old_parking_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['parking_no'], $content['parking_description'], $content['parking_longitude'], $content['parking_latitude'], $content['parking_images'], $content['parking_2dmap'],'2', $content['parking_entry_ticket']);
							   
						   }
						   
					   }
					   
						if(isset($_POST['parking-group']))
						{
						  $GroupLists = $_POST['parking-group'];
						  foreach($GroupLists as $key=> $listrow){
							  /*echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";
							  die();*/
							  if($listrow['parking_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['parking_no'],
									'facility_description'  => $listrow['parking_description'],
									'facility_type'  => parking_facility_type,
									'parking_type' => $listrow['parking_entry_ticket'],
									'parking_fee' => $listrow['parking_fees_amt'],
									'longitude'     => $listrow['parking_longitude'],
									'latitude'     => $listrow['parking_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Parking Images 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_images'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_images'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_images'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Washroom 2dmap 
								$_FILES['userfile']['name']  = $_FILES['parking-group']['name'][$key]['parking_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['parking-group']['type'][$key]['parking_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['parking-group']['tmp_name'][$key]['parking_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['parking-group']['error'][$key]['parking_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['parking-group']['size'][$key]['parking_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= max_file_size;
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
								 
								
							  }
						   }
						}
						
						$old_dispensary_group=$this->input->post('old-group-dispensary');
						
						if(isset($old_dispensary_group) &&  !empty($old_dispensary_group)){
						   foreach($old_dispensary_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['dispensary_no'], $content['dispensary_description'], $content['dispensary_longitude'], $content['dispensary_latitude'], $content['dispensary_images'], $content['dispensary_2dmap'],'3');
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-dispensary']))
						{
						  $GroupLists = $_POST['group-dispensary'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['dispensary_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['dispensary_no'],
									'facility_description'  => $listrow['dispensary_description'],
									'facility_type'  => dispensary_facility_type,
									'longitude'     => $listrow['dispensary_longitude'],
									'latitude'     => $listrow['dispensary_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Dispensary Images 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_images'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_images'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_images'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Dispensary 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-dispensary']['name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-dispensary']['type'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-dispensary']['tmp_name'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-dispensary']['error'][$key]['dispensary_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-dispensary']['size'][$key]['dispensary_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_police_booth_group=$this->input->post('old-group-police-booth');
						
						if(isset($old_police_booth_group) &&  !empty($old_police_booth_group)){
						   foreach($old_police_booth_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['police_booth_no'], $content['police_booth_description'], $content['police_booth_longitude'], $content['police_booth_latitude'], $content['police_booth_images'], $content['police_booth_2dmap'],'4');
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-police-booth']))
						{
						  $GroupLists = $_POST['group-police-booth'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['police_booth_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['police_booth_no'],
									'facility_description'  => $listrow['police_booth_description'],
									'facility_type'  => police_booth_facility_type,
									'longitude'     => $listrow['police_booth_longitude'],
									'latitude'     => $listrow['police_booth_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_images'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_images'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_images'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-police-booth']['name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-police-booth']['type'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-police-booth']['tmp_name'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-police-booth']['error'][$key]['police_booth_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-police-booth']['size'][$key]['police_booth_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_shoe_group=$this->input->post('old-group-shoe');
						
						if(isset($old_shoe_group) &&  !empty($old_shoe_group)){
						   foreach($old_shoe_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['shoe_no'], $content['shoe_description'], $content['shoe_longitude'], $content['shoe_latitude'], $content['shoe_images'], $content['shoe_2dmap'],'5');
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-shoe']))
						{
						  $GroupLists = $_POST['group-shoe'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['shoe_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['shoe_no'],
									'facility_description'  => $listrow['shoe_description'],
									'facility_type'  => shoe_facility_type,
									'longitude'     => $listrow['shoe_longitude'],
									'latitude'     => $listrow['shoe_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_images'];
								$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_images'];
								$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_images'];
								$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-shoe']['name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-shoe']['type'][$key]['shoe_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-shoe']['tmp_name'][$key]['shoe_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-shoe']['error'][$key]['shoe_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-shoe']['size'][$key]['shoe_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_luggage_group=$this->input->post('old-group-luggage');
						
						if(isset($old_luggage_group) &&  !empty($old_luggage_group)){
						   foreach($old_luggage_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['luggage_no'], $content['luggage_description'], $content['luggage_longitude'], $content['luggage_latitude'], $content['luggage_images'], $content['luggage_2dmap'],'6');
							   
						   }
						   
					   }
					   
						if(isset($_POST['group-luggage']))
						{
						  $GroupLists = $_POST['group-luggage'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['luggage_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['luggage_no'],
									'facility_description'  => $listrow['luggage_description'],
									'facility_type'  => luggage_facility_type,
									'longitude'     => $listrow['luggage_longitude'],
									'latitude'     => $listrow['luggage_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_images'];
								$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_images'];
								$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_images'];
								$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-luggage']['name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-luggage']['type'][$key]['luggage_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-luggage']['tmp_name'][$key]['luggage_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-luggage']['error'][$key]['luggage_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-luggage']['size'][$key]['luggage_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_langar_group=$this->input->post('old-group-langar');
						
						if(isset($old_langar_group) &&  !empty($old_langar_group)){
						   foreach($old_langar_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['langar_no'], $content['langar_description'], $content['langar_longitude'], $content['langar_latitude'], $content['langar_images'], $content['langar_2dmap'],'7');
							   
						   }
						   
					   }
						if(isset($_POST['group-langar']))
						{
						  $GroupLists = $_POST['group-langar'];
						  foreach($GroupLists as $key=> $listrow){
							 /* echo "<pre>";
							  print_r($listrow);
							  echo "</pre>";
							  echo "<br>";
							  echo "<br>";*/
							  if($listrow['langar_longitude']!='') 
							  {
							   $insert_data = array(
									'language_id'=>$this->session->userdata('content_language_id'),
									'location_id'=>$location_id,
									'facility_name_no'  => $listrow['langar_no'],
									'facility_description'  => $listrow['langar_description'],
									'facility_type'  => langar_facility_type,
									'longitude'     => $listrow['langar_longitude'],
									'latitude'     => $listrow['langar_latitude'],
									'created_on'      => date('Y-m-d H:i:s')
								);
								$location_facility_id = $this->slocations_model->insertFacility($insert_data);
								
								//Police Booth Images 
								$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_images'];
								$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_images'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_images'];
								$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_images'];
								$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_images'];
								
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'photo_name' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 } 
								 
								//Police Booth 2dmap 
								$_FILES['userfile']['name']  = $_FILES['group-langar']['name'][$key]['langar_2dmap'];
								$_FILES['userfile']['type']    = $_FILES['group-langar']['type'][$key]['langar_2dmap'];
								$_FILES['userfile']['tmp_name'] = $_FILES['group-langar']['tmp_name'][$key]['langar_2dmap'];
								$_FILES['userfile']['error']   = $_FILES['group-langar']['error'][$key]['langar_2dmap'];
								$_FILES['userfile']['size']  = $_FILES['group-langar']['size'][$key]['langar_2dmap'];
							
								$config['upload_path'] = $this->facility_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;
								$file_name = time().'_'.$location_facility_id.'_'.$_FILES['userfile']['name'];	
								$config['file_name'] =$file_name;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										  
										$updatefield =array( 
											'map2d' => $file_name
										);	
										$unique_id = array('location_facility_id' =>$location_facility_id);
										$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
									  }
									  $config['file_name'] =$file_name;
									  $this->upload->initialize($config);
									  $this->upload->do_upload('userfile');
									  if ($this->upload->do_upload('userfile'))
									  {
									   $data['uploads'][$key] = $this->upload->data();
									  }
									  else
									  {
									   $data['upload_errors'][$key] = $this->upload->display_errors();
									  } 
								 }  
							  }
						   }
						}
						
						$old_ticketcounter_group=$this->input->post('old-group-ticketcounter');
						
						if(isset($old_ticketcounter_group) &&  !empty($old_ticketcounter_group)){
						   foreach($old_ticketcounter_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['ticketcounter_no'], $content['ticketcounter_description'], $content['ticketcounter_longitude'], $content['ticketcounter_latitude'], $content['ticketcounter_images'], $content['ticketcounter_2dmap'],'8');
							   
						   }
						   
					   }
						
				 if(isset($_POST['group-ticketcounter']))
					{
					  $GroupLists = $_POST['group-ticketcounter'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['ticketcounter_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('content_language_id'),
								'location_id'=>$location_id,
								'facility_type'  => ticketcounter_facility_type,
								'facility_name_no'  => $listrow['ticketcounter_no'],
								'facility_description'  => $listrow['ticketcounter_description'],
								'longitude'     => $listrow['ticketcounter_longitude'],
								'latitude'     => $listrow['ticketcounter_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->slocations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_images'];
							$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_images'];
							$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_images'];
							$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							 
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-ticketcounter']['name'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-ticketcounter']['type'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-ticketcounter']['tmp_name'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-ticketcounter']['error'][$key]['ticketcounter_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-ticketcounter']['size'][$key]['ticketcounter_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					
					$old_enquiry_group=$this->input->post('old-group-enquiry');
					
					if(isset($old_enquiry_group) &&  !empty($old_enquiry_group)){
						   foreach($old_enquiry_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['enquiry_no'], $content['enquiry_description'], $content['enquiry_longitude'], $content['enquiry_latitude'], $content['enquiry_images'], $content['enquiry_2dmap'],'9');
							   
						   }
						   
					   }
					
					if(isset($_POST['group-enquiry']))
					{
					  $GroupLists = $_POST['group-enquiry'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['enquiry_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('content_language_id'),
								'location_id'=>$location_id,
								'facility_type'  => enquiry_facility_type,
								'facility_name_no'  => $listrow['enquiry_no'],
								'facility_description'  => $listrow['enquiry_description'],
								'longitude'     => $listrow['enquiry_longitude'],
								'latitude'     => $listrow['enquiry_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->slocations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_images'];
							$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_images'];
							$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_images'];
							$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('slocation_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							 
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-enquiry']['name'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-enquiry']['type'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-enquiry']['tmp_name'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-enquiry']['error'][$key]['enquiry_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-enquiry']['size'][$key]['enquiry_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					$old_resthouse_group=$this->input->post('old-group-resthouse');
					if(isset($old_resthouse_group) &&  !empty($old_resthouse_group)){
						   foreach($old_resthouse_group as $content){
							   
							   $this->slocations_model->insertOldFacilities($old_location_id,$location_id, $content['resthouse_no'], $content['resthouse_description'], $content['resthouse_longitude'], $content['resthouse_latitude'], $content['resthouse_images'], $content['resthouse_2dmap'],'10');
							   
						   }
						   
					   }
					
					
					if(isset($_POST['group-resthouse']))
					{
					  $GroupLists = $_POST['group-resthouse'];
					  foreach($GroupLists as $key=> $listrow){
						 /* echo "<pre>";
						  print_r($listrow);
						  echo "</pre>";
						  echo "<br>";
						  echo "<br>";*/
						  if($listrow['resthouse_longitude']!='') 
						  {
						   $insert_data = array(
								'language_id'=>$this->session->userdata('content_language_id'),
								'location_id'=>$location_id,
								'facility_type'  => resthouse_facility_type,
								'facility_name_no'  => $listrow['resthouse_no'],
								'facility_description'  => $listrow['resthouse_description'],
								'longitude'     => $listrow['resthouse_longitude'],
								'latitude'     => $listrow['resthouse_latitude'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$location_facility_id = $this->slocations_model->insertFacility($insert_data);
							
							//Police Booth Images 
							$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_images'];
							$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_images'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_images'];
							$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_images'];
							$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_images'];
							
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'photo_name' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 } 
							 
							//Police Booth 2dmap 
							$_FILES['userfile']['name']  = $_FILES['group-resthouse']['name'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['type']    = $_FILES['group-resthouse']['type'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['tmp_name'] = $_FILES['group-resthouse']['tmp_name'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['error']   = $_FILES['group-resthouse']['error'][$key]['resthouse_2dmap'];
							$_FILES['userfile']['size']  = $_FILES['group-resthouse']['size'][$key]['resthouse_2dmap'];
						
							$config['upload_path'] = $this->facility_path;
							$config['allowed_types'] = 'jpeg|gif|jpg|png';
							$config['max_size']	= '5120';
							$config['max_width']  = '0';
							$config['max_height']  = '0';
							$config['overwrite'] = true;
							$file_name = time().'_'.$location_id.'_'.$_FILES['userfile']['name'];	
							$config['file_name'] =$file_name;	
							if($_FILES['userfile']['error']!='4'){
								  if($_FILES['userfile']['name']!=''){
									  
									$updatefield =array( 
										'2dmap' => $file_name
									);	
									$unique_id = array('location_facility_id' =>$location_facility_id);
									$resultupdate = update_table_fields('location_facilities',$updatefield,$unique_id);
								  }
								  $config['file_name'] =$file_name;
								  $this->upload->initialize($config);
								  $this->upload->do_upload('userfile');
								  if ($this->upload->do_upload('userfile'))
								  {
								   $data['uploads'][$key] = $this->upload->data();
								  }
								  else
								  {
								   $data['upload_errors'][$key] = $this->upload->display_errors();
								  } 
							 }  
						  }
					   }
					}
					
					
					
					
				}	
		        
		  
			
				
		
		      if($result=='1')
				{   
						//Copy
					   $msg = $this->lang->line('copy_success_text_message');
					   $this->session->set_flashdata('success_message', $msg);
					   
					   //Unset Sessions
		   
						$this->session->unset_userdata('content_language_id');
						$this->session->unset_userdata('content_digital_media');
						$this->session->unset_userdata('content_facilities');
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
		        //Copy
				redirect(base_url() . "employees/slocations/view/");
				
		
		}		
		   $result =  $this->slocations_model->location_edit($location_id);
		  $data['edit_data'] = $result;
		  $fields = array('location_id'=>$result->location_id,'is_active'=>'1');
		  $catrow = gettableinfo('slocation_categories',$fields);
		  
		  $data['category_type_id'] = isset($catrow->category_type_id) ? $catrow->category_type_id : 0;
		  
		    $fields = array('location_id'=>$location_id,'is_active'=>'1');
			$catresult = gettableresult('slocation_categories',$fields,'category_id');
			if(is_array($catresult))
			{
				$category_ids=array();
				foreach($catresult as $ckey => $catval) {
				  $category_ids[] = $catval->category_id;	
				}
			  $categoryids =  implode(',',$category_ids);
			  //echo "---------------->".$category_ids;
			  //$categoryids =  "'".$categoryids."'";
			 //echo "---------------->".$categoryids;
			}else
			{
				$categoryids =  '';
			}
			
			//print_r($category_ids);					
		  $data['category_ids'] = $categoryids;
		  
		  $this->load->view('employees/slocations/copy.php', $data);
		 
	} //end of Copy functionality*/
}	
?>