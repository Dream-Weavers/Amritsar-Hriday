<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Survey extends CI_Controller {
	var $original_path;
	var $resized_path;	
	public function __construct()
	{
		parent:: __construct();
		//valid_logged_in(FALSE,'E');	
		//check_permissions();
		//time_zone();
		$this->load->model('employees/Survey_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->gallery_path = realpath('images/survey/gallery/');
		$this->audio_path = realpath('images/survey/audio/');
		$this->video_path = realpath('images/survey/video/');
		$this->old_pictures_collected_path = realpath('images/survey/old-pictures-collection/');
	}
	public function view(){	
	    
		$data=array();
		$data['title'] = title." ".$this->lang->line('view_surveys_title')."";
	    $data['main_heading'] = $this->lang->line('surveys_title');
	    $data['heading'] = $this->lang->line('view_surveys_title');	
	    
		
	   //print_r($_POST);	

		/* if($this->input->post('per_page'))
			$per_page = $this->input->post('per_page');
		elseif($this->uri->segment('10'))
			$per_page=$this->uri->segment('10');
		else
			$per_page=per_page;	 */
			
		/* $config = array();
		$config["base_url"] = base_url() . "employees/survey/view/".$designation_id."/".$role_id."/".$search_by."/".$search_value."/".$status."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 11;
		$config["total_rows"] =$this->Survey_model->count_surveys($designation_id,$role_id,$search_by,$search_value,$status);
		$this->pagination->initialize($config);
        $page = ($this->uri->segment(11)) ? $this->uri->segment(11) : 0; 
		$data['results'] = $this->Survey_model->view_surveys($designation_id,$role_id,$search_by,$search_value,$status,$config['per_page'], $page);
		$data['links']   = $this->pagination->create_links();
		$data['num_rows'] = $config['total_rows'];	
		
		$data['designation_id'] = $designation_id;
		$data['role_id'] = $role_id;
		$data['status'] = $status;
		$data['search_by'] = $search_by;	
		$data['search_value'] = $search_value;	
		$data['per_page'] = $per_page; */
		$data['results'] = $this->Survey_model->view_survey();  	  
	    $this->load->view('employees/survey/view', $data);
		}
	public function add()
	{
		  $data=array();
		  $data['title'] = title." ".$this->lang->line('add_survey_title')."";
		  $data['main_heading'] = $this->lang->line('surveys_title');
		  $data['heading'] = $this->lang->line('add_survey_title');
		  $data['already_msg'] = "";
		  $data['survey_number'] = $this->Survey_model->get_survey_num();	
		  $this->form_validation->set_rules('customer_name', 'Name', 'required|trim');
		     /* echo "<pre>";
		  //print_r($_FILES['media-group']['name'][0]['place_pictures']);
		  print_r($_FILES);
		  $total= count($_FILES['media-group']['name']);
		  die; */   
		  $total= count($_FILES['media-group']['name']);
		  if ($this->form_validation->run()) {
				$survey_id =  $this->Survey_model->add();
				if($survey_id!=0){
						for($i=0;$i<$total;$i++){
							if($_FILES['media-group']['name'][$i]['place_pictures']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['place_pictures'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['place_pictures'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['place_pictures'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['place_pictures'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['place_pictures'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,1,4,$_FILES['userfile']['name']);	
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['place_audios']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['place_audios'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['place_audios'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['place_audios'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['place_audios'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['place_audios'];
								
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,1,1,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 }
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['place_videos']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['place_videos'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['place_videos'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['place_videos'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['place_videos'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['place_videos'];
								
								
								$config['upload_path'] = $this->video_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,1,2,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['place_old_pictures_collected']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['place_old_pictures_collected'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['place_old_pictures_collected'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['place_old_pictures_collected'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['place_old_pictures_collected'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['place_old_pictures_collected'];
								
								
								$config['upload_path'] = $this->old_pictures_collected_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,1,5,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 }
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['event_audios']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['event_audios'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['event_audios'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['event_audios'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['event_audios'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['event_audios'];
								
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,2,1,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['event_videos']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['event_videos'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['event_videos'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['event_videos'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['event_videos'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['event_videos'];
								
								
								$config['upload_path'] = $this->video_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,2,2,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['event_old_pictures_collected']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['event_old_pictures_collected'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['event_old_pictures_collected'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['event_old_pictures_collected'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['event_old_pictures_collected'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['event_old_pictures_collected'];
								
								
								$config['upload_path'] = $this->old_pictures_collected_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,2,5,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['event_pictures']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['event_pictures'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['event_pictures'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['event_pictures'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['event_pictures'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['event_pictures'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,2,4,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['site_audios']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['site_audios'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['site_audios'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['site_audios'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['site_audios'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['site_audios'];
								
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,3,1,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['site_videos']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['site_videos'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['site_videos'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['site_videos'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['site_videos'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['site_videos'];
								
								
								$config['upload_path'] = $this->video_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,3,2,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['site_old_pictures_collected']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['site_old_pictures_collected'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['site_old_pictures_collected'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['site_old_pictures_collected'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['site_old_pictures_collected'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['site_old_pictures_collected'];
								
								
								$config['upload_path'] = $this->old_pictures_collected_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,3,5,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 /* if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									 } */ 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['site_pictures']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['site_pictures'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['site_pictures'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['site_pictures'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['site_pictures'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['site_pictures'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,3,4,$_FILES['userfile']['name']);	
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
						}
						
				}			
				if($survey_id!=0)
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
				redirect(base_url() . "employees/survey/view");
				
			}
			$this->load->view('employees/survey/add', $data);
	} //end of add  functionality

	public function edit($survey_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_survey_title')."";
		  $data['main_heading'] = $this->lang->line('surveys_title');
		  $data['heading'] = $this->lang->line('edit_survey_title');
		  $data['already_msg'] = "";
		  
		  $data['mediagroup'] = $this->Survey_model->fetch_survey_attribute_collection($survey_id);

  		  $this->form_validation->set_rules('customer_name', 'Name', 'required|trim');
	
		      
		  $total= count($_FILES['media-group']['name']);
		  if ($this->form_validation->run()) {
				
				// Update records 
	
		        $result =  $this->Survey_model->update_survey($survey_id);
				if($result!=0){
						for($i=0;$i<$total;$i++){
							if($_FILES['media-group']['name'][$i]['place_pictures']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['place_pictures'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['place_pictures'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['place_pictures'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['place_pictures'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['place_pictures'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,1,4,$_FILES['userfile']['name']);	
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['place_audios']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['place_audios'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['place_audios'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['place_audios'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['place_audios'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['place_audios'];
								
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,1,1,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 }
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['place_videos']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['place_videos'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['place_videos'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['place_videos'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['place_videos'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['place_videos'];
								
								
								$config['upload_path'] = $this->video_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,1,2,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['place_old_pictures_collected']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['place_old_pictures_collected'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['place_old_pictures_collected'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['place_old_pictures_collected'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['place_old_pictures_collected'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['place_old_pictures_collected'];
								
								
								$config['upload_path'] = $this->old_pictures_collected_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,1,5,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 }
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['event_audios']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['event_audios'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['event_audios'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['event_audios'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['event_audios'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['event_audios'];
								
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,2,1,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['event_videos']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['event_videos'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['event_videos'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['event_videos'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['event_videos'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['event_videos'];
								
								
								$config['upload_path'] = $this->video_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,2,2,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['event_old_pictures_collected']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['event_old_pictures_collected'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['event_old_pictures_collected'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['event_old_pictures_collected'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['event_old_pictures_collected'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['event_old_pictures_collected'];
								
								
								$config['upload_path'] = $this->old_pictures_collected_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,2,5,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['event_pictures']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['event_pictures'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['event_pictures'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['event_pictures'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['event_pictures'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['event_pictures'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,2,4,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['site_audios']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['site_audios'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['site_audios'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['site_audios'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['site_audios'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['site_audios'];
								
								
								$config['upload_path'] = $this->audio_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,3,1,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['site_videos']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['site_videos'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['site_videos'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['site_videos'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['site_videos'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['site_videos'];
								
								
								$config['upload_path'] = $this->video_path;
								$config['allowed_types'] = '*';
								$config['max_size']	= '20000000';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,3,2,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['site_old_pictures_collected']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['site_old_pictures_collected'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['site_old_pictures_collected'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['site_old_pictures_collected'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['site_old_pictures_collected'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['site_old_pictures_collected'];
								
								
								$config['upload_path'] = $this->old_pictures_collected_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,3,5,$_FILES['userfile']['name']);
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									 /* if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   $data['upload_errors'][$i] = $this->upload->display_errors();
									 } */ 
								}  
							}
							
							if($_FILES['media-group']['name'][$i]['site_pictures']!=''){	
							
								$_FILES['userfile']['name']=$_FILES['media-group']['name'][$i]['site_pictures'];
								$_FILES['userfile']['type']    = $_FILES['media-group']['type'][$i]['site_pictures'];
								$_FILES['userfile']['tmp_name'] = $_FILES['media-group']['tmp_name'][$i]['site_pictures'];
								$_FILES['userfile']['error']       = $_FILES['media-group']['error'][$i]['site_pictures'];
								$_FILES['userfile']['size']    = $_FILES['media-group']['size'][$i]['site_pictures'];
								
								
								$config['upload_path'] = $this->gallery_path;
								$config['allowed_types'] = 'jpeg|gif|jpg|png';
								$config['max_size']	= '5120';
								$config['max_width']  = '0';
								$config['max_height']  = '0';
								$config['overwrite'] = true;	
								if($_FILES['userfile']['error']!='4'){
									  if($_FILES['userfile']['name']!=''){
										$this->Survey_model->survey_attribute_collection($survey_id,3,4,$_FILES['userfile']['name']);	
									  }
									  $config['file_name'] =$survey_id.'_'.$_FILES['userfile']['name'];
									  $this->upload->initialize($config);
									  
									  $this->upload->do_upload('userfile');
									  
									  if ($this->upload->do_upload('userfile'))
									 {
									   $data['uploads'][$i] = $this->upload->data();
									 }
									 else
									 {
									   echo $data['upload_errors'][$i] = $this->upload->display_errors();
									   die;
									 } 
								}  
							}
							
						}
						
				}			
			  if($result=='1')
				{   
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
				else
				{ 
				   $msg=  $this->lang->line('error_text_message');
				   $this->session->set_flashdata('error_message', $msg);
				}
				redirect(base_url() . "employees/survey/view/".$survey_id);
				
			} 
	
		  $result =  $this->Survey_model->survey_edit($survey_id);
		  $data['edit_data'] = $result;
		  
		  $this->load->view('employees/survey/edit.php', $data);
		 
	}//end of Edit functionality*/	
	
	public function view_record($survey_id){
		
		  $data['title'] = title." ".$this->lang->line('edit_survey_title')."";
		  $data['main_heading'] = $this->lang->line('surveys_title');
		  $data['heading'] = $this->lang->line('edit_survey_title');
		  $data['already_msg'] = "";
		 
		  $result =  $this->Survey_model->survey_view($survey_id);
		  $data['view_data'] = $result;
		  
		  $this->load->view('employees/survey/view_record', $data);
		 
	}//end of Edit functionality*/	
}	
?>