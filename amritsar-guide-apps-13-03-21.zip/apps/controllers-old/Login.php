<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {	 
	 
	public function index()
	{
		//phpinfo();die;
		$data['title'] = title." | Login";
		$data['heading'] = title." | Login";
		$data['msg'] = "";
		$url='';
		
		if($this->session->userdata('user_id'))
		{
			
			$url = $this->input->post("url");
			if($this->session->userdata('user_type')=='A')
			 {   
				   if($url !=''){
					  redirect($url);  
				   }else{
			          redirect(base_url() . 'backoffice/dashboard');
				   }
		     }
			else if($this->session->userdata('user_type')=='D')
			 {   
				   if($url !=''){
					  redirect($url);  
				   }else{
			          redirect(base_url() . 'departments/dashboard');
				   }
		     }
		}
		//Validate the credentials
		
		$this->load->library('encrypt');
	
		$this->load->model('Login_model');
		//time_zone();
        $this->form_validation->set_rules('username', 'Username','trim|required');
        $this->form_validation->set_rules('password', 'Password','trim|required');
	
		if($this->form_validation->run())
        {	//Fetch the inputs provided by the user
			$username = $this->input->post("username");
			$password = $this->input->post("password");
			//Login Model use to check user exists or not
			$result=$this->Login_model->login($username, $password);	
				//print $result;die;
			if($result=='0')
			$data['msg'] = $this->lang->line('login_invalid_message');
			elseif($result=='1')
			$data['msg'] = $this->lang->line('login_deactivated_message');//"Your login is turned off. Please visit later.";
			elseif($result=='2')
			$data['msg'] = $this->lang->line('login_expired_message');
			else{	
				
			   if($this->session->userdata('user_type')=='A'){
				   if($url !=''){
					  redirect($url);  
				   }else{
			        redirect(base_url() . 'backoffice/dashboard');
				   }
			   }
			   elseif($this->session->userdata('user_type')=='D'){
				   if($url !=''){
					  redirect($url);  
				   }else{
			        redirect(base_url() . 'departments/dashboard');
				   }
			   }
			   else if( $this->session->userdata('user_type')=='E'){
				   $get_user_role = get_user_role($this->session->userdata('user_id'));

				   $mobile=$this->agent->is_mobile();
				   if($mobile && $get_user_role->role_id=='3'){
					   redirect(base_url() . 'employees/slocations/view');
					  
				   }
				   else if($url !=''){
					  redirect($url);  
				   }else{
			        redirect(base_url() . 'backoffice/dashboard');
				   }
			   }
			   else if( $this->session->userdata('user_type')=='L'){
				   if($url !=''){
					  redirect($url);  
				   }else{
			        
				   }
			   }
				 elseif($this->session->userdata('user_type')=='U')
				 {
					if($url !=''){
					  redirect($url);  
					 }else{
					 echo "<script type=\"text/javascript\">
					 localStorage.clear();
					 window.location.href ='".base_url()."users/dashboard';
					 </script>";
					 }
				 }
			  }
			}
			
		   $this->load->view('login.php', $data);		 
	}
	public function normal_login()
	{
		$data = array();
		$data['error_msg']='';
		$data['email_mobile']=$this->session->userdata('email_mobile');
		
		$this->form_validation->set_rules('password', 'Password', 'required',
			array('required' => 'You must provide a %s.')
		);
		if ($this->form_validation->run()) {
			$result =  $this->Login_model->normal_login();
			if($result=='0')
			   $msg = "There is some error.";
			 else  
			  redirect(base_url().'login/confirm'); 
			 
			  $this->session->set_flashdata('success_message', $msg);
			   
		} else{		
			$data['error_msg'] = validation_errors();
		}
		
		$this->load->view('normal_login',$data);
	}
	public function confirm()
	{
		$data = array();
		$data['otp']=0;
		$data['error_msg']='';
		$data['email_mobile']=$this->session->userdata('email_mobile');
		$rules = array(array('field' => 'otp', 'label' => 'OTP', 'rules' => 'trim|required'));
		
		if($this->input->post("otp")!=''){
			   if($this->input->post("otp")==$this->session->userdata('user_details')->unique_code){
				  $data['otp']=1;
				  //redirect(base_url().'login/confirm');
			   } else {
				  $data['error_msg'] = ' Invalid OTP';
			   }
	    } else if($this->input->post("newpassword")!='' || $this->input->post("confirmpass")!=''){
				$data['otp']=1;
			    $this->form_validation->set_rules('newpassword', 'Password', 'required',
					array('required' => 'You must provide a %s.')
			    );
				$this->form_validation->set_rules('confirmpass', 'Confirm Password', 'required|matches[newpassword]');
				if ($this->form_validation->run()) {
					$result =  $this->Login_model->update_password();
					if($result=='0')
					   $msg = "There is some error.";
					 else  
					  $msg = "Password has been set successfully.";
					 
					  $this->session->set_flashdata('success_message', $msg);
					  redirect(base_url().'login/confirm');  
				} else{		
					$data['error_msg'] = validation_errors();
				}
	    } 
		$this->load->view('login_confirm',$data);
	}
}