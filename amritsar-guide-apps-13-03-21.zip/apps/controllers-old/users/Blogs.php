<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Blogs extends CI_Controller {
	
	function __construct()
	{
    	parent :: __construct();
		//is_valid_login('ad');
		validateAccess();
	    $this->load->model('users/Blog_model');
		$this->load->library('upload');
		$this->load->library('image_lib');
		$this->image_path = realpath('images/blogs/');
	}
	public function visibilitystatus($blog_id,$status)
	{	 // Update status  
	     $result = $this->Blog_model->update_visibilitystatus($blog_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', 'Visibility Status has been changed.');
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', "There is some error, please try again");
		 }
		 redirect(base_url() . "users/blogs");		
		 
	}//end of Status  functionality*/
	
	public function approvalstatus($blog_id,$status)
	{	 // Update status  
	     $result = $this->Blog_model->update_approvalstatus($blog_id,$status);
		 if($result=='1')
		 {
		   $this->session->set_flashdata('success_message', 'Record has been sent for approval');
		 }
		 else
		 {
			 $this->session->set_flashdata('warning_message', "There is some error, please try again");
		 }
		 redirect(base_url() . "users/blogs");		
		 
	}//end of Status  functionality*/
	
	
	public function index(){
	    $data['title'] = "Blogs";
		$data['main_heading'] ="View All Blogs";
		$data['heading'] = "Blogs";
		$data['already_msg']=""; 
		
		if($this->input->post('category_id'))
			 $category_id = $this->input->post('category_id');
		 elseif($this->uri->segment('4'))
			 $category_id=$this->uri->segment('4');
		 else
			 $category_id='0';
			 
			 	 
		
	    if($this->input->post('title'))
			$title = $this->input->post('title');
		 elseif($this->uri->segment('5'))
			$title=$this->uri->segment('5');
		 else
			$title='';
		
		
		/********Get Blogs Records********/	
		$per_page=per_page;	
		$config = array();
		$config["base_url"] = base_url() . "users/blogs/index/".$category_id."/".$title."/".$per_page;
		$config["per_page"] = $per_page;
        $config["uri_segment"] = 7;
		
        $page = ($this->uri->segment(6)) ? $this->uri->segment(6) : 0;  
		$data['results'] = $this->Blog_model->viewBlogs($category_id,$title,$config['per_page'], $page);
		$config["total_rows"] =$this->Blog_model->countblogrecords();
		$this->pagination->initialize($config);
		
		$data['links']   = $this->pagination->create_links();
		
		
		$data['num_rows'] = $config["total_rows"];
	    $this->load->view('users/blogs/view',$data);	
	}//End of Index
	
	public function add($blog_id=NULL){
		$this->add_edit_blogs($blog_id);	
	}
	
	public function edit($blog_id=NULL){
		$this->add_edit_blogs($blog_id);	
	}
	public function add_edit_blogs($blog_id=NULL){
		  if($blog_id==0){
				 $data['heading'] = "Add Blog";
			  } elseif($blog_id!=0){
				 $data['heading'] = "Edit Blog";
			  }  
		 
		  $data['already_msg']    = "";
		  $data['error_msg']    = "";
		  $error_msg = '';
		  /*******Variable declarations*********/
		  $category_id = '';
		  $title = '';
		  $description = '';
		  $vide_ = '';
		  $video_url = '';
		  $visibility = '';
		 
		 
		  $blog_id = ($blog_id!='') ? $blog_id : 0;
		  $this->Blog_model->blog_id   = $blog_id;
		  $categorytype_records_array = array();
	      if($blog_id!='0'){
	   		$categorytype_records_array = $this->Blog_model->editBlogData(); 
				
			/*******Assign fetched record to variables to set value of input box******/
			$category_id	= $categorytype_records_array->category_id;
			$title	= $categorytype_records_array->title;
			$description	= $categorytype_records_array->description;
			$video_url	= $categorytype_records_array->video_url;
			$visibility = $categorytype_records_array->visibility;
			
	      }
		 
		 if($this->input->post()){
			
			$category_id = isset($_POST['category_id'])? $_POST['category_id']: '';
			$title = isset($_POST['title'])? $_POST['title']: '';
			$description = isset($_POST['description'])? $_POST['description']: '';
			
			$video_url = isset($_POST['video_url'])? $_POST['video_url']: '';
			$visibility = isset($_POST['visibility'])? $_POST['visibility']: '';
			
			
			
			 /********Check validations************/
			  if($blog_id==0){
				$this->form_validation->set_rules('title','Title', 'required|is_unique[blogs.title]');
				$this->form_validation->set_rules('description','Description', 'required');
				$this->form_validation->set_rules('visibility','Visibility', 'required');
			  } elseif($blog_id!=0){
				$this->form_validation->set_rules('title','Title', 'required');
				$this->form_validation->set_rules('description','Description', 'required');
				$this->form_validation->set_rules('visibility','Visibility', 'required');
			  }  
			  
			/********After validation*********/
			if($error_msg==''){
				if ($this->form_validation->run()) { 
			
				/*****Assign posted value to model's variable******/
				$this->Blog_model->category_id = $category_id;
				$this->Blog_model->title = $title;
				$this->Blog_model->description = $description;
				$this->Blog_model->video_url = $video_url;
				$this->Blog_model->visibility = $visibility;
				
				
				
				
				if($blog_id==0)
					$blog_id = $this->Blog_model->addBlog();
				else
					$blog_id = $this->Blog_model->editBlog();
				
				
				if($_FILES['featured_image']){	
					$config['upload_path'] = $this->image_path;
					$config['allowed_types'] = 'jpeg|gif|jpg|png';
					$config['max_size']	= max_file_size;
					//$config['max_width']  = '0';
					//$config['max_height']  = '0';
					$config['overwrite'] = true;	
					if($_FILES['featured_image']['error']!='4'){
						  if($_FILES['featured_image']['name']!=''){
							$image_id = $this->Blog_model->add_icon($blog_id,$_FILES['featured_image']['name']);	
						  }
						  $config['file_name'] =time().'_'.$blog_id.'_'.$_FILES['featured_image']['name'];
						  $this->upload->initialize($config);
						  $this->upload->do_upload('featured_image');
					}  
				}
			
			    if($blog_id=='0'){
				   $msg = $this->lang->line('success_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				} else {
				   $msg = $this->lang->line('update_text_message');
				   $this->session->set_flashdata('success_message', $msg);
				}
			
			      redirect(base_url() . 'users/Blogs');
				} 
				else {
					$data['error_msg'] = validation_errors();
				}
			}
			else
				$data['error_msg'] = $error_msg;
		}
		
		  $data['blog_id']= $blog_id;		
		  $data['category_id']= $category_id;		
		  $data['title']=$title;
		  $data['visibility']=$visibility;
		  $data['description']=$description;
		  $data['video_url']=$video_url;
		 
		  
		  
	   $this->load->view('users/blogs/add_edit_blogs',$data);	
	}
}
