<?php

class Kiosks_model extends CI_Model
{	

       function add_category()
		{   
			$fields = array('language_id'=>$this->session->userdata('lang_id'),'is_active'=>'1');
			$weightmax = get_max_values('kiosk_categories','weight',$fields);
			$data  = array(
				'language_id' => $this->session->userdata('lang_id'),
				'category_name'     => $this->input->post("category_name"),
				'description'     => $this->input->post("description"),
				'weight'   => $weightmax,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$result   = $this->db->insert('kiosk_categories', $data);
			$kiosk_category_id  = $this->db->insert_id();
			if($result > 0)
			{
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "kiosk_categories";
				$operation = "Record added";
				createLogFile($operation,$kiosk_category_id,$update_by_id,$table_name);
			 }
			 if($result){
				return $kiosk_category_id;
			 }
			else
				return 0;
	
		} //End of add function
	
		
		 function category_edit($kiosk_category_id)
		 {
			if ($kiosk_category_id == '') {
				redirect(base_url() . "backoffice/kiosks/view_category");
			}
			$this->db->select('*');
			$this->db->from('kiosk_categories');
			$this->db->where('kiosk_category_id', $kiosk_category_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_category($kiosk_category_id)
		 {
			$data = array(
			    'language_id' => $this->session->userdata('lang_id'),
			    'category_name'     => $this->input->post("category_name"),
				'description'     => $this->input->post("description"),
				'weight'   => $weightmax
			);
			$this->db->where('kiosk_category_id', $kiosk_category_id);
			$result = $this->db->update('kiosk_categories', $data);
			if($result > 0)
   		    {	$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "kiosk_categories";
				$operation = "Record updated";
				createLogFile($operation,$kiosk_category_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
		 

       function view_category($category_name,$status,$limit, $start)
       {
		$this->db->select('*');
		if($category_name!='0')
		$this->db->like('category_name', $category_name);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('category_name','ASC');
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('kiosk_categories');
        $query = $this->db->get();
	//  echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

     } //End of View  function
	
	  function count_category($category_name,$status) {
		if($category_name!='0')
		$this->db->like('category_name', $category_name);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('kiosk_categories');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
	

      function view_kiosks($kiosk_id,$status,$limit, $start)
     {
		$this->db->select('*');
		if($kiosk_id!='0')
		$this->db->like('kiosk_id', $kiosk_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('kiosk_name','ASC');
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('kiosks');
        $query = $this->db->get();
	//  echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	  function count_kiosks($kiosk_id,$status) {
		
		if($kiosk_id!='0')
		$this->db->like('kiosk_id', $kiosk_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('kiosks');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
		function add()
		{   
			$fields = array('language_id'=>$this->session->userdata('lang_id'),'is_active'=>'1');
			$weightmax = get_max_values('kiosks','weight',$fields);
			$data  = array(
				'language_id' => $this->session->userdata('lang_id'),
				'kiosk_category_id'     => $this->input->post("kiosk_category_id"),
				'kiosk_name'     => $this->input->post("kiosk_name"),
				'kiosk_type_id'     => $this->input->post("kiosk_type_id"),
				'mac_id'     => $this->input->post("mac_id"),
				'unique_id'     => $this->input->post("unique_id"),
				'latitude'     => $this->input->post("latitude"),
				'longitude'     => $this->input->post("longitude"),
				'address'     => $this->input->post("address"),
				'description'   => $this->input->post("description"),
				'weight'   => $weightmax,
				'created_by'      => $this->session->userdata('user_id'),
				'created_on'      => date('Y-m-d H:i:s')
			);
			$result   = $this->db->insert('kiosks', $data);
			$kiosk_id  = $this->db->insert_id();
			if($result > 0)
			{
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "kiosks";
				$operation = "Record added";
				createLogFile($operation,$kiosk_id,$update_by_id,$table_name);
			 }
			 if($result){
				return $kiosk_id;
			 }
			else
				return 0;
	
	
		} //End of add function
	

	
		 function kiosk_edit($kiosk_id)
		 {
			if ($kiosk_id == '') {
				redirect(base_url() . "backoffice/kiosks/view");
			}
			$this->db->select('*');
			$this->db->from('kiosks');
			$this->db->where('kiosk_id', $kiosk_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_kiosk($kiosk_id)
		 {
			$data = array(
			   'language_id' => $this->session->userdata('lang_id'),
			   'kiosk_category_id'     => $this->input->post("kiosk_category_id"),
				'kiosk_name'     => $this->input->post("kiosk_name"),
				'kiosk_type_id'     => $this->input->post("kiosk_type_id"),
				'mac_id'     => $this->input->post("mac_id"),
				'unique_id'     => $this->input->post("unique_id"),
				'latitude'     => $this->input->post("latitude"),
				'longitude'     => $this->input->post("longitude"),
				'address'     => $this->input->post("address"),
				'description'   => $this->input->post("description"),
				'weight'   => $weightmax,
				'modified_by'      => $this->session->userdata('user_id'),
			);
			$this->db->where('kiosk_id', $kiosk_id);
			$result = $this->db->update('kiosks', $data);
			if($result > 0)
   		    {	$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "kiosks";
				$operation = "Record updated";
				createLogFile($operation,$kiosk_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
    function update_status($kiosk_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('kiosk_id', $kiosk_id);
	    $result = $this->db->update('kiosks', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function
	
	
	function update_category_status($kiosk_category_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('kiosk_category_id', $kiosk_category_id);
	    $result = $this->db->update('kiosk_categories', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function


}