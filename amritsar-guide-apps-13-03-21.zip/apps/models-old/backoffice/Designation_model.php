<?php

class Designation_model extends CI_Model
{
	
	function view_designation()
	{
		$this->db->select('*');
		$this->db->from('designation');
		$this->db->order_by('designation_id', 'DESC');
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->result();
		return $results;
	} //End of View function
		
		
	function fetchdesignation($designation_id)
	{
		$this->db->select('*');
		$this->db->from('designation');
		$this->db->order_by('designation_id', 'DESC');
		$this->db->where('designation_id',$designation_id);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->row();
		return $results;
	} //End of View function		
	
	   
	 function add()
     {
         $data        = array(
		    'designation_name'   => $this->input->post("designation_name"), 
		    'is_active'=>'1'
		  );
        $result   = $this->db->insert('designation', $data);
		$designation_id  = $this->db->insert_id();
		 if($result)
			return $designation_id;
		else
			return 0;


    } //End of add function
	

	
	
	 function update_designation($designation_id)
	 {
		 $data        = array(
		    'designation_name'   => $this->input->post("designation_name"), 
		 );
		
		
		$this->db->where('designation_id', $designation_id);
		$result = $this->db->update('designation', $data);
		if ($result)
		   return 1;
		 else
		   return 0;
		
	 } //End of Update function

	function update_status($designation_id, $status)
    {
		 $data = array(
				'is_active' => $status
		 );
		
		
        $this->db->where('designation_id', $designation_id);
        $result = $this->db->update('designation', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
}