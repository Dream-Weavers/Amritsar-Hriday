<?php

class Project_model extends CI_Model
{
	
	function view_projects()
	{
		$this->db->select('projects.*,country.country_name,locality.locality_name,city.city_name,state.state_name');
		$this->db->from('projects');
		$this->db->join('country','projects.country_id=country.country_id','left');
		$this->db->join('state','projects.state_id=state.state_id','left');
		$this->db->join('city','projects.city_id=city.city_id','left');
		$this->db->join('locality','projects.locality_id=locality.locality_id','left');
		$this->db->order_by('projects.project_id', 'DESC');
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->result();
		return $results;
	} //End of View function
		
	function add_icon($project_id,$filename)
	{			
		$data     = array(
			'icon'     => $project_id.'_'.$filename
		);
		
		$this->db->where('project_id', $project_id);
		$result = $this->db->update('projects', $data);
	}
		
	function fetchproject($projectid)
	{
		$this->db->select('*');
		$this->db->from('projects');
		$this->db->order_by('project_id', 'DESC');
		$this->db->where('project_id',$projectid);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->row();
		return $results;
	} //End of View function		
	
	   
	 function add()
     {
         $data        = array(
		    'project_name'   => $this->input->post("project_name"), 
		    'description'     => $this->input->post("description"), 
		    'country_id'     => $this->input->post("country_id"), 
		    //'country_lock'     => $this->input->post("country_lock"), 
		    'state_id'     => $this->input->post("state_id"), 
		    //'state_lock'     => md5($this->input->post("state_lock")), 
		    'city_id'     => $this->input->post("city_id"), 
		    'city_lock'     => $this->input->post("city_lock"), 
			'locality_id'     => $this->input->post("locality_id"), 
			'created_date'      => date('Y-m-d H:i:s')
			 
        );
        $result   = $this->db->insert('projects', $data);
		$project_id  = $this->db->insert_id();
		 if($result)
			return $project_id;
		else
			return 0;


    } //End of add function
	

	
	
	 function update_project($project_id)
	 {
		 $data        = array(
		    'project_name'   => $this->input->post("project_name"), 
		    'description'     => $this->input->post("description"), 
		    'country_id'     => $this->input->post("country_id"), 
		    //'country_lock'     => $this->input->post("country_lock"), 
		    'state_id'     => $this->input->post("state_id"), 
		    //'state_lock'     => md5($this->input->post("state_lock")), 
		    'city_id'     => $this->input->post("city_id"), 
		    'city_lock'     => $this->input->post("city_lock"), 
			'locality_id'     => $this->input->post("locality_id")
		 );
		
		
		$this->db->where('project_id', $project_id);
		$result = $this->db->update('projects', $data);
		if ($result)
		   return 1;
		 else
		   return 0;
		
	 } //End of Update function
		 
    function update_status($project_id, $status_id)
    {
		 	$data = array(
				'project_status' => $status_id,
			);
        $this->db->where('project_id', $project_id);
        $result = $this->db->update('projects', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
}