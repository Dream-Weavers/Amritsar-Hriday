<?php



class Quiz_model extends CI_Model

{	

	function add()

	{   	

		 

		 $quiz_number = $this->get_quiz_num(); 

		

		

         $data        = array(

			'name'     => $this->input->post("customer_name"),

			'gender'   => $this->input->post("gender"),

			'age'     => $this->input->post("age"),

			'address'     => $this->input->post("address"),

			'area'     => $this->input->post("area"),

			'city'     => $this->input->post("city"),

			'staying_amritsar_before_independence'     => $this->input->post("staying_amritsar_before_independence"),

			'staying_amritsar_after_independence'     => $this->input->post("staying_amritsar_after_independence"),

			'years_staying_in_amritsar_after_independence'     => $this->input->post("years_staying_in_amritsar_after_independence"),

			'know_place_not_exists_now'     => $this->input->post("know_place_not_exists_now"),

			'place_exact_location'     => $this->input->post("place_exact_location"),

			'place_longitude'     => $this->input->post("place_longitude"),

			'place_latitude'     => $this->input->post("place_latitude"),

			'place_remarks'     => $this->input->post("place_remarks"),

			'event_not_exists_now'     => $this->input->post("event_not_exists_now"),

			'event_exact_location'     => $this->input->post("event_exact_location"),

			'event_longitude'     => $this->input->post("event_longitude"),

			'event_latitude'     => $this->input->post("event_latitude"),

			'event_remarks'     => $this->input->post("event_remarks"),

			'site_alteration'     => $this->input->post("site_alteration"),

			'site_exact_location'     => $this->input->post("site_exact_location"),

			'site_latitude'     => $this->input->post("site_latitude"),

			'site_longitude'     => $this->input->post("site_longitude"),

			'site_remarks'     => $this->input->post("site_remarks"),

			'remarks'     => $this->input->post("remarks"),

			'quiz_number'     => $quiz_number,

			'quiz_date'     => $this->input->post("quiz_date"),

			'user_id'     => $this->session->userdata('user_id'),

			'created_date'      => date('Y-m-d H:i:s')

        );

        $result   = $this->db->insert('question_bank', $data);

		$quiz_id  = $this->db->insert_id();

		

		 if($result){

			return $quiz_id;

		 }

		 else

			return 0;





    } //End of add function

	function fetch_quiz_type_settings($type_id)

    { 

		$this->db->select('*');

		$this->db->where('type_id', $type_id);

        $this->db->from('question_bank_types');

        $query = $this->db->get();

	    $result = $query->row();

	   //echo "--->".$this->db->last_query();

		//echo "<br><br>";

		/*echo "<pre>";

		print_r($result);

		echo "</pre>";*/

       

        return $result;



    } //End of View  function

	

	function question_bank($data) { 

			$this->db->insert('question_bank', $data);

	 }

	 function update_question_bank($data) { 

	
			$this->db->where('question_id', $data['question_id']);	

			$this->db->update('question_bank', $data);

		

	 }

	 function deletequestion($question_id) {

		

	   $this->db->where('question_id',$question_id);

	    $result = $this->db->delete('question_bank');

		if($result){ 

			return '1';

	    }

	  	else{

		      return '0';

		}

		

	}

	

	 function viewquestions($location_id)

     	{

			$this->db->select('*');

			$this->db->from('question_bank');

			$this->db->where('location_id', $location_id);

			$this->db->order_by('question_id', 'ASC');

			$query = $this->db->get();

			$results = $query->result();

			//echo $this->db->last_query();

			return $results;



	   } //End of View function

	 function fetch_quiz($quiz_id)

     	{

			$this->db->select('*');

			$this->db->from('question_bank_settings');

			$this->db->where('question_bank_setting_id', $quiz_id);

			$this->db->order_by('question_bank_setting_id', 'ASC');

			$query = $this->db->get();

			$result = $query->row();

			//echo $this->db->last_query();

			return $result;



	   } //End of View function
	   
	   function fetch_quiz_questions($quiz_id)

     	{

			$this->db->select('*');

			$this->db->from('question_bank');

			$this->db->where('quiz_id', $quiz_id);

			$this->db->order_by('question_id', 'ASC');

			$query = $this->db->get();

			$result = $query->result();

			//echo $this->db->last_query();

			return $result;



	   } //End of View function
	   
	   
	   function fetch_quiz_settings($quiz_id)

     	{

			$this->db->select('*');

			$this->db->from('question_bank_settings');

			$this->db->where('question_bank_setting_id', $quiz_id);

			$this->db->order_by('question_bank_setting_id', 'ASC');

			$query = $this->db->get();

			$result = $query->row();

			//echo $this->db->last_query();

			return $result;



	   } //End of View function
	   

	function add_quiz_settings()

 	{

		  $types_assigned='';

		  
		if($this->input->post("quiz_mode")==''){
			$quiz_mode=$this->session->userdata('quiz_mode');
		} else {
			$quiz_mode=$this->input->post("quiz_mode");
			
		}
		  

		  if($this->input->post("manual_type_status")==1){

			  $types_assigned .="1,";

		  }

		  if($this->input->post("automatic_type_status")==1){

			  $types_assigned .="2,";

		  }

		  if($this->input->post("rapid_type_status")==1){

			  $types_assigned .="3,";

		  }



		  $types=trim($types_assigned,",");



		  $data =array( 

				'location_id' => $this->input->post("location_id"),

				'language_id' => $this->session->userdata('lang_id'),

				'quiz_name' => $this->input->post("quiz_name"),

				'quiz_mode' => $quiz_mode,

				'theme_assigned' => $this->input->post("quiz_theme"),

				'quiz_status' => $this->input->post("quiz_status"),

				'audio_status' => $this->input->post("audio_status"),

				'types_assigned' => $types,

				'created_on'  => date('Y-m-d H:i:s')

		  );

		  $this->db->insert('question_bank_settings', $data);

		  return $quiz_id  = $this->db->insert_id();



	}

	function manage_quiz_settings($quiz_id)

 	{

		  $types_assigned='';

		  

		  if($this->input->post("manual_type_status")==1){

			  $types_assigned .="1,";

		  }

		  if($this->input->post("automatic_type_status")==1){

			  $types_assigned .="2,";

		  }

		  if($this->input->post("rapid_type_status")==1){

			  $types_assigned .="3,";

		  }



		  $types=trim($types_assigned,",");



		  $data =array( 

				'location_id' => $this->input->post("location_id"),

				'quiz_name' => $this->input->post("quiz_name"),

				'theme_assigned' => $this->input->post("quiz_theme"),

				'quiz_status' => $this->input->post("quiz_status"),

				'audio_status' => $this->input->post("audio_status"),

				'types_assigned' => $types

		  );

		  $this->db->where('question_bank_setting_id', $quiz_id);
		  $this->db->update('question_bank_settings', $data);



	}
	
	
	function update_quiz_type_settings()

 	{

		

		  for($i=1;$i<=3;$i++){

			 if($i==1){

				 $data =array( 

					'sort_by' => $this->input->post("m_sort_by"),

					'compulsory_status' => $this->input->post("m_quiz_que_compulsory"),

					'back_button_status' => $this->input->post("m_back_button_status"),

					'next_button_status' => $this->input->post("m_next_button_status"),

					'edit_options_status' => $this->input->post("m_edit_option_status")

				  ); 

			 } else if($i==2){

				 $data =array( 

					'display_time' => $this->input->post("a_display_time"),

					'sort_by' => $this->input->post("a_sort_by"),

					'compulsory_status' => $this->input->post("a_quiz_que_compulsory"),

					'back_button_status' => $this->input->post("a_back_button_status"),

					'next_button_status' => $this->input->post("a_next_button_status"),

					'edit_options_status' => $this->input->post("a_edit_option_status")

				  ); 

			 } else if($i==3){

				  $data =array( 

					'display_time' => $this->input->post("r_display_time"),

					'sort_by' => $this->input->post("r_sort_by")

				  ); 

			 }

			 

			  $this->db->where('type_id', $i);	

			  $this->db->update('question_bank_types', $data);

		  }



	}

	function quiz_attribute_collection($quiz_id, $source_type, $media_type, $filename)

    {	

		$filename = str_replace(" ","_",$filename);

		$data        = array(

			'source'     => $quiz_id.'_'.$filename,

			'quiz_id'  => $quiz_id,

			'source_type'     	=> $source_type,

			'media_type'     	=> $media_type

        );

        $this->db->insert('quiz_attribute_collection', $data);

    }

	

	function fetch_quiz_attribute_collection($quiz_id)

    {	

	

		$this->db->select('*');

		$this->db->where('quiz_id', $quiz_id);

		$query=$this->db->get('quiz_attribute_collection');

		$result = $query->result(); 

		$allrecords=array();

		$record_ids=array();

		foreach($result as $val){

			$allrecords[$val->source_type][$val->media_type][]=$val->source."||".$val->quiz_gal_id;

		}

		return $allrecords;

	/* 	echo "<pre>";

		print_r($allrecords);

		die; */

    }

	

	function view_quiz($location_id,$quiz_name,$status)	{		
	
		$this->db->select('question_bank_settings.*, locations.location_name');	
		$this->db->join('locations','question_bank_settings.location_id=locations.location_id');				
		if($location_id!='0')	
		$this->db->where('question_bank_settings.location_id', $location_id);	
		if($quiz_name!='')		
		$this->db->where("question_bank_settings.quiz_name LIKE '%$quiz_name%'");	
		if($status!='0')	
		{
			if($status == 'a')	
			{	
				$status = '1';		
			}	else	{	
				$status = '0';
			}			
			$this->db->where('question_bank_settings.quiz_status',$status);		
		}		
		$this->db->where('question_bank_settings.language_id',$this->session->userdata('lang_id'));
		$this->db->from('question_bank_settings');	
		$this->db->order_by('question_bank_settings.question_bank_setting_id', 'DESC');	
		$query = $this->db->get();
		$results = $query->result();
		return $results;	
	} //End of View function */	
	
	function viewquiz()	{	
		$this->db->select('question_bank_settings.*, locations.location_name');	
		$this->db->join('locations','question_bank_settings.location_id=locations.location_id');
		$this->db->from('question_bank_settings');		
		$this->db->where('question_bank_settings.language_id',$this->session->userdata('lang_id'));		
		$this->db->order_by('question_bank_settings.question_bank_setting_id', 'DESC');	
		$query = $this->db->get();			
		$results = $query->result();	
		return $results;	
	} //End of View function

    function update_status($quiz_id, $status)

    {

	     $data = array(

				'quiz_status' => $status,

		);


        $this->db->where('question_bank_setting_id', $quiz_id);

        $result = $this->db->update('question_bank_settings', $data);

		if($result)

		  return '1';

		 else 

		 return '0';



    } //End of Update status function
	
	
	function update_quiz($quiz_id)

	 {

		

		$data        = array(

			'name'     => $this->input->post("customer_name"),

			'gender'   => $this->input->post("gender"),

			'age'     => $this->input->post("age"),

			'address'     => $this->input->post("address"),

			'city'     => $this->input->post("city"),

			'area'     => $this->input->post("area"),

			'staying_amritsar_before_independence'     => $this->input->post("staying_amritsar_before_independence"),

			'staying_amritsar_after_independence'     => $this->input->post("staying_amritsar_after_independence"),

			'years_staying_in_amritsar_after_independence'     => $this->input->post("years_staying_in_amritsar_after_independence"),

			'know_place_not_exists_now'     => $this->input->post("know_place_not_exists_now"),

			'place_exact_location'     => $this->input->post("place_exact_location"),

			'place_longitude'     => $this->input->post("place_longitude"),

			'place_latitude'     => $this->input->post("place_latitude"),

			'place_remarks'     => $this->input->post("place_remarks"),

			'event_not_exists_now'     => $this->input->post("event_not_exists_now"),

			'event_exact_location'     => $this->input->post("event_exact_location"),

			'event_longitude'     => $this->input->post("event_longitude"),

			'event_latitude'     => $this->input->post("event_latitude"),

			'event_remarks'     => $this->input->post("event_remarks"),

			'site_alteration'     => $this->input->post("site_alteration"),

			'site_exact_location'     => $this->input->post("site_exact_location"),

			'site_latitude'     => $this->input->post("site_latitude"),

			'site_longitude'     => $this->input->post("site_longitude"),

			'site_remarks'     => $this->input->post("site_remarks"),

			'remarks'     => $this->input->post("remarks"),

			'quiz_number'     => $quiz_number,

			'quiz_date'     => $this->input->post("quiz_date")

        );



		$this->db->where('quiz_id', $quiz_id);

		$result = $this->db->update('quiz', $data);

		/* if($result > 0)

		{

			if($this->input->post("country_id")!='')

			 {

				$quiz_id = $this->updateUserAddress($quiz_id,$quiz_id);

			 }

			 

			 if($this->input->post("role_id")!='')

			 {

				 $roleResult = $this->UpdateUserRole($quiz_id);

			 }

			$update_by[] = array('uid' => $this->session->userdata('quiz_id'), 'dt' => date('Y-m-d H:i:s'));

			$update_by_id = json_encode($update_by);

			$table_name = "users";

			$operation = "Record updated";

			createLogFile($operation,$quiz_id,$update_by_id,$table_name);

		} */

		if ($result)

		   return 1;

		 else

		   return 0;

		

	 } //End of Update function

	function quiz_edit($quiz_id)

	 {



		if ($quiz_id == '') {

			redirect(base_url() . "backoffice/quiz/view");

		}

		$this->db->select('*');

		$this->db->from('quiz');

		$this->db->where('quiz_id', $quiz_id);

		$query = $this->db->get();



		return $query->row();



	} //End of edit function

	

	function quiz_view($quiz_id)

	 {



		if ($quiz_id == '') {

			redirect(base_url() . "backoffice/quiz/view");

		}

		$this->db->select('*');

		$this->db->from('quiz');

		$this->db->where('quiz_id', $quiz_id);

		$query = $this->db->get();



		return $query->row();



	} //End of edit function

}