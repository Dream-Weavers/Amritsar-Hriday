<?php

class Department_model extends CI_Model
{
	
	function view_department()
	{
		$this->db->select('*');
		$this->db->from('department');
		$this->db->order_by('department_id', 'DESC');
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->result();
		return $results;
	} //End of View function
		
		
	function fetchdepartment($department_id)
	{
		$this->db->select('*');
		$this->db->from('department');
		$this->db->order_by('department_id', 'DESC');
		$this->db->where('department_id',$department_id);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->row();
		return $results;
	} //End of View function		
	
	   
	 function add()
     {
         $data        = array(
		    'department_name'   => $this->input->post("department_name"), 
		    'is_active'=>'1'
		  );
        $result   = $this->db->insert('department', $data);
		$department_id  = $this->db->insert_id();
		 if($result)
			return $department_id;
		else
			return 0;


    } //End of add function
	

	
	
	 function update_department($department_id)
	 {
		 $data        = array(
		    'department_name'   => $this->input->post("department_name"), 
		 );
		
		
		$this->db->where('department_id', $department_id);
		$result = $this->db->update('department', $data);
		if ($result)
		   return 1;
		 else
		   return 0;
		
	 } //End of Update function

	function update_status($department_id, $status)
    {
		 $data = array(
				'is_active' => $status
		 );
		
		
        $this->db->where('department_id', $department_id);
        $result = $this->db->update('department', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
}