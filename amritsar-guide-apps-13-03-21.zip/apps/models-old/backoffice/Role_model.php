<?php

class Role_model extends CI_Model
{
   var $roleId,$roleAdminUserName,$roleName,$rolePassword;
   function Role_model(){
	   $this->roleAdminUserName    = 0;
	   $this->roleName      		= 0;
	   $this->rolePassword 		= 0;
	   $this->roleId   			= 0;
   }
   
   function addRole(){
         $data          = array(
            'role_name'     		=>  $this->roleName,
            'description'     		=>  $this->description,
            'permission_access'     =>  $this->user_rights,
            'post_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result  = $this->db->insert('roles', $data);
		
       if($result)
	   	return 1;
	   else
	   	return 0;
   
   }//End of addRole
	
   function editRole(){
         $data          = array(
            'role_name'     		=>  $this->roleName,
            'description'     			=>  $this->description,
			'permission_access'     =>  $this->user_rights,
        );
		$this->db->where('roleid', $this->roleId);
        $result  = $this->db->update('roles', $data);
		if($result)
			return 1;
		else
			return 0;
   }//End of editRole
   
   function editRoleData(){
		$this->db->where('roleid',$this->roleId);         
		$query  = $this->db->get('roles');		  
   		$result = $query->row(); 
		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editRoleData
   
   function viewRoles(){		
		$query=$this->db->get('roles');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } // End of viewRole
   
   
   function navigate_menus($default_opt){
		$this->db->select('*');
		$this->db->from('permissions');
		$this->db->where('is_parent','0');
		//$this->db->where('is_active','1');
		//$this->db->order_by('weight', 'ASC');
		$query = $this->db->get();
		$result = $query->result();
		echo "<div class='userrights'>";
		foreach($result as $res){
			$name=strtoupper($res->per_name);
			$ids=$res->permissionid;
			$links=$res->path;
			$key = array_search($ids,$default_opt);
			if( $key !== false ) {
			   $checked='checked';
			} else {
			   $checked='';
			}
			echo "<li><div class='md-checkbox'><input class='allselect md-check parent".$ids."' type='checkbox' ".$checked."  name='user_rights[]' id='user_rights".$ids."' value='".$ids."'><label for='user_rights".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name."</label></div>";
			
			
		$getchilds=$this->getchild_checkbox($ids,$default_opt,'parent',$ids);
		}
		echo "</div>";
		
	}
	function getchild_checkbox($cid,$default_opt,$child_sta,$parentid){

			$this->db->select('*');
			$this->db->from('permissions');
			$this->db->where('is_parent',$cid);
			//$this->db->where('is_active','1');
			//$this->db->order_by('weight', 'ASC');
			$query = $this->db->get();
			//echo $this->db->last_query();die;
			$countrows=$query->num_rows();
			
			if($countrows>0){
				$result = $query->result();
				/* echo "<pre>";
				print_r($result);
				die; */
				echo "<ul>";
				foreach($result as $childs){//echo "<pre>";print_r($childs);
					$name_get=strtoupper($childs->per_name);
					$links=$childs->path;
					$ids=$childs->permissionid;
					$key = array_search($ids,$default_opt);
					if( $key !== false ) {
					   $checked='checked';
					} else {
					   $checked='';
					}
					if($child_sta=='child'){
						$parentget=$parentid;
					} else {
						$parentget=$cid;
					}
					$classname = str_replace(' ', '_', $name_get);//echo $parentget;
					echo  "<li><div class='md-checkbox'><input class='md-check allselect getParentid$cid getAncestorid$parentget' type='checkbox' ".$checked."  name='user_rights[]' id='user_rights".$ids."' value='".$ids."'><label for='user_rights".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name_get."</label></div></li>";
					$nameof= $this->getchild_checkbox($ids,$default_opt,'child',$cid); 
				}
				echo "</ul>";
			}else{
				echo "</li>";
			}
			//return $output;
		}
}
?>