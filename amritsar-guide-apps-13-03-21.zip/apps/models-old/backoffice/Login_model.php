<?php

class Login_model extends CI_Model
{
	function login_process(){
		$emailid=$this->input->post("emailid");
		$password=md5($this->input->post("password"));
		$this->db->select('*');
		$this->db->where('email',$emailid);
		$this->db->where('password',$password);
		$this->db->where('user_id','1');
		$query = $this->db->get('users');
		$num_rows=$query->num_rows();
		
		//echo $sql = $this->db->last_query();
		if($num_rows>0){
			$result = $query->row();
			return $result;
		}else{
			return False;
		}
		
		//$result = $query->result();
		
	} 
}