<?php

class Groups_model extends CI_Model
{	
        function get_groups_dropdown($language_id){
	    $this->db->select('groups.*,groups_types.group_type_name');
		$this->db->join('groups_types', 'groups_types.group_type_id = groups.group_type_id');
        $this->db->from('groups');
		$this->db->where('groups.language_id',$language_id);
		$this->db->where('groups.is_active', '1');
		$this->db->order_by('groups_types.group_type_name','ASC');
		$this->db->order_by('groups.group_name','ASC');
		//echo $this->db->last_query();
        $result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
        	$return[''] = 'Select ';
            foreach ($result->result_array() as $row) {
		          $return[$row['group_id']] = ucwords($row['group_type_name']).' - '.ucwords($row['group_name']);
		      }
        }
        return $return;
   }
   
   
      function add_mapping()
 	   {   
	   $kiosk_ids =$this->input->post("kiosk_id");
	   if(is_array($kiosk_ids))
	    {
	    foreach($kiosk_ids as $kioskkey=> $kioskval){
		 if($kioskval!='')
		  { 
			$this->db->select('*');
			$this->db->from('group_interlinks');
			$this->db->where('group_id',$group_id);
			$this->db->where('interlink_id',$kioskval);
			$this->db->order_by('group_interlink_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'group_id' => $this->input->post("group_id"),
					'interlink_id' => $kioskval,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('group_interlinks',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}
   
	

	
		
		 function category_edit($group_category_id)
		 {
			if ($group_category_id == '') {
				redirect(base_url() . "backoffice/groups/view_category");
			}
			$this->db->select('*');
			$this->db->from('group_categories');
			$this->db->where('group_category_id', $group_category_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_category($group_category_id)
		 {
			$data = array(
			    'language_id' => $this->session->userdata('lang_id'),
			    'category_name'     => $this->input->post("category_name"),
				'description'     => $this->input->post("description"),
				'weight'   => $weightmax
			);
			$this->db->where('group_category_id', $group_category_id);
			$result = $this->db->update('group_categories', $data);
			if($result > 0)
   		    {	$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "group_categories";
				$operation = "Record updated";
				createLogFile($operation,$group_category_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
		 

     
      function view_mapping($group_id,$status,$limit, $start)
      {
		$this->db->select('group_interlinks.*,groups.group_name,groups.group_type_id');
		$this->db->join('groups', 'groups.group_id = group_interlinks.group_id');
		if($group_id!='0')
		$this->db->where('group_interlinks.group_id', $group_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('group_interlinks.is_active',$status);
		}	
		$this->db->where('groups.language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('groups.group_name','ASC');
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('group_interlinks');
        $query = $this->db->get();
	 // echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	  function count_mapping($group_id,$status) {
		
		$this->db->join('groups', 'groups.group_id = group_interlinks.group_id');
		if($group_id!='0')
		$this->db->where('group_interlinks.group_id', $group_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('group_interlinks.is_active',$status);
		}	
		$this->db->where('groups.language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('group_interlinks');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
	

      function view_groups($group_type_id,$status,$limit, $start)
      {
		$this->db->select('groups.*,groups_types.group_type_name');
		$this->db->join('groups_types', 'groups_types.group_type_id = groups.group_type_id');
		if($group_type_id!='0')
		$this->db->where('groups.group_type_id', $group_type_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('groups.is_active',$status);
		}	
		$this->db->where('groups.language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('groups.group_name','ASC');
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('groups');
        $query = $this->db->get();
	//  echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	  function count_groups($group_type_id,$status) {
		
		$this->db->join('groups_types', 'groups_types.group_type_id = groups.group_type_id');
		if($group_type_id!='0')
		$this->db->where('groups.group_type_id', $group_type_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('groups.is_active',$status);
		}	
		$this->db->where('groups.language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('groups');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
	
		function add()
		{   
			$fields = array('language_id'=>$this->session->userdata('lang_id'),'is_active'=>'1');
			$weightmax = get_max_values('groups','weight',$fields);
			$data  = array(
				'language_id' => $this->session->userdata('lang_id'),
				'group_type_id'     => $this->input->post("group_type_id"),
				'group_name'     => $this->input->post("group_name"),
				'weight'   => $weightmax,
				'created_by'      => $this->session->userdata('user_id'),
				'created_on'      => date('Y-m-d H:i:s')
			);
			$result   = $this->db->insert('groups', $data);
			$group_id  = $this->db->insert_id();
			if($result > 0)
			{
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "groups";
				$operation = "Record added";
				createLogFile($operation,$group_id,$update_by_id,$table_name);
			 }
			 if($result){
				return $group_id;
			 }
			else
				return 0;
	
	
		} //End of add function
	

	
		 function group_edit($group_id)
		 {
			if ($group_id == '') {
				redirect(base_url() . "backoffice/groups/view");
			}
			$this->db->select('*');
			$this->db->from('groups');
			$this->db->where('group_id', $group_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_group($group_id)
		 {
			$data = array(
			   'language_id' => $this->session->userdata('lang_id'),
				'group_type_id'     => $this->input->post("group_type_id"),
				'group_name'     => $this->input->post("group_name"),
			);
			$this->db->where('group_id', $group_id);
			$result = $this->db->update('groups', $data);
			if($result > 0)
   		    {	$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "groups";
				$operation = "Record updated";
				createLogFile($operation,$group_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
    function update_status($group_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('group_id', $group_id);
	    $result = $this->db->update('groups', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function
	
	
	function update_category_status($group_category_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('group_category_id', $group_category_id);
	    $result = $this->db->update('group_categories', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function


}