<?php

class Areas_model extends CI_Model
{
	
	function view_areas()
	{
		$this->db->select('*');
		$this->db->from('areas');
		$this->db->order_by('area_id', 'DESC');
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query = $this->db->get();
		
		//echo $this->db->last_query();
		$results = $query->result();
		return $results;
	} //End of View function
		
		
	function fetcharea($areaid)
	{
		$this->db->select('*');
		$this->db->from('areas');
		$this->db->order_by('area_id', 'DESC');
		$this->db->where('area_id',$areaid);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->row();
		return $results;
	} //End of View function		
	
	   
	 function add()
     {
         $data        = array(
		    'area_name'   => $this->input->post("area_name"), 
		    'language_id'=>$this->session->userdata('lang_id'),
			'created_on'      => date('Y-m-d H:i:s')
			 
        );
        $result   = $this->db->insert('areas', $data);
		$area_id  = $this->db->insert_id();
		 if($result)
			return $area_id;
		else
			return 0;


    } //End of add function
	

	
	
	 function update_area($area_id)
	 {
		 $data        = array(
		    'area_name'   => $this->input->post("area_name"), 
		    'language_id'=>$this->session->userdata('lang_id') 
		 );
		
		
		$this->db->where('area_id', $area_id);
		$result = $this->db->update('areas', $data);
		if ($result)
		   return 1;
		 else
		   return 0;
		
	 } //End of Update function

	
}