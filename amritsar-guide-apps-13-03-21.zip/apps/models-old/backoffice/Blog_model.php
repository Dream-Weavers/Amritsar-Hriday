<?php

class Blog_model extends CI_Model
{
   
   function addBlog(){
	
         $data          = array(
		    'language_id'=>$this->session->userdata('lang_id'),
		    'created_by'=>$this->session->userdata('user_id'),
            'category_id'     	=>  $this->category_id,
            'title'     		=>  $this->title,
            'description'     	=>  $this->description,
            'status'     		=>  '1',
            'approval_status'   =>  '1',
            'visibility'     	=>  'public',
            'user_type'     	=>  'A',
            'video_url'     	=>  $this->video_url,
            'created_date'      =>  date('Y-m-d H:i:s'),
        );
        $result  = $this->db->insert('blogs', $data);
		
		$id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0;
   
   }
   //End of addBlog
	
   function add_icon($blog_id,$filename)
   {			
		$data     = array(
			'image_url'     => time().'_'.$blog_id.'_'.$filename
		);
		$this->db->where('blog_id', $blog_id);
		$result = $this->db->update('blogs', $data);
   }
	
   function editBlog(){
           $data          = array(
            'modified_by' =>$this->session->userdata('user_id'),
            'category_id'     		=>  $this->category_id,
            'title'     	=>  $this->title,
            'description'     		=>  $this->description,
            'video_url'     	=>  $this->video_url
        );
		$this->db->where('blog_id', $this->blog_id);
        $result  = $this->db->update('blogs', $data);
		if($result)
			return $this->blog_id;
		else
			return 0;
   }//End of editBlog
   
   function editBlogData(){
		$this->db->where('blog_id',$this->blog_id);         
		$query  = $this->db->get('blogs');		  
   		$result = $query->row(); 

		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editBlogData
   
   function viewBlogs($category_id,$title, $limit, $start){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, blogs.*, blog_categories.category_name");	
		$this->db->join('blog_categories','blogs.category_id=blog_categories.category_id','left');
		$this->db->join('users','blogs.created_by=users.user_id');
		$this->db->where('blogs.language_id',$this->session->userdata('lang_id'));
		$this->db->where('blogs.approval_status','1');
		
		if($category_id!='0')
		$this->db->where('blogs.category_id', $category_id);
	
		if($title!='') {
			//$this->db->like('blogs.title', $title);
			//$this->db->or_like('blogs.description', $title);
			$where .= "(blogs.title LIKE '%$title%' OR ";
			$where .= "blogs.description LIKE '%$title%')";
			$this->db->where($where);
		} 
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
		$query=$this->db->order_by('blog_id','desc');
		$query=$this->db->get('blogs');
		//echo $this->db->last_query();
   		$result = $query->result(); 
		return $result;
   } // End of viewBlog
   
   function viewUserBlogs($category_id,$title, $limit, $start){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, blogs.*, blog_categories.category_name");	
		$this->db->join('blog_categories','blogs.category_id=blog_categories.category_id','left');
		$this->db->join('users','blogs.created_by=users.user_id');
		$this->db->where('blogs.language_id',$this->session->userdata('lang_id'));
		$this->db->where('blogs.user_type','U');
		$this->db->where('blogs.approval_status','0');
		
		if($category_id!='0')
		$this->db->where('blogs.category_id', $category_id);
	
		if($title!='') {
			$where .= "(blogs.title LIKE '%$title%' OR ";
			$where .= "blogs.description LIKE '%$title%')";
			$this->db->where($where);
		} 
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
		$query=$this->db->order_by('blog_id','desca');
		$query=$this->db->get('blogs');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } // End of viewBlog
   
   function update_status($blog_id, $status)
    {
		 if($status=='1')
		 {	$data = array(
				'status' => $status,
			);
		 }
		 else
		 {
			$data = array(
				'status' => $status,
			);
		 }
        $this->db->where('blog_id', $blog_id);
        $result = $this->db->update('blogs', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
	function update_publish($blog_id, $status)
    {
		$data = array(
				'status' => $status,
				'approval_status' => $status
		);

		
        $this->db->where('blog_id', $blog_id);
        $result = $this->db->update('blogs', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
	function reject_status($blog_id, $status, $rejection_status_remarks )
    {
		$data = array(
				'approval_status' => $status,
				'rejection_status_remarks' => $rejection_status_remarks
			);
			
		
	
        $this->db->where('blog_id', $blog_id);
        $result = $this->db->update('blogs', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
   /* function countblogrecords(){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, blogs.*, blog_categories.category_name");	
		$this->db->join('blog_categories','blogs.category_id=blog_categories.category_id','left');
		$this->db->join('users','blogs.created_by=users.user_id');
		$this->db->where('blogs.language_id',$this->session->userdata('lang_id'));
		$this->db->where('blogs.approval_status','1');
		
		$query=$this->db->get('blogs');
   		return $num = $query->num_rows(); 
   } */
   
   function countuserblogrecords(){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, blogs.*, blog_categories.category_name");	
		$this->db->join('blog_categories','blogs.category_id=blog_categories.category_id','left');
		$this->db->join('users','blogs.created_by=users.user_id');
		$this->db->where('blogs.language_id',$this->session->userdata('lang_id'));
		$this->db->where('blogs.user_type','U');
		$this->db->where('blogs.approval_status','0');
		$query=$this->db->get('blogs');
   		return $num = $query->num_rows(); 
   }
   
}
?>