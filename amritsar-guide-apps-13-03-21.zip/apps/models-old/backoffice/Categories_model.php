<?php

class Categories_model extends CI_Model
{
    function language_info($lang_id){
        $this->db->select('*');
		$this->db->from('languages');
		$this->db->where_not_in('language_id',$lang_id);
		$query = $this->db->get();
		return $query->result();
    }
    function get_category_info($cat_id,$language_id){
        $this->db->select('*');
		$this->db->from('categories_translation');
		$this->db->where('category_id',$cat_id);
		$this->db->where('language_id',$language_id);
		$query = $this->db->get();
		//print $this->db->last_query();die;
		return $query->row();
    }
    
    function update_translate($cat_id,$language_id){
       $update_att =array( 
			'category_name' => $this->input->post("category_name"),
			'description' => $this->input->post("description"),
			);	
		 $this->db->where('category_id', $cat_id);
		 $this->db->where('language_id', $language_id);
		 $updateresult = $this->db->update('categories_translation', $update_att);
   }
    
    function get_cat_info($cat_type_id){
        	$this->db->select('*');
		 //$this->db->where('language_id',1);
		 //	$this->db->join('product_attributes', 'product_attributes.product_id = products.product_id');
		 $this->db->where('category_id',$cat_type_id);
		//$this->db->order_by('product_id DESC');
        $this->db->from('categories');
        $query = $this->db->get();
        //print $this->db->last_query();die;
	    $result = $query->row();

       
        return $result;
    }
    
     function add_translate($language_id,$cat_type_id)
	{   
	   
        $data        = array(
			'category_name'     => $this->input->post("category_name"),
			'category_id'=>$cat_type_id,
			'description'     => $this->input->post("description"),
			'language_id'     =>$language_id,
			'post_date'      => date('Y-m-d H:i:s')
        );
        $result   =$this->db->insert('categories_translation', $data);
		$cat_type_id1  = $this->db->insert_id();
		if($result > 0)
		{
            
            
		    $user_id=$this->session->userdata('user_id');
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $cat_type_id1;
		 }
		else
			return 0;


    } //End of add function
   
   function addCategories(){
	
         $data          = array(
			'language_id'=>$this->session->userdata('lang_id'),
            'category_type_id'     	=>  $this->category_type_id,
            'category_parent_id'    =>  $this->category_parent_id,
            'category_name'     	=>  $this->category_name,
            'description'     		=>  $this->description,
            'post_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result = $this->db->insert('categories', $data);
		
		$id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0;
   
   }//End of addCategories
	
   function add_icon($category_id,$filename)
   {			
		$data     = array(
			'icon'     => $category_id.'_'.$filename
		);
		$this->db->where('category_id', $category_id);
		$result = $this->db->update('categories', $data);
   }
	
   function editCategories(){
           $data          = array(
            'category_type_id'     	=>  $this->category_type_id,
            'category_parent_id'    =>  $this->category_parent_id,
            'category_name'     	=>  $this->category_name,
            'description'     		=>  $this->description
        );
		$this->db->where('category_id', $this->category_id);
        $result  = $this->db->update('categories', $data);
		if(isset($_POST['filter_id']))
		    {
			 $categoryfilterresult = $this->updateCategoryFilter($this->category_id,$_POST['filter_id']);
			}
		if($result)
			return $this->category_id;
		else
			return 0;
   }//End of editCategories
   
   function editCategoriesData(){
		$this->db->where('category_id',$this->category_id);         
		$query  = $this->db->get('categories');		  
   		$result = $query->row(); 

		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editCategoriesData
   
   
   
     function updateCategoryFilter($category_id,$filterList)
 	  {
		/*echo "<pre>";
		print_r($filterList);
		echo "</pre>";
	die();*/
		$insertresult=false;
		if(is_array($filterList))
		{
		 $done=0; 	
		 $already=0; 
		 $fields=array('category_id'=>$category_id,'is_active'=>'1');
	     $filterresult=gettableresult('category_filters',$fields);
	     if(is_array($filterresult))
	     {
		  foreach($filterresult as $grow){
			 if(!in_array($grow->filterid,$filterList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('category_id', $category_id);
			  $this->db->where('filterid',$grow->filterid);
			  $updateresult = $this->db->update('category_filters', $data);
			}
		  }
		 }
		foreach($filterList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('category_filter_id');
						$this->db->from('category_filters');
						$this->db->where('category_id',$category_id);
						$this->db->where('filterid',$listrow);
						$filter_result = $this->db->get();
						if($filter_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $filter_result->row();	
						      $category_filter_id = $tgrow->category_filter_id;
							  $this->db->where('category_filter_id', $category_filter_id);
							  $this->db->where('category_id', $category_id);
							  $this->db->where('filterid',$listrow);
							  $updateresult = $this->db->update('category_filters', $data);
						}else
						{
							$this->db->select('category_filter_id');
							$this->db->from('category_filters');
							$this->db->where('category_id',$category_id);
							$this->db->where('filterid',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{ 
							 $fields = array('category_id'=>$category_id);
							 $weightmax = get_max_values('category_filters',$fields,'weight');
																		  
							  $data_type =array( 
								'category_id'   =>  $category_id,
								'filterid'    =>  $listrow,
								'weight'    =>  $weightmax,
								'created_by'    =>  $this->session->userdata('user_id'),
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('category_filters',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	

   function viewCategories(){
		$this->db->select('categories.*, categories_parent.category_name as parent_category, category_types.category_type');	
		$this->db->join('categories as categories_parent','categories.category_parent_id=categories_parent.category_id','left');
		$this->db->join('category_types','categories.category_type_id=category_types.category_type_id','left');
		$this->db->where('categories.language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('categories');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } // End of viewCategories
}
?>