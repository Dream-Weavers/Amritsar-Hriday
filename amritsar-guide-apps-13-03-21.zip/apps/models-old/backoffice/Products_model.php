<?php

class Products_model extends CI_Model
{	
   
   function vendors_list(){
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('is_active','1');
        $this->db->where('user_type','V');
        //$this->db->order_by('beacon_unique_id','ASC');
        $result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select';
            foreach ($result->result_array() as $row) {
                $return[$row['user_id']] = $row['first_name'].' - '.$row['last_name'];
            }
        }
        return $return;
       
   }
   
   function media_info($product_id,$media_type,$language_id){
        $this->db->select('*');
        $this->db->from('product_digital_media');
        $this->db->where('product_id',$product_id);
        $this->db->where('media_type',$media_type);
        $this->db->where('language_id',$language_id);
        $this->db->order_by('product_media_id', 'ASC');
        $query = $this->db->get();
        //print $this->db->last_query();
        if ($query->num_rows() > 0) {
            return $result = $query->result();
        }else{
            return false;
        }
   }
    function view_users($search_value,$limit, $start)
    {
		$this->db->select('users.user_id,users.first_name,users.last_name,users.email,users.gender,users.date_of_birth,users.mobile_no1,users.created_by,users.created_on,users.is_active,user_address.country_id,user_address.state_id,user_address.city_id,user_address.pin_code,user_address.address, vendor_details.*');
		$this->db->where('users.user_type','V');
		$this->db->where('users.email!=','');
		$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
		$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','LEFT');
		
		if($search_value!='0')
		{
		   $where = "(users.first_name LIKE  '%".trim($search_value)."%' or users.last_name LIKE  '%".trim($search_value)."%' or users.email LIKE  '%".trim($search_value)."%' or users.mobile_no1  LIKE  '%".trim($search_value)."%' or vendor_details.shop_title LIKE  '%".trim($search_value)."%' or vendor_details.shop_address LIKE  '%".trim($search_value)."%')";
		   $this->db->where($where);
		}
		/* if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('users.is_active',$status);
		}  */	
		$this->db->group_by('users.user_id'); 
		$this->db->order_by('users.user_id DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('users');
        $query = $this->db->get();
	    //echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	function viewbeaconvendors($vendor_id)
     	{
			$this->db->select('beacon_vendors.*,beacon_vendor_actions.action_plan_id,beacon_vendor_actions.instruction_id,beacon_vendor_actions.sound_file_id');
			$this->db->from('beacon_vendors');
			$this->db->join('beacon_vendor_actions', 'beacon_vendor_actions.beacon_vendor_id = beacon_vendors.beacon_vendor_id');
			$this->db->where('beacon_vendors.vendor_id', $vendor_id);
			$this->db->order_by('beacon_vendors.beacon_vendor_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	function get_beacons_dropdown()
    {   $this->db->select('*');
        $this->db->from('beacons');
		$this->db->where('is_active','1');
		$this->db->order_by('beacon_unique_id','ASC');
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select';
            foreach ($result->result_array() as $row) {
                $return[$row['beacon_unique_id']] = $row['beacon_unique_id'].' - '.$row['beacon_name'];
            }
        }
        return $return;
    }
	
	function count_users($search_value) {
		$this->db->where('users.user_type','V');
		$this->db->where('users.email!=','');
		$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
		$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','LEFT');
		
		if($search_value!='0')
		{
		   $where = "(users.first_name LIKE  '%".trim($search_value)."%' or users.last_name LIKE  '%".trim($search_value)."%' or users.email LIKE  '%".trim($search_value)."%' or users.mobile_no1  LIKE  '%".trim($search_value)."%' or vendor_details.shop_title LIKE  '%".trim($search_value)."%' or vendor_details.shop_address LIKE  '%".trim($search_value)."%')";
		   $this->db->where($where);
		}
		/* if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('users.is_active',$status);
		} */	
		$this->db->group_by('users.user_id'); 
		$query=$this->db->get('users');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
	function add()
	{   
		
		$data        = array(
            'product_name'   => $this->input->post("product_name"),
			'product_desc'     => $this->input->post("product_desc"),
			//'vendor_id'     => $this->input->post("vendor_id"),
			'language_id'     => 1,
			'product_status'=>1,
			'price'=> $this->input->post("product_price"),
			'post_date'      => date('Y-m-d H:i:s')
        );
        $result   =$this->db->insert('products', $data);
		$product_id  = $this->db->insert_id();
		if($result > 0)
		{
		    
            
            
            // product catefory
            if(!empty($_POST['location_category'])){
                $category=$_POST['location_category'];
                foreach($category as $val){
                    $pro_cat        = array(
                    'product_id'   => $product_id,
        			'category_id'     => $val,
                    );
                    $result   =$this->db->insert('product_categories', $pro_cat);
                }
            }
            
		    $user_id=$this->session->userdata('user_id');
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $product_id;
		 }
		else
			return 0;


    } //End of add function
    
    
    
    function add_translate($language_id,$product_id)
	{   
		//$productinfo=$this->get_product_info($product_id);
		$data        = array(
		    'product_id'=>$product_id,
            'product_title'   => $this->input->post("product_name"),
			'product_desc'     => $this->input->post("product_desc"),
			'price'     =>  $this->input->post("product_price"),
			'language_id'     =>$language_id,
			'post_date'      => date('Y-m-d H:i:s')
        );
        $result   =$this->db->insert('product_translation', $data);
		 $this->db->insert_id();
		if($result > 0)
		{
            
           /* $entity_info       = array(
            'entity_type'   => 'product',
			'entity_id'     => $product_id,
			'language_id'     => $language_id,
			'target_id'     => $product_id1,
             );
            $entity_result   =$this->db->insert('language_entity', $entity_info);*/
            
            
            /*$pro_category=$this->list_product_categories($product_id);
            foreach($pro_category as $pro_row){
                 $pro_cat     = array(
    			'product_id'     => $product_id1,
    			'category_id'     => $pro_row->category_id,
                 );
                $category_result   =$this->db->insert('product_categories', $pro_cat);
            }*/
            // product catefory
            /*if(!empty($_POST['location_category'])){
                $category=$_POST['location_category'];
                foreach($category as $val){
                    $pro_cat        = array(
                    'product_id'   => $product_id1,
        			'category_id'     => $val,
                    );
                    $result   =$this->db->insert('product_categories', $pro_cat);
                }
            }*/
            
            
		    $user_id=$this->session->userdata('user_id');
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $product_id;
		 }
		else
			return 0;


    } //End of add function
    
    function list_product_categories($product_id){
        //product_categories
        $this->db->select('*');
        $this->db->from('product_categories');
        $this->db->where('product_id',$product_id);
        //$this->db->where('category_type_id',$category_type_id);
        //$this->db->where('category_id',$listrow);
        $category_result = $this->db->get();
        return $category_result->result();
    }
	
	
	
	
	    function deleteDigitalMedia($media_id){
		   // Check first record exists or not if not than no delete 	   
		   $this->db->where('vendor_media_id',$media_id); 
		   $query = $this->db->get('vendor_digital_media');
		   if($query->num_rows() > 0 ){
			  $row_media = $query->row();
			  
			   $this->db->where('vendor_media_id',$media_id); 
			   $result = $this->db->delete('vendor_digital_media');
			   if($result)
				{
				  return '1';
				}
		   }
			 else{
			 return '0';
		   } 
		   return 1;
		}
	
		 function update_user($user_id,$user_address_id,$working_hours)
		 {
			
			$data = array(
				'email'     => strtolower($this->input->post("email")),
				
				'first_name'   => $this->input->post("first_name"),
				'last_name'     => $this->input->post("last_name"),
				'gender'     => $this->input->post("gender"),
				
				
				'mobile_no1'     => $this->input->post("mobile_no1")
			);
			$this->db->where('user_id', $user_id);
			$result = $this->db->update('users', $data);
			
			$data        = array(
            'shop_title'   => $this->input->post("shop_title"),
			'shop_address'     => $this->input->post("shop_address"),
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude")
			);
			$this->db->where('user_id', $user_id);
			$this->db->update('vendor_details', $data);
			
			$data    = array(
				'airport_distance'     => $this->input->post("airport_distance"),
				'railway_station_distance'     => $this->input->post("railway_station_distance"),
				'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
				'city_centre_distance'     => $this->input->post("city_centre_distance"),
				
				'working_hours'     => $working_hours,
				
				'rules_regulations'     => $this->input->post("rules_regulations"),
				'visitors_in_month'     => $this->input->post("visitors_in_month"),
				'vendor_review'     => $this->input->post("vendor_review"),
				'remarks'     => $this->input->post("remarks")
			);
			$this->db->where('vendor_id', $user_id);
			$this->db->update('vendor_distance_timings', $data);
			
		
		
			if($result > 0)
   		    {
				if($this->input->post("country_id")!='')
				 {
					$user_address_id = $this->updateUserAddress($user_id,$user_address_id);
				 }
	
				if(isset($_POST['location_category']))
		        {	$updateresult = $this->updateLocationCategory($this->input->post("category_type_id"),$user_id,$_POST['location_category']);
				}
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
	 function updateLocationCategory($category_type_id,$vendor_id,$CategoryList)
 	  {
		/*echo "<pre>";
		print_r($CategoryList);
		echo "</pre>";*/
	
		$insertresult=false;
		if(is_array($CategoryList))
		{
		 $done=0; 	
		 $already=0; 	
		 $fields=array('vendor_id'=>$vendor_id,'is_active'=>'1');
	     $categoryresult=gettableresult('vendor_categories',$fields);
	     if(is_array($categoryresult))
	     {
		  foreach($categoryresult as $grow){
			 if(!in_array($grow->category_id,$CategoryList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('vendor_id', $vendor_id);
			  $this->db->where('category_id',$grow->category_id);
			  $updateresult = $this->db->update('vendor_categories', $data);
			}
		  }
		 }
		foreach($CategoryList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('location_category_id');
						$this->db->from('location_categories');
						$this->db->where('location_id',$location_id);
						$this->db->where('category_type_id',$category_type_id);
						$this->db->where('category_id',$listrow);
						$category_result = $this->db->get();
						if($category_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $category_result->row();	
						      $location_category_id = $tgrow->location_category_id;
							  $this->db->where('location_category_id', $location_category_id);
							  $this->db->where('location_id', $location_id);
							  $this->db->where('category_id',$listrow);
							  $updateresult = $this->db->update('location_categories', $data);
						}else
						{
							$this->db->select('location_category_id');
							$this->db->from('location_categories');
							$this->db->where('location_category_id', $location_category_id);
							$this->db->where('location_id',$location_id);
							$this->db->where('category_id',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{  
							  $data_type =array( 
								'location_id'   =>  $location_id,
								'category_type_id'    =>  $category_type_id,
								'category_id'    =>  $listrow,
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('location_categories',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	
	
	
	 function view_products($search_value,$limit, $start)
    {
		$this->db->select('*');
		//$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
	//	$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','LEFT');
		 $this->db->where('language_id',1);
		if($search_value!='0')
		{
		   $where = "(product_name LIKE  '%".trim($search_value)."%')";
		   $this->db->where($where);
		}
		/* if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('users.is_active',$status);
		}  */	
		$this->db->group_by('product_id'); 
		$this->db->order_by('product_id DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('products');
        $query = $this->db->get();
	    //echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
    
    
    function get_product_info($product_id){
        	$this->db->select('*');
		 //$this->db->where('language_id',1);
		 	//$this->db->join('product_attributes', 'product_attributes.product_id = products.product_id');
		 $this->db->where('products.product_id',$product_id);
		//$this->db->order_by('product_id DESC');
        $this->db->from('products');
        $query = $this->db->get();
        //print $this->db->last_query();die;
	    $result = $query->row();

       
        return $result;
    }
    
   function get_product_translation($product_id,$language_id){
   
       $this->db->select('*');
		 //$this->db->where('language_id',1);
		 	//$this->db->join('product_attributes', 'product_attributes.product_id = products.product_id');
		 $this->db->where('product_id',$product_id);
		 $this->db->where('language_id',$language_id);
		//$this->db->order_by('product_id DESC');
        $this->db->from('product_translation');
        $query = $this->db->get();
        //print $this->db->last_query();die;
	    $result = $query->row();

       
        return $result;
   }
   
   
   function oldmedia($old_product_id,$product_id,$media_file_name,$mediapath=NULL,$language_id){
       $old_media_img=$_POST['old-digital-image'];
        $old_media_video=$_POST['old-digital-video'];
         $count_media=count($old_media_img);
	    $count_mediatable=$this->get_medialist($p_id,2,'num_rows',$language_id);
	
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,2,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_img as $img_old){
    				$imgn=$img_old['gallery_images'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('product_digital_media');
    					$this->db->where('product_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('language_id', $language_id);
    					$this->db->delete($tables);
    					unlink('./assets/products/gallery/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('product_digital_media');
    			$this->db->where('product_id', $p_id);
    			$this->db->where('language_id', $language_id);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	
    	
    	$count_media=count($old_media_video);
        //print '<pre>';print_r($count_media);
        $count_mediatable=$this->get_medialist($p_id,1,'num_rows',$language_id);
        
		if($count_media!=$count_mediatable){
		     if($count_media>0){
		        $media_img_arr=array();
		        $mediatable_img_arr=array();
		        $result_mediatable=$this->get_medialist($p_id,1,'result',$language_id);
		        foreach($result_mediatable as $fr_table){
		            $flname=$fr_table->media_file_name;
		            $mediatable_img_arr[$flname]=$flname;
		        }
    		    foreach($old_media_video as $img_old){
    		        $imgn=$img_old['gallery_videos'];
    		        $media_img_arr[$imgn]=$imgn;
    		    }
    		    $result = array_diff($mediatable_img_arr, $media_img_arr);
    		    if(count($result)>0){
        		    foreach($result as $res){
        		        $tables = array('product_digital_media');
                        $this->db->where('product_id', $p_id);
                        $this->db->where('language_id', $language_id);
                        $this->db->where('media_file_name', $res);
                        $this->db->delete($tables);
                        unlink('./assets/products/gallery/'.$res);
        		    }
		        }
		     }else{
                $tables = array('product_digital_media');
                $this->db->where('product_id', $p_id);
                $this->db->where('media_type', 1);
                $this->db->where('language_id', $language_id);
                $this->db->delete($tables);
		     }
		}
   }
    
    function update_translate($language_id,$product_id)
	{   
		
        $old_media_img=$_POST['old-digital-image'];
        $old_media_video=$_POST['old-digital-video'];
        
        $update_pro =array( 
			'product_title' => $this->input->post("product_name"),
			'product_desc'     => $this->input->post("product_desc"),
			'price'=>$this->input->post("product_price"),
			);	
		 $this->db->where('product_id', $product_id);
		  $this->db->where('language_id', $language_id);
		 $updateresult = $this->db->update('product_translation', $update_pro);
        
		if($updateresult > 0)
		{
		    
        $p_id=$product_id;
         $count_media=count($old_media_img);
	    $count_mediatable=$this->get_medialist($p_id,2,'num_rows',$language_id);
	
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,2,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_img as $img_old){
    				$imgn=$img_old['gallery_images'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('product_digital_media');
    					$this->db->where('product_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('language_id', $language_id);
    					$this->db->delete($tables);
    					unlink('./assets/products/gallery/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('product_digital_media');
    			$this->db->where('product_id', $p_id);
    			$this->db->where('language_id', $language_id);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	
    	
    	$count_media=count($old_media_video);
        //print '<pre>';print_r($count_media);
        $count_mediatable=$this->get_medialist($p_id,1,'num_rows',$language_id);
        
		if($count_media!=$count_mediatable){
		     if($count_media>0){
		        $media_img_arr=array();
		        $mediatable_img_arr=array();
		        $result_mediatable=$this->get_medialist($p_id,1,'result',$language_id);
		        foreach($result_mediatable as $fr_table){
		            $flname=$fr_table->media_file_name;
		            $mediatable_img_arr[$flname]=$flname;
		        }
    		    foreach($old_media_video as $img_old){
    		        $imgn=$img_old['gallery_videos'];
    		        $media_img_arr[$imgn]=$imgn;
    		    }
    		    $result = array_diff($mediatable_img_arr, $media_img_arr);
    		    if(count($result)>0){
        		    foreach($result as $res){
        		        $tables = array('product_digital_media');
                        $this->db->where('product_id', $p_id);
                        $this->db->where('language_id', $language_id);
                        $this->db->where('media_file_name', $res);
                        $this->db->delete($tables);
                        unlink('./assets/products/gallery/'.$res);
        		    }
		        }
		     }else{
                $tables = array('product_digital_media');
                $this->db->where('product_id', $p_id);
                $this->db->where('media_type', 1);
                $this->db->where('language_id', $language_id);
                $this->db->delete($tables);
		     }
		}
    	
            
            
		    $user_id=$this->session->userdata('user_id');
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $product_id;
		 }
		else
			return 0;


    } //End of add function
    
    function count_products($search_value) {
		//$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
		//$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','LEFT');
		$this->db->where('language_id',1);
		if($search_value!='0')
		{
		   $where = "(product_name LIKE  '%".trim($search_value)."%')";
		   $this->db->where($where);
		}
		/* if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('users.is_active',$status);
		} */	
		$this->db->group_by('product_id'); 
		$query=$this->db->get('products');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function


    

	function insertDigitalMedia($product_id,$media_type,$media_file_name,$language_id)
 	  {
		    $this->db->select('product_media_id');
			$this->db->from('product_digital_media');
			$this->db->where('product_id',$product_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('language_id',$language_id);
			$this->db->where('default_media','1');
			$this->db->order_by('product_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				//'language_id'   => $this->session->userdata('lang_id'),
				'product_id'    => $product_id,
				'language_id'=>$language_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('product_digital_media',$data_type);
			//print $this->db->last_query();die;
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	

	  
	function viewDigitalMedia($vendor_id,$media_type)
	{
		$this->db->select('vendor_digital_media.*');
		$this->db->from('vendor_digital_media');
		$this->db->join('users', 'users.user_id = vendor_digital_media.vendor_id');
		//$this->db->where('vendor_digital_media.is_primary', '1');
		$this->db->where('vendor_digital_media.vendor_id', $vendor_id);
		$this->db->where('vendor_digital_media.media_type', $media_type);
		$this->db->order_by('vendor_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->result();
		//echo $this->db->last_query();
		return $results;

   } //End of View function
	   
   function setDefaultMedia($vendor_id,$vendor_media_id,$media_type){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('vendor_media_id',$vendor_media_id); 
	   $this->db->where('media_type',$media_type);
	   $query = $this->db->get('vendor_digital_media');
	   if($query->num_rows() > 0 ){
		 $update_data =array( 
			'default_media' => '0',
			);	
		 $this->db->where('vendor_id', $vendor_id);
		 $this->db->where('media_type', $media_type);	
		 $updateresult = $this->db->update('vendor_digital_media', $update_data);
		 
		  $updatedata =array( 
			'default_media' => '1',
			);	
		 $this->db->where('vendor_id', $vendor_id);
		 $this->db->where('media_type', $media_type);
		 $this->db->where('vendor_media_id', $vendor_media_id);	
		 $updateresult = $this->db->update('vendor_digital_media', $updatedata);
		 if($updateresult)
		 { return '1';
		 }
	    }
	  	 else{
		 return '0';
	   }
	}

  function insertBeaconvendors($data) {
	$result = $this->db->insert('beacon_vendor_actions', $data);
	$beacon_action_id = $this->db->insert_id();
	if($beacon_action_id)
	{    return $beacon_action_id;
	}
	else
	{	 return '0';
	}
 }
    
    function language_info($lang_id){
        $this->db->select('*');
		$this->db->from('languages');
		$this->db->where_not_in('language_id',$lang_id);
		$query = $this->db->get();
		return $query->result();
    }
    
    function product_languages($product_id){
        $this->db->select('*');
		$this->db->from('language_entity');
		$this->db->where_not_in('entity_id',$product_id);
		$query = $this->db->get();
		return $query->result();
    }
    function insertOldDigitalMedia($old_product_id,$product_id,$media_file_name,$mediapath=NULL,$language_id)
 	{
		    $this->db->select('*');
			$this->db->from('product_digital_media');
			$this->db->where('product_id',$old_product_id);
			//$this->db->where('language_id',$language_id);
			$this->db->where('media_file_name',$media_file_name);
			$query = $this->db->get();
			//print $this->db->last_query();die;
			if($query->num_rows() > 0)
			{	
				$fetched_data=$query->row_array();
				
				//Copy File	if exists			
				 if ($mediapath!='') {
				
				    $new_media_file=$product_id."_".time()."_".$media_file_name;
					$oldfile = $mediapath."/".$media_file_name; 
					$newfile = $mediapath."/".$new_media_file;
					copy($oldfile, $newfile);
					
					$data_type =array( 
						//'language_id'=>$this->session->userdata('lang_id'),
						'product_id'    => $product_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $new_media_file,
						'created_on'      => date('Y-m-d H:i:s'),
						'language_id'=>$language_id,
					);
				 } else {
					 $data_type =array( 
						//'language_id'=>$this->session->userdata('lang_id'),
						'product_id'    => $product_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $media_file_name,
						'created_on'      => date('Y-m-d H:i:s'),
						'language_id'=>$language_id,
					);
				 }
				
				  
				
				$this->db->insert('product_digital_media',$data_type);	
			//	print $this->db->last_query();die;
				return true;
			}		
	}
	
    function get_categorylist($product_id){
        $this->db->select('category_id');
        $this->db->from('product_categories');
        $this->db->where('product_id',$product_id);
        $query = $this->db->get();
        return $query->result();
	}
	
	function get_medialist($product_id,$type,$return_type,$language_id){
        $this->db->select('*');
        $this->db->from('product_digital_media');
        $this->db->where('product_id',$product_id);
        $this->db->where('media_type',$type);
        $this->db->where('language_id',$language_id);
        $query = $this->db->get();
        return $query->$return_type();
	}
	
	
	
	function updateproduct($p_id,$language_id){
	    $old_media_img=$_POST['old-digital-image'];
	    $old_media_video=$_POST['old-digital-video'];
	    
	    $update_pro =array( 
			'product_name' => $this->input->post("product_name"),
			'product_desc' => $this->input->post("product_desc"),
			'price' => $this->input->post("product_price"),
			'product_status' => $this->input->post("product_status"),
			);	
		 $this->db->where('product_id', $p_id);
		 $updateresult = $this->db->update('products', $update_pro);
		 
		 
		    $tables = array('product_categories');
            $this->db->where('product_id', $p_id);
            $this->db->delete($tables);
            
        // product catefory
        
        
        
        if(!empty($_POST['location_category'])){
            $category=$_POST['location_category'];
            foreach($category as $val){
                $pro_cat        = array(
                'product_id'   => $p_id,
    			'category_id'     => $val,
                );
                $result   =$this->db->insert('product_categories', $pro_cat);
            }
        }
        $count_media=count($old_media_img);
        //print '<pre>';print_r($count_media);
        $count_mediatable=$this->get_medialist($p_id,2,'num_rows',1);
        
		if($count_media!=$count_mediatable){
		     if($count_media>0){
		        $media_img_arr=array();
		        $mediatable_img_arr=array();
		        $result_mediatable=$this->get_medialist($p_id,2,'result',1);
		        foreach($result_mediatable as $fr_table){
		            $flname=$fr_table->media_file_name;
		            $mediatable_img_arr[$flname]=$flname;
		        }
    		    foreach($old_media_img as $img_old){
    		        $imgn=$img_old['gallery_images'];
    		        $media_img_arr[$imgn]=$imgn;
    		    }
    		    $result = array_diff($mediatable_img_arr, $media_img_arr);
    		    if(count($result)>0){
        		    foreach($result as $res){
        		        $tables = array('product_digital_media');
                        $this->db->where('product_id', $p_id);
                        $this->db->where('language_id', 1);
                        $this->db->where('media_type', 2);
                        $this->db->where('media_file_name', $res);
                        $this->db->delete($tables);
                        unlink('./assets/products/gallery/'.$res);
        		    }
		        }
		     }else{
                $tables = array('product_digital_media');
                $this->db->where('product_id', $p_id);
                $this->db->where('language_id', 1);
                $this->db->where('media_type', 2);
                $this->db->delete($tables);
		     }
		}//die;
		
		 $count_media=count($old_media_video);
        //print '<pre>';print_r($count_media);
        $count_mediatable=$this->get_medialist($p_id,1,'num_rows',1);
        
		if($count_media!=$count_mediatable){
		     if($count_media>0){
		        $media_img_arr=array();
		        $mediatable_img_arr=array();
		        $result_mediatable=$this->get_medialist($p_id,1,'result',1);
		        foreach($result_mediatable as $fr_table){
		            $flname=$fr_table->media_file_name;
		            $mediatable_img_arr[$flname]=$flname;
		        }
    		    foreach($old_media_video as $img_old){
    		        $imgn=$img_old['gallery_videos'];
    		        $media_img_arr[$imgn]=$imgn;
    		    }
    		    $result = array_diff($mediatable_img_arr, $media_img_arr);
    		    if(count($result)>0){
        		    foreach($result as $res){
        		        $tables = array('product_digital_media');
                        $this->db->where('product_id', $p_id);
                        $this->db->where('language_id', 1);
                        $this->db->where('media_type', 1);
                        $this->db->where('media_file_name', $res);
                        $this->db->delete($tables);
                        unlink('./assets/products/gallery/'.$res);
        		    }
		        }
		     }else{
                $tables = array('product_digital_media');
                $this->db->where('product_id', $p_id);
                $this->db->where('media_type', 1);
                $this->db->where('language_id', 1);
                $this->db->delete($tables);
		     }
		}
		
		
		$get_product_lang_target_id=$this->product_languages($p_id);
        foreach($get_product_lang_target_id as $val){
            $target_id=$val->target_id;
            $tables = array('product_categories');
            $this->db->where('product_id', $target_id);
            $this->db->delete($tables);
            
            if(!empty($_POST['location_category'])){
                $category=$_POST['location_category'];
                foreach($category as $val){
                    $pro_cat        = array(
                    'product_id'   => $target_id,
        			'category_id'     => $val,
                    );
                    $result   =$this->db->insert('product_categories', $pro_cat);
                }
            }
            
        }
		
		return true;
		 /*$get_category=$this->get_categorylist($p_id);
		 $category_arr=array();
		 $category_arr1=array();
		 foreach($get_category as $cat1){
		    $category_arr[$cat1->category_id]= $cat1->category_id;
		 }
		 foreach($_POST['location_category'] as $cat2){
		    $category_arr1[$cat2]= $cat2;
		 }
		 //print '<pre>';print_r($category_arr);
		 //print '<pre>';print_r($category_arr1);
         $result = array_diff($category_arr1, $category_arr);
         if (in_array('12.4', $a, true)) {
            echo "'12.4' found with strict check\n";
        }
		 print '<pre>';print_r($result);die;*/

	}
    
 

}