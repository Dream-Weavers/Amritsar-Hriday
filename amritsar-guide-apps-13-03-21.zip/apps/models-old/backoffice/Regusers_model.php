<?php

class Regusers_model extends CI_Model
{	
    function view_users($search_value,$limit, $start)
    {
		$this->db->select('users.user_id,users.first_name,users.last_name,users.email,users.gender,users.date_of_birth,users.mobile_no1,users.created_by,users.created_on,users.is_active,user_address.country_id,user_address.state_id,user_address.city_id,user_address.pin_code,user_address.address');
		$this->db->where('users.user_type','U');
		$this->db->where('users.email!=','');
		$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
		
		if($search_value!='0')
		{
		   $where = "(users.first_name LIKE  '%".trim($search_value)."%' or users.last_name LIKE  '%".trim($search_value)."%' or users.email LIKE  '%".trim($search_value)."%' or users.mobile_no1  LIKE  '%".trim($search_value)."%')";
		   $this->db->where($where);
		}
		/* if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('users.is_active',$status);
		}  */	
		$this->db->group_by('users.user_id'); 
		$this->db->order_by('users.user_id DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('users');
        $query = $this->db->get();
	    //echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	function getroutes()
    {
		$this->db->select('*');
		//$this->db->where('user_id',$this->session->userdata('user_id'));
		$this->db->where('user_id','39');
        $this->db->from('user_location_trackings');
        $query = $this->db->get();
	    //echo "--->".$this->db->last_query();
	    $result = $query->row();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	function count_users($search_value) {
		$this->db->where('users.user_type','U');
		$this->db->where('users.email!=','');
		$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
		
		if($search_value!='0')
		{
		   $where = "(users.first_name LIKE  '%".trim($search_value)."%' or users.last_name LIKE  '%".trim($search_value)."%' or users.email LIKE  '%".trim($search_value)."%' or users.mobile_no1  LIKE  '%".trim($search_value)."%')";
		   $this->db->where($where);
		}
		/* if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('users.is_active',$status);
		} */	
		$this->db->group_by('users.user_id'); 
		$query=$this->db->get('users');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
	function add()
	{   
		 $salt           = create_salt($password=NULL);
		 $password  = $this->input->post("userpass");	
         $data        = array(
            'email'     => strtolower($this->input->post("email")),
			'password'=> SHA1($password.$salt),
			'salt'=>  $salt,
			'user_type'   => 'U',
			
			'first_name'   => $this->input->post("first_name"),
			'last_name'     => $this->input->post("last_name"),
			'gender'     => $this->input->post("gender"),
			'mobile_no1'     => $this->input->post("mobile_no1"),
			'created_by '   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
        $result   = $this->db->insert('users', $data);
		$user_id  = $this->db->insert_id();
		if($result > 0)
		{
		    if($this->input->post("country_id")!='')
		    {
		     $user_address_id = $this->insertUserAddress($user_id);
			 $update_data =array( 
				'user_address_id' => $user_address_id,
			 );	
			 $this->db->where('user_id', $user_id);
			 $result = $this->db->update('users', $update_data);
		    }
		    
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $user_id;
		 }
		else
			return 0;


    } //End of add function
	
	
	function insertUserAddress($user_id)
 	  {
		   $address_data =array( 
		        'user_id' => $user_id,
				'country_id' => $this->input->post("country_id"),
				'state_id' => $this->input->post("state_id"),
				'city_id' => $this->input->post("city_id"),
				'pin_code' => $this->input->post("pin_code"),
				'is_primary'=>'1',
				'post_date'      => date('Y-m-d H:i:s')
			 );	
			 $result= $this->db->insert('user_address',$address_data);	
			 $user_address_id  = $this->db->insert_id();
			if($result)
				return $user_address_id;
			else
				return 0;
	}
	
	
	
	function updateUserAddress($user_id,$user_address_id)
 	  {			$address_data =array( 
				'country_id' => $this->input->post("country_id"),
				'state_id' => $this->input->post("state_id"),
				'city_id' => $this->input->post("city_id"),
				'address' => $this->input->post("address"),
				'pin_code' => $this->input->post("pin_code")
			 );	
			 $this->db->where('user_address_id', $user_address_id);
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_address', $address_data);
			if($result)
				return 1;
			else
				return 0;
	}
	
	 function insertUserRole($user_id)
 	  {
		   $rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
		   $role_data =array( 
		        'user_id' => $user_id,
				'role_id' => $this->input->post("role_id"),
				'role_rights' =>$rolerow->role_permission,
				'created_on'  => date('Y-m-d H:i:s')
			 );	
			 $result= $this->db->insert('user_roles',$role_data);	
			 $user_role_id  = $this->db->insert_id();
			if($result)
				return $user_role_id;
			else
				return 0;
	}
	

	
	function UpdateUserRole($user_id)
 	  {			
	    	if($this->input->post("current_role_id") !=$this->input->post("role_id"))
			{	
		
			$rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
			    $role_data =array( 
					'user_id' => $user_id,
					'role_id' => $this->input->post("role_id"),
					'role_rights' =>$rolerow->role_permission,
					'created_on'      => date('Y-m-d H:i:s')
				  );	
	/* 			  echo "<pre>";
				  print_r($role_data);
				  die; */
				 $result= $this->db->insert('user_roles',$role_data);	
				 $user_role_id  = $this->db->insert_id(); 
				 
			 $roledata =array( 
				'is_active' => '0'
			 );	
			 $this->db->where('role_id', $this->input->post("current_role_id"));
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_roles', $roledata);
			}
			elseif($this->input->post("current_role_id")=='0' && $this->input->post("current_role_id")=='')
			{
			   $rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
			   $role_data =array( 
					'user_id' => $user_id,
					'role_id' => $this->input->post("role_id"),
					'role_rights' =>$rolerow->role_permission,
					'created_on'      => date('Y-m-d H:i:s')
				 );	
				 $result= $this->db->insert('user_roles',$role_data);	
				 $user_role_id  = $this->db->insert_id();
			}else
			{
				$result=true;
			}
			if($result)
				return 1;
			else
				return 0;
	}
	
	
		 function user_edit($user_id)
		 {
			if ($user_id == '') {
				redirect(base_url() . "backoffice/regusers/view");
			}
			$this->db->select('users.*,user_address.country_id,user_address.state_id,user_address.city_id,user_address.pin_code,user_address.address');
			$this->db->from('users');
			$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
			$this->db->where('users.user_id', $user_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_user($user_id,$user_address_id)
		 {
			
			$data = array(
				'email'     => strtolower($this->input->post("email")),
				
				'first_name'   => $this->input->post("first_name"),
				'last_name'     => $this->input->post("last_name"),
				'gender'     => $this->input->post("gender"),
				
				
				'mobile_no1'     => $this->input->post("mobile_no1")
			);
			$this->db->where('user_id', $user_id);
			$this->db->where('user_type','U');
			$result = $this->db->update('users', $data);
			if($result > 0)
   		    {
				if($this->input->post("country_id")!='')
				 {
					$user_address_id = $this->updateUserAddress($user_id,$user_address_id);
				 }
	
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "users";
				$operation = "Record updated";
				createLogFile($operation,$user_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
	 
	function update_photo($user_id,$file_name)
    { 
        $data = array(
			'user_photo'   => $file_name,
        );
        $this->db->where('user_id', $user_id);
		$this->db->where('user_type','U');
        $result = $this->db->update('users', $data);
		if($result)
		{
		  return 1;
		}
        
    } //End of Update User function
	 

    function update_status($user_id, $status)
    {
		 if($status=='1')
		 {	$data = array(
				'is_active' => $status
			);
		 }
		 else
		 {
			$data = array(
				'is_active' => $status
			);
		 }
        $this->db->where('user_id', $user_id);
        $result = $this->db->update('users', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function


}