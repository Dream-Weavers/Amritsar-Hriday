<?php

class Beacons_model extends CI_Model
{	
    function view_beacons($beacon_id,$status,$limit, $start)
    {
		$this->db->select('*');
		//$this->db->join('beacon_locations', 'beacon_locations.beacon_unique_id = beacons.beacon_unique_id','LEFT');
		//$this->db->join('locations', 'locations.location_id = beacon_locations.location_id','LEFT');
		if($beacon_id!='0')
		$this->db->like('beacons.beacon_id', $beacon_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('beacons.is_active',$status);
		}	
		$this->db->where('beacons.language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('beacons.beacon_id','desc');
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('beacons');
        //$this->db->order_by("beacon_id", "desc");
        $query = $this->db->get();
	    //echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	function count_beacons($beacon_id,$status) {
		
		if($beacon_id!='0')
		$this->db->like('beacon_id', $beacon_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('beacons');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
	function add()
	{   
		 $data  = array(
			'language_id' => $this->session->userdata('lang_id'),
            'beacon_unique_id'     => $this->input->post("beacon_unique_id"),
			'beacon_name'   => $this->input->post("beacon_name"),
			'created_on'      => date('Y-m-d H:i:s')
        );
        $result   = $this->db->insert('beacons', $data);
		$beacon_id  = $this->db->insert_id();
		if($result > 0)
		{
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "beacons";
			$operation = "Record added";
			createLogFile($operation,$beacon_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $beacon_id;
		 }
		else
			return 0;


    } //End of add function
	

	
		 function beacon_edit($beacon_id)
		 {
			if ($beacon_id == '') {
				redirect(base_url() . "backoffice/beacons/view");
			}
			$this->db->select('*');
			$this->db->from('beacons');
			$this->db->where('beacon_id', $beacon_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_beacon($beacon_id)
		 {
			$data = array(
				 'beacon_unique_id'     => $this->input->post("beacon_unique_id"),
				 'beacon_name'   => $this->input->post("beacon_name")
			);
			$this->db->where('beacon_id', $beacon_id);
			$result = $this->db->update('beacons', $data);
			if($result > 0)
   		    {	$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "beacons";
				$operation = "Record updated";
				createLogFile($operation,$beacon_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
    function update_status($beacon_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('beacon_id', $beacon_id);
	    $result = $this->db->update('beacons', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function

    function update_beacon_img($beacon_id,$image){
        $data = array(
				 'beacon_img'     => $image,
			);
			$this->db->where('beacon_id', $beacon_id);
			$result = $this->db->update('beacons', $data);
		return true;
    }

}