<?php

class Confirmpassword_model extends CI_Model
{
	 function update_password()
	 {
			 $data        = array(
				'password'     => md5($this->input->post("newpassword")), 
			);
		 
		 $this->db->where('user_id', $this->session->userdata('user_id'));
		 $result = $this->db->update('users', $data);
			
		if ($result)
		   return 1;
		 else
		   return 0;
		
	 } //End of Update function	
}