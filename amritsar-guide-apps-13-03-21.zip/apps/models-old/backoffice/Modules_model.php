<?php

class Modules_model extends CI_Model
{	
   function insert_in_table($table_name,$fields){
		$this->db->trans_begin();
		$result = $this->db->insert($table_name, $fields);
		$id  = $this->db->insert_id();
		//make transaction complete
		$this->db->trans_complete();
		//check if transaction status TRUE or FALSE
		if ($this->db->trans_status() === FALSE) {
			//if something went wrong, rollback everything
			$this->db->trans_rollback();
			return FALSE;
		} else {
			//if everything went right, commit the data to the database
			$this->db->trans_commit();
			return $id;
		}
	}
	
	function update_table($tablename,$mod_fields,$wherefield){
		$this->db->set($mod_fields);
		foreach($wherefield as $key=>$val)
		$this->db->where($key, $val);
		$resultdata=$this->db->update($tablename);
		
		if($resultdata){
			return TRUE;
		}else{
			return FALSE;
		}
	}
	
	
	function count_modules($module_name,$module_category,$module_visibility,$module_type,$module_conf_type) {
		if($module_category!='0')
		$this->db->where('modules.module_category_id', $module_category);
		if($module_visibility!='0')
		$this->db->where('modules.module_visibility', $module_visibility);
		if($module_type!='0')
		$this->db->where('modules.module_type', $module_type);
		if($module_conf_type!='0')
		$this->db->where('modules.is_latest', $module_conf_type);
		if($module_name!='0')
		{  		   	
		   $this->db->like('modules.module_name', $module_name);
		}
		
		$query=$this->db->get('modules');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
	
	function view_modules($module_name,$module_category,$module_visibility,$module_type,$module_conf_type,$limit, $start) {
		if($module_category!='0')
		$this->db->where('modules.module_category_id', $module_category);
		if($module_visibility!='0')
		$this->db->where('modules.module_visibility', $module_visibility);
		if($module_type!='0')
		$this->db->where('modules.module_type', $module_type);
		if($module_conf_type!='0')
		$this->db->where('modules.is_latest', $module_conf_type);
		if($module_name!='0')
		{  		   	
		   $this->db->like('modules.module_name', $module_name);
		}
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
		$this->db->order_by("modules.weight", "asc");
		$query=$this->db->get('modules');	
		$result = $query->result();		
		//echo "--------------------->". $this->db->last_query();	   
		return $result;
		
	}     //End of Count function
	
	function module_attr($module_id,$type,$is_latest,$limit){
		
		if($type==2){
			if($is_latest!=1){
				$this->db->select('locations.location_name,locations.pin_code,state.state_name,city.city_name,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
				$this->db->order_by("module_interlinks.weight", "asc");
			}else{
				$this->db->select('locations.location_name,locations.pin_code,state.state_name,city.city_name');
				$this->db->order_by("locations.location_id", "DESC");
			}
			
			$this->db->join('state', 'state.state_id = locations.state_id');
			$this->db->join('city', 'city.city_id = locations.state_id');
			
		}else if($type==3){
			if($is_latest!=1){
				$this->db->select('categories.category_name,categories.icon,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('categories', 'categories.category_id = module_interlinks.category_id');
				$this->db->order_by("module_interlinks.weight", "asc");
			}
			else{
				$this->db->select('categories.category_name,categories.icon');
			}
			$this->db->order_by("categories.category_id", "DESC");
		}else if($type==1){
			if($is_latest!=1){
				$this->db->select('category_types.category_type,category_types.icon,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('category_types', 'category_types.category_type_id = module_interlinks.category_type_id');
				$this->db->order_by("module_interlinks.weight", "asc");
			}
			else{
				$this->db->select('category_types.category_type,category_types.icon');
			}
			$this->db->order_by("category_types.category_type_id", "DESC");
		}else if($type==4){
		    if($is_latest!=1){
				$this->db->select('locations.location_id,locations.location_name,locations.pin_code,state.state_name,city.city_name,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('locations', 'locations.location_id = module_interlinks.slide_id');
				$this->db->order_by("module_interlinks.weight", "asc");
			}else{
				$this->db->select('locations.location_name,locations.pin_code,state.state_name,city.city_name');
				$this->db->order_by("locations.location_id", "DESC");
			}
			
			$this->db->join('state', 'state.state_id = locations.state_id');
			$this->db->join('city', 'city.city_id = locations.state_id');
			/*if($is_latest!=1){
				$this->db->select('slides.slide_title,slides.slide_file_name,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('slides', 'slides.slide_id = module_interlinks.slide_id');
				$this->db->order_by("slides.weight", "asc");
			}
			else{
				$this->db->select('slides.slide_title,slides.slide_file_name');
			}
			$this->db->order_by("slides.slide_id", "DESC");*/
		}else if($type==6){   // Trails
			if($is_latest!=1){
				/*$this->db->select('slides.slide_title,slides.slide_file_name,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('slides', 'slides.slide_id = module_interlinks.slide_id');
				$this->db->order_by("slides.weight", "asc");*/
				$this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_image,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('tour_trails', 'tour_trails.tour_trail_id = module_interlinks.trail_id');
				$this->db->order_by("tour_trails.weight", "asc");
			}
			else{
				$this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_image');
			}
			$this->db->order_by("tour_trails.tour_trail_id", "DESC");
		}
		
		if($is_latest==1){
			$this->db->limit($limit,0);
			if($type==2){
				//$this->db->where('modules.module_id', $module_id);
				$query=$this->db->get('locations');	
			}elseif($type==3){
				$query=$this->db->get('categories');	
			}
			elseif($type==1){
				$query=$this->db->get('category_types');	
			}elseif($type==4){
				$query=$this->db->get('locations');	
			}elseif($type==6){
				$query=$this->db->get('tour_trails');	
			}
			
		}else{
			$this->db->where('module_interlinks.module_id', $module_id);
			$query=$this->db->get('module_interlinks');	
		}
		//print $this->db->last_query();die;
		$result = $query->result();	
		foreach($result as $row){
		    if($type==4){
    		    $loc_id=$row->location_id;
    		    $getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
    			//$row_info['slide_title']=$row_info['location_name'];
    			if($getpath!=''){
    				$row->image_path = base_url().gallery_path.$getpath->media_file_name;
    			}else{
    				$row->image_path = base_url().'assets/image-not-available.jpg';
    			}
    		}
		}
		//print '<pre>';print_r($result);die;
		return $result;
	}
	function count_module_attr($module_id,$type,$is_latest,$limit){
		if($type==2){
			if($is_latest!=1){
				$this->db->select('locations.location_name,locations.pin_code,state.state_name,city.city_name,module_interlinks.module_interlink_id,module_interlinks.interlink_type');
				$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
			}else{
				$this->db->select('locations.location_name,locations.pin_code,state.state_name,city.city_name');
			}
			
			$this->db->join('state', 'state.state_id = locations.state_id');
			$this->db->join('city', 'city.city_id = locations.state_id');
			$this->db->order_by("locations.location_id", "DESC");
		}else if($type==3){
			if($is_latest!=1){
				$this->db->select('categories.category_name,categories.icon,module_interlinks.module_interlink_id,module_interlinks.interlink_type');
				$this->db->join('categories', 'categories.category_id = module_interlinks.category_id');
			}
			else{
				$this->db->select('categories.category_name,categories.icon');
				$this->db->order_by("categories.category_id", "DESC");
			}
			
		}else if($type==1){
			if($is_latest!=1){
				$this->db->select('category_types.category_type,category_types.icon,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('category_types', 'category_types.category_type_id = module_interlinks.category_type_id');
				$this->db->order_by("module_interlinks.weight", "asc");
			}
			else{
				$this->db->select('category_types.category_type,category_types.icon');
				$this->db->order_by("category_types.category_type_id", "DESC");
			}
			
		}else if($type==4){
			if($is_latest!=1){
				$this->db->select('locations.location_name,locations.pin_code,state.state_name,city.city_name,module_interlinks.module_interlink_id,module_interlinks.interlink_type');
				$this->db->join('locations', 'locations.location_id = module_interlinks.slide_id');
			}else{
				$this->db->select('locations.location_name,locations.pin_code,state.state_name,city.city_name');
			}
			
			$this->db->join('state', 'state.state_id = locations.state_id');
			$this->db->join('city', 'city.city_id = locations.state_id');
			$this->db->order_by("locations.location_id", "DESC");
			
		}else if($type==6){   // Trails
			if($is_latest!=1){
				/*$this->db->select('slides.slide_title,slides.slide_file_name,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('slides', 'slides.slide_id = module_interlinks.slide_id');
				$this->db->order_by("slides.weight", "asc");*/
				$this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_image,module_interlinks.module_interlink_id,module_interlinks.interlink_type,module_interlinks.weight');
				$this->db->join('tour_trails', 'tour_trails.tour_trail_id = module_interlinks.trail_id');
				$this->db->order_by("tour_trails.weight", "asc");
			}
			else{
				$this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_image');
			}
			$this->db->order_by("tour_trails.tour_trail_id", "DESC");
		}
		if($is_latest==1){
			$this->db->limit($limit,0);
			if($type==2){
				//$this->db->where('modules.module_id', $module_id);
				$query=$this->db->get('locations');	
			}elseif($type==3){
				$query=$this->db->get('categories');	
			}elseif($type==1){
				$query=$this->db->get('category_types');	
			}elseif($type==4){
				//$query=$this->db->get('slides');	
				$query=$this->db->get('locations');	
			}elseif($type==6){
				$query=$this->db->get('tour_trails');	
			}
			
		}else{
			$this->db->where('module_interlinks.module_id', $module_id);
			$query=$this->db->get('module_interlinks');	
		}
		$result = $query->num_rows();		
		return $result;
	}
	
	
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		//echo $this->db->last_query();
		return $results;

	}
	
	function delete_module_attr($attr_id){
		$this->db->where('module_interlink_id', $attr_id);
		$result=$this->db->delete('module_interlinks');
		if($result){
			return True;
		}else{
			return False;
		}
	}
	
	
	
	function module_field_sorting($tablename,$primary_field){
		$components=$_POST['components'];
		foreach($components as $key=>$sorting){
			$cid=$key;
			$weight=$sorting['weight'];
			$value=array('weight'=>$weight);
			//$this->db->where('report_weight_id',$cid);
			$this->db->where($primary_field,$cid);
			//$this->db->where('company_id',$this->session->userdata('master_id'));
			$result=$this->db->update($tablename,$value);
		}
		if($result){
			return true;
		}else{
			return false;
		}
	}
	
	function loclist($moduleid){
		$this->db->select('module_interlinks.location_id');
		$this->db->where('module_interlinks.module_id',$moduleid);
		$query=$this->db->get('module_interlinks');
		$result = $query->result();	
		foreach($result as $row){
			$ids[] = $row->location_id;
		}
		
		$this->db->select('locations.location_id,locations.location_name');
		$this->db->where_not_in('locations.location_id', $ids);
		$query=$this->db->get('locations');
		$result1 = $query->result_array();	
		//$array=array_merge
		$result=array(''=>'--Select--');
		$loc_info = array_column($result1, 'location_name', 'location_id');
		$returnloc=array_replace($result, $loc_info);
		
		return $returnloc;
	}
	
	function category_type_list($moduleid){
		$this->db->select('module_interlinks.category_type_id');
		$this->db->where('module_interlinks.module_id',$moduleid);
		$query=$this->db->get('module_interlinks');
		$result = $query->result();	
		foreach($result as $row){
			$ids[] = $row->category_type_id;
		}
		
		$this->db->select('category_types.category_type,category_types.category_type_id');
		$this->db->where_not_in('category_types.category_type_id', $ids);
		$query=$this->db->get('category_types');
		
		$result1 = $query->result_array();	
		
		//$array=array_merge
		$result=array(''=>'--Select--');
		$cate_type_info = array_column($result1, 'category_type', 'category_type_id');
		$returncattype=array_replace($result, $cate_type_info);
		return $returncattype;
	}
	
	function category_list($moduleid){
		$this->db->select('module_interlinks.category_id');
		$this->db->where('module_interlinks.module_id',$moduleid);
		$query=$this->db->get('module_interlinks');
		$result = $query->result();	
		foreach($result as $row){
			$ids[] = $row->category_id;
		}
		
		$this->db->select('categories.category_name,categories.category_id');
		$this->db->where_not_in('categories.category_id', $ids);
		$query=$this->db->get('categories');
		
		$result1 = $query->result_array();	
		
		//$array=array_merge
		$result=array(''=>'--Select--');
		$cate_type_info = array_column($result1, 'category_name', 'category_id');
		$returncattype=array_replace($result, $cate_type_info);
		return $returncattype;
	}
	function slides_list($moduleid){
		$this->db->select('module_interlinks.slide_id');
		$this->db->where('module_interlinks.module_id',$moduleid);
		$query=$this->db->get('module_interlinks');
		$result = $query->result();	
		foreach($result as $row){
			$ids[] = $row->slide_id;
		}
		
		$this->db->select('locations.location_id,locations.location_name');
		$this->db->where_not_in('locations.location_id', $ids);
		$this->db->where('locations.language_id',1);
		$query=$this->db->get('locations');
		
		$result1 = $query->result_array();	
		foreach($result1 as $rowinfo){
		    $loc_id=$rowinfo['location_id'];
		    $getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			//$row_info['slide_title']=$row_info['location_name'];
			if($getpath!=''){
				$rowinfo['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$rowinfo['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$rows[] = $rowinfo;
		}
		//print '<pre>';print_r($rows);die;
		//$array=array_merge
		$result=array(''=>'--Select--');
		$cate_type_info = array_column($rows, 'image_path', 'location_id');
		return $cate_type_info;
	}
	
	function deletemodule_table($tablename,$module_id){
		$this->db->where('module_id', $module_id);
		$result=$this->db->delete($tablename);
		if($result){
			$this->db->where('module_id', $module_id);
			$result=$this->db->delete('module_interlinks');
			return True;
		}else{
			return False;
		}
	}
	
}