<?php

class Categorytype_model extends CI_Model
{
    function language_info($lang_id){
        $this->db->select('*');
		$this->db->from('languages');
		$this->db->where_not_in('language_id',$lang_id);
		$query = $this->db->get();
		return $query->result();
    }
    
    function get_category_type_info($cat_type_id,$language_id){
        $this->db->select('*');
		$this->db->from('category_type_translation');
		$this->db->where('category_type_id',$cat_type_id);
		$this->db->where('language_id',$language_id);
		$query = $this->db->get();
		return $query->row();
    }
   
   
   function get_cat_type_info($cat_type_id){
        	$this->db->select('*');
		 //$this->db->where('language_id',1);
		 //	$this->db->join('product_attributes', 'product_attributes.product_id = products.product_id');
		 $this->db->where('category_type_id',$cat_type_id);
		//$this->db->order_by('product_id DESC');
        $this->db->from('category_types');
        $query = $this->db->get();
        //print $this->db->last_query();die;
	    $result = $query->row();

       
        return $result;
    }
   
   
   function update_translate($cat_type_id,$language_id){
       $update_att =array( 
			'category_type' => $this->input->post("category_type"),
			'category_description' => $this->input->post("description"),
			);	
		 $this->db->where('category_type_id', $cat_type_id);
		 $this->db->where('language_id', $language_id);
		 $updateresult = $this->db->update('category_type_translation', $update_att);
   }
   
   function insertOldDigitalMedia($old_cat_type_id,$cat_id,$media_file_name,$mediapath=NULL){
	    $this->db->select('*');
			$this->db->from('category_types');
			$this->db->where('category_type_id',$old_cat_type_id);
			$this->db->where('icon',$media_file_name);
			$query = $this->db->get();
			//print $this->db->last_query();die;
			if($query->num_rows() > 0)
			{	
                
				//Copy File	if exists			
				 if ($mediapath!='') {
				
				    $new_media_file=$cat_id."_".time()."_".$media_file_name;
					$oldfile = $mediapath."/".$media_file_name; 
					$newfile = $mediapath."/".$new_media_file;
					copy($oldfile, $newfile);
					//print $new_media_file;die;
					 
					 $update_att =array( 
        			'icon' => $new_media_file,
        			);	
        		 $this->db->where('category_type_id', $cat_id);
        		 $updateresult = $this->db->update('category_types', $update_att);
				 } 
				//print $this->db->last_query();die;
				return true;
			}
	}
   
   function add_translate($language_id,$cat_type_id)
	{   
	    $cat_type_info=$this->get_cat_type_info($cat_type_id);
		/*$data        = array(
		    'project_id'=>1,
			'category_type'     => $this->input->post("category_type"),
			'description'     => $this->input->post("description"),
			'language_id'     =>$language_id,
			'picture_min_limit'=>$cat_type_info->picture_min_limit,
			'picture_max_limit'=>$cat_type_info->picture_max_limit,
			'video_min_limit'=>$cat_type_info->video_min_limit,
			'video_max_limit'=>$cat_type_info->video_max_limit,
			'panorama_min_limit'=>$cat_type_info->panorama_min_limit,
			'panorama_max_limit'=>$cat_type_info->panorama_max_limit,
			'audio_min_limit'=>$cat_type_info->audio_min_limit,
			'audio_max_limit'=>$cat_type_info->audio_max_limit,
			'is_active'=>'1',
			'post_date'      => date('Y-m-d H:i:s')
        );*/
        $data        = array(
			'category_type'     => $this->input->post("category_type"),
			'category_type_id'=>$cat_type_id,
			'category_description'     => $this->input->post("description"),
			'language_id'     =>$language_id,
			'category_type_id'=>$cat_type_id,
			'post_date'      => date('Y-m-d H:i:s')
        );
        $result   =$this->db->insert('category_type_translation', $data);
		$cat_type_id1  = $this->db->insert_id();
		if($result > 0)
		{
            
           /* $entity_info       = array(
            'entity_type'   => 'category_type',
			'entity_id'     => $cat_type_id,
			'language_id'     => $language_id,
			'target_id'     => $cat_type_id1,
             );
            $entity_result   =$this->db->insert('language_entity', $entity_info);*/
            
            
            
            
		    $user_id=$this->session->userdata('user_id');
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $cat_type_id1;
		 }
		else
			return 0;


    } //End of add function
   
   function addCategoryType(){
	
         $data          = array(
		    'language_id'=>$this->session->userdata('lang_id'),
            'project_id'     		=>  $this->project_id,
            'category_type'     	=>  $this->category_type,
            'description'     		=>  $this->description,
            'picture_min_limit'     =>  $this->picture_min_limit,
            'video_min_limit'     	=>  $this->video_min_limit,
            'audio_min_limit'     	=>  $this->audio_min_limit,
            'panorama_min_limit'    =>  $this->panorama_min_limit,
            'picture_max_limit'     =>  $this->picture_max_limit,
            'video_max_limit'     	=>  $this->video_max_limit,
            'audio_max_limit'     	=>  $this->audio_max_limit,
            'panorama_max_limit'    =>  $this->panorama_max_limit,
            'post_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result  = $this->db->insert('category_types', $data);
		
		$id  = $this->db->insert_id();
		 if($result)
		 {
			 $this->add_interlinks($id);
			return $id;
		 }
		else
			return 0;
   
   }//End of addCategoryType
   
   
   function add_interlinks($category_type_id)
   {	
	  $data  = array(
		'language_id' => $this->session->userdata('lang_id'),
		'category_type_id'     => $category_type_id,
		'location_link'     => $this->input->post("location_link"),
		'vendor_link'     => $this->input->post("vendor_link"),
		'product_link'     => $this->input->post("product_link"),
		'created_on'      => date('Y-m-d H:i:s')
	   );
	  $result   = $this->db->insert('category_types_interlinks', $data);
   }
   
    function update_interlinks($category_type_id)
		 {
			    $this->db->select('cat_type_interlink_id');
				$this->db->from('category_types_interlinks');
				$this->db->where('language_id', $this->session->userdata('lang_id'));
				$this->db->where('category_type_id',$category_type_id);
				$query = $this->db->get();
			    if($query->num_rows() > 0 ){
				$data = array(
			   	'language_id' => $this->session->userdata('lang_id'),
				'location_link'     => $this->input->post("location_link"),
				'vendor_link'     => $this->input->post("vendor_link"),
				'product_link'     => $this->input->post("product_link"),
				);
			$this->db->where('category_type_id', $category_type_id);
			$result = $this->db->update('category_types_interlinks', $data);
		}else
		{
			  $data  = array(
			'language_id' => $this->session->userdata('lang_id'),
			'category_type_id'     => $category_type_id,
			'location_link'     => $this->input->post("location_link"),
			'vendor_link'     => $this->input->post("vendor_link"),
			'product_link'     => $this->input->post("product_link"),
			'created_on'      => date('Y-m-d H:i:s')
		   );
		  $result   = $this->db->insert('category_types_interlinks', $data);
		}
	 }
	
   function add_icon($category_type_id,$filename)
   {		

		$data     = array(
			'icon'     => $category_type_id.'_'.$filename
		);
		$this->db->where('category_type_id', $category_type_id);
		$result = $this->db->update('category_types', $data);
   }
	
   function update_image($category_type_id,$filename,$field_update)
   {		

		$data     = array(
			$field_update     => $category_type_id.'_'.$filename
		);
		$this->db->where('category_type_id', $category_type_id);
		$result = $this->db->update('category_types', $data);
   }
   
   function editCategoryType(){
           $data          = array(
            'project_id'     		=>  $this->project_id,
            'category_type'     	=>  $this->category_type,
            'description'     		=>  $this->description,
            'picture_min_limit'     =>  $this->picture_min_limit,
            'video_min_limit'     	=>  $this->video_min_limit,
            'audio_min_limit'     	=>  $this->audio_min_limit,
            'panorama_min_limit'    =>  $this->panorama_min_limit,
            'picture_max_limit'     =>  $this->picture_max_limit,
            'video_max_limit'     	=>  $this->video_max_limit,
            'audio_max_limit'     	=>  $this->audio_max_limit,
            'panorama_max_limit'    =>  $this->panorama_max_limit
        );
		$this->db->where('category_type_id', $this->category_type_id);
        $result  = $this->db->update('category_types', $data);
		if($result)
		{
			 $this->update_interlinks($this->category_type_id);
			return $this->category_type_id;
		}
		else
			return 0;
   }//End of editCategoryType
   
   
    function edit_category_types_interlinks($category_type_id)
	{
		$this->db->select('*');
		$this->db->from('category_types_interlinks');
		$this->db->where('language_id', $this->session->userdata('lang_id'));
		$this->db->where('category_type_id', $category_type_id);
		$query = $this->db->get();

		return $query->row();

	} //End of edit function
   
   function editCategoryTypeData(){
		$this->db->where('category_type_id',$this->category_type_id);         
		$query  = $this->db->get('category_types');		  
   		$result = $query->row(); 

		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editCategoryTypeData
   
   
   function viewCategoryTypes(){
		$this->db->select('category_types.*, projects.project_name');	
		$this->db->join('projects','category_types.project_id=projects.project_id','left');
		$this->db->where('category_types.language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('category_types');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } // End of viewCategoryType
}
?>