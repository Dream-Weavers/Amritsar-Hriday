<?php

class Survey_model extends CI_Model
{
   var $surveyId,$surveyAdminUserName,$surveyName,$surveyPassword;
   function Survey_model(){
	   $this->surveyAdminUserName    = 0;
	   $this->surveyName      		= 0;
	   $this->surveyPassword 		= 0;
	   $this->surveyId   			= 0;
   }
   
   function addSurvey(){
         $data          = array(
            'survey_name'     		=>  $this->surveyName,
            'description'     		=>  $this->description,
            'permission_access'     =>  $this->user_rights,
            'post_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result  = $this->db->insert('surveys', $data);
		
       if($result)
	   	return 1;
	   else
	   	return 0;
   
   }//End of addSurvey
	
   function editSurvey(){
         $data          = array(
            'survey_name'     		=>  $this->surveyName,
            'description'     			=>  $this->description,
			'permission_access'     =>  $this->user_rights,
        );
		$this->db->where('surveyid', $this->surveyId);
        $result  = $this->db->update('surveys', $data);
		if($result)
			return 1;
		else
			return 0;
   }//End of editSurvey
   
   function editSurveyData(){
		$this->db->where('surveyid',$this->surveyId);         
		$query  = $this->db->get('surveys');		  
   		$result = $query->row(); 
		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editSurveyData
   
   function viewSurveys(){		
		$query=$this->db->get('surveys');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } // End of viewSurvey
   
   
   function navigate_menus($default_opt){
		$this->db->select('*');
		$this->db->from('permissions');
		$this->db->where('is_parent','0');
		//$this->db->where('is_active','1');
		//$this->db->order_by('weight', 'ASC');
		$query = $this->db->get();
		$result = $query->result();
		echo "<div class='userrights'>";
		foreach($result as $res){
			$name=strtoupper($res->per_name);
			$ids=$res->permissionid;
			$links=$res->path;
			$key = array_search($ids,$default_opt);
			if( $key !== false ) {
			   $checked='checked';
			} else {
			   $checked='';
			}
			echo "<li><div class='md-checkbox'><input class='allselect md-check parent".$ids."' type='checkbox' ".$checked."  name='user_rights[]' id='user_rights".$ids."' value='".$ids."'><label for='user_rights".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name."</label></div>";
			
			
		$getchilds=$this->getchild_checkbox($ids,$default_opt,'parent',$ids);
		}
		echo "</div>";
		
	}
	function getchild_checkbox($cid,$default_opt,$child_sta,$parentid){

			$this->db->select('*');
			$this->db->from('permissions');
			$this->db->where('is_parent',$cid);
			//$this->db->where('is_active','1');
			//$this->db->order_by('weight', 'ASC');
			$query = $this->db->get();
			//echo $this->db->last_query();die;
			$countrows=$query->num_rows();
			
			if($countrows>0){
				$result = $query->result();
				/* echo "<pre>";
				print_r($result);
				die; */
				echo "<ul>";
				foreach($result as $childs){//echo "<pre>";print_r($childs);
					$name_get=strtoupper($childs->per_name);
					$links=$childs->path;
					$ids=$childs->permissionid;
					$key = array_search($ids,$default_opt);
					if( $key !== false ) {
					   $checked='checked';
					} else {
					   $checked='';
					}
					if($child_sta=='child'){
						$parentget=$parentid;
					} else {
						$parentget=$cid;
					}
					$classname = str_replace(' ', '_', $name_get);//echo $parentget;
					echo  "<li><div class='md-checkbox'><input class='md-check allselect getParentid$cid getAncestorid$parentget' type='checkbox' ".$checked."  name='user_rights[]' id='user_rights".$ids."' value='".$ids."'><label for='user_rights".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name_get."</label></div></li>";
					$nameof= $this->getchild_checkbox($ids,$default_opt,'child',$cid); 
				}
				echo "</ul>";
			}else{
				echo "</li>";
			}
			//return $output;
		}
}
?>