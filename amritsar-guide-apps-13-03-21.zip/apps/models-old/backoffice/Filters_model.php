<?php

class Filters_model extends CI_Model
{	
    function view_filters($filter_id,$status,$limit, $start)
    {
		$this->db->select('*');
		if($filter_id!='0')
		$this->db->like('filterid', $filter_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->order_by('filter_name','ASC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('filters');
		$this->db->where('language_id',$this->session->userdata('lang_id'));
        $query = $this->db->get();
	//  echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	function count_filters($filter_id,$status) {
		
		if($filter_id!='0')
		$this->db->like('filterid', $filter_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('filters');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
	function add()
	{   
		 $data        = array(
            'filter_name'     => $this->input->post("filter_name"),
			'weight'   => $this->input->post("weight"),
			'language_id'     => $this->session->userdata('lang_id'),
			'created_by '   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
        $result   = $this->db->insert('filters', $data);
		$filter_id  = $this->db->insert_id();
		if($result > 0)
		{
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$filter_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $filter_id;
		 }
		else
			return 0;


    } //End of add function
	

	
		 function filter_edit($filter_id)
		 {
			if ($filter_id == '') {
				redirect(base_url() . "backoffice/filters/view");
			}
			$this->db->select('*');
			$this->db->from('filters');
			$this->db->where('filterid', $filter_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_filter($filter_id)
		 {
			$data = array(
				 'filter_name'     => $this->input->post("filter_name"),
				 'weight'   => $this->input->post("weight")
			);
			$this->db->where('filterid', $filter_id);
			$result = $this->db->update('filters', $data);
			if($result > 0)
   		    {
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "filters";
				$operation = "Record updated";
				createLogFile($operation,$filter_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
    function update_status($filter_id, $status)
    {		$data = array(
				'is_active' => $status,
				
			);
        $this->db->where('filterid', $filter_id);
	    $result = $this->db->update('filters', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function


}