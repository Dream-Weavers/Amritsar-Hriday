<?php

class Rules_model extends CI_Model
{	

    function view_rules($rule_id,$limit, $start)
     {
		$this->db->select('*');
		if($rule_id!='0')
		$this->db->where('rule_id', $rule_id);
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('rule_name','ASC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('rules');
        $query = $this->db->get();
	//  echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	  function count_rules($rule_id) {
		
		if($rule_id!='0')
		$this->db->where('rule_id', $rule_id);
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('rules');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
		function add()
		{   
			$data  = array(
				'language_id' => $this->session->userdata('lang_id'),
				'rule_name'     => $this->input->post("rule_name"),
				'description'     => $this->input->post("description"),
				'created_by'      => $this->session->userdata('user_id'),
				'created_on'      => date('Y-m-d H:i:s')
			);
			$result   = $this->db->insert('rules', $data);
			$rule_id  = $this->db->insert_id();
			if($rule_id)
			{
				 //Category Types
				 if($this->input->post('choose_category_type')=='1')
				 {
				  $category_type_ids = $this->input->post("category_type_id"); 
				  if(is_array($category_type_ids))
				  {
				    foreach($category_type_ids as $typekey=> $typeid){
						if($typeid!='') 
						{   $this->db->select('rule_interlink_id');
							$this->db->from('rule_interlinks');
							$this->db->where('language_id', $this->session->userdata('lang_id'));
							$this->db->where('rule_id',$this->input->post("rule_id"));
							$this->db->where('category_type_id',$typeid);
							$cattype_result = $this->db->get();
							if($cattype_result->num_rows() == 0)
							{  $data  = array(
									'language_id' => $this->session->userdata('lang_id'),
									'rule_id'     => $rule_id,
									'category_type_id'     => $typeid,
									'created_on'      => date('Y-m-d H:i:s')
								);
								$interlinkresult   = $this->db->insert('rule_interlinks', $data);
							}
					    }
				      }
				    }
				  }	
				 //Categories
				 if($this->input->post('choose_category')=='2')
				 {
				   $category_ids = $this->input->post("category_id"); 
				   if(is_array($category_ids))
				   {
				           foreach($category_ids as $catkey=> $catid){
							if($catid!='') 
							{   $this->db->select('rule_interlink_id');
								$this->db->from('rule_interlinks');
								$this->db->where('language_id', $this->session->userdata('lang_id'));
								$this->db->where('rule_id',$this->input->post("rule_id"));
								$this->db->where('category_id',$catid);
								$cat_result = $this->db->get();
								if($cat_result->num_rows() == 0)
								{  
							  		$data  = array(
										'language_id' => $this->session->userdata('lang_id'),
										'rule_id'     => $rule_id,
										'category_id'     => $catid,
										'created_on'      => date('Y-m-d H:i:s')
									);
									$interlinkresult   = $this->db->insert('rule_interlinks', $data);
								}
						   }
				    	}
				    }
				  }	
				  
				//Locations
				 if($this->input->post('choose_locations')=='3')
				 {
					 if(is_array($_POST['group-a']))
					  {
						$GroupLists =$_POST['group-a'];  
						foreach($GroupLists as $key=> $listrow){
							
							if($listrow['location_id']!='') 
							$feild = array('language_id' =>$this->session->userdata('lang_id'),'rule_id' =>$rule_id,'location_id' =>$listrow['location_id']);
							$locresult = check_unique('rule_interlinks',$feild);
							if($locresult==0)
							{	
							$data  = array(
								'language_id' => $this->session->userdata('lang_id'),
								'rule_id'     => $rule_id,
								'location_id'     => $listrow['location_id'],
								'created_on'      => date('Y-m-d H:i:s')
							);
							$interlinkresult   = $this->db->insert('rule_interlinks', $data);
							}
						}
						 }
				 }
				 
				  //Vendors
				 if($this->input->post('choose_vendors')=='4')
				 {
				   $vendor_ids = $this->input->post("vendor_id"); 
				   if(is_array($vendor_ids))
				   {
				           foreach($vendor_ids as $vendkey=> $vendid){
							if($vendid!='') 
							{   $this->db->select('rule_interlink_id');
								$this->db->from('rule_interlinks');
								$this->db->where('language_id', $this->session->userdata('lang_id'));
								$this->db->where('rule_id',$this->input->post("rule_id"));
								$this->db->where('vendor_id',$vendid);
								$vend_result = $this->db->get();
								if($vend_result->num_rows() == 0)
								{  
							  		$data  = array(
										'language_id' => $this->session->userdata('lang_id'),
										'rule_id'     => $rule_id,
										'vendor_id'     => $vendid,
										'created_on'      => date('Y-m-d H:i:s')
									);
									$interlinkresult   = $this->db->insert('rule_interlinks', $data);
								}
						   }
				    	}
				    }
				  }	
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "rules";
				$operation = "Record added";
				createLogFile($operation,$rule_id,$update_by_id,$table_name);
			 }
			 if($result){
				return $rule_id;
			 }
			else
				return 0;
	
	
		} //End of add function
	
	  function view_rule_interlinks($language_id,$rule_id,$type)
		{
			if($type=='cattype')
			{
				$this->db->select('rules.*,rule_interlinks.*,category_types.category_type');
				$this->db->from('rules');
				$this->db->join('rule_interlinks', 'rule_interlinks.rule_id = rules.rule_id');
				$this->db->join('category_types', 'category_types.category_type_id = rule_interlinks.category_type_id');
				$this->db->where('rules.rule_id', $rule_id);
				$this->db->order_by('category_types.category_type', 'ASC');
			}
			if($type=='category')
			{
				$this->db->select('rules.*,rule_interlinks.*,categories.category_name');
				$this->db->from('rules');
				$this->db->join('rule_interlinks', 'rule_interlinks.rule_id = rules.rule_id');
				$this->db->join('categories', 'categories.category_id = rule_interlinks.category_id');
				$this->db->where('rules.rule_id', $rule_id);
				$this->db->order_by('categories.category_name', 'ASC');
			}
			if($type=='location')
			{
				$this->db->select('rules.*,rule_interlinks.*,locations.location_name');
				$this->db->from('rules');
				$this->db->join('rule_interlinks', 'rule_interlinks.rule_id = rules.rule_id');
				$this->db->join('locations', 'locations.location_id = rule_interlinks.location_id');
				$this->db->where('rules.rule_id', $rule_id);
				$this->db->order_by('locations.location_name', 'ASC');
			}
			if($type=='vendor')
			{
				$this->db->select('rules.*,rule_interlinks.*,users.user_id,users.first_name,users.last_name,vendor_details.shop_title');
				$this->db->from('rules');
				$this->db->join('rule_interlinks', 'rule_interlinks.rule_id = rules.rule_id');
				$this->db->join('users', 'users.user_id = rule_interlinks.vendor_id');
				$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id');
				$this->db->where('rules.rule_id', $rule_id);
				$this->db->order_by('users.user_id', 'ASC');
			}
			$query = $this->db->get();
			//echo $this->db->last_query();
			$result = $query->result();
			return $result;
	
		} //End of View function
		
	
		 function rule_edit($rule_id)
		 {
			if ($rule_id == '') {
				redirect(base_url() . "backoffice/rules/view");
			}
			$this->db->select('*');
			$this->db->from('rules');
			$this->db->where('rule_id', $rule_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_rule($rule_id)
		 {
			$data = array(
			   	'language_id' => $this->session->userdata('lang_id'),
				'rule_name'     => $this->input->post("rule_name"),
				'description'     => $this->input->post("description"),
				'modified_by'      => $this->session->userdata('user_id')
			);
			$this->db->where('rule_id', $rule_id);
			$result = $this->db->update('rules', $data);
			if($result > 0)
   		    {	$this->db->select('rule_interlink_id');
				$this->db->from('rule_interlinks');
				$this->db->where('language_id', $this->session->userdata('lang_id'));
				$this->db->where('rule_id',$rule_id);
				$query = $this->db->get();
			    if($query->num_rows() > 0 ){
					$this->db->where('language_id', $this->session->userdata('lang_id'));
					$this->db->where('rule_id',$rule_id);
					$resultdelete = $this->db->delete('rule_interlinks');
			     }
		   		 //Category Types
				 if($this->input->post('choose_category_type')=='1')
				 {
				  $category_type_ids = $this->input->post("category_type_id"); 
				  if(is_array($category_type_ids))
				  {
				    foreach($category_type_ids as $typekey=> $typeid){
						if($typeid!='') 
						{   $this->db->select('rule_interlink_id');
							$this->db->from('rule_interlinks');
							$this->db->where('language_id', $this->session->userdata('lang_id'));
							$this->db->where('rule_id',$this->input->post("rule_id"));
							$this->db->where('category_type_id',$typeid);
							$cattype_result = $this->db->get();
							if($cattype_result->num_rows() == 0)
							{  $data  = array(
									'language_id' => $this->session->userdata('lang_id'),
									'rule_id'     => $rule_id,
									'category_type_id'     => $typeid,
									'created_on'      => date('Y-m-d H:i:s')
								);
								$interlinkresult   = $this->db->insert('rule_interlinks', $data);
							}
					    }
				      }
				    }
				  }	
				 //Categories
				 if($this->input->post('choose_category')=='2')
				 {
				   $category_ids = $this->input->post("category_id"); 
				   if(is_array($category_ids))
				   {
				           foreach($category_ids as $catkey=> $catid){
							if($catid!='') 
							{   $this->db->select('rule_interlink_id');
								$this->db->from('rule_interlinks');
								$this->db->where('language_id', $this->session->userdata('lang_id'));
								$this->db->where('rule_id',$this->input->post("rule_id"));
								$this->db->where('category_id',$catid);
								$cat_result = $this->db->get();
								if($cat_result->num_rows() == 0)
								{  
							  		$data  = array(
										'language_id' => $this->session->userdata('lang_id'),
										'rule_id'     => $rule_id,
										'category_id'     => $catid,
										'created_on'      => date('Y-m-d H:i:s')
									);
									$interlinkresult   = $this->db->insert('rule_interlinks', $data);
								}
						   }
				    	}
				    }
				  }	
				  
				 //Locations
				 if($this->input->post('choose_locations')=='3')
				 {
					 if(is_array($this->input->post("locationid")))
					  {
					   $locationids = $this->input->post("locationid");	
					   foreach($locationids as $lockey=> $locid){
						$location_id = $_POST['locationid'][$lockey];
						
						$feild = array('language_id' =>$this->session->userdata('lang_id'),'rule_id' =>$rule_id,'location_id' =>$location_id);
						$locresult = check_unique('rule_interlinks',$feild);
						if($locresult==0)
						{	
						 $data  = array(
							'language_id' => $this->session->userdata('lang_id'),
							'rule_id'     => $rule_id,
							'location_id'     => $location_id,
							'created_on'      => date('Y-m-d H:i:s')
					     );
					     $interlinkresult   = $this->db->insert('rule_interlinks', $data);
						}
					  }
					 }
					 
					 if(is_array($_POST['group-a']))
					  {
						$GroupLists =$_POST['group-a'];  
						/*echo "<pre>";
						print_r($GroupLists);
						echo "</pre>";
						die();*/
						foreach($GroupLists as $key=> $listrow){
							if($listrow['location_id']!='') 
							$feild = array('language_id' =>$this->session->userdata('lang_id'),'rule_id' =>$rule_id,'location_id' =>$listrow['location_id']);
							$locresult = check_unique('rule_interlinks',$feild);
							if($locresult==0)
							{	
							 $data  = array(
								'language_id' => $this->session->userdata('lang_id'),
								'rule_id'     => $rule_id,
								'location_id'     => $listrow['location_id'],
								'created_on'      => date('Y-m-d H:i:s')
							 );
							$interlinkresult   = $this->db->insert('rule_interlinks', $data);
							}
						}
					 }
				  }
				
				 //Vendors
				 if($this->input->post('choose_vendors')=='4')
				 {
				   $vendor_ids = $this->input->post("vendor_id"); 
				   if(is_array($vendor_ids))
				   {
				           foreach($vendor_ids as $vendkey=> $vendid){
							if($vendid!='') 
							{   $this->db->select('rule_interlink_id');
								$this->db->from('rule_interlinks');
								$this->db->where('language_id', $this->session->userdata('lang_id'));
								$this->db->where('rule_id',$this->input->post("rule_id"));
								$this->db->where('vendor_id',$vendid);
								$vend_result = $this->db->get();
								if($vend_result->num_rows() == 0)
								{  
							  		$data  = array(
										'language_id' => $this->session->userdata('lang_id'),
										'rule_id'     => $rule_id,
										'vendor_id'     => $vendid,
										'created_on'      => date('Y-m-d H:i:s')
									);
									$interlinkresult   = $this->db->insert('rule_interlinks', $data);
								}
						   }
				    	}
				    }
				  }	
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "rules";
				$operation = "Record updated";
				createLogFile($operation,$rule_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	  
    function update_status($rule_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('rule_id', $rule_id);
	    $result = $this->db->update('rules', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function
	
	
		
 function update_default_rule($rule_id)
    {
		 $data = array(
				'is_default' => '1',
			);
        $this->db->where('rule_id', $rule_id);
	    $result = $this->db->update('rules', $data);
		
		$updatedata = array(
				'is_default' => '0',
			);
        $this->db->where('rule_id != ', $rule_id);
        $updateresult = $this->db->update('rules', $updatedata);
		if($updateresult)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function	
	
	
	function delete_rule_location($rule_interlink_id){
	   // Check first Player id exists or not if not than no delete 	
	    $this->db->select('rule_interlink_id');
		$this->db->from('rule_interlinks');
		$this->db->where('rule_interlink_id',$rule_interlink_id);
		$this->db->where('language_id', $this->session->userdata('lang_id'));
		$query = $this->db->get();
	   if($query->num_rows() > 0 ){
		   $this->db->where('rule_interlink_id',$rule_interlink_id);
		   $this->db->where('language_id', $this->session->userdata('lang_id'));
		   $result = $this->db->delete('rule_interlinks');
		   if($result)
			{
			  return '1';
			}
	   }
	   else{
		     return '0';
	      }
 	 }
	

}