<?php

class Tours_model extends CI_Model
{
   
   function addTours(){
	
         $data          = array(
			'language_id'=>$this->session->userdata('lang_id'),
			'user_id'=>$this->session->userdata('user_id'),
            'tour_trail_name'     	=>  $this->tour_name,
            'tour_trail_description'     		=>  $this->description,
            'modified_by'     		=>  $this->session->userdata('user_id'),
            'created_on'       		=>  date('Y-m-d H:i:s'),
        );
        $result = $this->db->insert('tour_trails', $data);
		
		$id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0;
   
   }//End of addTours
   
    function location_names($tour_id){
		$this->db->select('locations.location_name, tour_trail_locations.*');
		$this->db->join('locations','locations.location_id=tour_trail_locations.location_id');
		$this->db->where('tour_trail_locations.tour_trail_id',$tour_id);
		$this->db->order_by('tour_trail_locations.weight','asc');
		$query=$this->db->get('tour_trail_locations');
   		$result = $query->result();	
		return $result; 
	}
 
   function module_field_sorting($tablename,$primary_field){
		$components=$_POST['components'];
		foreach($components as $key=>$sorting){
			$cid=$key;
			$weight=$sorting['weight'];
			$value=array('weight'=>$weight);
			//$this->db->where('report_weight_id',$cid);
			$this->db->where($primary_field,$cid);
			//$this->db->where('company_id',$this->session->userdata('master_id'));
			$result=$this->db->update($tablename,$value);
		}
		if($result){
			return true;
		}else{
			return false;
		}
	}
	
	function addTourLocations($location_id=NULL, $tour_id=NULL){
	
         $data          = array(
			'tour_trail_id'     	=>  $tour_id,
            'location_id'     		=>  $location_id
        );
         $this->db->insert('tour_trail_locations', $data);
		
		/* $id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0; */
			return 1;
    
   }//End of addTours
   

   
   function add_icon($tour_id,$filename)
   {			
		$data     = array(
			'tour_trail_image'     => $tour_id.'_'.$filename
		);
		$this->db->where('tour_trail_id', $tour_id);
		$result = $this->db->update('tour_trails', $data);
   }
	function get_all_locations_data(){ 
			$this->db->select('locations.location_id, locations.location_name,locations.estimated_visit_time ,state.state_name,locality.locality_name,city.city_name,location_categories.category_type_id,location_categories.category_id');
			$this->db->join('locality','locality.locality_id=locations.locality_id');
			$this->db->join('state','state.state_id=locations.state_id');
			$this->db->join('city','city.city_id=locations.city_id');
			$this->db->join('location_categories','locations.location_id=location_categories.location_id');
			$this->db->where('locations.is_active','1');
			
			
			$this->db->where('location_categories.is_active','1');	 
			$this->db->group_by("location_categories.location_id");				
			//$this->db->group_by(array("location_categories.category_type_id", "location_categories.category_id","location_categories.location_id"));				
			$query = $this->db->get('locations');	  	
			$result=$query->result(); 
			
			/* echo "<pre>";
			print_r($result);
			die; */
			
			$estimated_time_array = get_estimated_time_array();

			foreach($result as $key=>$row){
				 if($row->estimated_visit_time!='00:00:00' && $row->estimated_visit_time!='')
				 $result[$key]->estimated_visit_time = $estimated_time_array[$row->estimated_visit_time]; 
				 else
				 $result[$key]->estimated_visit_time='';
			}
														 
			//echo $this->db->last_query();die;	
			return $result;
	 }
		 
   function editTours($tour_id){
		$data          = array(
			'tour_trail_name'     	=>  $this->input->post('tour_name'),
            'tour_trail_description'     		=>  $this->input->post('description'),
            'modified_by'     		=>  $this->session->userdata('user_id')
        );
		$this->db->where('tour_trail_id', $tour_id);
		$result=$this->db->update('tour_trails', $data);
		if($result)
			return 1;
		else
			return 0;
   }//End of editTours
   
   function editToursData(){
		$this->db->where('tour_id',$this->tour_id);         
		$query  = $this->db->get('tour_trails');		  
   		$result = $query->row(); 

		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editToursData
   
   
   
     function updateTourFilter($tour_id,$filterList)
 	  {
		/*echo "<pre>";
		print_r($filterList);
		echo "</pre>";
	die();*/
		$insertresult=false;
		if(is_array($filterList))
		{
		 $done=0; 	
		 $already=0; 
		 $fields=array('tour_id'=>$tour_id,'is_active'=>'1');
	     $filterresult=gettableresult('tour_filters',$fields);
	     if(is_array($filterresult))
	     {
		  foreach($filterresult as $grow){
			 if(!in_array($grow->filterid,$filterList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('tour_id', $tour_id);
			  $this->db->where('filterid',$grow->filterid);
			  $updateresult = $this->db->update('tour_filters', $data);
			}
		  }
		 }
		foreach($filterList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('tour_filter_id');
						$this->db->from('tour_filters');
						$this->db->where('tour_id',$tour_id);
						$this->db->where('filterid',$listrow);
						$filter_result = $this->db->get();
						if($filter_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $filter_result->row();	
						      $tour_filter_id = $tgrow->tour_filter_id;
							  $this->db->where('tour_filter_id', $tour_filter_id);
							  $this->db->where('tour_id', $tour_id);
							  $this->db->where('filterid',$listrow);
							  $updateresult = $this->db->update('tour_filters', $data);
						}else
						{
							$this->db->select('tour_filter_id');
							$this->db->from('tour_filters');
							$this->db->where('tour_id',$tour_id);
							$this->db->where('filterid',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{ 
							 $fields = array('tour_id'=>$tour_id);
							 $weightmax = get_max_values('tour_filters',$fields,'weight');
																		  
							  $data_type =array( 
								'tour_id'   =>  $tour_id,
								'filterid'    =>  $listrow,
								'weight'    =>  $weightmax,
								'created_by'    =>  $this->session->userdata('user_id'),
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('tour_filters',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	

	function update_status($tour_id, $status)

    {

	     $data = array(

				'is_active' => $status,

		);


        $this->db->where('tour_trail_id', $tour_id);

        $result = $this->db->update('tour_trails', $data);

		if($result)

		  return '1';

		 else 

		 return '0';



    } //End of Update status function
	
	
    function delete_data($tour_trail_location_id){
		$this->db->where('tour_trail_location_id', $tour_trail_location_id);
		$this->db->delete('tour_trail_locations');
	}
	
    function get_edited_data($tour_id){
		$this->db->select('*');
		$this->db->where('tour_trail_id',$tour_id);
		$query=$this->db->get('tour_trail_locations');
   		$result = $query->result_array(); 
		
		return $result;
   } 
    function viewTours($tour_name, $created_by, $status){
		$this->db->select('*');
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		if($tour_name!='')		
		$this->db->where("tour_trail_name LIKE '%$tour_name%'");	
		if($created_by!='')	{	
			if($created_by=='s'){
				$this->db->where("user_id=1");
			} else if($created_by=='u'){
				$this->db->where("user_id!=1");
			}	
		}
		if($status!='0')	
		{
			if($status == 'a')	
			{	
				$status = '1';		
			}	else	{	
				$status = '0';
			}			
			$this->db->where('is_active',$status);		
		}
		$this->db->order_by('tour_trail_id','desc');
		$query=$this->db->get('tour_trails');
		//echo $this->db->last_query(); 
   		$result = $query->result(); 
		return $result;
   } // End of viewTours 
   
   function viewPredefinedTours($tour_name, $created_by, $status){
		$this->db->select('*');
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		if($tour_name!='')		
		$this->db->where("tour_trail_name LIKE '%$tour_name%'");	
		if($created_by!='')	{	
			if($created_by=='s'){
				$this->db->where("user_id=1");
			} else if($created_by=='u'){
				$this->db->where("user_id!=1");
			}	
		}
		if($status!='0')	
		{
			if($status == 'a')	
			{	
				$status = '1';		
			}	else	{	
				$status = '0';
			}			
			$this->db->where('is_active',$status);		
		}
		$this->db->where('user_id',1);
		$this->db->order_by('tour_trail_id','desc');
		$query=$this->db->get('tour_trails');
		//echo $this->db->last_query(); 
   		$result = $query->result(); 
		return $result;
   } 
   function viewUserTours($tour_name, $created_by, $status){
		$this->db->select('*');
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		if($tour_name!='')		
		$this->db->where("tour_trail_name LIKE '%$tour_name%'");	
		if($created_by!='')	{	
			if($created_by=='s'){
				$this->db->where("user_id=1");
			} else if($created_by=='u'){
				$this->db->where("user_id!=1");
			}	
		}
		if($status!='0')	
		{
			if($status == 'a')	
			{	
				$status = '1';		
			}	else	{	
				$status = '0';
			}			
			$this->db->where('is_active',$status);		
		}
		$this->db->where("user_id!=1");
		$this->db->order_by('tour_trail_id','desc');
		$query=$this->db->get('tour_trails');
		//echo $this->db->last_query(); 
   		$result = $query->result(); 
		return $result;
   } 
   
   function fetch_record($tour_id){
		$this->db->select('*');
		$this->db->where('tour_trail_id',$tour_id);
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		
		$query=$this->db->get('tour_trails');
   		$result = $query->row(); 
		return $result;
   } // End of viewTours 
   
}
?>