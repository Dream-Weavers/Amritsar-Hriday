<?php

class User_model extends CI_Model
{
	
	 function view_users()
		{
			$this->db->select('users.*,roles.role_name');
			$this->db->from('users');
			$this->db->join('roles','users.assigned_role=roles.roleid','left');
			
			$this->db->where('users.delete_id','0');
			$this->db->where('users.user_id!=','1');
			$this->db->order_by('users.user_id', 'DESC');
			$query = $this->db->get();
			//echo $this->db->last_query();die;
			$results = $query->result();
	/* 			//Count Total newss Images Records
			foreach ($results as $row) {
				
				$row->total_images= $this->count_news_images($row->news_id);
			} */
			return $results;
		} //End of View function
		
		
	function fetchuser($userid)
	{
		$this->db->select('users.*');
		$this->db->from('users');
		$this->db->order_by('user_id', 'DESC');
		$this->db->where('user_id',$userid);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->row();
		return $results;
	} //End of View function		
	
	   
	 function add()
     {
		 //$password= password_generate(10);
         $data        = array(
		    'first_name'     => $this->input->post("user_name"), 
		    'email'    => $this->input->post("email"), 
		    'mobile_no1'   => $this->input->post("mobile"), 
		    'assigned_role'   => $this->input->post("assign_role"), 
		    //'password' => md5($password), 
			'reg_date' => date('Y-m-d H:i:s')
			 
        );
        $result   = $this->db->insert('users', $data);
		$user_id  = $this->db->insert_id();
		if($user_id!=''){
			$unique_code= password_generate(4);
			$data        = array(
				'unique_code'     => $user_id.$unique_code  
			);
			$this->db->where('user_id', $user_id);
			$this->db->update('users', $data);
		}
		if($result)
		{ 
			/* if($this->input->post("report_to")!=''){
				
				$report_to_user_details=user_details($this->input->post("report_to"));
				
				//Send Email Link to upload documents of employees under him/her
				$config = Array(
					'protocol' => 'mail',
					'mailtype' =>'html'
				);

				$this->email->initialize($config);
				$this->email->set_newline("\r\n");
				$this->email->set_mailtype("html");
				$this->email->from('hr@dreamweaversindia.com'); // change it to yours
				$this->email->to($report_to_user_details->email); // change it to yours";
				$this->email->subject('Hriday - Registration');
				
				$emp_name = ucwords($this->input->post("user_name"));
				$name = ucwords($report_to_user_details->name);
				
				$html = '<table style="width:100% !important;">
				<tr>
				<td></td>
				<td style="clear: both !important;display: block !important;margin: 0 auto !important;max-width: 600px !important;">

				<div style=" display: block;margin: 0 auto;max-width: 600px;padding: 15px;">
				<table>
				<tr>
				<td align="right"><h6
				style="color: #444444;font-size: 14px;font-weight: 900;margin: 0 !important;text-transform: uppercase;">&nbsp;
				</h6></td>
				</tr>
				</table>
				</div>

				</td>
				<td></td>
				</tr>
				</table>
				<!-- /HEADER -->


				<!-- BODY -->
				<table style="width:100%;">
				<tr>
				<td></td>
				<td style="clear: both !important;display: block !important;margin: 0 auto !important;max-width: 600px !important;"
				bgcolor="#FFFFFF">

				<div style="display: block;margin: 0 auto;max-width: 600px;padding: 15px;">
				<table>
				<tr>
				<td>
				<h4>Hi, '.$name.' </h4>

				<h4> Employee has successfully registered under your Team. Details are given below:-<br />
					<table>
						<tr><th>Name:</th><td>'.$emp_name.'</td></tr>
						<tr><th>Email</th><td>'.$this->input->post("email").'</td></tr>
						<tr><th>Mobile</th><td>'.$this->input->post("mobile").'</td></tr>
					</table>
				</h4>
				
				Please upload all the documents of your employee by clicking following after your login :-<br /><br />
					<a href="'.base_url().'manager/documents/add/'.$user_id.$unique_code.'">Upload Documents</a><br /><br />
				Thank you!
				<br />
				Warm Regards,<br>
				Team Hriday

				</h4>


				</td>
				</tr>
				</table>
				</div>
				<!-- /content -->

				</td>
				<td></td>
				</tr>
				</table>';
				$this->email->message($html);

				if ($this->email->send()) { //Update Last Key User Records
				   /*  $data = array(
						'last_key'      => $last_key,
						'last_key_date' => date('Y-m-d H:i:s'),
					);
					$this->db->where('user_id', $row->user_id);
					$this->db->update('users', $data);

					return '1'; 
					
					return $user_id;

				} else {
					//show_error($this->email->print_debugger());
					return '2';
				}
			} else {
				//Send Email
				$config = Array(
					'protocol' => 'mail',
					'mailtype' =>'html'
				);

				$this->email->initialize($config);
				$this->email->set_newline("\r\n");
				$this->email->set_mailtype("html");
				$this->email->from('hr@dreamweaversindia.com'); // change it to yours
				$this->email->to(strtolower($this->input->post("email"))); // change it to yours";
				$this->email->subject('Hriday - Registration');
				
				$name = ucwords($this->input->post("user_name"));
				
				$html = '<table style="width:100% !important;">
				<tr>
				<td></td>
				<td style="clear: both !important;display: block !important;margin: 0 auto !important;max-width: 600px !important;">

				<div style=" display: block;margin: 0 auto;max-width: 600px;padding: 15px;">
				<table>
				<tr>
				<td align="right"><h6
				style="color: #444444;font-size: 14px;font-weight: 900;margin: 0 !important;text-transform: uppercase;">&nbsp;
				</h6></td>
				</tr>
				</table>
				</div>

				</td>
				<td></td>
				</tr>
				</table>
				<!-- /HEADER -->


				<!-- BODY -->
				<table style="width:100%;">
				<tr>
				<td></td>
				<td style="clear: both !important;display: block !important;margin: 0 auto !important;max-width: 600px !important;"
				bgcolor="#FFFFFF">

				<div style="display: block;margin: 0 auto;max-width: 600px;padding: 15px;">
				<table>
				<tr>
				<td>
				<h4>Hi, '.$name.' </h4>

				<h4>You have successfully registered. You details are given below:-<br /><br />
					<strong>Email: '.$this->input->post("email").'</strong><br />
					<strong>Password: '.$password.'</strong>
				</h4>
				
				<h4>Please login through following link by filling your email and password. <br/></h4>
				<a href="'.PATH_TO_APPLICATION.'manager/">'.PATH_TO_APPLICATION.'manager/</a>
				<h4>
				Thank you!
				<br />
				Warm Regards,<br>
				Team Hriday

				</h4>


				</td>
				</tr>
				</table>
				</div>
				<!-- /content -->

				</td>
				<td></td>
				</tr>
				</table>';
				$this->email->message($html);

				if ($this->email->send()) { //Update Last Key User Records
				   /*  $data = array(
						'last_key'      => $last_key,
						'last_key_date' => date('Y-m-d H:i:s'),
					);
					$this->db->where('user_id', $row->user_id);
					$this->db->update('users', $data);

					return '1'; 
					
					return $user_id;

				} else {
					//show_error($this->email->print_debugger());
					return '2';
				}
			} */
			return 1;
		} else {
			return 0;
		}
    } //End of add function
	
	function user_edit($user_id)
	{
		if ($user_id == '') {
			redirect(base_url() . "backoffice/users");
		}
		$this->db->select('*');
		$this->db->where('user_id', $user_id);
		$this->db->from('users');
		$query = $this->db->get();

		return $query->row();

	} //End of edit function
	
	
	 function delete_record($user_id){
		  $data        = array( 
		    'delete_id'     => 1
		  );
		$this->db->where('user_id', $user_id);
		$result = $this->db->update('users', $data);
		if ($result)
		   return 1;
		 else
		   return 0;
	 }
	 function update_users($user_id)
	 {
		$data        = array( 
		    'first_name'     => $this->input->post("user_name"), 
		    'email'     => $this->input->post("email"),  
		    'mobile_no1'     => $this->input->post("mobile"), 
			'assigned_role'   => $this->input->post("assign_role"),
			'edit_date'      => date('Y-m-d H:i:s')
			);

		
		$this->db->where('user_id', $user_id);
		$result = $this->db->update('users', $data);
		if ($result)
		   return 1;
		 else
		   return 0;
		
	 } //End of Update function
		 
    function update_status($user_id, $status_id)
    {
		 	$data = array(
				'verification_status' => $status_id,
				'verified_date '      => date('Y-m-d H:i:s')
			);
        $this->db->where('user_id', $user_id);
        $result = $this->db->update('users', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
}