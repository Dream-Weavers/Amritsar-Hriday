<?php

class Vendors_model extends CI_Model
{	
    function view_users($search_value,$limit, $start)
    {
		$this->db->select('users.user_id,users.first_name,users.last_name,users.email,users.gender,users.date_of_birth,users.mobile_no1,users.created_by,users.created_on,users.is_active,user_address.country_id,user_address.state_id,user_address.city_id,user_address.pin_code,user_address.address, vendor_details.*');
		$this->db->where('users.user_type','V');
		$this->db->where('users.email!=','');
		$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
		$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','LEFT');
		
		if($search_value!='0')
		{
		   $where = "(users.first_name LIKE  '%".trim($search_value)."%' or users.last_name LIKE  '%".trim($search_value)."%' or users.email LIKE  '%".trim($search_value)."%' or users.mobile_no1  LIKE  '%".trim($search_value)."%' or vendor_details.shop_title LIKE  '%".trim($search_value)."%' or vendor_details.shop_address LIKE  '%".trim($search_value)."%')";
		   $this->db->where($where);
		}
		/* if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('users.is_active',$status);
		}  */	
		$this->db->group_by('users.user_id'); 
		$this->db->order_by('users.user_id DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('users');
        $query = $this->db->get();
	    //echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	function viewbeaconvendors($vendor_id)
     	{
			$this->db->select('beacon_vendors.*,beacon_vendor_actions.action_plan_id,beacon_vendor_actions.instruction_id,beacon_vendor_actions.sound_file_id');
			$this->db->from('beacon_vendors');
			$this->db->join('beacon_vendor_actions', 'beacon_vendor_actions.beacon_vendor_id = beacon_vendors.beacon_vendor_id');
			$this->db->where('beacon_vendors.vendor_id', $vendor_id);
			$this->db->order_by('beacon_vendors.beacon_vendor_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	function get_beacons_dropdown()
    {   $this->db->select('*');
        $this->db->from('beacons');
		$this->db->where('is_active','1');
		$this->db->order_by('beacon_unique_id','ASC');
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select';
            foreach ($result->result_array() as $row) {
                $return[$row['beacon_unique_id']] = $row['beacon_unique_id'].' - '.$row['beacon_name'];
            }
        }
        return $return;
    }
	
	function count_users($search_value) {
		$this->db->where('users.user_type','V');
		$this->db->where('users.email!=','');
		$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
		$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','LEFT');
		
		if($search_value!='0')
		{
		   $where = "(users.first_name LIKE  '%".trim($search_value)."%' or users.last_name LIKE  '%".trim($search_value)."%' or users.email LIKE  '%".trim($search_value)."%' or users.mobile_no1  LIKE  '%".trim($search_value)."%' or vendor_details.shop_title LIKE  '%".trim($search_value)."%' or vendor_details.shop_address LIKE  '%".trim($search_value)."%')";
		   $this->db->where($where);
		}
		/* if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('users.is_active',$status);
		} */	
		$this->db->group_by('users.user_id'); 
		$query=$this->db->get('users');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
	function add()
	{   
	
		 $salt           = create_salt($password=NULL);
		 $password  = $this->input->post("userpass");	
         $data        = array(
            'email'     => strtolower($this->input->post("email")),
			'password'=> SHA1($password.$salt),
			'salt'=>  $salt,
			'user_type'   => 'V',
			'first_name'   => $this->input->post("first_name"),
			'last_name'     => $this->input->post("last_name"),
			'gender'     => $this->input->post("gender"),
			'mobile_no1'     => $this->input->post("mobile_no1"),
			'created_by '   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
        $result   = $this->db->insert('users', $data);
		$user_id  = $this->db->insert_id();
		$vendorid=$user_id;
		
		if($_POST['productlisting']){ 
		    foreach($_POST['productlisting'] as $row){
		        $explode_data=explode("-",$row);
		        $data1        = array( 
                    'product_id'   => $explode_data[0],
        			'vendor_id'     => $vendorid,
        			'category_id'=>$explode_data[1],
                ); 
                $this->db->insert('vendor_product_categories', $data1);   
                unset($data1);
		    }
		}
		
		if($_POST['product_listing']){
		    foreach($_POST['product_listing'] as $row){
		        $data1        = array(
                    'product_id'   => $row,
        			'vendor_id'     => $vendorid,
                );
                $this->db->insert('vendor_products', $data1);
                unset($data1);
		    }
		}
		
		
		$data        = array(
		    'vendor_type_id'   => $this->input->post("vendor_type_id"),
            'shop_title'   => $this->input->post("shop_title"),
			'shop_address'     => $this->input->post("shop_address"),
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude"),
			'user_id'     => $user_id,
			'vendor_description'=>$this->input->post("vendor_description"),
			'created_date'      => date('Y-m-d H:i:s')
        );
        $this->db->insert('vendor_details', $data);
		
		if($result > 0)
		{
		    if($this->input->post("country_id")!='')
		    {
		     $user_address_id = $this->insertUserAddress($user_id);
			 $update_data =array( 
				'user_address_id' => $user_address_id,
			 );	
			 $this->db->where('user_id', $user_id);
			 $result = $this->db->update('users', $update_data);
		    }
		    
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $user_id;
		 }
		else
			return 0;


    } //End of add function
	
	
	function insertUserAddress($user_id)
 	  {
		   $address_data =array( 
		        'user_id' => $user_id,
				'country_id' => $this->input->post("country_id"),
				'state_id' => $this->input->post("state_id"),
				'city_id' => $this->input->post("city_id"),
				'pin_code' => $this->input->post("pin_code"),
				'is_primary'=>'1',
				'post_date'      => date('Y-m-d H:i:s')
			 );	
			 $result= $this->db->insert('user_address',$address_data);	
			 $user_address_id  = $this->db->insert_id();
			if($result)
				return $user_address_id;
			else
				return 0;
	}
	
	
	
		function updateUserAddress($user_id,$user_address_id)
		{			$address_data =array( 
					'country_id' => $this->input->post("country_id"),
					'state_id' => $this->input->post("state_id"),
					'city_id' => $this->input->post("city_id"),
					'address' => $this->input->post("address"),
					'pin_code' => $this->input->post("pin_code")
				 );	
				 $this->db->where('user_address_id', $user_address_id);
				 $this->db->where('user_id', $user_id);	
				 $result = $this->db->update('user_address', $address_data);
				if($result)
					return 1;
				else
					return 0;
		}
	
	function deleteLocBeacon($beacon_vendor_id){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('beacon_vendor_id',$beacon_vendor_id); 
	   $query = $this->db->get('beacon_vendors');
	   if($query->num_rows() > 0 ){
		   $this->db->where('beacon_vendor_id',$beacon_vendor_id); 
		   $result = $this->db->delete('beacon_vendors');
		   
		   $this->db->where('beacon_vendor_id',$beacon_vendor_id); 
		   $queryaction = $this->db->get('beacon_vendor_actions');
		   if($queryaction->num_rows() > 0 ){
			   $this->db->where('beacon_vendor_id',$beacon_vendor_id); 
			   $resultaction = $this->db->delete('beacon_location_actions');
		   }
		   if($result)
			{ return '1';
			}
	    }
	  	else{
		      return '0';
	        }
	}
	
		 function user_edit($user_id)
		 {
			if ($user_id == '') {
				redirect(base_url() . "backoffice/vendors/view");
			}
			$this->db->select('users.*,user_address.country_id,user_address.state_id,user_address.city_id,user_address.pin_code,user_address.address, vendor_details.*,vendor_distance_timings.*');
			$this->db->from('users');
			$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','LEFT');
			$this->db->join('vendor_distance_timings', 'users.user_id = vendor_distance_timings.vendor_id','LEFT');
			$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');
			$this->db->where('users.user_id', $user_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	    function deleteDigitalMedia($media_id){
		   // Check first record exists or not if not than no delete 	   
		   $this->db->where('vendor_media_id',$media_id); 
		   $query = $this->db->get('vendor_digital_media');
		   if($query->num_rows() > 0 ){
			  $row_media = $query->row();
			  
			   $this->db->where('vendor_media_id',$media_id); 
			   $result = $this->db->delete('vendor_digital_media');
			   if($result)
				{
				  return '1';
				}
		   }
			 else{
			 return '0';
		   } 
		   return 1;
		}
	
		 function update_user($user_id,$user_address_id,$working_hours)
		 {
			
			$data = array(
				'email'     => strtolower($this->input->post("email")),
				
				'first_name'   => $this->input->post("first_name"),
				'last_name'     => $this->input->post("last_name"),
				'gender'     => $this->input->post("gender"),
				
				
				'mobile_no1'     => $this->input->post("mobile_no1")
			);
			$this->db->where('user_id', $user_id);
			$result = $this->db->update('users', $data);
			
			$data        = array(
			'vendor_type_id'   => $this->input->post("vendor_type_id"),
            'shop_title'   => $this->input->post("shop_title"),
			'shop_address'     => $this->input->post("shop_address"),
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude"),
			'vendor_description'=>$this->input->post("vendor_description"),
			);
			$this->db->where('user_id', $user_id);
			$this->db->update('vendor_details', $data);
			
			
		
			
			$vendorid=$user_id;
			
			$this->db->where('vendor_id', $vendorid);
            $this->db->delete('vendor_product_categories');
            
            if($_POST['productlisting']){ 
		    foreach($_POST['productlisting'] as $row){
		        $explode_data=explode("-",$row);
		        $data1        = array( 
                    'product_id'   => $explode_data[0],
        			'vendor_id'     => $vendorid,
        			'category_id'=>$explode_data[1],
                ); 
                $this->db->insert('vendor_product_categories', $data1);   
                unset($data1);
		    }
		}
            
			$this->db->where('vendor_id',$vendorid); 
		    $this->db->delete('vendor_products');
    		if($_POST['product_listing']){
    		    foreach($_POST['product_listing'] as $row){
    		        $data1        = array(
                        'product_id'   => $row,
            			'vendor_id'     => $vendorid,
                    );
                    $this->db->insert('vendor_products', $data1);
                    unset($data1);
    		    }
    		}
			
			$data    = array(
				'airport_distance'     => $this->input->post("airport_distance"),
				'railway_station_distance'     => $this->input->post("railway_station_distance"),
				'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
				'city_centre_distance'     => $this->input->post("city_centre_distance"),
				
				'working_hours'     => $working_hours,
				
				'rules_regulations'     => $this->input->post("rules_regulations"),
				'visitors_in_month'     => $this->input->post("visitors_in_month"),
				'vendor_review'     => $this->input->post("vendor_review"),
				'remarks'     => $this->input->post("remarks")
			);
			$this->db->where('vendor_id', $user_id);
			$this->db->update('vendor_distance_timings', $data);
			
		
		
			if($result > 0)
   		    {
				if($this->input->post("country_id")!='')
				 {
					$user_address_id = $this->updateUserAddress($user_id,$user_address_id);
				 }
	
				if(isset($_POST['location_category']))
		        {	$updateresult = $this->updateLocationCategory($this->input->post("category_type_id"),$user_id,$_POST['location_category']);
				}
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
	 function updateLocationCategory($category_type_id,$vendor_id,$CategoryList)
 	  {
		/*echo "<pre>";
		print_r($CategoryList);
		echo "</pre>";*/
	
		$insertresult=false;
		if(is_array($CategoryList))
		{
		 $done=0; 	
		 $already=0; 	
		 $fields=array('vendor_id'=>$vendor_id,'is_active'=>'1');
	     $categoryresult=gettableresult('vendor_categories',$fields);
	     if(is_array($categoryresult))
	     {
		  foreach($categoryresult as $grow){
			 if(!in_array($grow->category_id,$CategoryList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('vendor_id', $vendor_id);
			  $this->db->where('category_id',$grow->category_id);
			  $updateresult = $this->db->update('vendor_categories', $data);
			}
		  }
		 }
		foreach($CategoryList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('location_category_id');
						$this->db->from('location_categories');
						$this->db->where('location_id',$location_id);
						$this->db->where('category_type_id',$category_type_id);
						$this->db->where('category_id',$listrow);
						$category_result = $this->db->get();
						if($category_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $category_result->row();	
						      $location_category_id = $tgrow->location_category_id;
							  $this->db->where('location_category_id', $location_category_id);
							  $this->db->where('location_id', $location_id);
							  $this->db->where('category_id',$listrow);
							  $updateresult = $this->db->update('location_categories', $data);
						}else
						{
							$this->db->select('location_category_id');
							$this->db->from('location_categories');
							$this->db->where('location_category_id', $location_category_id);
							$this->db->where('location_id',$location_id);
							$this->db->where('category_id',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{  
							  $data_type =array( 
								'location_id'   =>  $location_id,
								'category_type_id'    =>  $category_type_id,
								'category_id'    =>  $listrow,
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('location_categories',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	
	
	function update_photo($user_id,$file_name)
    { 
        $data = array(
			'user_photo'   => $file_name,
        );
        $this->db->where('user_id', $user_id);
		$this->db->where('user_type','V');
        $result = $this->db->update('users', $data);
		if($result)
		{
		  return 1;
		}
        
    } //End of Update Vendor function
	 

    function update_status($user_id, $status)
    {
		 if($status=='1')
		 {	$data = array(
				'is_active' => $status
			);
		 }
		 else
		 {
			$data = array(
				'is_active' => $status
			);
		 }
        $this->db->where('user_id', $user_id);
        $result = $this->db->update('users', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function

	function insertDigitalMedia($vendor_id,$media_type,$media_file_name)
 	  {
		    $this->db->select('vendor_media_id');
			$this->db->from('vendor_digital_media');
			$this->db->where('vendor_id',$vendor_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('vendor_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('lang_id'),
				'vendor_id'    => $vendor_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('vendor_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	function vendor_distance_timings($working_hours,$user_id)
	{    

		 
         $data    = array(
			'language_id'     => $this->session->userdata('lang_id'),
			
			'airport_distance'     => $this->input->post("airport_distance"),
			'railway_station_distance'     => $this->input->post("railway_station_distance"),
			'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
			'city_centre_distance'     => $this->input->post("city_centre_distance"),
			
			'working_hours'     => $working_hours,
			
			'rules_regulations'     => $this->input->post("rules_regulations"),
			'visitors_in_month'     => $this->input->post("visitors_in_month"),
			'vendor_review'     => $this->input->post("vendor_review"),
			'remarks'     => $this->input->post("remarks"),
			'vendor_id'   => $user_id,
			'created_on'      => date('Y-m-d H:i:s')
        );
		/*echo "<pre>";
		print_r($data);
		echo "</pre>";
		die();*/
        $result   = $this->db->insert('vendor_distance_timings', $data);
		$vendor_id  = $this->db->insert_id();
		if($result > 0)
		{
			if(isset($_POST['location_category']))
		    {
		     $categoryresult = $this->insertVendorCategory($user_id);
			}
		   
		}
		 if($result){
			return $vendor_id;
		 }
		else
			return 0;


    } //End of add function
	
	function insertVendorCategory($vendor_id)
 	   {   
	   $vendor_category = $_POST['location_category'];
	   if(is_array($vendor_category))
	    {
	    foreach($vendor_category as $catkey=> $catval){
		 if($catval!='')
		  { 
			$this->db->select('*');
			$this->db->from('vendor_categories');
			$this->db->where('vendor_id',$vendor_id);
			$this->db->where('category_id',$catval);
			$this->db->order_by('vendor_category_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'vendor_id' => $vendor_id,
					'category_type_id' => $this->input->post("category_type_id"),
					'category_id' => $catval,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('vendor_categories',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}
	
	
	 function insertBeacon($data) {
		 
        $result = $this->db->insert('beacon_vendors', $data);
		$beacon_vendor_id = $this->db->insert_id();
		if($beacon_vendor_id)
		{    return $beacon_vendor_id;
		}
		else
		{	 return '0';
		}
	 }
	  
	function viewDigitalMedia($vendor_id,$media_type)
	{
		$this->db->select('vendor_digital_media.*');
		$this->db->from('vendor_digital_media');
		$this->db->join('users', 'users.user_id = vendor_digital_media.vendor_id');
		//$this->db->where('vendor_digital_media.is_primary', '1');
		$this->db->where('vendor_digital_media.vendor_id', $vendor_id);
		$this->db->where('vendor_digital_media.media_type', $media_type);
		$this->db->order_by('vendor_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->result();
		//echo $this->db->last_query();
		return $results;

   } //End of View function
	   
   function setDefaultMedia($vendor_id,$vendor_media_id,$media_type){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('vendor_media_id',$vendor_media_id); 
	   $this->db->where('media_type',$media_type);
	   $query = $this->db->get('vendor_digital_media');
	   if($query->num_rows() > 0 ){
		 $update_data =array( 
			'default_media' => '0',
			);	
		 $this->db->where('vendor_id', $vendor_id);
		 $this->db->where('media_type', $media_type);	
		 $updateresult = $this->db->update('vendor_digital_media', $update_data);
		 
		  $updatedata =array( 
			'default_media' => '1',
			);	
		 $this->db->where('vendor_id', $vendor_id);
		 $this->db->where('media_type', $media_type);
		 $this->db->where('vendor_media_id', $vendor_media_id);	
		 $updateresult = $this->db->update('vendor_digital_media', $updatedata);
		 if($updateresult)
		 { return '1';
		 }
	    }
	  	 else{
		 return '0';
	   }
	}

  function insertBeaconvendors($data) {
	$result = $this->db->insert('beacon_vendor_actions', $data);
	$beacon_action_id = $this->db->insert_id();
	if($beacon_action_id)
	{    return $beacon_action_id;
	}
	else
	{	 return '0';
	}
 }
 
 	function products()
	{
		$this->db->select('*');
		$this->db->from('products');
		//$this->db->order_by('vendor_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->result();
		//echo $this->db->last_query();
		return $results;

   } //End of View function
   function selected_products($vendor_id)
	{
		$this->db->select('*');
		$this->db->from('vendor_products');
		$this->db->where('vendor_id', $vendor_id);
		$query = $this->db->get();
		$results = $query->result();
		return $results;

   } //End of View function
   
    function product_category()
	{
		$this->db->select('*');
		$this->db->from('categories');
		$this->db->where('category_type_id', 43);
		$query = $this->db->get();
		$results = $query->result();
		return $results;

   } //End of View function
   
   function selected_product_category($user_id){
       $this->db->select('*');
		$this->db->from('vendor_product_categories');
		$this->db->where('vendor_id', $user_id);
		$query = $this->db->get();
		$results = $query->result();
		return $results;
   }
   
   function all_products_listing($array_cat){
       $this->db->select("*");
       if(count($array_cat)>0){
        $this->db->where_in('category_id',$array_cat);
       }
       $this->db->where_in('category_id','');
        $this->db->join('products', 'product_categories.product_id = products.product_id');
        $query = $this->db->get('product_categories');
        $result=$query->result();
        return $result;
   }

}