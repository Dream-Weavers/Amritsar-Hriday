<?php

class Locationfilters_model extends CI_Model
{	
	 
    function view_locationfilters($location_id,$category_type_id,$location_name,$serial_no,$status,$limit, $start)
    {
		$this->db->select('locations.*,categories.category_name,location_categories.category_type_id,locality.locality_name');
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->where('location_categories.is_active','1');
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($location_name!='0')
		$this->db->like('locations.location_name', $location_name);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		$this->db->group_by('locations.location_id'); 
		$this->db->order_by('locations.location_name','ASC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('locations');
        $query = $this->db->get();
	    $result = $query->result();
		//echo "--->".$this->db->last_query();
		//echo "<br><br>";
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	function count_locationfilters($location_id,$category_type_id,$location_name,$serial_no,$status) {
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->where('location_categories.is_active','1');
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($location_name!='0')
		$this->db->like('locations.location_name', $location_name);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}		
		$this->db->group_by('locations.location_id'); 
		$query=$this->db->get('locations');		
		//echo "--------------------->". $this->db->last_query();	 
		//echo "<br><br>";  
		return $query->num_rows();
		
	}     //End of Count function
		
	
	
		
		
			
	function get_location_categories($location_id)
	{
		
		$this->db->select('categories.category_name,location_categories.location_category_id,location_categories.category_id');
		$this->db->from('categories');
		$this->db->join('location_categories','location_categories.category_id  = categories.category_id');
		$this->db->where('location_categories.is_active', '1');
		$this->db->where('location_categories.location_id', $location_id);
		$this->db->order_by('categories.category_name', 'ASC');
		$query = $this->db->get();
		$result = $query->result();
		//echo $this->db->last_query();	
		
		return $result;
   } //End of View function
   
   
	function insertDigitalMedia($location_id,$media_type,$media_file_name)
 	  {
		    $this->db->select('location_media_id');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('lang_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('location_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	
	 function insertFacility($data) {
        $result = $this->db->insert('location_facilities', $data);
		$location_facility_id = $this->db->insert_id();
		if($location_facility_id)
		{    return $location_facility_id;
		}
		else
		{	 return '0';
		}
		
      }
	  
	  
	   function insertLocationSection($data) {
        $result = $this->db->insert('location_sections', $data);
		$location_section_id = $this->db->insert_id();
		if($location_section_id)
		{    return $location_section_id;
		}
		else
		{	 return '0';
		}
		
      }
	  

	function insertDesignation($designation_name)
 	  {
		$this->db->select('*');
		$this->db->from('designation');
		$this->db->where('designation_name',$designation_name);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{ 
		  $desigrow = $query->row();
		  $designation_id = $desigrow->designation_id;
		}else
		{	 $data =array( 
				'designation_name' => $this->input->post("designation_name"),
			 );	
			 $result= $this->db->insert('designation',$data);	
			 $designation_id  = $this->db->insert_id();
		 }
		if($designation_id)
		 return $designation_id;
		else
		 return 0;
	}
	
	
	function insertDepartment($department_name)
 	  {
		$this->db->select('*');
		$this->db->from('department');
		$this->db->where('department_name',$department_name);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{ 
		  $deptrow = $query->row();
		  $department_id = $deptrow->department_id;
		}else
		{	 $data =array( 
				'department_name' => $this->input->post("department_name"),
			 );	
			 $result= $this->db->insert('department',$data);	
			 $department_id  = $this->db->insert_id();
		 }
		if($department_id)
		 return $department_id;
		else
		 return 0;
	}
	
	function updateUserAddress($user_id,$user_address_id)
 	  {			$address_data =array( 
				'country_id' => $this->input->post("country_id"),
				'state_id' => $this->input->post("state_id"),
				'city_id' => $this->input->post("city_id"),
				'address' => $this->input->post("address"),
				'pin_code' => $this->input->post("pin_code")
			 );	
			 $this->db->where('user_address_id', $user_address_id);
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_address', $address_data);
			if($result)
				return 1;
			else
				return 0;
	}
	
	 function insertLocationCategory($location_id)
 	   {   
	   $location_category = $_POST['location_category'];
	   if(is_array($location_category))
	    {
	    foreach($location_category as $catkey=> $catval){
		 if($catval!='')
		  { 
			$this->db->select('*');
			$this->db->from('location_categories');
			$this->db->where('location_id',$location_id);
			$this->db->where('category_id',$catval);
			$this->db->order_by('location_category_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'location_id' => $location_id,
					'category_type_id' => $this->input->post("category_type_id"),
					'category_id' => $catval,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('location_categories',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}
	
	
	function updateLocationCategory11($location_id)
 	   {   
	   $location_category = $_POST['location_category'];
	   if(is_array($location_category))
	    {
	    foreach($location_category as $catkey=> $catval){
		 if($catval!='')
		  { 
			$this->db->select('*');
			$this->db->from('location_categories');
			$this->db->where('location_id',$location_id);
			$this->db->where('category_id',$catval);
			$this->db->order_by('location_category_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'location_id' => $location_id,
					'category_type_id' => $this->input->post("category_type_id"),
					'category_id' => $catval,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('location_categories',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}

	
	function UpdateUserRole($user_id)
 	  {			
	    	if($this->input->post("current_role_id") !=$this->input->post("role_id"))
			{	$rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
			    $role_data =array( 
					'user_id' => $user_id,
					'role_id' => $this->input->post("role_id"),
					'role_rights' =>$rolerow->role_rights,
					'post_date'      => date('Y-m-d H:i:s')
				  );	
				 $result= $this->db->insert('user_roles',$role_data);	
				 $user_role_id  = $this->db->insert_id();
				 
			 $roledata =array( 
				'is_active' => '0'
			 );	
			 $this->db->where('role_id', $this->input->post("current_role_id"));
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_roles', $roledata);
			}
			elseif($this->input->post("current_role_id")=='0' && $this->input->post("current_role_id")=='')
			{
			   $rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
			   $role_data =array( 
					'user_id' => $user_id,
					'role_id' => $this->input->post("role_id"),
					'role_rights' =>$rolerow->role_rights,
					'post_date'      => date('Y-m-d H:i:s')
				 );	
				 $result= $this->db->insert('user_roles',$role_data);	
				 $user_role_id  = $this->db->insert_id();
			}else
			{
				$result=true;
			}
			if($result)
				return 1;
			else
				return 0;
	}
	
	
		 function location_edit($location_id)
		 {
			if ($location_id == '') {
				redirect(base_url() . "employees/locations/view");
			}
			$this->db->select('*');
			$this->db->from('locations');
			$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
			$this->db->where('locations.location_id', $location_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
		
		function viewDigitalMedia($location_id,$media_type)
     	{
			$this->db->select('location_digital_media.*');
			$this->db->from('location_digital_media');
			$this->db->join('locations', 'locations.location_id = location_digital_media.location_id');
			//$this->db->where('location_digital_media.is_primary', '1');
			$this->db->where('location_digital_media.location_id', $location_id);
			$this->db->where('location_digital_media.media_type', $media_type);
			$this->db->order_by('location_digital_media.created_on', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	 
	   function viewLocationSection($location_id)
     	{	$this->db->select('*');
			$this->db->from('location_sections');
			$this->db->where('location_id', $location_id);
			$this->db->order_by('section_title ', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	     
	   function viewfacilities($location_id,$facility_type)
     	{
			$this->db->select('location_facilities.*');
			$this->db->from('location_facilities');
			$this->db->join('locations', 'locations.location_id = location_facilities.location_id');
			$this->db->where('location_facilities.location_id', $location_id);
			$this->db->where('location_facilities.facility_type', $facility_type);
			$this->db->order_by('location_facilities.location_facility_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	
	
		 function update_location($location_id,$working_hours)
		 {
			 $ticket_fee_details =array();
		 	 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
			 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
			 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
			 $ticket_fee_details[] = $ticketdetails;
			  
			 if(is_array($ticket_fee_details))
			 $ticketfeedetails = json_encode($ticket_fee_details);
			 else
			 $ticketfeedetails = '';
			 
			$data = array(
				'location_name'     => $this->input->post("location_name"),
				'short_name'     => $this->input->post("short_name"),
				'address'     => $this->input->post("address"),
				'short_description'     => $this->input->post("short_description"),
				'description'     => $this->input->post("description"),
				'locality_id'    => $this->input->post("locality_id"),
				'pin_code'     => $this->input->post("pin_code"),
				'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
				'website_url'     => $this->input->post("website_url"),
				'entry_ticket'     => $this->input->post("location_entry_ticket"),
				'ticket_fee_details'     => $ticketfeedetails,
				'longitude'     => $this->input->post("longitude"),
				'latitude'     => $this->input->post("latitude"),
				'alert1_distance'     => $this->input->post("alert1_distance"),
				'alert2_distance'     => $this->input->post("alert2_distance"),
				'alert3_distance'     => $this->input->post("alert3_distance"),
				'alert4_distance'     => $this->input->post("alert4_distance"),
				'alert1_sound_file_id'     => $this->input->post("alert1_sound_file_id"),
				'alert2_sound_file_id'     => $this->input->post("alert2_sound_file_id"),
				'alert3_sound_file_id'     => $this->input->post("alert3_sound_file_id"),
				'alert4_sound_file_id'     => $this->input->post("alert4_sound_file_id"),
				'north_area'     => $this->input->post("north_area"),
				'north_area_title'     => $this->input->post("north_area_title"),
				'south_area'     => $this->input->post("south_area"),
				'south_area_title'     => $this->input->post("south_area_title"),
				'east_area'     => $this->input->post("east_area"),
				'east_area_title'     => $this->input->post("east_area_title"),
				'west_area'     => $this->input->post("west_area"),
				'west_area_title'     => $this->input->post("west_area_title"),
				'airport_distance'     => $this->input->post("airport_distance"),
				'railway_station_distance'     => $this->input->post("railway_station_distance"),
				'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
				'city_centre_distance'     => $this->input->post("city_centre_distance"),
				'wifi_availability'     => $this->input->post("wifi_availability"),
				'working_hours'     => $working_hours,
				'rules_regulations'     => $this->input->post("rules_regulations"),
				'visitors_in_month'     => $this->input->post("visitors_in_month"),
				'location_review'     => $this->input->post("location_review"),
				'surveyor_remarks'     => $this->input->post("surveyor_remarks")
			);
			$this->db->where('location_id', $location_id);
			$result = $this->db->update('locations', $data);
			if($result > 0)
   		    {
				if(isset($_POST['location_category']))
		        {	$updateresult = $this->updateLocationCategory($this->input->post("category_type_id"),$location_id,$_POST['location_category']);
				}
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "locations";
				$operation = "Record updated";
				createLogFile($operation,$location_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
	
	 function updateLocationCategory($category_type_id,$location_id,$CategoryList)
 	  {
		/*echo "<pre>";
		print_r($CategoryList);
		echo "</pre>";*/
	
		$insertresult=false;
		if(is_array($CategoryList))
		{
		 $done=0; 	
		 $already=0; 	
		 $fields=array('location_id'=>$location_id,'is_active'=>'1');
	     $categoryresult=gettableresult('location_categories',$fields);
	     if(is_array($categoryresult))
	     {
		  foreach($categoryresult as $grow){
			 if(!in_array($grow->category_id,$CategoryList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('location_id', $location_id);
			  $this->db->where('category_id',$grow->category_id);
			  $updateresult = $this->db->update('location_categories', $data);
			}
		  }
		 }
		foreach($CategoryList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('location_category_id');
						$this->db->from('location_categories');
						$this->db->where('location_id',$location_id);
						$this->db->where('category_type_id',$category_type_id);
						$this->db->where('category_id',$listrow);
						$category_result = $this->db->get();
						if($category_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $category_result->row();	
						      $location_category_id = $tgrow->location_category_id;
							  $this->db->where('location_category_id', $location_category_id);
							  $this->db->where('location_id', $location_id);
							  $this->db->where('category_id',$listrow);
							  $updateresult = $this->db->update('location_categories', $data);
						}else
						{
							$this->db->select('location_category_id');
							$this->db->from('location_categories');
							$this->db->where('location_id',$location_id);
							$this->db->where('category_id',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{  
							  $data_type =array( 
								'location_id'   =>  $location_id,
								'category_type_id'    =>  $category_type_id,
								'category_id'    =>  $listrow,
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('location_categories',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	
   

    function update_status($location_id, $status)
    {
		 if($status=='1')
		 {	$data = array(
				'is_active' => $status,
			);
		 }
		 else
		 {
			$data = array(
				'is_active' => $status,
			);
		 }
        $this->db->where('location_id', $location_id);
        $result = $this->db->update('locations', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
	
  function setDefaultMedia($location_id,$location_media_id,$media_type){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $this->db->where('media_type',$media_type);
	   $query = $this->db->get('location_digital_media');
	   if($query->num_rows() > 0 ){
		 $update_data =array( 
			'default_media' => '0',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);	
		 $updateresult = $this->db->update('location_digital_media', $update_data);
		 
		  $updatedata =array( 
			'default_media' => '1',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);
		 $this->db->where('location_media_id', $location_media_id);	
		 $updateresult = $this->db->update('location_digital_media', $updatedata);
		 if($updateresult)
		 { return '1';
		 }
	    }
	  	 else{
		 return '0';
	   }
	}
	
	function deleteDigitalMedia($location_media_id,$audio_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $query = $this->db->get('location_digital_media');
	   if($query->num_rows() > 0 ){
		  $row_media = $query->row();
		  if($row_media->media_file_name!='')
		  {	  $path_dir1 = $audio_path;
		      $shash=('\ '); 
			  $path_original =$path_dir1.trim($shash).$row_media->media_file_name;
			 if (file_exists($path_original)) {
				 chmod($path_dir1, 0777);
				$resultoriginal=  @unlink($path_original);
			  }
		  }
		   $this->db->where('location_media_id',$location_media_id); 
		   $result = $this->db->delete('location_digital_media');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   }
	}
	
	function deleteLocSection($location_section_id){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_section_id',$location_section_id); 
	   $query = $this->db->get('location_sections');
	   if($query->num_rows() > 0 ){
		   $this->db->where('location_section_id',$location_section_id); 
		   $result = $this->db->delete('location_sections');
		   if($result)
			{ return '1';
			}
	    }
	  	 else{
		 return '0';
	   }
	}
	
	
   function deleteFacility($location_facility_id,$facility_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_facility_id',$location_facility_id); 
	   $query = $this->db->get('location_facilities');
	   if($query->num_rows() > 0 ){
		  $row_facility = $query->row();
		  if($row_facility->photo_name!='')
		  {	  $path_dir1 = $facility_path;
		      $shash=('\ '); 
			  $photo_path =$path_dir1.trim($shash).$row_facility->photo_name;
			 if (file_exists($photo_path)) {
				 chmod($path_dir1, 0777);
				$resultphoto=  @unlink($photo_path);
			  }
		  }
		  if($row_facility->map2d!='')
		  {	  $path_dir2 = $facility_path;
		      $shash=('\ '); 
			  $map2d_path =$path_dir2.trim($shash).$row_facility->map2d;
			 if (file_exists($map2d_path)) {
				 chmod($path_dir2, 0777);
				$resultmap2d=  @unlink($map2d_path);
			  }
		  }
		   $this->db->where('location_facility_id',$location_facility_id); 
		   $result = $this->db->delete('location_facilities');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   }
	}


}