<?php

class surveyor_model extends CI_Model
{	
	 
    function view_locations($location_id,$category_type_id,$locality_id,$status,$limit, $start)
    {
		$this->db->select('slocations.*,categories.category_name,slocation_categories.category_type_id,locality.locality_name,users.user_type');
		$this->db->join('slocation_categories', 'slocation_categories.location_id = slocations.location_id','left');
		$this->db->join('categories', 'categories.category_id = slocation_categories.category_id','left');
		$this->db->join('locality', 'locality.locality_id = slocations.locality_id','left');
		$this->db->join('users', 'slocations.created_by = users.user_id','left');
		$this->db->where('slocation_categories.is_active','1');
		$this->db->where('slocations.language_id',$this->session->userdata('lang_id'));
		$this->db->where('users.user_type','E');
		$this->db->where('slocations.is_active','0');
		if($location_id!='0')
		$this->db->where('slocations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('slocation_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('slocations.locality_id', $locality_id);

		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('slocations.is_active',$status);
		}	
		$this->db->group_by('slocations.location_id'); 
		$this->db->order_by('slocations.location_id','DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('slocations');
        $query = $this->db->get();
	    $result = $query->result();
	   //echo "--->".$this->db->last_query();
		//echo "<br><br>";
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	function count_locations($location_id,$category_type_id,$locality_id,$status) {
		$this->db->join('slocation_categories', 'slocation_categories.location_id = slocations.location_id','left');
		$this->db->join('categories', 'categories.category_id = slocation_categories.category_id','left');
		$this->db->join('locality', 'locality.locality_id = slocations.locality_id','left');
		$this->db->join('users', 'slocations.created_by = users.user_id','left');
		$this->db->where('slocation_categories.is_active','1');
		$this->db->where('slocations.language_id',$this->session->userdata('lang_id'));
		$this->db->where('slocations.is_active','0');
		$this->db->where('users.user_type','E');
		if($location_id!='0')
		$this->db->where('slocations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('slocation_categories.category_type_id', $category_type_id);
		
		if($locality_id!='0')
		$this->db->where('slocations.locality_id', $locality_id);
		
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('slocations.is_active',$status);
		}	
		$this->db->group_by('slocations.location_id'); 
		$query=$this->db->get('slocations');		
		//echo "--------------------->". $this->db->last_query();	 
		//echo "<br><br>";  
		return $query->num_rows();
		
	}     //End of Count function
		
	
	function add($working_hours,$direction_locations)
	{    
		 $serial_no = random_string('numeric', 8);
	     $locationfeilds = array('serial_no' =>trim($this->input->post('serial_no')),'language_id'=>$this->session->userdata('lang_id'));
		 $serialnoresult = check_unique('slocations',$locationfeilds);
		 if($serialnoresult==1)
		 {   $serial_no = random_string('numeric', 8);
		 }
		 else
		 {  $serial_no = $serial_no;
		 }
		  
		 $ticket_fee_details =array();
		 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
		 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
		 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
		 $ticket_fee_details[] = $ticketdetails;
		  
		 if(is_array($ticket_fee_details))
		 $ticketfeedetails = json_encode($ticket_fee_details);
		 else
		 $ticketfeedetails = '';
		  
		 if(trim($this->input->post("locality_textbox")!='')){
			$data    = array(
			'locality_name'     => $this->input->post("locality_textbox"),
			'city_id'     => '3134',
			'is_active'     => '1'
			);
			$this->db->insert('locality', $data);
			$locality_id  = $this->db->insert_id();
		 } else {
			$locality_id  = $this->input->post("locality_id");
		 }
		  
         $data    = array(
			'language_id'     => $this->session->userdata('lang_id'),
			'location_name'     => $this->input->post("location_name"),
			'short_name'     => $this->input->post("short_name"),
			'serial_no'     => $serial_no,
			'qr_code '     => $serial_no,
			'address'     => $this->input->post("address"),
			'description'     => $this->input->post("description"),
			'state_id'     => $this->session->userdata('state_id'),
			'city_id'     => $this->session->userdata('city_id'),
			'locality_id'    => $locality_id,
			'pin_code'     => $this->input->post("pin_code"),
			'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
			'website_url'     => $this->input->post("website_url"),
			'entry_ticket'     => $this->input->post("location_entry_ticket"),
			'ticket_fee_details'     => $ticketfeedetails,
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude"),
			'north_area'     => $this->input->post("north_area"),
			'north_area_title'     => $this->input->post("north_area_title"),
			'south_area'     => $this->input->post("south_area"),
			'south_area_title'     => $this->input->post("south_area_title"),
			'east_area'     => $this->input->post("east_area"),
			'east_area_title'     => $this->input->post("east_area_title"),
			'west_area'     => $this->input->post("west_area"),
			'west_area_title'     => $this->input->post("west_area_title"),
			
			'wifi_availability'     => $this->input->post("wifi_availability"),
			'headphn_availability'     => $this->input->post("headphn_availability"),
			'working_hours'     => $working_hours,
			'direction_locations'     => $direction_locations,
			'rules_regulations'     => $this->input->post("rules_regulations"),
			'visitors_in_month'     => $this->input->post("visitors_in_month"),
			'location_review'     => $this->input->post("location_review"),
			'slocations_remarks'     => $this->input->post("slocations_remarks"),
			'created_by'   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
		/* echo "<pre>";
		print_r($data);
		echo "</pre>";
		die(); */
		$result =$this->db->insert('slocations', $data);
		/* $location_id  = $this->db->insert_id();
        //$result = $this->db->insert('slocations', $data);
		
		if($result > 0)
		{
			if(isset($_POST['category_id']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "slocations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0; */
		$location_id  = $this->db->insert_id();
		if($result > 0)
		{
			if(isset($_POST['location_category']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "slocations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0;

    } //End of add function
	
	
	function insertDigitalMedia($location_id,$media_type,$media_file_name)
 	{
			$data_type =array( 
				'language_id'   => $this->session->userdata('lang_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			//$this->db->insert('slocation_digital_media',$data_type);
			$insertresult= $this->db->insert('slocation_digital_media',$data_type);	
			//$insertresult= $this->db->insert('location_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	
	 function insertFacility($data) {
		//$this->db->insert('slocation_facilities', $data);
        //$result = $this->db->insert('location_facilities', $data);
        $result = $this->db->insert('slocation_facilities', $data);
		$location_facility_id = $this->db->insert_id(); 
		if($location_facility_id)
		{    return $location_facility_id;
		}
		else
		{	 return '0';
		}
     }
	  
	  function insertLocText($data) {
		//$this->db->insert('slocation_sections', $data);
        //$result = $this->db->insert('location_sections', $data);
        $result = $this->db->insert('slocation_sections', $data);
		$location_text_id = $this->db->insert_id();
		if($location_text_id)
		{    return $location_text_id;
		}
		else
		{	 return '0';
		}
		
      }
	
	function insertDigitalMedia1($location_id,$media_type,$GroupList,$media_file_name)
 	  {
		  foreach($GroupLists as $key=> $listrow){
			if($listrow['media_file_name']!='') 
			{	$this->db->select('location_media_id');
				$this->db->from('slocation_digital_media');
				$this->db->where('language_id',$this->session->userdata('lang_id'));
				$this->db->where('media_type',$media_type);
				$this->db->where('media_file_name',$media_file_name);
				$digital_result = $this->db->get();
				if($digital_result->num_rows() == 0)
				{  
				     $data_type =array( 
						'language_id'   => $this->session->userdata('lang_id'),
						'location_id'    => $location_id,
						'media_type'    =>  $media_type,
						'media_file_name'    =>  $media_file_name,
						'created_on'      => date('Y-m-d H:i:s')
					  );
					  //$this->db->insert('slocation_digital_media',$data_type);
					  //$insertresult= $this->db->insert('location_digital_media',$data_type);	
					  $insertresult= $this->db->insert('slocation_digital_media',$data_type);	
					  $location_media_id  = $this->db->insert_id();
					  $done++;
					  $update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
					  $update_by_id = json_encode($update_by);
					  $table_name = "slocation_digital_media";
					  $operation = "Record added";
					  createLogFile($operation,$location_media_id,$update_by_id,$table_name);
		
				}else
				{	  $already++;
				}
			}
		  }
			if($insertresult)
				return $insertresult;
			else
				return 0;
	}
	
	 function insertLocationSection($data) {
        $result = $this->db->insert('slocation_sections', $data);
		$location_section_id = $this->db->insert_id();
		if($location_section_id)
		{    return $location_section_id;
		}
		else
		{	 return '0';
		}
		
      }
	  
	  
	 function insertDesignation($designation_name)
 	  {
		$this->db->select('*');
		$this->db->from('designation');
		$this->db->where('designation_name',$designation_name);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{ 
		  $desigrow = $query->row();
		  $designation_id = $desigrow->designation_id;
		}else
		{	 $data =array( 
				'designation_name' => $this->input->post("designation_name"),
			 );	
			 $result= $this->db->insert('designation',$data);	
			 $designation_id  = $this->db->insert_id();
		 }
		if($designation_id)
		 return $designation_id;
		else
		 return 0;
	} 
	
	
	 function insertDepartment($department_name)
 	  {
		$this->db->select('*');
		$this->db->from('department');
		$this->db->where('department_name',$department_name);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{ 
		  $deptrow = $query->row();
		  $department_id = $deptrow->department_id;
		}else
		{	 $data =array( 
				'department_name' => $this->input->post("department_name"),
			 );	
			 $result= $this->db->insert('department',$data);	
			 $department_id  = $this->db->insert_id();
		 }
		if($department_id)
		 return $department_id;
		else
		 return 0;
	}
	
	 function updateUserAddress($user_id,$user_address_id)
 	{			
			
			$address_data =array( 
				'country_id' => $this->input->post("country_id"),
				'state_id' => $this->input->post("state_id"),
				'city_id' => $this->input->post("city_id"),
				'address' => $this->input->post("address"),
				'pin_code' => $this->input->post("pin_code")
			 );	
			 $this->db->where('user_address_id', $user_address_id);
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_address', $address_data);
			if($result)
				return 1;
			else
				return 0;
	} 
	
	 /* function insertLocationCategory($location_id)
 	 {   
		   $data =array( 
		        'location_id' => $location_id,
				'category_type_id' => $this->input->post("category_type_id"),
				'category_id' => $this->input->post("category_id"),
				'created_on'  => date('Y-m-d H:i:s')
			);	
			//$this->db->insert('slocation_categories',$data);
			$result= $this->db->insert('slocation_categories',$data);	
			//$result= $this->db->insert('location_categories',$data);	
			if($result)
				return $result;
			else
				return 0;
	 } */
		
	function insertLocationCategory($location_id)
    {   
	   $location_category = $_POST['location_category'];
	   if(is_array($location_category))
	    {
	    foreach($location_category as $catkey=> $catval){
		 if($catval!='')
		  { 
			$this->db->select('*');
			$this->db->from('slocation_categories');
			$this->db->where('location_id',$location_id);
			$this->db->where('category_id',$catval);
			$this->db->order_by('location_category_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'location_id' => $location_id,
					'category_type_id' => $this->input->post("category_type_id"),
					'category_id' => $catval,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('slocation_categories',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}

	
	function UpdateUserRole($user_id)
 	  {			
	    	if($this->input->post("current_role_id") !=$this->input->post("role_id"))
			{	$rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
			    $role_data =array( 
					'user_id' => $user_id,
					'role_id' => $this->input->post("role_id"),
					'role_rights' =>$rolerow->role_rights,
					'post_date'      => date('Y-m-d H:i:s')
				  );	
				 $result= $this->db->insert('user_roles',$role_data);	
				 $user_role_id  = $this->db->insert_id();
				 
			 $roledata =array( 
				'is_active' => '0'
			 );	
			 $this->db->where('role_id', $this->input->post("current_role_id"));
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_roles', $roledata);
			}
			elseif($this->input->post("current_role_id")=='0' && $this->input->post("current_role_id")=='')
			{
			   $rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
			   $role_data =array( 
					'user_id' => $user_id,
					'role_id' => $this->input->post("role_id"),
					'role_rights' =>$rolerow->role_rights,
					'post_date'      => date('Y-m-d H:i:s')
				 );	
				 $result= $this->db->insert('user_roles',$role_data);	
				 $user_role_id  = $this->db->insert_id();
			}else
			{
				$result=true;
			}
			if($result)
				return 1;
			else
				return 0;
	}
	
	
		 function location_edit($location_id)
		 {
			if ($location_id == '') {
				redirect(base_url() . "backoffice/slocations/view");
			}
			$this->db->select('*');
			$this->db->from('slocations');
			$this->db->join('slocation_categories', 'slocation_categories.location_id = slocations.location_id');
			$this->db->where('slocations.location_id', $location_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_location($location_id,$working_hours,$direction_locations)
		 {
			 $ticket_fee_details =array();
		 	 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
			 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
			 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
			 $ticket_fee_details[] = $ticketdetails;
			  
			 if(is_array($ticket_fee_details))
			 $ticketfeedetails = json_encode($ticket_fee_details);
			 else
			 $ticketfeedetails = '';
			 
			 if(trim($this->input->post("locality_textbox")!='')){
				$data    = array(
				'locality_name'     => $this->input->post("locality_textbox"),
				'city_id'     => '3134',
				'is_active'     => '1'
				);
				$this->db->insert('locality', $data);
				$locality_id  = $this->db->insert_id();
			 } else {
				$locality_id  = $this->input->post("locality_id");
			 }
		 
			$data = array(
				'location_name'     => $this->input->post("location_name"),
				'short_name'     => $this->input->post("short_name"),
				'address'     => $this->input->post("address"),
				'description'     => $this->input->post("description"),
				'locality_id'    => $locality_id,
				'pin_code'     => $this->input->post("pin_code"),
				'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
				'website_url'     => $this->input->post("website_url"),
				'entry_ticket'     => $this->input->post("location_entry_ticket"),
				'ticket_fee_details'     => $ticketfeedetails,
				'longitude'     => $this->input->post("longitude"),
				'latitude'     => $this->input->post("latitude"),
				'alert1_distance'     => $this->input->post("alert1_distance"),
				'alert2_distance'     => $this->input->post("alert2_distance"),
				'alert3_distance'     => $this->input->post("alert3_distance"),
				'alert4_distance'     => $this->input->post("alert4_distance"),
				'alert1_sound_file_id'     => $this->input->post("alert1_sound_file_id"),
				'alert2_sound_file_id'     => $this->input->post("alert2_sound_file_id"),
				'alert3_sound_file_id'     => $this->input->post("alert3_sound_file_id"),
				'alert4_sound_file_id'     => $this->input->post("alert4_sound_file_id"),
				'north_area'     => $this->input->post("north_area"),
				'north_area_title'     => $this->input->post("north_area_title"),
				'south_area'     => $this->input->post("south_area"),
				'south_area_title'     => $this->input->post("south_area_title"),
				'east_area'     => $this->input->post("east_area"),
				'east_area_title'     => $this->input->post("east_area_title"),
				'west_area'     => $this->input->post("west_area"),
				'west_area_title'     => $this->input->post("west_area_title"),
				'airport_distance'     => $this->input->post("airport_distance"),
				'railway_station_distance'     => $this->input->post("railway_station_distance"),
				'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
				'city_centre_distance'     => $this->input->post("city_centre_distance"),
				'wifi_availability'     => $this->input->post("wifi_availability"),
				'headphn_availability'     => $this->input->post("headphn_availability"),
				'working_hours'     => $working_hours,
				'direction_locations'     => $direction_locations,
				'rules_regulations'     => $this->input->post("rules_regulations"),
				'visitors_in_month'     => $this->input->post("visitors_in_month"),
				'location_review'     => $this->input->post("location_review"),
				'surveyor_remarks'     => $this->input->post("surveyor_remarks")
			);
			$this->db->where('location_id', $location_id);
			$result = $this->db->update('slocations', $data);
		
			/* if($result > 0)
   		    {
				if(isset($_POST['category_id']))
		        {
					$updateresult = $this->updateLocationCategory($location_id);
				 }
				 
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "slocations";
				$operation = "Record updated";
				createLogFile($operation,$location_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0; */
			if($result > 0)
   		    {
				if(isset($_POST['location_category']))
		        {	$updateresult = $this->updateLocationCategory($this->input->post("category_type_id"),$location_id,$_POST['location_category']);
				}
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "slocations";
				$operation = "Record updated";
				createLogFile($operation,$location_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
		 } //End of Update function
		 
	
   	/* function updateLocationCategory($location_id)
 	  {		$data =array( 
				'category_type_id' => $this->input->post("category_type_id"),
				'category_id' => $this->input->post("category_id"),
			 );	
			 $this->db->where('location_id', $location_id);
			 $result = $this->db->update('slocation_categories', $data);
			if($result)
				return 1;
			else
			    return 0;
	  } */
	function updateLocationCategory($category_type_id,$location_id,$CategoryList)
 	  {
		/*echo "<pre>";
		print_r($CategoryList);
		echo "</pre>";*/
	
		$insertresult=false;
		if(is_array($CategoryList))
		{
		 $done=0; 	
		 $already=0; 	
		 $fields=array('location_id'=>$location_id,'is_active'=>'1');
	     $categoryresult=gettableresult('slocation_categories',$fields);
	     if(is_array($categoryresult))
	     {
		  foreach($categoryresult as $grow){
			 if(!in_array($grow->category_id,$CategoryList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('location_id', $location_id);
			  $this->db->where('category_id',$grow->category_id);
			  $updateresult = $this->db->update('slocation_categories', $data);
			}
		  }
		 }
		foreach($CategoryList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('location_category_id');
						$this->db->from('slocation_categories');
						$this->db->where('location_id',$location_id);
						$this->db->where('category_type_id',$category_type_id);
						$this->db->where('category_id',$listrow);
						$category_result = $this->db->get();
						if($category_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $category_result->row();	
						      $location_category_id = $tgrow->location_category_id;
							  $this->db->where('location_category_id', $location_category_id);
							  $this->db->where('location_id', $location_id);
							  $this->db->where('category_id',$listrow);
							  $updateresult = $this->db->update('slocation_categories', $data);
						}else
						{
							$this->db->select('location_category_id');
							$this->db->from('slocation_categories');
							$this->db->where('location_category_id', $location_category_id);
							$this->db->where('location_id',$location_id);
							$this->db->where('category_id',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{  
							  $data_type =array( 
								'location_id'   =>  $location_id,
								'category_type_id'    =>  $category_type_id,
								'category_id'    =>  $listrow,
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('slocation_categories',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	
	function viewDigitalMedia($location_id,$media_type)
     	{
			$this->db->select('slocation_digital_media.*');
			$this->db->from('slocation_digital_media');
			$this->db->join('slocations', 'slocations.location_id = slocation_digital_media.location_id');
			//$this->db->where('location_digital_media.is_primary', '1');
			$this->db->where('slocation_digital_media.location_id', $location_id);
			$this->db->where('slocation_digital_media.media_type', $media_type);
			$this->db->order_by('slocation_digital_media.created_on', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	 function viewLocationSection($location_id)
     	{	$this->db->select('*');
			$this->db->from('slocation_sections');
			$this->db->where('location_id', $location_id);
			$this->db->order_by('section_title ', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	    function fetch_locations_log($location_id)
     	{	$this->db->select('*');
			$this->db->from('slocations_log');
			$this->db->where('location_id', $location_id);
			$this->db->order_by('slocations_log_id', 'DESC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;
	    } //End of View function
	   
	   function fetch_status_log($location_id)
     	{	
			$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS name, designation.designation_name,slocation_audits_log.*");
			$this->db->from('slocation_audits_log');
			$this->db->join('users','users.user_id=slocation_audits_log.submitted_by');
			$this->db->join('designation','users.designation_id=designation.designation_id');
			$this->db->where('slocation_audits_log.location_id', $location_id);
			$this->db->order_by('slocation_audits_log.slocation_audit_log_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;
	    } //End of View function
		
	   function viewfacilities($location_id,$facility_type)
       {
			$this->db->select('slocation_facilities.*');
			$this->db->from('slocation_facilities');
			$this->db->join('slocations', 'slocations.location_id = slocation_facilities.location_id');
			$this->db->where('slocation_facilities.location_id', $location_id);
			$this->db->where('slocation_facilities.facility_type', $facility_type);
			$this->db->order_by('slocation_facilities.location_facility_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function

	   
    function update_status($location_id)
    {
		$this->db->select('*');
		$this->db->where('location_id', $location_id);
        $this->db->from('slocations');
        $query = $this->db->get();
	    $result = $query->row();
	
        $data    = array(
			'language_id'     => $result->language_id,
			'location_name'     => $result->location_name,
			'short_name'     => $result->short_name,
			'serial_no'     => $result->serial_no,
			'qr_code '     => $result->serial_no,
			'address'     => $result->address,
			'short_description'     => $result->short_description,
			'description'     => $result->description,
			'state_id'     => $result->state_id,
			'city_id'     => $result->city_id,
			'locality_id'    => $result->locality_id,
			'pin_code'     => $result->pin_code,
			'estimated_visit_time'     => $result->estimated_visit_time,
			'website_url'     => $result->website_url,
			'entry_ticket'     => $result->entry_ticket,
			'ticket_fee_details'     => $result->ticket_fee_details,
			'longitude'     => $result->longitude,
			'latitude'     => $result->latitude,
			'alert1_distance'     => $result->alert1_distance,
			'alert2_distance'     => $result->alert2_distance,
			'alert3_distance'     => $result->alert3_distance,
			'alert4_distance'     => $result->alert4_distance,
			'alert1_sound_file_id'     => $result->alert1_sound_file_id,
			'alert2_sound_file_id'     => $result->alert2_sound_file_id,
			'alert3_sound_file_id'     => $result->alert3_sound_file_id,
			'alert4_sound_file_id'     => $result->alert4_sound_file_id,
			'north_area'     => $result->north_area,
			'north_area_title'     => $result->north_area_title,
			'south_area'     => $result->south_area,
			'south_area_title'     => $result->south_area_title,
			'east_area'     => $result->east_area,
			'east_area_title'     => $result->east_area_title,
			'west_area'     => $result->west_area,
			'west_area_title'     => $result->west_area_title,
			'wifi_availability'     => $result->wifi_availability,
			'headphn_availability'     => $result->headphn_availability,
			'working_hours'     => $result->working_hours,
			'direction_locations'     => $result->direction_locations,
			'rules_regulations'     => $result->rules_regulations,
			'visitors_in_month'     => $result->visitors_in_month,
			'location_review'     => $result->location_review,
			'is_active'     => 	'1',
			'surveyor_remarks'     => $result->surveyor_remarks,
			'created_by'   => $result->created_by,
			'created_on'      => $result->created_on
        );
		
        $this->db->insert('locations', $data);
		$main_location_id=$this->db->insert_id();
	
		
		$this->db->select('*');
		$this->db->from('slocation_categories');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_category_id', 'ASC');
		$query = $this->db->get();
		$result = $query->result();
		/* echo "<pre>";
		print_r($result);
		echo "</pre>";
		die(); */
		if($query->num_rows() > 0)
		{
		   foreach($result as $row){
			   
			   $data =array( 
					'location_id' => $main_location_id,
					'category_type_id' => $row->category_type_id,
					'category_id' => $row->category_id,
					'is_active' => $row->is_active,
					'created_on'  => $row->created_on
				);	
				$this->db->insert('location_categories',$data);
		   }
		}
			
		$this->db->select('*');
		$this->db->from('slocation_digital_media');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_media_id', 'ASC');
		$digital_result = $this->db->get();
		$result = $digital_result->result();
		if($digital_result->num_rows() > 0)
		{  
			foreach($result as $row){
			 $data_type =array( 
				'language_id'   => $row->language_id,
				'location_id'    => $main_location_id,
				'media_type'    =>  $row->media_type,
				'default_media'    =>  $row->default_media,
				'media_file_name'    =>  $row->media_file_name,
				'is_active' => $row->is_active,
				'created_on'      => $row->created_on
			  );
			  
			  $this->db->insert('location_digital_media',$data_type);	
			 // $location_media_id  = $this->db->insert_id();
			
			 /*  $update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			  $update_by_id = json_encode($update_by);
			  $table_name = "slocation_digital_media";
			  $operation = "Record added";
			  createLogFile($operation,$location_media_id,$update_by_id,$table_name); */
			}
		}
		
		$this->db->select('*');
		$this->db->from('slocation_facilities');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_facility_id', 'ASC');
		$fac_result = $this->db->get();
		if($digital_result->num_rows() > 0)
		$result = $fac_result->result();
		{  
			foreach($result as $row){
			 	$data = array(
					'language_id'=>$row->language_id,
					'location_id'=>$main_location_id,
					'facility_name_no'  => $row->facility_name_no,
					'facility_description'  => $row->facility_description,
					'facility_type'  => $row->facility_type,
					'washroom_availability' => $row->washroom_availability,
					'longitude'     => $row->longitude,
					'latitude'     => $row->latitude,
					'parking_type'     => $row->parking_type,
					'parking_fee'     => $row->parking_fee,
					'photo_name'     => $row->photo_name,
					'map2d '     => $row->map2d,
					'is_active' => $row->is_active,
					'created_on '      => $row->created_on
				);
			    $this->db->insert('location_facilities',$data);	
			}
		}
		$data = array(
				'is_active' => '1',
		);
        $this->db->where('location_id', $location_id);
        $result = $this->db->update('slocations', $data);
		return 1;
		
    } 
 
	function setDefaultMedia($location_id,$location_media_id,$media_type){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $this->db->where('media_type',$media_type);
	   $query = $this->db->get('slocation_digital_media');
	   if($query->num_rows() > 0 ){
		 $update_data =array( 
			'default_media' => '0',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);	
		 $updateresult = $this->db->update('slocation_digital_media', $update_data);
		 
		  $updatedata =array( 
			'default_media' => '1',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);
		 $this->db->where('location_media_id', $location_media_id);	
		 $updateresult = $this->db->update('slocation_digital_media', $updatedata);
		 if($updateresult)
		 { return '1';
		 }
	    }
	  	 else{
		 return '0';
	   }
	}
	
	function deleteDigitalMedia($location_media_id,$audio_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $query = $this->db->get('slocation_digital_media');
	   if($query->num_rows() > 0 ){
		  $row_media = $query->row();
		  if($row_media->media_file_name!='')
		  {	  $path_dir1 = $audio_path;
		      $shash=('\ '); 
			  $path_original =$path_dir1.trim($shash).$row_media->media_file_name;
			 if (file_exists($path_original)) {
				 chmod($path_dir1, 0777);
				$resultoriginal=  @unlink($path_original);
			  }
		  }
		   $this->db->where('location_media_id',$location_media_id); 
		   $result = $this->db->delete('slocation_digital_media');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   }
	}
	
	function deleteLocSection($location_section_id){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_section_id',$location_section_id); 
	   $query = $this->db->get('slocation_sections');
	   if($query->num_rows() > 0 ){
		   $this->db->where('location_section_id',$location_section_id); 
		   $result = $this->db->delete('slocation_sections');
		   if($result)
			{ return '1';
			}
	    }
	  	 else{
		 return '0';
	   }
	}
	
	
   function deleteFacility($location_facility_id,$facility_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_facility_id',$location_facility_id); 
	   $query = $this->db->get('slocation_facilities');
	   if($query->num_rows() > 0 ){
		  $row_facility = $query->row();
		  if($row_facility->photo_name!='')
		  {	  $path_dir1 = $facility_path;
		      $shash=('\ '); 
			  $photo_path =$path_dir1.trim($shash).$row_facility->photo_name;
			 if (file_exists($photo_path)) {
				 chmod($path_dir1, 0777);
				$resultphoto=  @unlink($photo_path);
			  }
		  }
		  if($row_facility->map2d!='')
		  {	  $path_dir2 = $facility_path;
		      $shash=('\ '); 
			  $map2d_path =$path_dir2.trim($shash).$row_facility->map2d;
			 if (file_exists($map2d_path)) {
				 chmod($path_dir2, 0777);
				$resultmap2d=  @unlink($map2d_path);
			  }
		  }
		   $this->db->where('location_facility_id',$location_facility_id); 
		   $result = $this->db->delete('slocation_facilities');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   }
	}
}