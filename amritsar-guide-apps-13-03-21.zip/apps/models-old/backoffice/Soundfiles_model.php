<?php

class Soundfiles_model extends CI_Model
{
	
	function view_soundfiles()
	{
		$this->db->select('*');
		$this->db->from('sound_files');
		$this->db->order_by('sound_file_id', 'DESC');
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->result();
		return $results;
	} //End of View function
		
		
	function fetchsoundfile($soundfileid)
	{
		$this->db->select('*');
		$this->db->from('sound_files');
		$this->db->order_by('sound_file_id', 'DESC');
		$this->db->where('sound_file_id',$soundfileid);
		$query = $this->db->get();
		//echo $this->db->last_query();
		$results = $query->row();
		return $results;
	} //End of View function		
	
	   
	 function add()
     {
         $data        = array(
		    'sound_file_title'   => $this->input->post("soundfile_name"), 
		    'language_id'=>$this->session->userdata('lang_id'),
			'created_on'      => date('Y-m-d H:i:s')
			 
        );
        $result   = $this->db->insert('sound_files', $data);
		$sound_file_id  = $this->db->insert_id();
		 if($result)
			return $sound_file_id;
		else
			return 0;


    } //End of add function
	

	
	
	 function update_soundfile($sound_file_id)
	 {
		 $data        = array(
		    'sound_file_title'   => $this->input->post("soundfile_name"), 
		    'language_id'=>$this->session->userdata('lang_id') 
		 );
		
		
		$this->db->where('sound_file_id', $sound_file_id);
		$result = $this->db->update('sound_files', $data);
		if ($result)
		   return 1;
		 else
		   return 0;
		
	 } //End of Update function

	
}