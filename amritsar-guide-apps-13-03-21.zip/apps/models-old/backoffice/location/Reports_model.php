<?php

class Reports_model extends CI_Model
{
   
   function addCategories(){
	
         $data          = array(
			'language_id'=>$this->session->userdata('lang_id'),
            'category_type_id'     	=>  $this->category_type_id,
            'category_parent_id'    =>  $this->category_parent_id,
            'category_name'     	=>  $this->category_name,
            'description'     		=>  $this->description,
            'post_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result = $this->db->insert('categories', $data);
		
		$id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0;
   
   }//End of addCategories
	
   function add_icon($category_id,$filename)
   {			
		$data     = array(
			'icon'     => $category_id.'_'.$filename
		);
		$this->db->where('category_id', $category_id);
		$result = $this->db->update('categories', $data);
   }
	
   function editCategories(){
           $data          = array(
            'category_type_id'     	=>  $this->category_type_id,
            'category_parent_id'    =>  $this->category_parent_id,
            'category_name'     	=>  $this->category_name,
            'description'     		=>  $this->description
        );
		$this->db->where('category_id', $this->category_id);
        $result  = $this->db->update('categories', $data);
		if(isset($_POST['filter_id']))
		    {
			 $categoryfilterresult = $this->updateCategoryFilter($this->category_id,$_POST['filter_id']);
			}
		if($result)
			return $this->category_id;
		else
			return 0;
   }//End of editCategories
   
   function editCategoriesData(){
		$this->db->where('category_id',$this->category_id);         
		$query  = $this->db->get('categories');		  
   		$result = $query->row(); 

		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editCategoriesData
   
   
   
     function updateCategoryFilter($category_id,$filterList)
 	  {
		/*echo "<pre>";
		print_r($filterList);
		echo "</pre>";
	die();*/
		$insertresult=false;
		if(is_array($filterList))
		{
		 $done=0; 	
		 $already=0; 
		 $fields=array('category_id'=>$category_id,'is_active'=>'1');
	     $filterresult=gettableresult('category_filters',$fields);
	     if(is_array($filterresult))
	     {
		  foreach($filterresult as $grow){
			 if(!in_array($grow->filterid,$filterList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('category_id', $category_id);
			  $this->db->where('filterid',$grow->filterid);
			  $updateresult = $this->db->update('category_filters', $data);
			}
		  }
		 }
		foreach($filterList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('category_filter_id');
						$this->db->from('category_filters');
						$this->db->where('category_id',$category_id);
						$this->db->where('filterid',$listrow);
						$filter_result = $this->db->get();
						if($filter_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $filter_result->row();	
						      $category_filter_id = $tgrow->category_filter_id;
							  $this->db->where('category_filter_id', $category_filter_id);
							  $this->db->where('category_id', $category_id);
							  $this->db->where('filterid',$listrow);
							  $updateresult = $this->db->update('category_filters', $data);
						}else
						{
							$this->db->select('category_filter_id');
							$this->db->from('category_filters');
							$this->db->where('category_id',$category_id);
							$this->db->where('filterid',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{ 
							 $fields = array('category_id'=>$category_id);
							 $weightmax = get_max_values('category_filters',$fields,'weight');
																		  
							  $data_type =array( 
								'category_id'   =>  $category_id,
								'filterid'    =>  $listrow,
								'weight'    =>  $weightmax,
								'created_by'    =>  $this->session->userdata('user_id'),
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('category_filters',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	

   function getCategories(){

		$this->db->select('language_id, COUNT(*) countedrecords');	
		//$this->db->where('is_active','1');
		$this->db->group_by('language_id');
		$query=$this->db->get('categories');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   }
   
   function getCategoryTypes(){

		$this->db->select('language_id, COUNT(*) countedrecords');	
		//$this->db->where('is_active','1');
		$this->db->group_by('language_id');
		$query=$this->db->get('category_types');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   }
    
	function locations() {
		$this->db->select('locations.language_id, COUNT(*) countedrecords');	
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.type!=','event');
		//$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		$this->db->group_by('locations.language_id'); 
		$query=$this->db->get('locations');		
 
		$result = $query->result(); 
		return $result;
		
	} 
   
   function beaconLocations(){

		$this->db->select('language_id, COUNT(*) countedrecords');	
		//$this->db->where('is_active','1');
		$this->db->group_by('language_id');
		$query=$this->db->get('beacon_locations');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } 
   
   function questionBank(){

		$this->db->select('language_id, COUNT(*) countedrecords');	
		//$this->db->where('is_active','1');
		$this->db->group_by('language_id');
		$query=$this->db->get('question_bank_settings');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   }
}
?>