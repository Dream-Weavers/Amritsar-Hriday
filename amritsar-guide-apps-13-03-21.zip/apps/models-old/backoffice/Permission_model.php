<?php

class Permission_model extends CI_Model
{
   var $permissionId,$permissionAdminUserName,$permissionName,$permissionPassword;
   function Permission_model(){
	   $this->permissionAdminUserName    = 0;
	   $this->permissionName      		= 0;
	   $this->permissionPassword 		= 0;
	   $this->permissionId   			= 0;
   }
   
   function addPermission(){
         $data          = array(
            'per_name'     		=>  $this->permissionName,
            'path'     		=>  $this->permissionPath,
            'is_parent'     		=>  $this->parentId,
            'post_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result  = $this->db->insert('permissions', $data);
		
       if($result)
	   	return 1;
	   else
	   	return 0;
   
   }//End of addPermission
	
   function editPermission(){
         $data          = array(
            'per_name'     		=>  $this->permissionName,
            'path'     			=>  $this->permissionPath,
            'is_parent'         =>  $this->parentId
        );
		$this->db->where('permissionid', $this->permissionId);
        $result  = $this->db->update('permissions', $data);
		if($result)
			return 1;
		else
			return 0;
   }//End of editPermission
   
   function editPermissionData(){
		$this->db->where('permissionid',$this->permissionId);         
		$query  = $this->db->get('permissions');		  
   		$result = $query->row(); 
		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editPermissionData
   
   function viewPermissions(){
		$this->db->select('permissions.*,perm.per_name as perm_name');
		$this->db->join('permissions as perm','permissions.is_parent=perm.permissionid','left');		
		$query=$this->db->get('permissions');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } // End of viewPermission
}
?>