<?php

class Ads_model extends CI_Model
{	


       function add_category()
		{   
			$fields = array('language_id'=>$this->session->userdata('lang_id'),'is_active'=>'1');
			$weightmax = get_max_values('ads_categories','weight',$fields);
			$data  = array(
				'language_id' => $this->session->userdata('lang_id'),
				'category_name'     => $this->input->post("category_name"),
				'description'     => $this->input->post("description"),
				'weight'   => $weightmax,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$result   = $this->db->insert('ads_categories', $data);
			$category_id  = $this->db->insert_id();
			if($result > 0)
			{
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "ads_categories";
				$operation = "Record added";
				createLogFile($operation,$category_id,$update_by_id,$table_name);
			 }
			 if($result){
				return $category_id;
			 }
			else
				return 0;
	
		} //End of add function
	
		
		 function category_edit($category_id)
		 {
			if ($category_id == '') {
				redirect(base_url() . "backoffice/ads/view_category");
			}
			$this->db->select('*');
			$this->db->from('ads_categories');
			$this->db->where('category_id', $category_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_category($category_id)
		 {
			$data = array(
			    'language_id' => $this->session->userdata('lang_id'),
			    'category_name'     => $this->input->post("category_name"),
				'description'     => $this->input->post("description"),
				'weight'   => $weightmax
			);
			$this->db->where('category_id', $category_id);
			$result = $this->db->update('ads_categories', $data);
			if($result > 0)
   		    {	$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "ads_categories";
				$operation = "Record updated";
				createLogFile($operation,$category_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
		 

       function view_category($category_name,$status,$limit, $start)
       {
		$this->db->select('*');
		if($category_name!='0')
		$this->db->like('category_name', $category_name);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('category_name','ASC');
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('ads_categories');
        $query = $this->db->get();
	//  echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

     } //End of View  function
	
	  function count_category($category_name,$status) {
		if($category_name!='0')
		$this->db->like('category_name', $category_name);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('ads_categories');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
	

      function view_ads($category_id,$vendor_id,$status,$limit, $start)
     {
		$this->db->select('*');
		if($category_id!='0')
		$this->db->where('category_id', $category_id);
		if($vendor_id!='0')
		$this->db->where('vendor_id', $vendor_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('ad_title','ASC');
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('ads');
        $query = $this->db->get();
	//  echo "--->".$this->db->last_query();
	    $result = $query->result();
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	  function count_ads($category_id,$vendor_id,$status) {
		
		if($category_id!='0')
		$this->db->where('category_id', $category_id);
		if($vendor_id!='0')
		$this->db->where('vendor_id', $vendor_id);
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('is_active',$status);
		}	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('ads');		
		//echo "--------------------->". $this->db->last_query();	   
		return $query->num_rows();
		
	}     //End of Count function
		
	
		function add()
		{   
			$data  = array(
				'language_id' => $this->session->userdata('lang_id'),
				'category_id'     => $this->input->post("category_id"),
				'vendor_id'     => $this->input->post("vendor_id"),
				'ad_title'     => $this->input->post("ad_title"),
				'ad_desc'     => $this->input->post("ad_desc"),
				'created_by'      => $this->session->userdata('user_id'),
				'created_on'      => date('Y-m-d H:i:s')
			);
			$result   = $this->db->insert('ads', $data);
			$ad_id  = $this->db->insert_id();
			if($result > 0)
			{
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "ads";
				$operation = "Record added";
				createLogFile($operation,$ad_id,$update_by_id,$table_name);
			 }
			 if($result){
				return $ad_id;
			 }
			else
				return 0;
	
	
		} //End of add function
	
		
		function add_campaigns($ad_id,$place_id,$rule_id,$start_date,$end_date,$goal_description)
		{		
				$unique_id =  random_string('alnum',8);
				$data   = array(
					'language_id'   => $this->session->userdata('lang_id'),
					'ad_id'   => $ad_id,
					'place_id'   => $place_id,
					'rule_id'   => $rule_id,
					'unique_id'   => $unique_id,
					'place_id'     => $place_id,
					'start_date'     => $start_date,
					'end_date'     => $end_date,
					'goal_description'   => $goal_description,
					'created_on'      => date('Y-m-d H:i:s')
				);
				$insertresult   = $this->db->insert('campaigns', $data);
				$campaign_id  = $this->db->insert_id();
				if($insertresult)
				return $campaign_id;
				else
				return 0;	
	  }
	  
	  
	  function view_ad_campaigns($language_id,$ad_id)
		{
			$this->db->select('*');
			$this->db->from('campaigns');
			$this->db->where('language_id',$language_id);
			$this->db->where('ad_id',$ad_id);
			$this->db->order_by('start_date', 'ASC');
			$query = $this->db->get();
			$result = $query->result();
			return $result;
	
		} //End of View function
		
	
		 function ad_edit($ad_id)
		 {
			if ($ad_id == '') {
				redirect(base_url() . "backoffice/ads/view");
			}
			$this->db->select('*');
			$this->db->from('ads');
			$this->db->where('ad_id', $ad_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_ad($ad_id)
		 {
			$data = array(
			    'category_id'     => $this->input->post("category_id"),
				'vendor_id'     => $this->input->post("vendor_id"),
				'ad_title'     => $this->input->post("ad_title"),
				'ad_desc'     => $this->input->post("ad_desc"),
				'modified_by'      => $this->session->userdata('user_id'),
				'created_on'      => date('Y-m-d H:i:s'),
			);
			$this->db->where('ad_id', $ad_id);
			$result = $this->db->update('ads', $data);
			if($result > 0)
   		    {	$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "ads";
				$operation = "Record updated";
				createLogFile($operation,$ad_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
	function update_campaigns($campaign_id,$ad_id,$place_id,$rule_id,$start_date,$end_date,$goal_description)
		{		
			$data   = array(
					'ad_id'   => $ad_id,
					'place_id'   => $place_id,
					'rule_id'   => $rule_id,
					'place_id'     => $place_id,
					'start_date'     => $start_date,
					'end_date'     => $end_date,
					'goal_description'   => $goal_description
				);
				$this->db->where('campaign_id', $campaign_id);
				$resultupdate = $this->db->update('campaigns', $data);
				if($resultupdate)
				return $campaign_id;
				else
				return 0;	
	  }
	  
	  
    function update_status($ad_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('ad_id', $ad_id);
	    $result = $this->db->update('ads', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function
	
	
 function update_campaign_status($campaign_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('campaign_id', $campaign_id);
	    $result = $this->db->update('campaigns', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function
	
	
	function update_category_status($category_id, $status)
    {		$data = array(
				'is_active' => $status,
			);
        $this->db->where('category_id', $category_id);
	    $result = $this->db->update('ads_categories', $data);
		if($result)
		  return '1';
		 else 
		  return '0';

    } //End of Update status function


}