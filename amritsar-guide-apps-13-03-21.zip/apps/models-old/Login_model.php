<?php 
class Login_model extends CI_Model
{
	 
	function login($email, $password)
		 {
		     
		   $this->db->select('*');
		   $this->db->from('users');
		   $this->db->where('email', $email);
		   $this->db->limit(1);
		   $query = $this->db->get();
		   
		   if($query -> num_rows() == 1)
		   {
			  $row = $query->row();	
			  
				if ($this->agent->is_browser())
				{		
					$agent = $this->agent->browser().' '.$this->agent->version();
				}
				elseif ($this->agent->is_robot())
				{		$agent = $this->agent->robot();
				}
				elseif ($this->agent->is_mobile())
				{		$agent = $this->agent->mobile();
				}
				else
				{		$agent = 'Unidentified User Agent';
				}
			if (SHA1($password.$row->salt) == $row->password)
			{ 
			  if($row->is_active=='0')
			  {
				  return '1';
				  exit();
			  }
			 /*  elseif($row->expiry_date !='0000-00-00' && $row->expiry_date <= date('Y-m-d'))
			  { 
			 	 return '2';  //Validity has been expired.
			     exit();
			  } */
			 else
			 { 
			 	//unset session values
				$this->session->unset_userdata('user_id');
				$this->session->unset_userdata('f_name');
				$this->session->unset_userdata('l_name');
				$this->session->unset_userdata('name');
				$this->session->unset_userdata('user_type');
				$this->session->unset_userdata('role_id');
				$this->session->unset_userdata('is_master');
				$this->session->unset_userdata('dept_id');
				//Set the basic values into the session
				$this->session->set_userdata('user_id', $row->user_id);
				$this->session->set_userdata('designation_id', $row->designation_id);
				$this->session->set_userdata('dept_id', $row->department_id);
				$this->session->set_userdata('f_name', $row->first_name);
				$this->session->set_userdata('l_name', $row->last_name);
				$this->session->set_userdata('user_type',$row->user_type);
				$this->session->set_userdata('is_master',$row->is_master);
				$this->session->set_userdata('site_lang','english'); 
				$this->session->set_userdata('lang_id','1');
				$this->session->set_userdata('lang_label_id','1');
				
				$field = array('project_id'=>'1','is_active'=>'1');
				$projectrow = gettableinfo('projects',$field);
				$staterow = get_table_info('state','state_id',$projectrow->state_id);
				$cityrow = get_table_info('city','city_id',$projectrow->city_id);
				
				$this->session->set_userdata('country_id',$projectrow->country_id);
				$this->session->set_userdata('state_id',$projectrow->state_id);
				$this->session->set_userdata('city_id',$projectrow->city_id);
				
				$this->session->set_userdata('state_name',$staterow->state_name);
				$this->session->set_userdata('city_name',$cityrow->city_name);
				
				if($row->user_type=='U')
				{
					 $fields = array('user_id'=>$row->user_id,'is_active'=>'1');
					 $rolerow = gettableinfo('user_roles',$fields);
							  
					$this->session->set_userdata('role_id',$rolerow->role_id);
				}
				 //Insert Log sessions
				 $data = array(
					 'session_id'=>session_id(),
					 'user_id'=>$this->session->userdata('user_id'),
					 'login_time'=>date('Y-m-d H:i:s'),
					 'logout_time'=>date('Y-m-d H:i:s'),
					 'IP_address'=>$_SERVER['REMOTE_ADDR'],
					 'user_agent'=>$agent,				 
				 );
				$result = $this->db->insert('log_sessions',$data);
				
			   return $query->row();
			   exit();
			  }
				
			 }
			
			else
		    {
			 return '0'; //Invalid Password Details
			 exit();
		    }
		   }
		   else
		   {
			 return '0'; //Invalid Email Details
			 exit();
		   }
		 }  //End of login function
		 
		 
	 function normal_login(){
		$email_mobile=$this->session->userdata('email_mobile');
		$password=md5($this->input->post("password"));
		$this->db->select('*');
		$this->db->where('password',$password);
		$this->db->where("(email=$email_mobile or mobile=$email_mobile)");
		//$this->db->or_where('mobile',$email_mobile);
		$query = $this->db->get('users');
		$num_rows=$query->num_rows();
		
		$sql = $this->db->last_query();
		if($num_rows>0){
			$result = $query->row();
			return $result;
		}else{
			return False;
		}
		
		//$result = $query->result();
		
	} 
	function update_password()
	{
			 $data        = array(
				'password'     => md5($this->input->post("newpassword")), 
			);
		 
		 $this->db->where('user_id', $this->session->userdata('user_id'));
		 $result = $this->db->update('users', $data);
			
		if ($result)
		   return 1;
		 else
		   return 0;
		
	} //End of Update function	
		 
}
?>