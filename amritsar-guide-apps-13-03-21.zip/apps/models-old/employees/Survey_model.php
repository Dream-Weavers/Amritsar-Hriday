<?php

class Survey_model extends CI_Model
{	
	function add()
	{   	
		 
		 $survey_number = $this->get_survey_num(); 
		
		
         $data        = array(
			'name'     => $this->input->post("customer_name"),
			'gender'   => $this->input->post("gender"),
			'age'     => $this->input->post("age"),
			'address'     => $this->input->post("address"),
			'area'     => $this->input->post("area"),
			'city'     => $this->input->post("city"),
			'staying_amritsar_before_independence'     => $this->input->post("staying_amritsar_before_independence"),
			'staying_amritsar_after_independence'     => $this->input->post("staying_amritsar_after_independence"),
			'years_staying_in_amritsar_after_independence'     => $this->input->post("years_staying_in_amritsar_after_independence"),
			'know_place_not_exists_now'     => $this->input->post("know_place_not_exists_now"),
			'place_exact_location'     => $this->input->post("place_exact_location"),
			'place_longitude'     => $this->input->post("place_longitude"),
			'place_latitude'     => $this->input->post("place_latitude"),
			'place_remarks'     => $this->input->post("place_remarks"),
			'event_not_exists_now'     => $this->input->post("event_not_exists_now"),
			'event_exact_location'     => $this->input->post("event_exact_location"),
			'event_longitude'     => $this->input->post("event_longitude"),
			'event_latitude'     => $this->input->post("event_latitude"),
			'event_remarks'     => $this->input->post("event_remarks"),
			'site_alteration'     => $this->input->post("site_alteration"),
			'site_exact_location'     => $this->input->post("site_exact_location"),
			'site_latitude'     => $this->input->post("site_latitude"),
			'site_longitude'     => $this->input->post("site_longitude"),
			'site_remarks'     => $this->input->post("site_remarks"),
			'remarks'     => $this->input->post("remarks"),
			'survey_number'     => $survey_number,
			'survey_date'     => $this->input->post("survey_date"),
			'user_id'     => $this->session->userdata('user_id'),
			'created_date'      => date('Y-m-d H:i:s')
        );
        $result   = $this->db->insert('survey', $data);
		$survey_id  = $this->db->insert_id();
		/* if($result > 0)
		{
		    if($this->input->post("country_id")!='')
		    {
		     $survey_id = $this->insertUserAddress($survey_id);
			 $update_data =array( 
				'survey_id' => $survey_id,
			 );	
			 $this->db->where('survey_id', $survey_id);
			 $result = $this->db->update('surveys', $update_data);
		    }
		    if($this->input->post("role_id")!='')
		    {
		     $survey_role_id = $this->insertUserRole($survey_id);
		    }
			$update_by[] = array('uid' => $this->session->userdata('survey_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "survey";
			$operation = "Record added";
			createLogFile($operation,$survey_id,$update_by_id,$table_name);
		 } */
		 if($result){
			return $survey_id;
		 }
		 else
			return 0;


    } //End of add function
	function get_survey_num()
	{
		$this->db->select('MAX(survey_number) AS survey_number');
	    $query=$this->db->get('survey');
		$survey_number = $query->row(); 
		if($survey_number->survey_number==''){
			return 1;
		} else {
			return $survey_number->survey_number+1;
		}
	}
	function survey_attribute_collection($survey_id, $source_type, $media_type, $filename)
    {	
		$filename = str_replace(" ","_",$filename);
		$data        = array(
			'source'     => $survey_id.'_'.$filename,
			'survey_id'  => $survey_id,
			'source_type'     	=> $source_type,
			'media_type'     	=> $media_type
        );
        $this->db->insert('survey_attribute_collection', $data);
    }
	
	function fetch_survey_attribute_collection($survey_id)
    {	
	
		$this->db->select('*');
		$this->db->where('survey_id', $survey_id);
		$query=$this->db->get('survey_attribute_collection');
		$result = $query->result(); 
		$allrecords=array();
		$record_ids=array();
		foreach($result as $val){
			$allrecords[$val->source_type][$val->media_type][]=$val->source."||".$val->survey_gal_id;
		}
		return $allrecords;
	/* 	echo "<pre>";
		print_r($allrecords);
		die; */
    }
	
	function view_survey()
	{
		$this->db->select('*');
		$this->db->from('survey');
		$this->db->order_by('survey_id', 'DESC');
		$query = $this->db->get();
		//echo $this->db->last_query();die;
		$results = $query->result();
		/* 			
		//Count Total newss Images Records
		foreach ($results as $row) {
			
			$row->total_images= $this->count_news_images($row->news_id);
		} 
		*/
		return $results;
	} //End of View function
	function update_survey($survey_id)
	 {
		
		$data        = array(
			'name'     => $this->input->post("customer_name"),
			'gender'   => $this->input->post("gender"),
			'age'     => $this->input->post("age"),
			'address'     => $this->input->post("address"),
			'city'     => $this->input->post("city"),
			'area'     => $this->input->post("area"),
			'staying_amritsar_before_independence'     => $this->input->post("staying_amritsar_before_independence"),
			'staying_amritsar_after_independence'     => $this->input->post("staying_amritsar_after_independence"),
			'years_staying_in_amritsar_after_independence'     => $this->input->post("years_staying_in_amritsar_after_independence"),
			'know_place_not_exists_now'     => $this->input->post("know_place_not_exists_now"),
			'place_exact_location'     => $this->input->post("place_exact_location"),
			'place_longitude'     => $this->input->post("place_longitude"),
			'place_latitude'     => $this->input->post("place_latitude"),
			'place_remarks'     => $this->input->post("place_remarks"),
			'event_not_exists_now'     => $this->input->post("event_not_exists_now"),
			'event_exact_location'     => $this->input->post("event_exact_location"),
			'event_longitude'     => $this->input->post("event_longitude"),
			'event_latitude'     => $this->input->post("event_latitude"),
			'event_remarks'     => $this->input->post("event_remarks"),
			'site_alteration'     => $this->input->post("site_alteration"),
			'site_exact_location'     => $this->input->post("site_exact_location"),
			'site_latitude'     => $this->input->post("site_latitude"),
			'site_longitude'     => $this->input->post("site_longitude"),
			'site_remarks'     => $this->input->post("site_remarks"),
			'remarks'     => $this->input->post("remarks"),
			'survey_number'     => $survey_number,
			'survey_date'     => $this->input->post("survey_date")
        );

		$this->db->where('survey_id', $survey_id);
		$result = $this->db->update('survey', $data);
		/* if($result > 0)
		{
			if($this->input->post("country_id")!='')
			 {
				$survey_id = $this->updateUserAddress($survey_id,$survey_id);
			 }
			 
			 if($this->input->post("role_id")!='')
			 {
				 $roleResult = $this->UpdateUserRole($survey_id);
			 }
			$update_by[] = array('uid' => $this->session->userdata('survey_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record updated";
			createLogFile($operation,$survey_id,$update_by_id,$table_name);
		} */
		if ($result)
		   return 1;
		 else
		   return 0;
		
	 } //End of Update function
	function survey_edit($survey_id)
	 {

		if ($survey_id == '') {
			redirect(base_url() . "employees/survey/view");
		}
		$this->db->select('*');
		$this->db->from('survey');
		$this->db->where('survey_id', $survey_id);
		$query = $this->db->get();

		return $query->row();

	} //End of edit function
	
	function survey_view($survey_id)
	 {

		if ($survey_id == '') {
			redirect(base_url() . "employees/survey/view");
		}
		$this->db->select('*');
		$this->db->from('survey');
		$this->db->where('survey_id', $survey_id);
		$query = $this->db->get();

		return $query->row();

	} //End of edit function
}