<?php

class Deptlocations_model extends CI_Model
{	
    
    function language_info($lang_id){
        $this->db->select('*');
		$this->db->from('languages');
		$this->db->where_not_in('language_id',$lang_id);
		$query = $this->db->get();
		return $query->result();
    }
	 
	 function get_location_type_info($loc_id){
        	$this->db->select('*');
		 //$this->db->where('language_id',1);
		 //	$this->db->join('product_attributes', 'product_attributes.product_id = products.product_id');
		 $this->db->where('location_id',$loc_id);
		//$this->db->order_by('product_id DESC');
        $this->db->from('locations');
        $query = $this->db->get();
        //print $this->db->last_query();die;
	    $result = $query->row();

       
        return $result;
    }
    
    function media_info($location_id,$media_type,$language_id){
        $this->db->select('*');
        $this->db->from('location_digital_media');
        $this->db->where('location_id',$location_id);
        $this->db->where('media_type',$media_type);
        $this->db->where('language_id',$language_id);
        $this->db->order_by('location_media_id', 'ASC');
        $query = $this->db->get();
        //print $this->db->last_query();
        if ($query->num_rows() > 0) {
            return $result = $query->result();
        }else{
            return false;
        }
   }
   
   
    
    function get_location_info($loc_id,$language_id){
        $this->db->select('*');
		$this->db->from('location_translation');
		$this->db->where('location_id',$loc_id);
		$this->db->where('language_id',$language_id);
		$query = $this->db->get();
		return $query->row();
    }
  
    function view_locations($location_id,$category_type_id,$locality_id,$serial_no,$status,$limit, $start)
    { 
		$this->db->select('locations.*,categories.category_name,location_categories.category_type_id,locality.locality_name');
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->join('location_departments', 'location_departments.location_id = locations.location_id');
		$this->db->where('location_departments.department_id',$this->session->userdata('dept_id'));
		$this->db->where('locations.type!=','event');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('locations.locality_id', $locality_id);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		//$this->db->group_by('locations.location_id'); 
		$this->db->order_by('locations.location_id','DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('locations');
        $query = $this->db->get();
	    $result = $query->result();
	   //echo "--->".$this->db->last_query();
		//echo "<br><br>";
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	
	function count_locations($location_id,$category_type_id,$locality_id,$serial_no,$status) {
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->join('location_departments', 'location_departments.location_id = locations.location_id');
		$this->db->where('location_departments.department_id',$this->session->userdata('dept_id'));
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.type!=','event');
		$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('locations.locality_id', $locality_id);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		//$this->db->group_by('locations.location_id'); 
		$query=$this->db->get('locations');		
		//echo "--------------------->". $this->db->last_query();	 
		//echo "<br><br>";  
		return $query->num_rows();
		
	}     //End of Count function

    
    function get_medialist($product_id,$type,$return_type,$language_id){
        $this->db->select('*');
        $this->db->from('location_digital_media');
        $this->db->where('location_id',$product_id);
        $this->db->where('media_type',$type);
        $this->db->where('language_id',$language_id);
        $query = $this->db->get();
        return $query->$return_type();
	}
  
 	function insertDigitalMedia($location_id,$media_type,$media_file_name)
 	  {
		    $this->db->select('location_media_id');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('lang_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('location_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
		function viewDigitalMedia($location_id,$media_type)
     	{
			$this->db->select('location_digital_media.*');
			$this->db->from('location_digital_media');
			$this->db->join('locations', 'locations.location_id = location_digital_media.location_id');
			//$this->db->where('location_digital_media.is_primary', '1');
			$this->db->where('location_digital_media.location_id', $location_id);
			$this->db->where('location_digital_media.media_type', $media_type);
			$this->db->where('location_digital_media.language_id', 1);
			$this->db->order_by('location_digital_media.created_on', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	 
	   function viewLocationSection($location_id)
     	{	$this->db->select('*');
			$this->db->from('location_sections');
			$this->db->where('location_id', $location_id);
			$this->db->order_by('section_title ', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	     
	   function viewfacilities($location_id,$facility_type)
     	{
			$this->db->select('location_facilities.*');
			$this->db->from('location_facilities');
			$this->db->join('locations', 'locations.location_id = location_facilities.location_id');
			$this->db->where('location_facilities.location_id', $location_id);
			$this->db->where('location_facilities.facility_type', $facility_type);
			$this->db->order_by('location_facilities.location_facility_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	    function viewbeaconlocations($location_id)
     	{
			$this->db->select('beacon_locations.*,beacon_location_actions.action_plan_id,beacon_location_actions.instruction_id,beacon_location_actions.sound_file_id');
			$this->db->from('beacon_locations');
			$this->db->join('beacon_location_actions', 'beacon_location_actions.beacon_location_id = beacon_locations.beacon_location_id');
			$this->db->where('beacon_locations.location_id', $location_id);
			$this->db->order_by('beacon_locations.beacon_location_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	
  function update_status($location_id, $status)
    {
		 if($status=='1')
		 {	$data = array(
				'is_active' => $status,
			);
		 }
		 else
		 {
			$data = array(
				'is_active' => $status,
			);
		 }
        $this->db->where('location_id', $location_id);
        $result = $this->db->update('locations', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
		
	
  function setDefaultMedia($location_id,$location_media_id,$media_type){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $this->db->where('media_type',$media_type);
	   $query = $this->db->get('location_digital_media');
	   if($query->num_rows() > 0 ){
		 $update_data =array( 
			'default_media' => '0',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);	
		 $updateresult = $this->db->update('location_digital_media', $update_data);
		 
		  $updatedata =array( 
			'default_media' => '1',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);
		 $this->db->where('location_media_id', $location_media_id);	
		 $updateresult = $this->db->update('location_digital_media', $updatedata);
		 if($updateresult)
		 { return '1';
		 }
	    }
	  	 else{
		 return '0';
	   }
	}
	
	function deleteDigitalMedia($location_media_id,$audio_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $query = $this->db->get('location_digital_media');
	   if($query->num_rows() > 0 ){
		  $row_media = $query->row();
		  if($row_media->media_file_name!='')
		  {	  $path_dir1 = $audio_path;
		      $shash=('\ '); 
			  $path_original =$path_dir1.trim($shash).$row_media->media_file_name;
			 if (file_exists($path_original)) {
				 chmod($path_dir1, 0777);
				$resultoriginal=  @unlink($path_original);
			  }
		  }
		   $this->db->where('location_media_id',$location_media_id); 
		   $result = $this->db->delete('location_digital_media');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   } 
	   return 1;
	}
	
	function deleteLocSection($location_section_id){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_section_id',$location_section_id); 
	   $query = $this->db->get('location_sections');
	   if($query->num_rows() > 0 ){
		   $this->db->where('location_section_id',$location_section_id); 
		   $result = $this->db->delete('location_sections');
		   if($result)
			{ return '1';
			}
	    }
	  	 else{
		 return '0';
	   }
	}
	
	
	function deleteLocBeacon($beacon_location_id,$location_id){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('beacon_location_id',$beacon_location_id); 
	   $this->db->where('location_id',$location_id);
	   $query = $this->db->get('beacon_locations');
	   if($query->num_rows() > 0 ){
		   $this->db->where('beacon_location_id',$beacon_location_id); 
		   $this->db->where('location_id',$location_id);
		   $result = $this->db->delete('beacon_locations');
		   
		   $this->db->where('beacon_location_id',$beacon_location_id); 
		   $queryaction = $this->db->get('beacon_location_actions');
		   if($queryaction->num_rows() > 0 ){
			   $this->db->where('beacon_location_id',$beacon_location_id); 
			   $resultaction = $this->db->delete('beacon_location_actions');
		   }
		   if($result)
			{ return '1';
			}
	    }
	  	else{
		      return '0';
	        }
	}
	
	
	
   function deleteFacility($location_facility_id,$facility_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_facility_id',$location_facility_id); 
	   $query = $this->db->get('location_facilities');
	   if($query->num_rows() > 0 ){
		  $row_facility = $query->row();
		  if($row_facility->photo_name!='')
		  {	  $path_dir1 = $facility_path;
		      $shash=('\ '); 
			  $photo_path =$path_dir1.trim($shash).$row_facility->photo_name;
			 if (file_exists($photo_path)) {
				 chmod($path_dir1, 0777);
				$resultphoto=  @unlink($photo_path);
			  }
		  }
		  if($row_facility->map2d!='')
		  {	  $path_dir2 = $facility_path;
		      $shash=('\ '); 
			  $map2d_path =$path_dir2.trim($shash).$row_facility->map2d;
			 if (file_exists($map2d_path)) {
				 chmod($path_dir2, 0777);
				$resultmap2d=  @unlink($map2d_path);
			  }
		  }
		   $this->db->where('location_facility_id',$location_facility_id); 
		   $result = $this->db->delete('location_facilities');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   }
	}
	
	
	function location_details($location_id)
     {
        $this->db->select('*');
	    $this->db->where('location_id', $location_id);
        $this->db->from('locations');
        $query = $this->db->get();
		//echo $this->db->last_query();

        return $result = $query->row();

    } //End of View function
	
	function location_categories($location_id)
     {
			$this->db->select('categories.*,location_categories.category_type_id');
			$this->db->from('categories');
			$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
			$this->db->where('location_categories.location_id', $location_id);
			$this->db->where('location_categories.is_active', '1');
			$this->db->order_by('categories.weight', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;
	 }


  
	
}