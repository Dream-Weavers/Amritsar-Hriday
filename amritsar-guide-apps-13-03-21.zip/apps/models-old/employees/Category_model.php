<?php

class Category_model extends CI_Model
{
	
	   // $count: just a counter, call it as 0 in your function call and forget about it
		function get_categories_list($parent_id,$is_active, $count, $lastname='') {
		static $option_results;
		$option_results[''] = '- None - ';
		$indent_flag='';
		// if there is no current navigation id set, start off at the top level (zero)
		if (!isset($parent_id)) {
			$parent_id=1;
		}
		// increment the counter by 1
		$count = $count+1;
	
		// query the database for the sub-categories of whatever the parent navigation is
		$this->db->select('categories.*');
		$this->db->from('categories');
		$this->db->join('category_types', 'category_types.category_type_id = categories.category_type_id');
		if($is_active!='all')
		$this->db->where('categories.is_active', $is_active);
		$this->db->where('category_types.type', 'event');
		$this->db->where('categories.category_parent_id', $parent_id);
		$this->db->where('categories.language_id', $this->session->userdata('lang_id'));
		$this->db->order_by('categories.category_name','ASC');
		$result = $this->db->get();
		//echo 	 $this->db->last_query();
		//echo "<br>";
		   $return = array();
		   if ($result->num_rows() > 0) {
			
			foreach ($result->result_array() as $rowcat) {
		
			if ($parent_id!=0) {
				$indent_flag =  $lastname . '--';
					$indent_flag .=  '>';
			}
				$rowcat['category_name'] = $indent_flag.$rowcat['category_name'];
				$option_results[$rowcat['category_id']] = $rowcat['category_name'];
				// now call the function again, to recurse through the child Navigation
				$this->category_model->get_categories_list($rowcat['category_id'],$is_active, $count, $rowcat['category_name']);
			}
		}
	
    return $option_results;
}
		

	   function add(){
	
         $data   = array(
			'language_id'=>$this->session->userdata('lang_id'),
            'category_type_id'     	=>  '31',
            'category_parent_id'    =>  $this->input->post("parent_id"),
            'category_name'     	=>  $this->input->post("category_name"),
            'description'     		=>  $this->input->post("description"),
            'post_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result = $this->db->insert('categories', $data);
		$id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0;
   
   }//End of addCategories
	
	   function add_icon($category_id,$filename)
	   {			
			$data     = array(
				'icon'     => $category_id.'_'.$filename
			);
			$this->db->where('category_id', $category_id);
			$result = $this->db->update('categories', $data);
	   }
	
	    function view_categories($category_id)
		{	$this->db->select('categories.*,category_types.category_type_id,category_types.category_type');
			$this->db->from('category_types');
			$this->db->join('categories', 'categories.category_type_id = category_types.category_type_id');
			if($category_id!='0')
			$this->db->where('categories.category_id', $category_id);
			$this->db->where('category_types.type', 'event');
			$this->db->order_by('categories.category_type_id', 'ASC');
			$this->db->order_by('categories.category_name', 'ASC');
			$query = $this->db->get();
			//echo $this->db->last_query();
			$result = $query->result();
			return $result;
			
	
		} //End of View function
		
		
		
	
		 function category_edit($category_id)
		 {
			if ($category_id == '') {
				redirect(base_url() . "employees/categories/view");
			}
			$this->db->where('category_id', $category_id);
			$this->db->from('categories');
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
	
		 function update_category($category_id)
		 {
			$data = array(
			 'category_parent_id'    =>  $this->input->post("parent_id"),
            'category_name'     	=>  $this->input->post("category_name"),
            'description'     		=>  $this->input->post("description"),
			);
			$this->db->where('category_id', $category_id);
			$result = $this->db->update('categories', $data);
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
		 
		function update_status($category_id, $status)
		{
			 $data = array(
					'is_active' => $status,
				);
			$this->db->where('category_id', $category_id);
			$result = $this->db->update('categories', $data);
			if($result)
			  return '1';
			 else 
			 return '0';
	
		} //End of Update status function
	 
	 
	
	
}