<?php

class Locations_model extends CI_Model
{	
    
    function language_info($lang_id){
        $this->db->select('*');
		$this->db->from('languages');
		$this->db->where_not_in('language_id',$lang_id);
		$query = $this->db->get();
		return $query->result();
    }
	 
	 function get_location_type_info($loc_id){
        	$this->db->select('*');
		 //$this->db->where('language_id',1);
		 //	$this->db->join('product_attributes', 'product_attributes.product_id = products.product_id');
		 $this->db->where('location_id',$loc_id);
		//$this->db->order_by('product_id DESC');
        $this->db->from('locations');
        $query = $this->db->get();
        //print $this->db->last_query();die;
	    $result = $query->row();

       
        return $result;
    }
    
    function media_info($location_id,$media_type,$language_id){
        $this->db->select('*');
        $this->db->from('location_digital_media');
        $this->db->where('location_id',$location_id);
        $this->db->where('media_type',$media_type);
        $this->db->where('language_id',$language_id);
        $this->db->order_by('location_media_id', 'ASC');
        $query = $this->db->get();
        //print $this->db->last_query();
        if ($query->num_rows() > 0) {
            return $result = $query->result();
        }else{
            return false;
        }
   }
   
   
    
    function get_location_info($loc_id,$language_id){
        $this->db->select('*');
		$this->db->from('location_translation');
		$this->db->where('location_id',$loc_id);
		$this->db->where('language_id',$language_id);
		$query = $this->db->get();
		return $query->row();
    }
    function add_translate($language_id,$loc_id)
	{   
	   
        $data        = array(
			'location_name'     => $this->input->post("location_name"),
			'location_id'=>$loc_id,
			'description'     => $this->input->post("description"),
			'short_name'=>$this->input->post("short_name"),
			'short_description'=>$this->input->post("short_description"),
			'address'=>$this->input->post("address"),
			'language_id'     =>$language_id,
			'rules_regulations'=>$this->input->post("rules_regulations"),
			'alert1_distance'=>$this->input->post("alert1_distance"),
			'alert2_distance'=>$this->input->post("alert2_distance"),
			'alert3_distance'=>$this->input->post("alert3_distance"),
			'alert4_distance'=>$this->input->post("alert4_distance"),
			'alert1_sound_file_id'=>$this->input->post("alert1_sound_file_id"),
			'alert2_sound_file_id'=>$this->input->post("alert2_sound_file_id"),
			'alert3_sound_file_id'=>$this->input->post("alert3_sound_file_id"),
			'alert4_sound_file_id'=>$this->input->post("alert4_sound_file_id"),
			'post_date'      => date('Y-m-d H:i:s')
        );
        $result   =$this->db->insert('location_translation', $data);
		$loc1  = $this->db->insert_id();
		if($result > 0)
		{
            
        
            
            
		    $user_id=$this->session->userdata('user_id');
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $loc1;
		 }
		else
			return 0;


    } //End of add function
	 
    function view_locations($location_id,$category_type_id,$locality_id,$serial_no,$status,$limit, $start)
    { 
		$this->db->select('locations.*,categories.category_name,location_categories.category_type_id,locality.locality_name');
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->where('locations.type!=','event');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('locations.locality_id', $locality_id);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		//$this->db->group_by('locations.location_id'); 
		$this->db->order_by('locations.location_id','DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('locations');
        $query = $this->db->get();
	    $result = $query->result();
	   //echo "--->".$this->db->last_query();
		//echo "<br><br>";
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	
	function count_locations($location_id,$category_type_id,$locality_id,$serial_no,$status) {
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.type!=','event');
		$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('locations.locality_id', $locality_id);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		//$this->db->group_by('locations.location_id'); 
		$query=$this->db->get('locations');		
		//echo "--------------------->". $this->db->last_query();	 
		//echo "<br><br>";  
		return $query->num_rows();
		
	}     //End of Count function

	
	function add($working_hours,$direction_locations)
	{    

	
		 $serial_no = random_string('numeric', 8);
	     $locationfeilds = array('serial_no' =>trim($this->input->post('serial_no')),'language_id'=>$this->session->userdata('lang_id'));
		 $serialnoresult = check_unique('locations',$locationfeilds);
		 if($serialnoresult==1)
		  {   $serial_no = random_string('numeric', 8);
		  }
		  else
		  {  $serial_no = $serial_no;
		  }
		  
		 	 $ticket_fee_details =array();
		 	 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
			 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
			 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
			 $ticket_fee_details[] = $ticketdetails;
			  
			 if(is_array($ticket_fee_details))
			 $ticketfeedetails = json_encode($ticket_fee_details);
			 else
			 $ticketfeedetails = '';
		 
				if(trim($this->input->post("locality_textbox")!='')){
					$data    = array(
					'locality_name'     => $this->input->post("locality_textbox"),
					'city_id'     => '3134',
					'is_active'     => '1'
					);
					$this->db->insert('locality', $data);
					$locality_id  = $this->db->insert_id();
				 } else {
					$locality_id  = $this->input->post("locality_id");
				 }
		 
         $data    = array(
			'language_id'     => $this->session->userdata('lang_id'),
			'location_name'     => $this->input->post("location_name"),
			'short_name'     => $this->input->post("short_name"),
			'serial_no'     => $serial_no,
			'qr_code '     => $serial_no,
			'mobile_no'     => $this->input->post("mobile_no"),
			'landline_no'     => $this->input->post("landline_no"),
			'address'     => $this->input->post("address"),
			'short_description'     => $this->input->post("short_description"),
			'description'     => $this->input->post("description"),
			'state_id'     => $this->session->userdata('state_id'),
			'city_id'     => $this->session->userdata('city_id'),
			'locality_id'    => $locality_id,
			'pin_code'     => $this->input->post("pin_code"),
			'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
			'website_url'     => $this->input->post("website_url"),
			'entry_ticket'     => $this->input->post("location_entry_ticket"),
			'ticket_fee_details'     => $ticketfeedetails,
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude"),
			'gps_location_enab_on_off'=>$this->input->post("gps_enabled"),
			'gps_location_noti_on_off'=>$this->input->post("gps_notification"),
			'alert1_distance'     => $this->input->post("alert1_distance"),
			'alert2_distance'     => $this->input->post("alert2_distance"),
			'alert3_distance'     => $this->input->post("alert3_distance"),
			'alert4_distance'     => $this->input->post("alert4_distance"),
			'alert1_sound_file_id'     => $this->input->post("alert1_sound_file_id"),
			'alert2_sound_file_id'     => $this->input->post("alert2_sound_file_id"),
			'alert3_sound_file_id'     => $this->input->post("alert3_sound_file_id"),
			'alert4_sound_file_id'     => $this->input->post("alert4_sound_file_id"),
			'north_area'     => $this->input->post("north_area"),
			'north_area_title'     => $this->input->post("north_area_title"),
			'south_area'     => $this->input->post("south_area"),
			'south_area_title'     => $this->input->post("south_area_title"),
			'east_area'     => $this->input->post("east_area"),
			'east_area_title'     => $this->input->post("east_area_title"),
			'west_area'     => $this->input->post("west_area"),
			'west_area_title'     => $this->input->post("west_area_title"),
			'airport_distance'     => $this->input->post("airport_distance"),
			'railway_station_distance'     => $this->input->post("railway_station_distance"),
			'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
			'city_centre_distance'     => $this->input->post("city_centre_distance"),
			'wifi_availability'     => $this->input->post("wifi_availability"),
			'headphn_availability'     => $this->input->post("headphn_availability"),
			'working_hours'     => $working_hours,
			'direction_locations'     => $direction_locations,
			'rules_regulations'     => $this->input->post("rules_regulations"),
			'visitors_in_month'     => $this->input->post("visitors_in_month"),
			'location_review'     => $this->input->post("location_review"),
			'surveyor_remarks'     => $this->input->post("surveyor_remarks"),
			'created_by'   => $this->session->userdata('user_id'),
			'reference_links'=>$this->input->post("reference_links"),
			'created_on'      => date('Y-m-d H:i:s')
        );
		/*echo "<pre>";
		print_r($data);
		echo "</pre>";
		die();*/
        $result   = $this->db->insert('locations', $data);
		$location_id  = $this->db->insert_id();
		if($result > 0)
		{
			if(isset($_POST['location_category']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
			
			if(isset($_POST['kiosk_id']))
		    {
		     $kioskresult = $this->insertKioskLocation($location_id);
			}
			
			if(isset($_POST['department_id']))
		    {
		     $departmentresult = $this->insertdepartmentLocation($location_id,$this->input->post("department_id"));
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "locations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0;


    } //End of add function
	
	function addContent($working_hours,$direction_locations)
	{    

	
		 $serial_no = random_string('numeric', 8);
	     $locationfeilds = array('serial_no' =>trim($this->input->post('serial_no')),'language_id'=>$this->session->userdata('content_language_id'));
		 $serialnoresult = check_unique('locations',$locationfeilds);
		 if($serialnoresult==1)
		  {   $serial_no = random_string('numeric', 8);
		  }
		  else
		  {  $serial_no = $serial_no;
		  }
		  
		 	 $ticket_fee_details =array();
		 	 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
			 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
			 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
			 $ticket_fee_details[] = $ticketdetails;
			  
			 if(is_array($ticket_fee_details))
			 $ticketfeedetails = json_encode($ticket_fee_details);
			 else
			 $ticketfeedetails = '';
		 
				if(trim($this->input->post("locality_textbox")!='')){
					$data    = array(
					'locality_name'     => $this->input->post("locality_textbox"),
					'city_id'     => '3134',
					'is_active'     => '1'
					);
					$this->db->insert('locality', $data);
					$locality_id  = $this->db->insert_id();
				 } else {
					$locality_id  = $this->input->post("locality_id");
				 }
		 
         $data    = array(
			'language_id'     => $this->session->userdata('content_language_id'),
			'location_name'     => $this->input->post("location_name"),
			'short_name'     => $this->input->post("short_name"),
			'serial_no'     => $serial_no,
			'qr_code '     => $serial_no,
			'mobile_no'     => $this->input->post("mobile_no"),
			'landline_no'     => $this->input->post("landline_no"),
			'address'     => $this->input->post("address"),
			'short_description'     => $this->input->post("short_description"),
			'description'     => $this->input->post("description"),
			'state_id'     => $this->session->userdata('state_id'),
			'city_id'     => $this->session->userdata('city_id'),
			'locality_id'    => $locality_id,
			'pin_code'     => $this->input->post("pin_code"),
			'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
			'website_url'     => $this->input->post("website_url"),
			'entry_ticket'     => $this->input->post("location_entry_ticket"),
			'ticket_fee_details'     => $ticketfeedetails,
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude"),
			'alert1_distance'     => $this->input->post("alert1_distance"),
			'alert2_distance'     => $this->input->post("alert2_distance"),
			'alert3_distance'     => $this->input->post("alert3_distance"),
			'alert4_distance'     => $this->input->post("alert4_distance"),
			'alert1_sound_file_id'     => $this->input->post("alert1_sound_file_id"),
			'alert2_sound_file_id'     => $this->input->post("alert2_sound_file_id"),
			'alert3_sound_file_id'     => $this->input->post("alert3_sound_file_id"),
			'alert4_sound_file_id'     => $this->input->post("alert4_sound_file_id"),
			'north_area'     => $this->input->post("north_area"),
			'north_area_title'     => $this->input->post("north_area_title"),
			'south_area'     => $this->input->post("south_area"),
			'south_area_title'     => $this->input->post("south_area_title"),
			'east_area'     => $this->input->post("east_area"),
			'east_area_title'     => $this->input->post("east_area_title"),
			'west_area'     => $this->input->post("west_area"),
			'west_area_title'     => $this->input->post("west_area_title"),
			'airport_distance'     => $this->input->post("airport_distance"),
			'railway_station_distance'     => $this->input->post("railway_station_distance"),
			'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
			'city_centre_distance'     => $this->input->post("city_centre_distance"),
			'wifi_availability'     => $this->input->post("wifi_availability"),
			'headphn_availability'     => $this->input->post("headphn_availability"),
			'working_hours'     => $working_hours,
			'direction_locations'     => $direction_locations,
			'rules_regulations'     => $this->input->post("rules_regulations"),
			'visitors_in_month'     => $this->input->post("visitors_in_month"),
			'location_review'     => $this->input->post("location_review"),
			'surveyor_remarks'     => $this->input->post("surveyor_remarks"),
			'created_by'   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
		/*echo "<pre>";
		print_r($data);
		echo "</pre>";
		die();*/
        $result   = $this->db->insert('locations', $data);
		$location_id  = $this->db->insert_id();
		if($result > 0)
		{
			if(isset($_POST['location_category']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "locations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0;


    } //End of add function
    
    function get_medialist($product_id,$type,$return_type,$language_id){
        $this->db->select('*');
        $this->db->from('location_digital_media');
        $this->db->where('location_id',$product_id);
        $this->db->where('media_type',$type);
        $this->db->where('language_id',$language_id);
        $query = $this->db->get();
        return $query->$return_type();
	}
     function update_translate($location_id,$language_id)
	{   
		$old_media_audio=$_POST['old-digital-audio'];
        $old_media_img=$_POST['old-digital-image'];
        $old_media_video=$_POST['old-digital-video'];
        $old_media_vr=$_POST['old-digital-vr'];
        
        $old_media_2d=$_POST['old-digital-2d'];
        $old_media_panorama=$_POST['old-digital-panorama'];
        $old_media_video360=$_POST['old-digital-video360'];
        $old_media_vt=$_POST['old-digital-vt'];
        
        
        $update_pro =array( 
			'location_name' => $this->input->post("location_name"),
			'short_name'     => $this->input->post("short_name"),
			'address'=>$this->input->post("address"),
			'description'=>$this->input->post("description"),
			'short_description'=>$this->input->post("short_description"),
			'rules_regulations'=>$this->input->post("rules_regulations"),
			'rules_regulations'=>$this->input->post("rules_regulations"),
			'alert1_distance'=>$this->input->post("alert1_distance"),
			'alert2_distance'=>$this->input->post("alert2_distance"),
			'alert3_distance'=>$this->input->post("alert3_distance"),
			'alert4_distance'=>$this->input->post("alert4_distance"),
			'alert1_sound_file_id'=>$this->input->post("alert1_sound_file_id"),
			'alert2_sound_file_id'=>$this->input->post("alert2_sound_file_id"),
			'alert3_sound_file_id'=>$this->input->post("alert3_sound_file_id"),
			'alert4_sound_file_id'=>$this->input->post("alert4_sound_file_id"),
			);	
		 $this->db->where('location_id', $location_id);
		  $this->db->where('language_id', $language_id);
		 $updateresult = $this->db->update('location_translation', $update_pro);
        
		if($updateresult > 0)
		{
		    
        $p_id=$location_id;
        
        /*  ================= Audio file starts from here ==================*/
        $count_media=count($old_media_audio);
	    $count_mediatable=$this->get_medialist($p_id,1,'num_rows',$language_id);
	    
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,1,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_audio as $img_old){
    				$imgn=$img_old['gallery_audio'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('location_digital_media');
    					$this->db->where('location_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('language_id', $language_id);
    					$this->db->where('media_type', 1);
    					$this->db->delete($tables);
    					unlink('./assets/static/locations/audio/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('location_digital_media');
    			$this->db->where('location_id', $p_id);
    			$this->db->where('language_id', $language_id);
    			$this->db->where('media_type', 1);
    			$this->db->delete($tables);
    		 }
    	}//die;
        /*  ================= Audio file end from here ==================*/
        /*  ================= Gallery file starts from here ==================*/
        unset($media_img_arr);
        unset($mediatable_img_arr);
         $count_media=count($old_media_img);
	    $count_mediatable=$this->get_medialist($p_id,2,'num_rows',$language_id);
	    //print $count_media.'-'.$count_mediatable;
	    
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,2,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_img as $img_old){
    				$imgn=$img_old['gallery_image'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('location_digital_media');
    					$this->db->where('location_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('language_id', $language_id);
    					$this->db->where('media_type',2);
    					$this->db->delete($tables);
    					
    					unlink('./assets/static/locations/gallery/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('location_digital_media');
    			$this->db->where('location_id', $p_id);
    			$this->db->where('media_type',2);
    			$this->db->where('language_id', $language_id);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	 /*  ================= Gallery file end from here ==================*/
    	 
    	  /*  ================= video file starts from here ==================*/
    	  unset($media_img_arr);
        unset($mediatable_img_arr);
         $count_media=count($old_media_video);
	    $count_mediatable=$this->get_medialist($p_id,3,'num_rows',$language_id);
	    //print $count_media.'-'.$count_mediatable;
	    
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,3,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_video as $img_old){
    				$imgn=$img_old['gallery_video'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('location_digital_media');
    					$this->db->where('location_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('language_id', $language_id);
    					$this->db->where('media_type',3);
    					$this->db->delete($tables);
    					
    				//	unlink('./assets/static/locations/gallery/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('location_digital_media');
    			$this->db->where('location_id', $p_id);
    			$this->db->where('media_type',3);
    			$this->db->where('language_id', $language_id);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	 /*  ================= video file end from here ==================*/
    	
    	 /*  ================= VR file start from here ==================*/
    	 unset($media_img_arr);
        unset($mediatable_img_arr);
    	  $count_media=count($old_media_vr);
	    $count_mediatable=$this->get_medialist($p_id,4,'num_rows',$language_id);
	
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,4,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_vr as $img_old){
    				$imgn=$img_old['gallery_vr'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('location_digital_media');
    					$this->db->where('location_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('language_id', $language_id);
    					$this->db->where('media_type',4);
    					$this->db->delete($tables);
    					unlink('./assets/static/locations/vr/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('location_digital_media');
    			$this->db->where('location_id', $p_id);
    			$this->db->where('media_type',4);
    			$this->db->where('language_id', $language_id);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	/*  ================= VR file end from here ==================*/
    	
    	/*  ================= 2D file start from here ==================*/
    	unset($media_img_arr);
        unset($mediatable_img_arr);
    	  $count_media=count($old_media_2d);
	    $count_mediatable=$this->get_medialist($p_id,5,'num_rows',$language_id);
	
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,5,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_2d as $img_old){
    				$imgn=$img_old['gallery_2d'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('location_digital_media');
    					$this->db->where('location_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('language_id', $language_id);
    					$this->db->where('media_type',5);
    					$this->db->delete($tables);
    					unlink('./assets/static/locations/2dmap/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('location_digital_media');
    			$this->db->where('location_id', $p_id);
    			$this->db->where('media_type',5);
    			$this->db->where('language_id', $language_id);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	/*  ================= 2D file end from here ==================*/
    	
    	/*  ================= panorama file start from here ==================*/
    	unset($media_img_arr);
        unset($mediatable_img_arr);
    	  $count_media=count($old_media_panorama);
	    $count_mediatable=$this->get_medialist($p_id,6,'num_rows',$language_id);
	
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,6,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_panorama as $img_old){
    				$imgn=$img_old['gallery_panorama'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('location_digital_media');
    					$this->db->where('location_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('media_type',6);
    					$this->db->where('language_id', $language_id);
    					$this->db->delete($tables);
    					unlink('./assets/static/locations/panorama/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('location_digital_media');
    			$this->db->where('location_id', $p_id);
    			$this->db->where('language_id', $language_id);
    			$this->db->where('media_type',6);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	/*  ================= panorama file end from here ==================*/
    	
    	
    	 /*  ================= video360 file starts from here ==================*/
    	 unset($media_img_arr);
        unset($mediatable_img_arr);
         $count_media=count($old_media_video360);
	    $count_mediatable=$this->get_medialist($p_id,7,'num_rows',$language_id);
	    //print $count_media.'-'.$count_mediatable;
	    
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,7,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_video360 as $img_old){
    				$imgn=$img_old['gallery_video360'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('location_digital_media');
    					$this->db->where('location_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('language_id', $language_id);
    					$this->db->where('media_type',7);
    					$this->db->delete($tables);
    					
    				//	unlink('./assets/static/locations/gallery/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('location_digital_media');
    			$this->db->where('location_id', $p_id);
    			$this->db->where('media_type',7);
    			$this->db->where('language_id', $language_id);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	 /*  ================= video360 file end from here ==================*/
    	
    	/*  ================= VT file start from here ==================*/
    	unset($media_img_arr);
        unset($mediatable_img_arr);
    	  $count_media=count($old_media_vt);
	    $count_mediatable=$this->get_medialist($p_id,8,'num_rows',$language_id);
	
    	if($count_media!=$count_mediatable){
    		 if($count_media>0){
    			$media_img_arr=array();
    			$mediatable_img_arr=array();
    			$result_mediatable=$this->get_medialist($p_id,8,'result',$language_id);
    			foreach($result_mediatable as $fr_table){
    				$flname=$fr_table->media_file_name;
    				$mediatable_img_arr[$flname]=$flname;
    			}
    			foreach($old_media_vt as $img_old){
    				$imgn=$img_old['gallery_vt'];
    				$media_img_arr[$imgn]=$imgn;
    			}
    			$result = array_diff($mediatable_img_arr, $media_img_arr);
    			if(count($result)>0){
    				foreach($result as $res){
    					$tables = array('location_digital_media');
    					$this->db->where('location_id', $p_id);
    					$this->db->where('media_file_name', $res);
    					$this->db->where('media_type',8);
    					$this->db->where('language_id', $language_id);
    					$this->db->delete($tables);
    					unlink('./assets/static/locations/vt/'.$res);
    				}
    			}
    		 }else{
    			$tables = array('location_digital_media');
    			$this->db->where('location_id', $p_id);
    			$this->db->where('language_id', $language_id);
    			$this->db->where('media_type',8);
    			$this->db->delete($tables);
    		 }
    	}//die;
    	/*  ================= VT file end from here ==================*/
            
            
		    $user_id=$this->session->userdata('user_id');
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "users";
			$operation = "Record added";
			createLogFile($operation,$user_id,$update_by_id,$table_name);
		 }
		 if($updateresult){
			return $location_id;
		 }
		else
			return 0;


    } //End of add function
    
    function insertOldDigitalMedia_intranslate($loc_id,$media_file_name,$mediapath=NULL,$language_id,$oldlan,$media_type)
 	{
		    $this->db->select('*');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$loc_id);
			$this->db->where('language_id',$oldlan);
			$this->db->where('media_type',$media_type);
			$this->db->where('media_file_name',$media_file_name);
			$query = $this->db->get();
			//print $this->db->last_query();die;
			if($query->num_rows() > 0)
			{	
				$fetched_data=$query->row_array();
				
				//Copy File	if exists			
				 if ($mediapath!='') {
				
				    $new_media_file=$loc_id."_".time()."_".$media_file_name;
					$oldfile = $mediapath."/".$media_file_name; 
					$newfile = $mediapath."/".$new_media_file;
					copy($oldfile, $newfile);
					
					$data_type =array( 
						//'language_id'=>$this->session->userdata('lang_id'),
						'location_id'    => $loc_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $new_media_file,
						'created_on'      => date('Y-m-d H:i:s'),
						'language_id'=>$language_id,
					);
				 } else {
					 $data_type =array( 
						//'language_id'=>$this->session->userdata('lang_id'),
						'location_id'    => $loc_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $media_file_name,
						'created_on'      => date('Y-m-d H:i:s'),
						'language_id'=>$language_id,
					);
				 }
				
				  
				
				$this->db->insert('location_digital_media',$data_type);	
				//print $this->db->last_query();die;
				return true;
			}		
	}
	
	
	function insertOldDigitalMedia($old_location_id,$location_id,$media_file_name,$mediapath=NULL)
 	{
		    $this->db->select('*');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$old_location_id);
			$this->db->where('media_file_name',$media_file_name);
			$query = $this->db->get();
			
			if($query->num_rows() > 0)
			{	
				$fetched_data=$query->row_array();
				
				//Copy File	if exists			
				 if ($mediapath!='') {
				
				    $new_media_file=$location_id."_".time()."_".$media_file_name;
					$oldfile = $mediapath."/".$media_file_name; 
					$newfile = $mediapath."/".$new_media_file;
					copy($oldfile, $newfile);
					
					$data_type =array( 
						'language_id'=>$this->session->userdata('content_language_id'),
						'location_id'    => $location_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $new_media_file,
						'created_on'      => date('Y-m-d H:i:s')
					);
				 } else {
					 $data_type =array( 
						'language_id'=>$this->session->userdata('content_language_id'),
						'location_id'    => $location_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $media_file_name,
						'created_on'      => date('Y-m-d H:i:s')
					);
				 }
				
				  
				
				$this->db->insert('location_digital_media',$data_type);	
				return 1;
			}		
	}
	
	
	function insertDigitalMedia($location_id,$media_type,$media_file_name)
 	  {
		    $this->db->select('location_media_id');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('lang_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('location_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	function insertDigitalMedia_translate($location_id,$media_type,$media_file_name,$language_id)
 	  {
		    $this->db->select('location_media_id');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('language_id',$language_id);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $language_id,
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('location_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	
	
	function insertContentDigitalMedia($location_id,$media_type,$media_file_name)
 	  {
		    $this->db->select('location_media_id');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('location_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	function insertOldFacilities($old_location_id, $location_id, $facility_name_no=NULL, $facility_description=NULL, $longitude=NULL,$latitude=NULL,$photo_name=NULL,$map2d=NULL,$facility_type=NULL,$parking_ticket=NULL,$washroom_availability=NULL)
 	{

		$mediapath=realpath('assets/static/locations/facility');
		
		if (isset($photo_name) && $photo_name!=''){
		
			$new_media_file=$location_id."_".time()."_".$photo_name;
			
			$oldfile = $mediapath."/".$photo_name; 
			$newfile = $mediapath."/".$new_media_file;
			copy($oldfile, $newfile);
			
		} else {
			
			$new_media_file='';
		}
		
		//Map
		if (isset($map2d) && $map2d!=''){
		
			$new_map_file=$location_id."_".time()."_".$map2d;
			
			$oldmapfile = $mediapath."/".$map2d; 
			$newmapfile = $mediapath."/".$new_map_file;
			copy($oldmapfile, $newmapfile);
			
		} else {
		
			$new_map_file='';
		}
		
		if($parking_ticket!=''){
			
			$data_type =array( 
				'language_id'=>$this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude,
				'photo_name'    =>  $new_media_file,
				'facility_type'    =>  $facility_type,
				'parking_type'    =>  $parking_ticket,
				'map2d'    =>  $new_map_file,
				'created_on'      => date('Y-m-d H:i:s')
			);

			
		} else if($washroom_availability!=''){
			
			$data_type =array( 
				'language_id'=>$this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude,
				'photo_name'    =>  $new_media_file,
				'facility_type'    =>  $facility_type,
				'washroom_availability'    =>  $washroom_availability,
				'map2d'    =>  $new_map_file,
				'created_on'      => date('Y-m-d H:i:s')
			);

			
		} else {
			$data_type =array( 
				'language_id'=>$this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude,
				'photo_name'    =>  $new_media_file,
				'facility_type'    =>  $facility_type,
				'map2d'    =>  $new_map_file,
				'created_on'      => date('Y-m-d H:i:s')
			);
		}
		$this->db->insert('location_facilities',$data_type);	
		
		return 1;
			
		
	}
	
	function editOldFacilities($location_facility_id, $facility_name_no=NULL, $facility_description=NULL, $longitude=NULL,$latitude=NULL, $parking_ticket=NULL)
 	{

		
			
		if($parking_ticket!=''){
			
			$data_type =array( 
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude,
				'parking_type'    =>  $parking_ticket
			);

			
		} else {
			$data_type =array( 
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude
			);
		}
		$this->db->where('location_facility_id',$location_facility_id);	
		$this->db->update('location_facilities',$data_type);	
		
		return 1;
			
		
	}
	
	 function insertBeacon($data) {
        $result = $this->db->insert('beacon_locations', $data);
		$beacon_location_id = $this->db->insert_id();
		if($beacon_location_id)
		{    return $beacon_location_id;
		}
		else
		{	 return '0';
		}
	 }
	  
	
	  function insertBeaconlocations($data) {
        $result = $this->db->insert('beacon_location_actions', $data);
		//echo $this->db->last_query();die;
		$beacon_action_id = $this->db->insert_id();
		if($beacon_action_id)
		{    return $beacon_action_id;
		}
		else
		{	 return '0';
		}
	 }
	 
	  
	
	
	 
	   function insertLocationSection($data) {
        $result = $this->db->insert('location_sections', $data);
		$location_section_id = $this->db->insert_id();
		if($location_section_id)
		{    return $location_section_id;
		}
		else
		{	 return '0';
		}
		
      }
	  
    function insertFacility($data) {
        $result = $this->db->insert('location_facilities', $data);
		$location_facility_id = $this->db->insert_id();
		if($location_facility_id)
		{    return $location_facility_id;
		}
		else
		{	 return '0';
		}
	 }
	  
	  
	function insertDesignation($designation_name)
 	  {
		$this->db->select('*');
		$this->db->from('designation');
		$this->db->where('designation_name',$designation_name);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{ 
		  $desigrow = $query->row();
		  $designation_id = $desigrow->designation_id;
		}else
		{	 $data =array( 
				'designation_name' => $this->input->post("designation_name"),
			 );	
			 $result= $this->db->insert('designation',$data);	
			 $designation_id  = $this->db->insert_id();
		 }
		if($designation_id)
		 return $designation_id;
		else
		 return 0;
	}
	
	
	function insertDepartment($department_name)
 	  {
		$this->db->select('*');
		$this->db->from('department');
		$this->db->where('department_name',$department_name);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{ 
		  $deptrow = $query->row();
		  $department_id = $deptrow->department_id;
		}else
		{	 $data =array( 
				'department_name' => $this->input->post("department_name"),
			 );	
			 $result= $this->db->insert('department',$data);	
			 $department_id  = $this->db->insert_id();
		 }
		if($department_id)
		 return $department_id;
		else
		 return 0;
	}
	
	function updateUserAddress($user_id,$user_address_id)
 	  {			$address_data =array( 
				'country_id' => $this->input->post("country_id"),
				'state_id' => $this->input->post("state_id"),
				'city_id' => $this->input->post("city_id"),
				'address' => $this->input->post("address"),
				'pin_code' => $this->input->post("pin_code")
			 );	
			 $this->db->where('user_address_id', $user_address_id);
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_address', $address_data);
			if($result)
				return 1;
			else
				return 0;
	}
	
	 function insertLocationCategory($location_id)
 	   {   
	   $location_category = $_POST['location_category'];
	   if(is_array($location_category))
	    {
	    foreach($location_category as $catkey=> $catval){
		 if($catval!='')
		  { 
			$this->db->select('*');
			$this->db->from('location_categories');
			$this->db->where('location_id',$location_id);
			$this->db->where('category_id',$catval);
			$this->db->order_by('location_category_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'location_id' => $location_id,
					'category_type_id' => $this->input->post("category_type_id"),
					'category_id' => $catval,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('location_categories',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}
	
	
	 function location_edit($location_id)
		 {
			if ($location_id == '') {
				redirect(base_url() . "employees/locations/view");
			}
			$this->db->select('*');
			$this->db->from('locations');
			$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
			$this->db->where('locations.location_id', $location_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
		
		
		 function location_kioskedit($location_id)
		 {
			$this->db->select('kiosks.kiosk_id,kiosks.kiosk_name,kiosks.kiosk_category_id,location_kiosks.location_kiosk_id');
			$this->db->join('kiosks', 'kiosks.kiosk_id = location_kiosks.kiosk_id');
			$this->db->from('location_kiosks');
			$this->db->where('location_kiosks.is_active','1');
			$this->db->where('location_kiosks.location_id', $location_id);
			$this->db->where('location_kiosks.language_id', $this->session->userdata('lang_id'));
			$this->db->order_by('location_kiosks.kiosk_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;
	
		} //End of edit function
		
		function viewDigitalMedia($location_id,$media_type)
     	{
			$this->db->select('location_digital_media.*');
			$this->db->from('location_digital_media');
			$this->db->join('locations', 'locations.location_id = location_digital_media.location_id');
			//$this->db->where('location_digital_media.is_primary', '1');
			$this->db->where('location_digital_media.location_id', $location_id);
			$this->db->where('location_digital_media.media_type', $media_type);
			$this->db->where('location_digital_media.language_id', 1);
			$this->db->order_by('location_digital_media.created_on', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	 
	   function viewLocationSection($location_id)
     	{	$this->db->select('*');
			$this->db->from('location_sections');
			$this->db->where('location_id', $location_id);
			$this->db->order_by('section_title ', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	     
	   function viewfacilities($location_id,$facility_type)
     	{
			$this->db->select('location_facilities.*');
			$this->db->from('location_facilities');
			$this->db->join('locations', 'locations.location_id = location_facilities.location_id');
			$this->db->where('location_facilities.location_id', $location_id);
			$this->db->where('location_facilities.facility_type', $facility_type);
			$this->db->order_by('location_facilities.location_facility_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	    function viewbeaconlocations($location_id)
     	{
			$this->db->select('beacon_locations.*,beacon_location_actions.*');
			$this->db->from('beacon_locations');
			$this->db->join('beacon_location_actions', 'beacon_location_actions.beacon_location_id = beacon_locations.beacon_location_id');
			$this->db->where('beacon_locations.location_id', $location_id);
			$this->db->order_by('beacon_locations.beacon_location_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	
	
		 function update_location($location_id,$working_hours,$direction_locations)
		 {
			 $ticket_fee_details =array();
		 	 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
			 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
			 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
			 $ticket_fee_details[] = $ticketdetails;
			  
			 if(is_array($ticket_fee_details))
			 $ticketfeedetails = json_encode($ticket_fee_details);
			 else
			 $ticketfeedetails = '';
		 
		 
			 if(trim($this->input->post("locality_textbox")!='')){
				$data    = array(
				'locality_name'     => $this->input->post("locality_textbox"),
				'city_id'     => '3134',
				'is_active'     => '1'
				);
				$this->db->insert('locality', $data);
				$locality_id  = $this->db->insert_id();
			 } else {
				$locality_id  = $this->input->post("locality_id");
			 }
			 
			 
			 
			$data = array(
				'location_name'     => $this->input->post("location_name"),
				'short_name'     => $this->input->post("short_name"),
				'mobile_no'     => $this->input->post("mobile_no"),
				'landline_no'     => $this->input->post("landline_no"),
				'address'     => $this->input->post("address"),
				'short_description'     => $this->input->post("short_description"),
				'description'     => $this->input->post("description"),
				'locality_id'    => $locality_id,
				'pin_code'     => $this->input->post("pin_code"),
				'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
				'website_url'     => $this->input->post("website_url"),
				'entry_ticket'     => $this->input->post("location_entry_ticket"),
				'ticket_fee_details'     => $ticketfeedetails,
				'longitude'     => $this->input->post("longitude"),
				'latitude'     => $this->input->post("latitude"),
				'alert1_distance'     => $this->input->post("alert1_distance"),
				'gps_location_enab_on_off' => $this->input->post("gps_enabled"),
				'gps_location_noti_on_off' => $this->input->post("gps_notification"),
				/*'alert2_distance'     => $this->input->post("alert2_distance"),
				'alert3_distance'     => $this->input->post("alert3_distance"),
				'alert4_distance'     => $this->input->post("alert4_distance"),*/
				'alert1_sound_file_id'     => $this->input->post("alert1_sound_file_id"),
				/*'alert2_sound_file_id'     => $this->input->post("alert2_sound_file_id"),
				'alert3_sound_file_id'     => $this->input->post("alert3_sound_file_id"),
				'alert4_sound_file_id'     => $this->input->post("alert4_sound_file_id"),*/
				'north_area'     => $this->input->post("north_area"),
				'north_area_title'     => $this->input->post("north_area_title"),
				'south_area'     => $this->input->post("south_area"),
				'south_area_title'     => $this->input->post("south_area_title"),
				'east_area'     => $this->input->post("east_area"),
				'east_area_title'     => $this->input->post("east_area_title"),
				'west_area'     => $this->input->post("west_area"),
				'west_area_title'     => $this->input->post("west_area_title"),
				'airport_distance'     => $this->input->post("airport_distance"),
				'railway_station_distance'     => $this->input->post("railway_station_distance"),
				'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
				'city_centre_distance'     => $this->input->post("city_centre_distance"),
				'wifi_availability'     => $this->input->post("wifi_availability"),
				'headphn_availability'     => $this->input->post("headphn_availability"),
				'working_hours'     => $working_hours,
				'direction_locations'     => $direction_locations,
				'rules_regulations'     => $this->input->post("rules_regulations"),
				'visitors_in_month'     => $this->input->post("visitors_in_month"),
				'location_review'     => $this->input->post("location_review"),
				'surveyor_remarks'     => $this->input->post("surveyor_remarks"),
				'reference_links'=>$this->input->post("reference_links"),
			);
			$this->db->where('location_id', $location_id);
			$result = $this->db->update('locations', $data);
			
			if($result > 0)
   		    {
				if(isset($_POST['location_category']))
		        {	
		            //print 'sssssfffff';die;
		            $updateresult = $this->updateLocationCategory($this->input->post("category_type_id"),$location_id,$_POST['location_category']);
				
		            
		        }
				
				/*if(isset($_POST['kiosk_id']))
		        {	$updatekioskresult = $this->updateKiosklocation($location_id,$this->input->post("kiosk_id"));
				}
				if(isset($_POST['department_id']))
		        {	$updatedepartmentresult = $this->updatedepartmentLocation($location_id,$this->input->post("department_id"));
				}*/
				
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "locations";
				$operation = "Record updated";
				createLogFile($operation,$location_id,$update_by_id,$table_name);
		    } 
			if ($result){
			   //print 'dddddd';die;
			   return 1;
			
			    
			}
			 else{
			    //print 'sssss';die;
			   return 0;
			 }
			
		 } //End of Update function
		 
	
	
	 function updateLocationCategory($category_type_id,$location_id,$CategoryList)
 	  {
		
		$insertresult=false;
		if(is_array($CategoryList))
		{
		 $done=0; 	
		 $already=0; 	
		 $fields1=array('location_id'=>$location_id,'is_active'=>'1');
		 //print '<pre>';print_r($fields);die;
	     $categoryresult=gettableresult('location_categories',$fields1);
	     
	     if(is_array($categoryresult))
	     {
		  foreach($categoryresult as $grow){
			 if(!in_array($grow->category_id,$CategoryList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('location_id', $location_id);
			  $this->db->where('category_id',$grow->category_id);
			  $updateresult = $this->db->update('location_categories', $data);
			}
		  }
		 }
		 
		foreach($CategoryList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('location_category_id');
						$this->db->from('location_categories');
						$this->db->where('location_id',$location_id);
						$this->db->where('category_type_id',$category_type_id);
						$this->db->where('category_id',$listrow);
						$category_result = $this->db->get();
						if($category_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $category_result->row();	
						      $location_category_id = $tgrow->location_category_id;
							  $this->db->where('location_category_id', $location_category_id);
							  $this->db->where('location_id', $location_id);
							  $this->db->where('category_id',$listrow);
							  $updateresult = $this->db->update('location_categories', $data);
						}else
						{
							$this->db->select('location_category_id');
							$this->db->from('location_categories');
							$this->db->where('location_category_id', $location_category_id);
							$this->db->where('location_id',$location_id);
							$this->db->where('category_id',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{  
							  $data_type =array( 
								'location_id'   =>  $location_id,
								'category_type_id'    =>  $category_type_id,
								'category_id'    =>  $listrow,
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('location_categories',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	
   

    function update_status($location_id, $status)
    {
		 if($status=='1')
		 {	$data = array(
				'is_active' => $status,
			);
		 }
		 else
		 {
			$data = array(
				'is_active' => $status,
			);
		 }
        $this->db->where('location_id', $location_id);
        $result = $this->db->update('locations', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
	function copy_status($location_id)
    {
		$this->db->select('*');
		$this->db->where('location_id', $location_id);
        $this->db->from('locations');
        $query = $this->db->get();
	    $result = $query->row();
	
        $data    = array(

			'language_id'     => $result->language_id,
			'state_id'     => $result->state_id,
			'city_id'     => $result->city_id,
			'locality_id'    => $result->locality_id,
			'pin_code'     => $result->pin_code,
			'estimated_visit_time'     => $result->estimated_visit_time,
			'website_url'     => $result->website_url,
			'entry_ticket'     => $result->entry_ticket,
			'ticket_fee_details'     => $result->ticket_fee_details,
			'longitude'     => $result->longitude,
			'latitude'     => $result->latitude,
			'alert1_distance'     => $result->alert1_distance,
			'alert2_distance'     => $result->alert2_distance,
			'alert3_distance'     => $result->alert3_distance,
			'alert4_distance'     => $result->alert4_distance,
			'alert1_sound_file_id'=> $result->alert1_sound_file_id,
			'alert2_sound_file_id'     => $result->alert2_sound_file_id,
			'alert3_sound_file_id'     => $result->alert3_sound_file_id,
			'alert4_sound_file_id'     => $result->alert4_sound_file_id,
			'north_area'     => $result->north_area,
			'north_area_title'     => $result->north_area_title,
			'south_area'     => $result->south_area,
			'south_area_title'     => $result->south_area_title,
			'east_area'     => $result->east_area,
			'east_area_title'     => $result->east_area_title,
			'west_area'     => $result->west_area,
			'west_area_title'     => $result->west_area_title,
			'airport_distance'     => $result->airport_distance,
			'railway_station_distance'     => $result->railway_station_distance,
			'bus_stand_distance'     => $result->bus_stand_distance,
			'city_centre_distance'     => $result->city_centre_distance,
			'wifi_availability'     => $result->wifi_availability,
			'headphn_availability'     => $result->headphn_availability,
			'working_hours'     => $result->working_hours,
			'direction_locations'     => $result->direction_locations,
			'rules_regulations'     => $result->rules_regulations,
			'visitors_in_month'     => $result->visitors_in_month,
			'location_review'     => $result->location_review,
			'is_active'     => 	$result->is_active,
			'surveyor_remarks'     => $result->surveyor_remarks,
			'created_by'   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
		
        $this->db->insert('locations', $data);
		$main_location_id=$this->db->insert_id();
		
		$this->db->select('*');
		$this->db->from('location_categories');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_category_id', 'ASC');
		$query = $this->db->get();
		$result = $query->result();
		/* echo "<pre>";
		print_r($result);
		echo "</pre>";
		die(); */
		if($query->num_rows() > 0)
		{
		   foreach($result as $row){
			   
			   $data =array( 
					'location_id' => $main_location_id,
					'category_type_id' => $row->category_type_id,
					'category_id' => $row->category_id,
					'is_active' => $row->is_active,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$this->db->insert('location_categories',$data);
		   }
		}
			
		/* $this->db->select('*');
		$this->db->from('slocation_digital_media');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_media_id', 'ASC');
		$digital_result = $this->db->get();
		$result = $digital_result->result();
		if($digital_result->num_rows() > 0)
		{  
			foreach($result as $row){
			 $data_type =array( 
				'language_id'   => $row->language_id,
				'location_id'    => $main_location_id,
				'media_type'    =>  $row->media_type,
				'default_media'    =>  $row->default_media,
				'media_file_name'    =>  $row->media_file_name,
				'created_on'      => $row->created_on
			  );
			  
			  $this->db->insert('location_digital_media',$data_type);	
			 // $location_media_id  = $this->db->insert_id();
			
			 /*  $update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			  $update_by_id = json_encode($update_by);
			  $table_name = "slocation_digital_media";
			  $operation = "Record added";
			  createLogFile($operation,$location_media_id,$update_by_id,$table_name); 
			}
		} */
		
		$this->db->select('*');
		$this->db->from('location_facilities');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_facility_id', 'ASC');
		$fac_result = $this->db->get();
		if($digital_result->num_rows() > 0)
		$result = $fac_result->result();
		{  
			foreach($result as $row){
			 	$data = array(
					'language_id'=>$row->language_id,
					'location_id'=>$main_location_id,
					'facility_name_no'  => $row->facility_name_no,
					'facility_description'  => $row->facility_description,
					'facility_type'  => $row->facility_type,
					'washroom_availability' => $row->washroom_availability,
					'longitude'     => $row->longitude,
					'latitude'     => $row->latitude,
					'parking_type'     => $row->parking_type,
					'parking_fee'     => $row->parking_fee,
					'is_active' => $row->is_active,
					'created_on '      => date('Y-m-d H:i:s')
				);
			    $this->db->insert('location_facilities',$data);	
			}
		}
		return $main_location_id;
		
    } 
	
	function new_record_copy_media($old_location_id,$new_location_id)
    {
		$this->db->select('*');
		$this->db->from('location_digital_media');
		$this->db->where('location_id',$old_location_id);
		$this->db->order_by('location_media_id', 'ASC');
		$digital_result = $this->db->get();
		$result = $digital_result->result();
		if($digital_result->num_rows() > 0)
		{  
			foreach($result as $row){
			 $data_type =array( 
				'language_id'   => $row->language_id,
				'location_id'    => $new_location_id,
				'media_type'    =>  $row->media_type,
				'default_media'    =>  $row->default_media,
				'media_file_name'    =>  $new_location_id."_".$row->media_file_name,
				'created_on'      => $row->created_on
			  );
			  
			  $this->db->insert('location_digital_media',$data_type);	
			 // $location_media_id  = $this->db->insert_id();
			
			 /*  $update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			  $update_by_id = json_encode($update_by);
			  $table_name = "slocation_digital_media";
			  $operation = "Record added";
			  createLogFile($operation,$location_media_id,$update_by_id,$table_name); 
			} */
		}
		
		$this->db->select('*');
		$this->db->from('location_facilities');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_facility_id', 'ASC');
		$fac_result = $this->db->get();
		if($digital_result->num_rows() > 0)
		$result = $fac_result->result();
		{  
			foreach($result as $row){
			 	$data = array(
					'language_id'=>$row->language_id,
					'location_id'=>$new_location_id,
					'facility_name_no'  => $row->facility_name_no,
					'facility_description'  => $row->facility_description,
					'facility_type'  => $row->facility_type,
					'washroom_availability' => $row->washroom_availability,
					'longitude'     => $row->longitude,
					'latitude'     => $row->latitude,
					'parking_type'     => $row->parking_type,
					'parking_fee'     => $row->parking_fee,
					'is_active' => $row->is_active,
					'created_on '      => date('Y-m-d H:i:s')
				);
			    $this->db->insert('location_facilities',$data);	
			}
		}
		return $main_location_id;
		
} }
	
  function setDefaultMedia($location_id,$location_media_id,$media_type){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $this->db->where('media_type',$media_type);
	   $query = $this->db->get('location_digital_media');
	   if($query->num_rows() > 0 ){
		 $update_data =array( 
			'default_media' => '0',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);	
		 $updateresult = $this->db->update('location_digital_media', $update_data);
		 
		  $updatedata =array( 
			'default_media' => '1',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);
		 $this->db->where('location_media_id', $location_media_id);	
		 $updateresult = $this->db->update('location_digital_media', $updatedata);
		 if($updateresult)
		 { return '1';
		 }
	    }
	  	 else{
		 return '0';
	   }
	}
	
	function deleteDigitalMedia($location_media_id,$audio_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $query = $this->db->get('location_digital_media');
	   if($query->num_rows() > 0 ){
		  $row_media = $query->row();
		  if($row_media->media_file_name!='')
		  {	  $path_dir1 = $audio_path;
		      $shash=('\ '); 
			  $path_original =$path_dir1.trim($shash).$row_media->media_file_name;
			 if (file_exists($path_original)) {
				 chmod($path_dir1, 0777);
				$resultoriginal=  @unlink($path_original);
			  }
		  }
		   $this->db->where('location_media_id',$location_media_id); 
		   $result = $this->db->delete('location_digital_media');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   } 
	   return 1;
	}
	
	function deleteLocSection($location_section_id){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_section_id',$location_section_id); 
	   $query = $this->db->get('location_sections');
	   if($query->num_rows() > 0 ){
		   $this->db->where('location_section_id',$location_section_id); 
		   $result = $this->db->delete('location_sections');
		   if($result)
			{ return '1';
			}
	    }
	  	 else{
		 return '0';
	   }
	}
	
	
	function deleteLocBeacon($beacon_location_id,$location_id){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('beacon_location_id',$beacon_location_id); 
	   $this->db->where('location_id',$location_id);
	   $query = $this->db->get('beacon_locations');
	   if($query->num_rows() > 0 ){
		   $this->db->where('beacon_location_id',$beacon_location_id); 
		   $this->db->where('location_id',$location_id);
		   $result = $this->db->delete('beacon_locations');
		   
		   $this->db->where('beacon_location_id',$beacon_location_id); 
		   $queryaction = $this->db->get('beacon_location_actions');
		   if($queryaction->num_rows() > 0 ){
			   $this->db->where('beacon_location_id',$beacon_location_id); 
			   $resultaction = $this->db->delete('beacon_location_actions');
		   }
		   if($result)
			{ return '1';
			}
	    }
	  	else{
		      return '0';
	        }
	}
	
	
	
   function deleteFacility($location_facility_id,$facility_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_facility_id',$location_facility_id); 
	   $query = $this->db->get('location_facilities');
	   if($query->num_rows() > 0 ){
		  $row_facility = $query->row();
		  if($row_facility->photo_name!='')
		  {	  $path_dir1 = $facility_path;
		      $shash=('\ '); 
			  $photo_path =$path_dir1.trim($shash).$row_facility->photo_name;
			 if (file_exists($photo_path)) {
				 chmod($path_dir1, 0777);
				$resultphoto=  @unlink($photo_path);
			  }
		  }
		  if($row_facility->map2d!='')
		  {	  $path_dir2 = $facility_path;
		      $shash=('\ '); 
			  $map2d_path =$path_dir2.trim($shash).$row_facility->map2d;
			 if (file_exists($map2d_path)) {
				 chmod($path_dir2, 0777);
				$resultmap2d=  @unlink($map2d_path);
			  }
		  }
		   $this->db->where('location_facility_id',$location_facility_id); 
		   $result = $this->db->delete('location_facilities');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   }
	}
	
	
	function location_details($location_id)
     {
        $this->db->select('*');
	    $this->db->where('location_id', $location_id);
        $this->db->from('locations');
        $query = $this->db->get();
		//echo $this->db->last_query();

        return $result = $query->row();

    } //End of View function
	
	function location_categories($location_id)
     {
			$this->db->select('categories.*,location_categories.category_type_id');
			$this->db->from('categories');
			$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
			$this->db->where('location_categories.location_id', $location_id);
			$this->db->where('location_categories.is_active', '1');
			$this->db->order_by('categories.weight', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;
	 }


    function get_beacons_dropdown()
    {  
		$this->db->select('*');
        $this->db->from('beacons');
		$this->db->where('is_active','1');
		$this->db->order_by('beacon_name','ASC');
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select';
            foreach ($result->result_array() as $row) {
                $return[$row['beacon_unique_id']] = $row['beacon_name'];
            }
        }
        return $return;
    }
	
	function get_beacon_ids()
    {  
		/*$this->db->select('beacon_unique_id');
        $this->db->from('beacon_locations');
		$this->db->where('is_active','1');
		$this->db->order_by('beacon_unique_id','ASC');
		$this->db->group_by('beacon_unique_id');
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $return[$row['beacon_unique_id']] = $row['beacon_unique_id'];
            } 
        }*/
        $this->db->select('beacon_unique_id');
        $this->db->from('beacon_locations1');
		//$this->db->where('is_active','1');
		//$this->db->where('assigned_to','L');
		$this->db->order_by('beacon_unique_id','ASC');
		//$this->db->group_by('beacon_unique_id');
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $return[$row['beacon_unique_id']] = $row['beacon_unique_id'];
            }
        }
        return $return;
    }
    
    
    function beacon_location_assigned(){
        $this->db->select('*');
        $this->db->from('beacon_locations1');
		$this->db->where('assigned_to','L');
		$this->db->where('language_id',1);
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select';
            foreach ($result->result_array() as $row) {
                $return[$row['type_id']] = $row['type_id'];
            }
        }
        return $return;
    }
    
    function beacon_vendor_assigned(){
        $this->db->select('*');
        $this->db->from('beacon_locations1');
		$this->db->where('assigned_to','V');
		$this->db->where('language_id',1);
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select';
            foreach ($result->result_array() as $row) {
                $return[$row['type_id']] = $row['type_id'];
            }
        }
        return $return;
    }
    
	
	function get_beacon_edit_ids($loc_id)
    {  
		$this->db->select('beacon_unique_id');
        $this->db->from('beacon_locations');
		$this->db->where('is_active','1');
		$this->db->where('location_id!=',$loc_id);
		$this->db->order_by('beacon_unique_id','ASC');
		$this->db->group_by('beacon_unique_id');
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $return[$row['beacon_unique_id']] = $row['beacon_unique_id'];
            }
        }
        return $return;
    }
   
    
    function get_beacon_translate_edit_ids($beacon_id)
    {  
		/*$this->db->select('*');
        $this->db->from('beacons');
		$this->db->where('beacons.is_active','1');
		$this->db->where('beacons.beacon_unique_id',$beacon_id);
		$this->db->join('beacon_locations', 'beacon_locations.beacon_unique_id = beacons.beacon_unique_id');
		$this->db->order_by('beacons.beacon_name','ASC');
		$this->db->group_by('beacon_locations.location_id'); 
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select';
            foreach ($result->result_array() as $row) {
                $return[$row['beacon_unique_id']] = $row['beacon_name'];
            }
        }*/
        $return[1] = 'asdda';
        return $return;
    }
    
    /*	function get_beacon_translate_edit_ids($loc_id)
    {  
		$this->db->select('beacon_unique_id');
        $this->db->from('beacon_locations');
		$this->db->where('is_active','1');
		$this->db->where('location_id',$loc_id);
		$this->db->order_by('beacon_unique_id','ASC');
		$this->db->group_by('beacon_unique_id');
		$result = $this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $return[$row['beacon_unique_id']] = $row['beacon_unique_id'];
            }
        }
        return $return;
    }*/
	
	function get_beacon_action_edit_ids($loc_id)
    {  
		$this->db->select('beacon_location_actions.action_plan_id');
		$this->db->join('beacon_locations', 'beacon_locations.beacon_location_id = beacon_location_actions.beacon_location_id');
		$this->db->from('beacon_location_actions');
		$this->db->where('beacon_locations.location_id',$loc_id);
		$result=$this->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
            foreach ($result->result_array() as $row) {
                $return[$row['action_plan_id']] = $row['action_plan_id'];
            }
        }
        return $return;
    }
	
	 function insertKioskLocation($location_id)
 	   {   
	   $kiosk_ids = $_POST['kiosk_id'];
	   if(is_array($kiosk_ids))
	    {
	    foreach($kiosk_ids as $kioskkey=> $kioskval){
		 if($kioskval!='')
		  { 
			$this->db->select('*');
			$this->db->from('location_kiosks');
			$this->db->where('location_id',$location_id);
			$this->db->where('kiosk_id',$kioskval);
			$this->db->order_by('location_kiosk_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'language_id'   => $this->session->userdata('lang_id'),
					'location_id'    => $location_id,
					'kiosk_id'    =>  $kiosk_id,
					'created_on'      => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('location_kiosks',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}
	
	 function insertdepartmentLocation($location_id,$department_id)
 	  {
		    if($department_id!='')
			{
				$this->db->select('location_department_id');
				$this->db->from('location_departments');
				$this->db->where('location_id',$location_id);
				$this->db->where('department_id',$department_id);
				$this->db->order_by('location_department_id', 'ASC');
				$query = $this->db->get();
				if($query->num_rows() == 0)
				{	
					$data_type =array( 
						'language_id'   => $this->session->userdata('lang_id'),
						'location_id'    => $location_id,
						'department_id'    =>  $department_id,
						'created_by'      => $this->session->userdata('user_id'),
						'created_on'      => date('Y-m-d H:i:s')
					);
					$insertresult= $this->db->insert('location_departments',$data_type);	
				}
			}
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	
	
	  function updateKiosklocation($location_id,$Kioskist)
 	  {
		/*echo "<pre>";
		print_r($Kioskist);
		echo "</pre>";
		die();*/
	
		$insertresult=false;
		if(is_array($Kioskist))
		{
		 $done=0; 	
		 $already=0; 	
		 $fields=array('location_id'=>$location_id,'is_active'=>'1');
	     $kioskresult=gettableresult('location_kiosks',$fields);
	     if(is_array($kioskresult))
	     {
		  foreach($kioskresult as $grow){
			 if(!in_array($grow->kiosk_id,$Kioskist)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('location_id', $location_id);
			  $this->db->where('kiosk_id',$grow->kiosk_id);
			  $updateresult = $this->db->update('location_kiosks', $data);
			}
		  }
		 }
		 
		foreach($Kioskist as $key=> $kioskid){
			 		if($kioskid!='') 
					{   
						$this->db->select('*');
						$this->db->from('location_kiosks');
						$this->db->where('location_id',$location_id);
						$this->db->where('kiosk_id',$kioskid);
						$kiosk_result = $this->db->get();
						if($kiosk_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $kiosk_result->row();	
						      $this->db->where('location_id', $location_id);
							  $this->db->where('kiosk_id',$kioskid);
							  $updateresult = $this->db->update('location_kiosks', $data);
						}else
						{
							$this->db->select('location_kiosk_id');
							$this->db->from('location_kiosks');
							$this->db->where('location_id',$location_id);
							$this->db->where('kiosk_id',$kioskid);
							$this->db->where('is_active','1');
							$kiosks_result = $this->db->get();
							if($kiosks_result->num_rows() == 0)
							{  
							  $data_type =array( 
							    'language_id'   => $this->session->userdata('lang_id'),
								'location_id'   =>  $location_id,
								'kiosk_id'    =>  $kioskid,
								'created_on'      => date('Y-m-d H:i:s')
							   );	
							  $insertresult= $this->db->insert('location_kiosks',$data_type);	
							  $done++;
							}else
							{	  $already++;
							}
						}
		  			}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	
	

	 function updatedepartmentLocation($location_id,$department_id)
		 {
			 if($department_id!='')
			 {
				$this->db->select('location_department_id');
				$this->db->from('location_departments');
				$this->db->where('language_id',$this->session->userdata('lang_id'));
				$this->db->where('location_id',$location_id);
				$this->db->order_by('location_department_id', 'ASC');
				$query = $this->db->get();
				//echo $this->db->last_query();
				//die();
				if($query->num_rows() == 0)
				{	
				   //echo "---------->1";
					$data_type =array( 
						'language_id'   => $this->session->userdata('lang_id'),
						'location_id'    => $location_id,
						'department_id'    => $department_id,
						'created_by'      => $this->session->userdata('user_id'),
						'created_on'      => date('Y-m-d H:i:s')
					);
					$result= $this->db->insert('location_departments',$data_type);	
				     //print_r($data_type);
					 //die();
				}
				else
				{
					$data =array( 
						'department_id'    =>  $department_id
			 		);	
					 $this->db->where('location_id', $location_id);	
					 $this->db->where('language_id', $this->session->userdata('lang_id'));	
					 $result = $this->db->update('location_departments', $data);
				}
				//echo $this->db->last_query();
				//die();
				//die();
			}
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	function all_vendors(){
	    $this->db->select('user_id,first_name,last_name');
		$this->db->from('users');
		$this->db->where('user_type','V');
		$this->db->where('is_active','1');
		$this->db->order_by('user_id', 'ASC');
		$query = $this->db->get();
		//print $this->db->last_query();
		$vn=array();
		$vn['']='Select';
		foreach ($query->result_array() as $row)
        {
            $id=$row['user_id'];
            $vn[$id]=$row['first_name'].' '.$row['last_name'];
        }
        return $vn;
	}
	function all_locations(){
	    $this->db->select('location_id,location_name');
		$this->db->from('locations');
		$this->db->where('is_active','1');
		$this->db->where('language_id',1);
		$this->db->order_by('location_id', 'ASC');
		$query = $this->db->get();
		//print $this->db->last_query();
		$loc=array();
		$loc['']='Select';
		foreach ($query->result_array() as $row)
        {
            $id=$row['location_id'];
            $loc[$id]=$row['location_name'];
        }
        return $loc;
	}
	
	function assign_beac($type,$id,$beaconid){
     $data_type =array( 
	    'beacon_unique_id'   => $beaconid,
		'assigned_to'   =>  $type,
		'type_id'    =>  $id,
		'language_id'    =>  1,
		'user_id'      => $this->session->userdata('user_id')
	   );	
	  $insertresult= $this->db->insert('beacon_locations1',$data_type);	
	  $lastid= $this->db->insert_id();
	   return $lastid;
	}
	
	function beacon_actions($last_insert,$array){
     $data_type =array( 
	    'beacon_auto_id'   => $last_insert,
		'beacon_actions'   =>  json_encode($array),
	   );	
	  $insertresult= $this->db->insert('beacon_location_actions1',$data_type);	
	   return $lastid;
	}
	
	function basic_beacons($id){
	    $this->db->select('*');
		$this->db->from('beacon_locations1');
		$this->db->where('beacon_auto_id',$id);
		$query = $this->db->get();
		$row=$query->row();
        return $row;
	}
	
    function advanced_beacons($id){
	    $this->db->select('*');
		$this->db->from('beacon_location_actions1');
		$this->db->where('beacon_auto_id',$id);
		$query = $this->db->get();
		$row=$query->row();
        return $row;
	}
	
	function update_beac($id,$type,$tid,$beaconid){
	  
	  $data_type =array( 
	    'beacon_unique_id'   => $beaconid,
		'assigned_to'   =>  $type,
		'type_id'    =>  $tid,
	   );
	 $this->db->where('beacon_auto_id', $id);	
	 $this->db->where('language_id', 1);	
	 $result = $this->db->update('beacon_locations1', $data_type);
	  
	   return true;
	}
	
	function update_beacon_actions($id,$array){

	   $data_type =array( 
	    'beacon_actions'   => json_encode($array),
	   );
	 $this->db->where('beacon_auto_id', $id);	
	 $result = $this->db->update('beacon_location_actions1', $data_type);
	  
	   return true; 
	   
	}
	
	function gps_info($lid,$lang_id){
	    $this->db->select('*');
		$this->db->from('locations_gps_info');
		$this->db->where('location_id',$lid);
		$this->db->where('language_id',$lang_id);
		$query = $this->db->get();
		$row=$query->row();
        return $row;
	}
	
	function insert_gps_info($lid,$lang_id,$resp_data){
	    
	    $data_type =array( 
	    'location_id'   => $lid,
		'language_id'   =>  $lang_id,
		'location_gps_info'    =>  $resp_data,
	   );	
	  $insertresult= $this->db->insert('locations_gps_info',$data_type);	
	  $lastid= $this->db->insert_id();
	  return true;
	}
	
	function checkrecord_exists_gps($lid,$lang_id){
	     $this->db->select('*');
		$this->db->from('locations_gps_info');
		$this->db->where('location_id',$lid);
		$this->db->where('language_id',$lang_id);
		$query = $this->db->get();
		$rows=$query->num_rows();
		return $rows;
	}
	
}