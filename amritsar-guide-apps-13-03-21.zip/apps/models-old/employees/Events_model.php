<?php

class Events_model extends CI_Model
{	
	 
    function view_locations($location_id,$category_type_id,$locality_id,$serial_no,$status,$limit, $start)
    { 
		$this->db->select('locations.*,categories.category_name,location_categories.category_type_id,locality.locality_name');
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		
		$this->db->where('locations.type','event');
		
		$this->db->where('location_categories.is_active','1');
		
		$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('locations.locality_id', $locality_id);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		$this->db->group_by('locations.location_id'); 
		$this->db->order_by('locations.location_id','DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('locations');
        $query = $this->db->get();
	    $result = $query->result();
	   //echo "--->".$this->db->last_query();
		//echo "<br><br>";
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	
	function count_locations($location_id,$category_type_id,$locality_id,$serial_no,$status) {
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->where('locations.type','event');
		
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('locations.locality_id', $locality_id);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		$this->db->group_by('locations.location_id'); 
		$query=$this->db->get('locations');		
		//echo "--------------------->". $this->db->last_query();	 
		//echo "<br><br>";  
		return $query->num_rows();
		
	}     //End of Count function
	
	
	
  function view_deptlocations($location_id,$category_type_id,$locality_id,$serial_no,$status,$limit, $start)
    { 
		$this->db->select('locations.*,categories.category_name,location_categories.category_type_id,locality.locality_name');
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->join('location_departments', 'location_departments.location_id = locations.location_id');
		$this->db->where('location_departments.department_id',$this->session->userdata('dept_id'));
		$this->db->where('locations.type','event');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('locations.locality_id', $locality_id);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		$this->db->group_by('locations.location_id'); 
		$this->db->order_by('locations.location_id','DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('locations');
        $query = $this->db->get();
	    $result = $query->result();
	   //echo "--->".$this->db->last_query();
		//echo "<br><br>";
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	
	function count_deptlocations($location_id,$category_type_id,$locality_id,$serial_no,$status) {
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->join('location_departments', 'location_departments.location_id = locations.location_id');
		$this->db->where('location_departments.department_id',$this->session->userdata('dept_id'));
		$this->db->where('locations.type','event');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		if($location_id!='0')
		$this->db->where('locations.location_id', $location_id);
		if($category_type_id!='0')
		$this->db->where('location_categories.category_type_id', $category_type_id);
		if($locality_id!='0')
		$this->db->where('locations.locality_id', $locality_id);
		if($serial_no!='0')
		$this->db->where('locations.serial_no', $serial_no);
		
		if($status!='0')
		{	if($status == 'a')
			{	$status = '1';
			}
			else
			{	$status = '0';
			}
			$this->db->where('locations.is_active',$status);
		}	
		$this->db->group_by('locations.location_id'); 
		$query=$this->db->get('locations');		
		//echo "--------------------->". $this->db->last_query();	 
		//echo "<br><br>";  
		return $query->num_rows();
		
	}     //End of Count function

	
	function add($working_hours)
	{    
		 $serial_no = random_string('numeric', 8);
	     $locationfeilds = array('serial_no' =>trim($this->input->post('serial_no')),'language_id'=>$this->session->userdata('lang_id'));
		 $serialnoresult = check_unique('locations',$locationfeilds);
		 if($serialnoresult==1)
		  {   $serial_no = random_string('numeric', 8);
		  }
		  else
		  {  $serial_no = $serial_no;
		  }
		  
		 	 $ticket_fee_details =array();
		 	 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
			 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
			 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
			 $ticketdetails['tkt_avai_title']= $this->input->post("tkt_avai_title"); 	
			 $ticketdetails['tkt_avai_website_url']= $this->input->post("tkt_avai_website_url"); 	
			 $ticketdetails['tkt_avai_description']= $this->input->post("tkt_avai_description"); 	
			 $ticketdetails['tkt_avai_mobile_no']= $this->input->post("tkt_avai_mobile_no"); 	
			 $ticketdetails['tkt_avai_landline_no']= $this->input->post("tkt_avai_landline_no"); 	
			 $ticket_fee_details[] = $ticketdetails;
			  
			 if(is_array($ticket_fee_details))
			 $ticketfeedetails = json_encode($ticket_fee_details);
			 else
			 $ticketfeedetails = '';
		 
				if(trim($this->input->post("locality_textbox")!='')){
					$data    = array(
					'locality_name'     => $this->input->post("locality_textbox"),
					'city_id'     => '3134',
					'is_active'     => '1'
					);
					$this->db->insert('locality', $data);
					$locality_id  = $this->db->insert_id();
				 } else {
					$locality_id  = $this->input->post("locality_id");
				 }
		 
         $data    = array(
			'language_id'     => $this->session->userdata('lang_id'),
			'location_name'     => $this->input->post("location_name"),
			'mobile_no'     => $this->input->post("mobile_no"),
			'landline_no'     => $this->input->post("landline_no"),
			'address'     => $this->input->post("address"),
			'description'     => $this->input->post("description"),
			'state_id'     => $this->session->userdata('state_id'),
			'city_id'     => $this->session->userdata('city_id'),
			'locality_id'    => $locality_id,
			'pin_code'     => $this->input->post("pin_code"),
			'website_url'     => $this->input->post("website_url"),
			'entry_ticket'     => $this->input->post("location_entry_ticket"),
			'ticket_fee_details'     => $ticketfeedetails,
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude"),
			'working_hours'     => $working_hours,
			'type'     => 'event',
			'organized_by'     => $this->input->post("organized_by"),
			'event_start_date'     => $this->input->post("event_start_date"),
			'event_end_date'     => $this->input->post("event_end_date"),
			'created_by'   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
		/*echo "<pre>";
		print_r($data);
		echo "</pre>";
		die();*/
        $result   = $this->db->insert('locations', $data);
		$location_id  = $this->db->insert_id();
		if($result > 0)
		{
			if(isset($_POST['location_category']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
			if(isset($_POST['department_id']))
		    {
		     $departmentresult = $this->insertdepartmentLocation($location_id,$this->input->post("department_id"));
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "locations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0;


    } //End of add function
	
	
	function insertDigitalMedia($location_id,$media_type,$media_file_name)
 	  {
		    $this->db->select('location_media_id');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('lang_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('location_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
	}

	
	function insertContentDigitalMedia($location_id,$media_type,$media_file_name)
 	  {
		    $this->db->select('location_media_id');
			$this->db->from('location_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('location_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	 function insertLocationCategory($location_id)
 	   {   
	   $location_category = $_POST['location_category'];
	   if(is_array($location_category))
	    {
	    foreach($location_category as $catkey=> $catval){
		 if($catval!='')
		  { 
			$this->db->select('*');
			$this->db->from('location_categories');
			$this->db->where('location_id',$location_id);
			$this->db->where('category_id',$catval);
			$this->db->order_by('location_category_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'location_id' => $location_id,
					'category_type_id' => $this->input->post("category_type_id"),
					'category_id' => $catval,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('location_categories',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}
	
	
	 function location_edit($location_id)
		 {
			if ($location_id == '') {
				redirect(base_url() . "employees/events/view");
			}
			$this->db->select('*');
			$this->db->from('locations');
			$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
			$this->db->where('locations.location_id', $location_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
		
		
		function viewDigitalMedia($location_id,$media_type)
     	{
			$this->db->select('location_digital_media.*');
			$this->db->from('location_digital_media');
			$this->db->join('locations', 'locations.location_id = location_digital_media.location_id');
			//$this->db->where('location_digital_media.is_primary', '1');
			$this->db->where('location_digital_media.location_id', $location_id);
			$this->db->where('location_digital_media.media_type', $media_type);
			$this->db->order_by('location_digital_media.created_on', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	
		 function update_location($location_id,$working_hours)
		 {
			 $ticket_fee_details =array();
		 	 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
			 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
			 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 
			 $ticketdetails['tkt_avai_title']= $this->input->post("tkt_avai_title"); 	
			 $ticketdetails['tkt_avai_website_url']= $this->input->post("tkt_avai_website_url"); 	
			 $ticketdetails['tkt_avai_description']= $this->input->post("tkt_avai_description"); 	
			 $ticketdetails['tkt_avai_mobile_no']= $this->input->post("tkt_avai_mobile_no"); 	
			 $ticketdetails['tkt_avai_landline_no']= $this->input->post("tkt_avai_landline_no"); 				 
			 $ticket_fee_details[] = $ticketdetails;
			  
			 if(is_array($ticket_fee_details))
			 $ticketfeedetails = json_encode($ticket_fee_details);
			 else
			 $ticketfeedetails = '';
		 
		 
			 if(trim($this->input->post("locality_textbox")!='')){
				$data    = array(
				'locality_name'     => $this->input->post("locality_textbox"),
				'city_id'     => '3134',
				'is_active'     => '1'
				);
				$this->db->insert('locality', $data);
				$locality_id  = $this->db->insert_id();
			 } else {
				$locality_id  = $this->input->post("locality_id");
			 }
			 
		 
			$data = array(
				'location_name'     => $this->input->post("location_name"),
				'mobile_no' => $this->input->post("mobile_no"),
				'landline_no'     => $this->input->post("landline_no"),
				'address'     => $this->input->post("address"),
				
				'description'     => $this->input->post("description"),
				'locality_id'    => $locality_id,
				'pin_code'     => $this->input->post("pin_code"),
				
				'website_url'     => $this->input->post("website_url"),
				'entry_ticket'     => $this->input->post("location_entry_ticket"),
				'ticket_fee_details'     => $ticketfeedetails,
				'longitude'     => $this->input->post("longitude"),
				'latitude'     => $this->input->post("latitude"),
				
				'wifi_availability'     => $this->input->post("wifi_availability"),
				'working_hours'     => $working_hours,
				'organized_by'     => $this->input->post("organized_by"),
				'event_start_date'     => $this->input->post("event_start_date"),
				'event_end_date'     => $this->input->post("event_end_date")
				
			);
			$this->db->where('location_id', $location_id);
			$result = $this->db->update('locations', $data);
			if($result > 0)
   		    {
				if(isset($_POST['location_category']))
		        {	$updateresult = $this->updateLocationCategory($this->input->post("category_type_id"),$location_id,$_POST['location_category']);
				}
				if(isset($_POST['department_id']))
		        {	$updatedepartmentresult = $this->updatedepartmentLocation($location_id,$this->input->post("department_id"));
				}
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "locations";
				$operation = "Record updated";
				createLogFile($operation,$location_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
	
	 function updateLocationCategory($category_type_id,$location_id,$CategoryList)
 	  {
		/*echo "<pre>";
		print_r($CategoryList);
		echo "</pre>";*/
	
		$insertresult=false;
		if(is_array($CategoryList))
		{
		 $done=0; 	
		 $already=0; 	
		 $fields=array('location_id'=>$location_id,'is_active'=>'1');
	     $categoryresult=gettableresult('location_categories',$fields);
	     if(is_array($categoryresult))
	     {
		  foreach($categoryresult as $grow){
			 if(!in_array($grow->category_id,$CategoryList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('location_id', $location_id);
			  $this->db->where('category_id',$grow->category_id);
			  $updateresult = $this->db->update('location_categories', $data);
			}
		  }
		 }
		foreach($CategoryList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('location_category_id');
						$this->db->from('location_categories');
						$this->db->where('location_id',$location_id);
						$this->db->where('category_type_id',$category_type_id);
						$this->db->where('category_id',$listrow);
						$category_result = $this->db->get();
						if($category_result->num_rows() > 0)
						{  
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $category_result->row();	
						      $location_category_id = $tgrow->location_category_id;
							  $this->db->where('location_category_id', $location_category_id);
							  $this->db->where('location_id', $location_id);
							  $this->db->where('category_id',$listrow);
							  $updateresult = $this->db->update('location_categories', $data);
						}else
						{
							$this->db->select('location_category_id');
							$this->db->from('location_categories');
							$this->db->where('location_category_id', $location_category_id);
							$this->db->where('location_id',$location_id);
							$this->db->where('category_id',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{  
							  $data_type =array( 
								'location_id'   =>  $location_id,
								'category_type_id'    =>  $category_type_id,
								'category_id'    =>  $listrow,
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('location_categories',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			if($insertresult)
			return 1;
			else
			return 0;	
	}
	
   

    function update_status($location_id, $status)
    {
		 if($status=='1')
		 {	$data = array(
				'is_active' => $status,
			);
		 }
		 else
		 {
			$data = array(
				'is_active' => $status,
			);
		 }
        $this->db->where('location_id', $location_id);
        $result = $this->db->update('locations', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
	
  function setDefaultMedia($location_id,$location_media_id,$media_type){
	   // Check first record exists or not if not than no delete 	
	   $this->db->select('*');   
	   $this->db->from('location_digital_media');
	   $this->db->where('location_media_id',$location_media_id); 
	   $this->db->where('media_type',$media_type);
	   $query = $this->db->get();
	   //echo $this->db->last_query();
	  // die();
	   if($query->num_rows() > 0 ){
		 $update_data =array( 
			'default_media' => '0',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);	
		 $updateresult = $this->db->update('location_digital_media', $update_data);
		 
		  $updatedata =array( 
			'default_media' => '1',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);
		 $this->db->where('location_media_id', $location_media_id);	
		 $updateresult = $this->db->update('location_digital_media', $updatedata);
		 if($updateresult)
		 { return '1';
		 }
	    }
	  	 else{
		 return '0';
	   }
	}
	
	function deleteDigitalMedia($location_media_id,$audio_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $query = $this->db->get('location_digital_media');
	   if($query->num_rows() > 0 ){
		  $row_media = $query->row();
		  if($row_media->media_file_name!='')
		  {	  $path_dir1 = $audio_path;
		      $shash=('\ '); 
			  $path_original =$path_dir1.trim($shash).$row_media->media_file_name;
			 if (file_exists($path_original)) {
				 chmod($path_dir1, 0777);
				$resultoriginal=  @unlink($path_original);
			  }
		  }
		   $this->db->where('location_media_id',$location_media_id); 
		   $result = $this->db->delete('location_digital_media');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   } 
	   return 1;
	}
	
		
	function location_details($location_id)
     {
        $this->db->select('*');
	    $this->db->where('location_id', $location_id);
        $this->db->from('locations');
        $query = $this->db->get();
		//echo $this->db->last_query();

        return $result = $query->row();

    } //End of View function
	
	function location_categories($location_id)
     {
			$this->db->select('categories.*,location_categories.category_type_id');
			$this->db->from('categories');
			$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
			$this->db->where('location_categories.location_id', $location_id);
			$this->db->where('location_categories.is_active', '1');
			$this->db->order_by('categories.weight', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;
	 }


   
    function insertdepartmentLocation($location_id,$department_id)
 	  {
		    if($department_id!='')
			{
				$this->db->select('location_department_id');
				$this->db->from('location_departments');
				$this->db->where('location_id',$location_id);
				$this->db->where('department_id',$department_id);
				$this->db->order_by('location_department_id', 'ASC');
				$query = $this->db->get();
				if($query->num_rows() == 0)
				{	
					$data_type =array( 
						'language_id'   => $this->session->userdata('lang_id'),
						'location_id'    => $location_id,
						'department_id'    =>  $department_id,
						'created_by'      => $this->session->userdata('user_id'),
						'created_on'      => date('Y-m-d H:i:s')
					);
					$insertresult= $this->db->insert('location_departments',$data_type);	
				}
			}
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	
	function updatedepartmentLocation($location_id,$department_id)
	 {
			 if($department_id!='')
			 {
				$this->db->select('location_department_id');
				$this->db->from('location_departments');
				$this->db->where('language_id',$this->session->userdata('lang_id'));
				$this->db->where('location_id',$location_id);
				$this->db->order_by('location_department_id', 'ASC');
				$query = $this->db->get();
				if($query->num_rows() == 0)
				{	
					$data_type =array( 
						'language_id'   => $this->session->userdata('lang_id'),
						'location_id'    => $location_id,
						'department_id'    => $department_id,
						'created_by'      => $this->session->userdata('user_id'),
						'created_on'      => date('Y-m-d H:i:s')
					);
					$result= $this->db->insert('location_departments',$data_type);	
				}
				else
				{
					$data =array( 
						'department_id'    =>  $department_id
			 		);	
					 $this->db->where('location_id', $location_id);	
					 $this->db->where('language_id', $this->session->userdata('lang_id'));	
					 $result = $this->db->update('location_departments', $data);
				}
			}
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function

}