<?php

class Slocations_model extends CI_Model
{	
	 
    function view_locations($location_id,$locality_id,$limit, $start)
    {
		$this->db->select('slocations.*,categories.category_name,slocation_categories.category_type_id,locality.locality_name');
		$this->db->join('slocation_categories', 'slocation_categories.location_id = slocations.location_id','left');
		$this->db->join('categories', 'categories.category_id = slocation_categories.category_id','left');
		$this->db->join('locality', 'locality.locality_id = slocations.locality_id','left');
		$this->db->where('slocation_categories.is_active','1');
		$this->db->where('slocations.created_by',$this->session->userdata('user_id'));
		$this->db->where('slocations.is_active','0');
		
		if($location_id!='0')
		$this->db->where('slocations.location_id', $location_id);
	
		if($locality_id!='0')
		$this->db->where('slocations.locality_id', $locality_id);


		$this->db->group_by('slocations.location_id'); 
		$this->db->order_by('slocations.location_id','DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
        $this->db->from('slocations');
        $query = $this->db->get();
	    $result = $query->result();
	   //echo "--->".$this->db->last_query();
		//echo "<br><br>";
		/*echo "<pre>";
		print_r($result);
		echo "</pre>";*/
       
        return $result;

    } //End of View  function
	
	function count_locations($location_id,$locality_id) {
		$this->db->join('slocation_categories', 'slocation_categories.location_id = slocations.location_id','left');
		$this->db->join('categories', 'categories.category_id = slocation_categories.category_id','left');
		$this->db->join('locality', 'locality.locality_id = slocations.locality_id','left');
		$this->db->where('slocation_categories.is_active','1');
		if($location_id!='0')
		$this->db->where('slocations.location_id', $location_id);
		
		$this->db->where('slocations.created_by',$this->session->userdata('user_id'));
		$this->db->where('slocations.is_active','0');

		if($locality_id!='0')
		$this->db->where('slocations.locality_id', $locality_id);
		
		
		
		$this->db->group_by('slocations.location_id'); 
		$query=$this->db->get('slocations');		
		//echo "--------------------->". $this->db->last_query();	 
		//echo "<br><br>";  
		return $query->num_rows();
		
	}     //End of Count function
		
	
	function approved_locations($category_type_id, $location, $limit, $start)
    {
		$user_designation=get_designation();
		
		$this->db->select('slocations.*,categories.category_name,slocation_categories.category_type_id,locality.locality_name');
		
		$this->db->join('slocations', 'slocation_audits.location_id = slocations.location_id');
		$this->db->join('slocation_audit_orders', 'slocation_audits.order_id = slocation_audit_orders.order_id');
		$this->db->join('users', 'slocation_audit_orders.designation_id = users.designation_id');
		$this->db->join('slocation_categories', 'slocation_categories.location_id = slocations.location_id');
		$this->db->join('categories', 'categories.category_id = slocation_categories.category_id','left');
		$this->db->join('locality', 'locality.locality_id = slocations.locality_id','left');
		$this->db->where('slocation_categories.is_active','1');
		$this->db->where('slocations.is_active','0');
		$this->db->where('users.is_active','1');
		$this->db->where('slocation_categories.category_type_id', $category_type_id);
		$this->db->where('slocation_audit_orders.designation_id', $user_designation->designation_id);
		//$this->db->where('slocation_categories.category_type_id', $category_type_id);
		if($location!='')
		$this->db->like('slocations.location_name', $location);

		$this->db->group_by('slocations.location_id'); 
		$this->db->order_by('slocations.location_id','DESC');
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	 
		
        $this->db->from('slocation_audits');
		
		
        $query = $this->db->get();
	    $result = $query->result();
	    //echo "--->".$this->db->last_query();die;
		//echo "<br><br>";
/* 		echo "<pre>";
		print_r($result);
		echo "</pre>"; */
       
        return $result;

    } //End of View  function
	
	
	function add($working_hours,$direction_locations)
	{    
		 $serial_no = random_string('numeric', 8);
	     $locationfeilds = array('serial_no' =>trim($this->input->post('serial_no')),'language_id'=>$this->session->userdata('lang_id'));
		 $serialnoresult = check_unique('slocations',$locationfeilds);
		 if($serialnoresult==1)
		 {   $serial_no = random_string('numeric', 8);
		 }
		 else
		 {  $serial_no = $serial_no;
		 }
		  
		 $ticket_fee_details =array();
		 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
		 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
		 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
		 $ticket_fee_details[] = $ticketdetails;
		  
		 if(is_array($ticket_fee_details))
		 $ticketfeedetails = json_encode($ticket_fee_details);
		 else
		 $ticketfeedetails = '';
		  
		 if(trim($this->input->post("locality_textbox")!='')){
			$data    = array(
			'locality_name'     => $this->input->post("locality_textbox"),
			'city_id'     => '3134',
			'is_active'     => '1'
			);
			$this->db->insert('locality', $data);
			$locality_id  = $this->db->insert_id();
		 } else {
			$locality_id  = $this->input->post("locality_id");
		 }
		  
         $data    = array(
			'language_id'     => $this->session->userdata('lang_id'),
			'location_name'     => $this->input->post("location_name"),
			'short_name'     => $this->input->post("short_name"),
			'serial_no'     => $serial_no,
			'qr_code '     => $serial_no,
			'address'     => $this->input->post("address"),
			'description'     => $this->input->post("description"),
			'state_id'     => $this->session->userdata('state_id'),
			'city_id'     => $this->session->userdata('city_id'),
			'locality_id'    => $locality_id,
			'pin_code'     => $this->input->post("pin_code"),
			'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
			'website_url'     => $this->input->post("website_url"),
			'entry_ticket'     => $this->input->post("location_entry_ticket"),
			'ticket_fee_details'     => $ticketfeedetails,
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude"),
			'north_area'     => $this->input->post("north_area"),
			'north_area_title'     => $this->input->post("north_area_title"),
			'south_area'     => $this->input->post("south_area"),
			'south_area_title'     => $this->input->post("south_area_title"),
			'east_area'     => $this->input->post("east_area"),
			'east_area_title'     => $this->input->post("east_area_title"),
			'west_area'     => $this->input->post("west_area"),
			'west_area_title'     => $this->input->post("west_area_title"),
			
			'wifi_availability'     => $this->input->post("wifi_availability"),
			'headphn_availability'     => $this->input->post("headphn_availability"),
			'working_hours'     => $working_hours,
			'direction_locations'     => $direction_locations,
			'rules_regulations'     => $this->input->post("rules_regulations"),
			'visitors_in_month'     => $this->input->post("visitors_in_month"),
			'location_review'     => $this->input->post("location_review"),
			'surveyor_remarks'     => $this->input->post("surveyor_remarks"),
			'created_by'   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
		/* echo "<pre>";
		print_r($data);
		echo "</pre>";
		die(); */
		$result =$this->db->insert('slocations', $data);
		/* $location_id  = $this->db->insert_id();
        //$result = $this->db->insert('slocations', $data);
		
		if($result > 0)
		{
			if(isset($_POST['category_id']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "slocations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0; */
		$location_id  = $this->db->insert_id();
		if($result > 0)
		{
			if(isset($_POST['location_category']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "slocations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0;

    } //End of add function
	
	function addContent($working_hours,$direction_locations)
	{    
		 $serial_no = random_string('numeric', 8);
	     $locationfeilds = array('serial_no' =>trim($this->input->post('serial_no')),'language_id'=>$this->session->userdata('content_language_id'));
		 $serialnoresult = check_unique('slocations',$locationfeilds);
		 if($serialnoresult==1)
		 {   $serial_no = random_string('numeric', 8);
		 }
		 else
		 {  $serial_no = $serial_no;
		 }
		  
		 $ticket_fee_details =array();
		 $ticketdetails['adult_fee']= $this->input->post("adult_fee"); 	
		 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
		 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 	
		 $ticket_fee_details[] = $ticketdetails;
		  
		 if(is_array($ticket_fee_details))
		 $ticketfeedetails = json_encode($ticket_fee_details);
		 else
		 $ticketfeedetails = '';
		  
		 if(trim($this->input->post("locality_textbox")!='')){
			$data    = array(
			'locality_name'     => $this->input->post("locality_textbox"),
			'city_id'     => '3134',
			'is_active'     => '1'
			);
			$this->db->insert('locality', $data);
			$locality_id  = $this->db->insert_id();
		 } else {
			$locality_id  = $this->input->post("locality_id");
		 }
		  
         $data    = array(
			'language_id'     => $this->session->userdata('content_language_id'),
			'location_name'     => $this->input->post("location_name"),
			'short_name'     => $this->input->post("short_name"),
			'serial_no'     => $serial_no,
			'qr_code '     => $serial_no,
			'address'     => $this->input->post("address"),
			'description'     => $this->input->post("description"),
			'state_id'     => $this->session->userdata('state_id'),
			'city_id'     => $this->session->userdata('city_id'),
			'locality_id'    => $locality_id,
			'pin_code'     => $this->input->post("pin_code"),
			'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
			'website_url'     => $this->input->post("website_url"),
			'entry_ticket'     => $this->input->post("location_entry_ticket"),
			'ticket_fee_details'     => $ticketfeedetails,
			'longitude'     => $this->input->post("longitude"),
			'latitude'     => $this->input->post("latitude"),
			'north_area'     => $this->input->post("north_area"),
			'north_area_title'     => $this->input->post("north_area_title"),
			'south_area'     => $this->input->post("south_area"),
			'south_area_title'     => $this->input->post("south_area_title"),
			'east_area'     => $this->input->post("east_area"),
			'east_area_title'     => $this->input->post("east_area_title"),
			'west_area'     => $this->input->post("west_area"),
			'west_area_title'     => $this->input->post("west_area_title"),
			
			'wifi_availability'     => $this->input->post("wifi_availability"),
			'headphn_availability'     => $this->input->post("headphn_availability"),
			'working_hours'     => $working_hours,
			'direction_locations'     => $direction_locations,
			'rules_regulations'     => $this->input->post("rules_regulations"),
			'visitors_in_month'     => $this->input->post("visitors_in_month"),
			'location_review'     => $this->input->post("location_review"),
			'surveyor_remarks'     => $this->input->post("surveyor_remarks"),
			'created_by'   => $this->session->userdata('user_id'),
			'created_on'      => date('Y-m-d H:i:s')
        );
		/* echo "<pre>";
		print_r($data);
		echo "</pre>";
		die(); */
		$result =$this->db->insert('slocations', $data);
		/* $location_id  = $this->db->insert_id();
        //$result = $this->db->insert('slocations', $data);
		
		if($result > 0)
		{
			if(isset($_POST['category_id']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "slocations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0; */
		$location_id  = $this->db->insert_id();
		if($result > 0)
		{
			if(isset($_POST['location_category']))
		    {
		     $categoryresult = $this->insertLocationCategory($location_id);
			}
		   
			$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			$update_by_id = json_encode($update_by);
			$table_name = "slocations";
			$operation = "Record added";
			createLogFile($operation,$location_id,$update_by_id,$table_name);
		 }
		 if($result){
			return $location_id;
		 }
		else
			return 0;

    } //End of add function
	
	
	function insertOldDigitalMedia($old_location_id,$location_id,$media_file_name,$mediapath=NULL)
 	{
		    $this->db->select('*');
			$this->db->from('slocation_digital_media');
			$this->db->where('location_id',$old_location_id);
			$this->db->where('media_file_name',$media_file_name);
			$query = $this->db->get();
			
			if($query->num_rows() > 0)
			{	
				$fetched_data=$query->row_array();
				
				//Copy File	if exists			
				 if ($mediapath!='') {
				
				    $new_media_file=$location_id."_".time()."_".$media_file_name;
					$oldfile = $mediapath."/".$media_file_name; 
					$newfile = $mediapath."/".$new_media_file;
					copy($oldfile, $newfile);
					
					$data_type =array( 
						'language_id'=>$this->session->userdata('content_language_id'),
						'location_id'    => $location_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $new_media_file,
						'created_on'      => date('Y-m-d H:i:s')
					);
				 } else {
					 $data_type =array( 
						'language_id'=>$this->session->userdata('content_language_id'),
						'location_id'    => $location_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $media_file_name,
						'created_on'      => date('Y-m-d H:i:s')
					);
				 }
				
				  
				
				$this->db->insert('slocation_digital_media',$data_type);	
				return 1;
			}		
	}
	
	function move_location($location_id)
    {
		$this->db->select('*');
		$this->db->where('location_id', $location_id);
        $this->db->from('slocations');
        $query = $this->db->get();
	    $result = $query->row();
	
        $data    = array(
			'language_id'     => $result->language_id,
			'location_name'     => $result->location_name,
			'short_name'     => $result->short_name,
			'serial_no'     => $result->serial_no,
			'qr_code '     => $result->serial_no,
			'address'     => $result->address,
			'short_description'     => $result->short_description,
			'description'     => $result->description,
			'state_id'     => $result->state_id,
			'city_id'     => $result->city_id,
			'locality_id'    => $result->locality_id,
			'pin_code'     => $result->pin_code,
			'estimated_visit_time'     => $result->estimated_visit_time,
			'website_url'     => $result->website_url,
			'entry_ticket'     => $result->entry_ticket,
			'ticket_fee_details'     => $result->ticket_fee_details,
			'longitude'     => $result->longitude,
			'latitude'     => $result->latitude,
			'alert1_distance'     => $result->alert1_distance,
			'alert2_distance'     => $result->alert2_distance,
			'alert3_distance'     => $result->alert3_distance,
			'alert4_distance'     => $result->alert4_distance,
			'alert1_sound_file_id'     => $result->alert1_sound_file_id,
			'alert2_sound_file_id'     => $result->alert2_sound_file_id,
			'alert3_sound_file_id'     => $result->alert3_sound_file_id,
			'alert4_sound_file_id'     => $result->alert4_sound_file_id,
			'north_area'     => $result->north_area,
			'north_area_title'     => $result->north_area_title,
			'south_area'     => $result->south_area,
			'south_area_title'     => $result->south_area_title,
			'east_area'     => $result->east_area,
			'east_area_title'     => $result->east_area_title,
			'west_area'     => $result->west_area,
			'west_area_title'     => $result->west_area_title,
			'wifi_availability'     => $result->wifi_availability,
			'headphn_availability'     => $result->headphn_availability,
			'working_hours'     => $result->working_hours,
			'direction_locations'     => $result->direction_locations,
			'rules_regulations'     => $result->rules_regulations,
			'visitors_in_month'     => $result->visitors_in_month,
			'location_review'     => $result->location_review,
			'is_active'     => 	'1',
			'surveyor_remarks'     => $result->surveyor_remarks,
			'created_by'   => $result->created_by,
			'created_on'      => $result->created_on
        );
		
        $this->db->insert('locations', $data);
		$main_location_id=$this->db->insert_id();
	
		
		$this->db->select('*');
		$this->db->from('slocation_categories');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_category_id', 'ASC');
		$query = $this->db->get();
		$result = $query->result();
		/* echo "<pre>";
		print_r($result);
		echo "</pre>";
		die(); */
		if($query->num_rows() > 0)
		{
		   foreach($result as $row){
			   
			   $data =array( 
					'location_id' => $main_location_id,
					'category_type_id' => $row->category_type_id,
					'category_id' => $row->category_id,
					'is_active' => $row->is_active,
					'created_on'  => $row->created_on
				);	
				$this->db->insert('location_categories',$data);
		   }
		}
			
		$this->db->select('*');
		$this->db->from('slocation_digital_media');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_media_id', 'ASC');
		$digital_result = $this->db->get();
		$result = $digital_result->result();
		if($digital_result->num_rows() > 0)
		{  
			foreach($result as $row){
			 $data_type =array( 
				'language_id'   => $row->language_id,
				'location_id'    => $main_location_id,
				'media_type'    =>  $row->media_type,
				'default_media'    =>  $row->default_media,
				'media_file_name'    =>  $row->media_file_name,
				'is_active' => $row->is_active,
				'created_on'      => $row->created_on
			  );
			  
			  $this->db->insert('location_digital_media',$data_type);	
			 // $location_media_id  = $this->db->insert_id();
			
			 /*  $update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
			  $update_by_id = json_encode($update_by);
			  $table_name = "slocation_digital_media";
			  $operation = "Record added";
			  createLogFile($operation,$location_media_id,$update_by_id,$table_name); */
			}
		}
		
		$this->db->select('*');
		$this->db->from('slocation_facilities');
		$this->db->where('location_id',$location_id);
		$this->db->order_by('location_facility_id', 'ASC');
		$fac_result = $this->db->get();
		if($digital_result->num_rows() > 0)
		$result = $fac_result->result();
		{  
			foreach($result as $row){
			 	$data = array(
					'language_id'=>$row->language_id,
					'location_id'=>$main_location_id,
					'facility_name_no'  => $row->facility_name_no,
					'facility_description'  => $row->facility_description,
					'facility_type'  => $row->facility_type,
					'washroom_availability' => $row->washroom_availability,
					'longitude'     => $row->longitude,
					'latitude'     => $row->latitude,
					'parking_type'     => $row->parking_type,
					'parking_fee'     => $row->parking_fee,
					'photo_name'     => $row->photo_name,
					'map2d '     => $row->map2d,
					'is_active' => $row->is_active,
					'created_on '      => $row->created_on
				);
			    $this->db->insert('location_facilities',$data);	
			}
		}
		/* $data = array(
				'is_active' => '1',
		);
        $this->db->where('location_id', $location_id);
        $result = $this->db->update('slocations', $data); */
		return 1;
		
    } 
	
	function submitforward($location_id)
 	{ 
			
			$this->db->select('order_id');
			$this->db->from('slocation_audits');
			$this->db->where('location_id',$location_id);
			$this->db->where('designation_id',$this->session->userdata('designation_id'));
			//$where = '(wrk_dlvrd_sts="open" or wrk_cl_sts = "Success")';
			//$this->db->where($where);
			$query = $this->db->get();
			if($query->num_rows() < 1)
			{
				$this->approverecord($location_id);
				
				//check any location id exists in slocation_audit withput cheking destination id
				$this->db->select('MAX(order_id) as order_id');
				$this->db->from('slocation_audits');
				$this->db->where('location_id',$location_id);
				$que = $this->db->get();
				$order_id=$que->row()->order_id;
				if($order_id=='')
				{
					$this->db->select('order_id');
					$this->db->from('slocation_audit_orders');
					$this->db->where('is_active','1');
					$this->db->limit(1,0);
					$que = $this->db->get();
					//echo $this->db->last_query();die;
					if($que->num_rows() > 0)
					{	
				
						$order_id=$que->row()->order_id;
						
						$data = array(
							 'location_id'=>$location_id,
							 'order_id'=>$que->row()->order_id,
							 'designation_id'=>$this->session->userdata('designation_id'),
							 'start_date'=>date('Y-m-d H:i:s')			 
						 );
						 $this->db->insert('slocation_audits',$data);
					}
					
					/* 
					if($order_id==''){
					$order_id=0;
					} */
					//Insert Log
					  $data = array(
						 'submitted_by '=>$this->session->userdata('user_id'),
						 'location_id'=>$location_id,
						 'order_id'=>$order_id,
						 'designation_id'=>$this->session->userdata('designation_id'),
						 'log_date'=>date('Y-m-d H:i:s'),
						 'ip_address '=>$_SERVER['REMOTE_ADDR']			 
						);
						
					   $this->db->insert('slocation_audits_log',$data);
					   
					   return 1;
				} else { 
					$this->db->select('order_id');
					$this->db->from('slocation_audit_orders');
					$this->db->where('order_id>',$order_id);
					$this->db->where('is_active','1');
					$this->db->limit(1,0);
					$que = $this->db->get();
					//echo $this->db->last_query();die;
					if($que->num_rows() > 0)
					{	
				
						$order_id=$que->row()->order_id;
						
						$data = array(
							 'location_id'=>$location_id,
							 'order_id'=>$order_id,
							 'designation_id'=>$this->session->userdata('designation_id'),
							 'start_date'=>date('Y-m-d H:i:s')			 
						 );
						 $this->db->insert('slocation_audits',$data);
					}
					else{
						//Move into main locations
						$this->move_location($location_id);
						$order_id=0;
						
						$data = array(
						 'location_id'=>$location_id,
						 'order_id'=>$order_id,
						 'designation_id'=>$this->session->userdata('designation_id'),
						 'start_date'=>date('Y-m-d H:i:s')			 
						 );
						 
						 $this->db->insert('slocation_audits',$data);
					 
					}
				
					
					
					 	 
						 
					//Insert Log
					  $data = array(
						 'submitted_by '=>$this->session->userdata('user_id'),
						 'location_id'=>$location_id,
						 'order_id'=>$order_id,
						 'designation_id'=>$this->session->userdata('designation_id'),
						 'log_date'=>date('Y-m-d H:i:s'),
						 'ip_address '=>$_SERVER['REMOTE_ADDR']			 
						);
						
					   $this->db->insert('slocation_audits_log',$data);
					   
					   return 1;
					
				}
			   
			} else {
				 $data = array(
						 'status'=>NULL
				 );
				 
				  $this->db->where('location_id', $location_id);
				  $this->db->where('designation_id', $this->session->userdata('designation_id'));	
				  $this->db->update('slocation_audits',$data);
				  
				  
				    $this->db->select('*');
					$this->db->from('slocation_audits');
					$this->db->where('location_id', $location_id);
				    $this->db->where('designation_id', $this->session->userdata('designation_id'));	
					$que = $this->db->get();
					
					//echo $this->db->last_query();die;
					
					if($que->num_rows() > 0)
					{
						
						
						//Insert Log
						$data = array(
						 'submitted_by '=>$this->session->userdata('user_id'),
						 'location_id'=>$location_id,
						 'order_id'=>$que->row()->order_id,
						 'designation_id'=>$this->session->userdata('designation_id'),
						 'log_date'=>date('Y-m-d H:i:s'),
						  'status'=>$que->row()->status,
						 'ip_address '=>$_SERVER['REMOTE_ADDR']			 
						);
						
					   $this->db->insert('slocation_audits_log',$data);
					}
				 
						
					
					
			}
			
			
	}
	
	function rejectrecord($location_id)
 	{ 
					$this->db->select('slocation_audits.designation_id,slocation_audits.order_id');
					$this->db->from('slocation_audits');
					$this->db->join('slocation_audit_orders','slocation_audits.order_id=slocation_audit_orders.order_id');
					$this->db->where('slocation_audits.location_id',$location_id);
					$this->db->where('slocation_audit_orders.designation_id',$this->session->userdata('designation_id'));
					$que = $this->db->get();
					$designation_id=$que->row()->designation_id;
					
					$order_id=$que->row()->order_id;
					
					if($designation_id!=''){
					$data = array(
						 'status'=>'0'
					 );
					 
					  $this->db->where('location_id', $location_id);
					  $this->db->where('designation_id', $designation_id);	
					  $this->db->update('slocation_audits',$data);
					}
					
					if($order_id!=''){
						//Insert Log
						$data = array(
						 'submitted_by '=>$this->session->userdata('user_id'),
						 'location_id'=>$location_id,
						 'order_id'=>$order_id,
						 'designation_id'=>$this->session->userdata('designation_id'),
						 'log_date'=>date('Y-m-d H:i:s'),
						  'status'=>'0',
						 'ip_address '=>$_SERVER['REMOTE_ADDR']			 
						);
						
					   $this->db->insert('slocation_audits_log',$data);
					}
					
					
					   
					   
				
			return 1;
			
	}
	function approverecord($location_id)
 	{ 
					$this->db->select('slocation_audits.designation_id,slocation_audits.order_id');
					$this->db->from('slocation_audits');
					$this->db->join('slocation_audit_orders','slocation_audits.order_id=slocation_audit_orders.order_id');
					$this->db->where('slocation_audits.location_id',$location_id);
					$this->db->where('slocation_audit_orders.designation_id',$this->session->userdata('designation_id'));
					$que = $this->db->get();
					$designation_id=$que->row()->designation_id;
					
					$order_id=$que->row()->order_id;
					
					
					if($designation_id!=''){
					$data = array(
						 'status'=>'1'
					 );
					 
					  $this->db->where('location_id', $location_id);
					  $this->db->where('designation_id', $designation_id);	
					  $this->db->update('slocation_audits',$data);
					}
					
					if($order_id!=''){
						//Insert Log
						$data = array(
						 'submitted_by '=>$this->session->userdata('user_id'),
						 'location_id'=>$location_id,
						 'order_id'=>$order_id,
						 'designation_id'=>$this->session->userdata('designation_id'),
						 'log_date'=>date('Y-m-d H:i:s'),
						  'status'=>'1',
						 'ip_address '=>$_SERVER['REMOTE_ADDR']			 
						);
						
					   $this->db->insert('slocation_audits_log',$data);
					}
					
			return 1;
			
	}
	function checksubmitforward($location_id,$designation_id)
 	{
		
		$this->db->select('slocation_audits.order_id');
		$this->db->from('slocation_audits');
		$this->db->join('slocation_audit_orders','slocation_audits.order_id=slocation_audit_orders.order_id');
		$this->db->join('users','slocation_audit_orders.designation_id=users.designation_id');
		$this->db->where('slocation_audits.location_id',$location_id);
		$this->db->where('slocation_audit_orders.designation_id',$designation_id);
		$this->db->where('users.is_active','1');
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{
			return $query->row();
		} else {
			return 0;
		}				
	}
	
	function fetchOldDigitalMedia($old_location_id,$location_id,$media_file_name,$mediapath=NULL)
 	{
		    $this->db->select('*');
			$this->db->from('slocation_digital_media');
			$this->db->where('location_id',$old_location_id);
			$this->db->where('media_file_name',$media_file_name);
			$query = $this->db->get();
			
			if($query->num_rows() > 0)
			{	
				$fetched_data=$query->row_array();
				
				//Copy File	if exists			
				 if ($mediapath!='') {
				
				    $new_media_file=$location_id."_".time()."_".$media_file_name;
					$oldfile = $mediapath."/".$media_file_name; 
					$newfile = $mediapath."/".$new_media_file;
					copy($oldfile, $newfile);
					
					$data_type =array( 
						'language_id'=>$this->session->userdata('content_language_id'),
						'location_id'    => $location_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $new_media_file,
						'created_on'      => date('Y-m-d H:i:s')
					);
				 } else {
					 $data_type =array( 
						'language_id'=>$this->session->userdata('content_language_id'),
						'location_id'    => $location_id,
						'media_type'    =>  $fetched_data['media_type'],
						'default_media'    =>  $fetched_data['default_media'],
						'media_file_name'    =>  $media_file_name,
						'created_on'      => date('Y-m-d H:i:s')
					);
				 }
				
				  
				
				$this->db->insert('slocation_digital_media',$data_type);	
				return 1;
			}		
	}
	function insertDigitalMedia($location_id,$media_type,$media_file_name,$location_new_data=NULL)
 	  {
		  
		    $this->db->select('location_media_id');
			$this->db->from('slocation_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('lang_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			if($location_new_data!=''){
				if($media_type=='1'){
					$media_type='audio';
				} else if($media_type=='2'){
					$media_type='gallery';
				} else if($media_type=='3'){
					$media_type='video';
				} else if($media_type=='5'){
					$media_type='map2d';
				} else if($media_type=='6'){
					$media_type='panorama';
				}
				$location_new_data['DigitalMedia'][$media_type]['default_media'][] = $default_media;
				$location_new_data['DigitalMedia'][$media_type]['media_file_name'][] = $media_file_name;
				$this->db->insert('slocation_digital_media',$data_type);	
				return $location_new_data;
			} else {
				$insertresult= $this->db->insert('slocation_digital_media',$data_type);	
				if($insertresult)
					return 1;
				else
					return 0;
			}
			
			 
			
				
	}
	
	
	
	function insertContentDigitalMedia($location_id,$media_type,$media_file_name)
 	  {
		    $this->db->select('location_media_id');
			$this->db->from('slocation_digital_media');
			$this->db->where('location_id',$location_id);
			$this->db->where('media_type',$media_type);
			$this->db->where('default_media','1');
			$this->db->order_by('location_media_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{	$default_media='1';
			}
			else
			{	$default_media='0';
			}
			$data_type =array( 
				'language_id'   => $this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'media_type'    =>  $media_type,
				'default_media'    =>  $default_media,
				'media_file_name'    =>  $media_file_name,
				'created_on'      => date('Y-m-d H:i:s')
			);
			$insertresult= $this->db->insert('slocation_digital_media',$data_type);	
			if($insertresult)
				return $insertresult;
			else
				return 0;
				
	}
	
	function insertOldFacilities($old_location_id, $location_id, $facility_name_no=NULL, $facility_description=NULL, $longitude=NULL,$latitude=NULL,$photo_name=NULL,$map2d=NULL,$facility_type=NULL,$parking_ticket=NULL,$washroom_availability=NULL)
 	{

		$mediapath=realpath('assets/static/locations/facility');
		
		if (isset($photo_name) && $photo_name!=''){
		
			$new_media_file=$location_id."_".time()."_".$photo_name;
			
			$oldfile = $mediapath."/".$photo_name; 
			$newfile = $mediapath."/".$new_media_file;
			copy($oldfile, $newfile);
			
		} else {
			
			$new_media_file='';
		}
		
		//Map
		if (isset($map2d) && $map2d!=''){
		
			$new_map_file=$location_id."_".time()."_".$map2d;
			
			$oldmapfile = $mediapath."/".$map2d; 
			$newmapfile = $mediapath."/".$new_map_file;
			copy($oldmapfile, $newmapfile);
			
		} else {
		
			$new_map_file='';
		}
		
		if($parking_ticket!=''){
			
			$data_type =array( 
				'language_id'=>$this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude,
				'photo_name'    =>  $new_media_file,
				'facility_type'    =>  $facility_type,
				'parking_type'    =>  $parking_ticket,
				'map2d'    =>  $new_map_file,
				'created_on'      => date('Y-m-d H:i:s')
			);

			
		} else if($washroom_availability!=''){
			
			$data_type =array( 
				'language_id'=>$this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude,
				'photo_name'    =>  $new_media_file,
				'facility_type'    =>  $facility_type,
				'washroom_availability'    =>  $washroom_availability,
				'map2d'    =>  $new_map_file,
				'created_on'      => date('Y-m-d H:i:s')
			);

			
		} else {
			$data_type =array( 
				'language_id'=>$this->session->userdata('content_language_id'),
				'location_id'    => $location_id,
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude,
				'photo_name'    =>  $new_media_file,
				'facility_type'    =>  $facility_type,
				'map2d'    =>  $new_map_file,
				'created_on'      => date('Y-m-d H:i:s')
			);
		}
		
		$this->db->insert('slocation_facilities',$data_type);	
		
		return 1;
			
		
	}
	
	 function insertFacility($data) {
		//$this->db->insert('slocation_facilities', $data);
        //$result = $this->db->insert('location_facilities', $data);
        $result = $this->db->insert('slocation_facilities', $data);
		$location_facility_id = $this->db->insert_id(); 
		if($location_facility_id)
		{    return $location_facility_id;
		}
		else
		{	 return '0';
		}
     }
	  
	  function insertLocText($data) {
		//$this->db->insert('slocation_sections', $data);
        //$result = $this->db->insert('location_sections', $data);
        $result = $this->db->insert('slocation_sections', $data);
		$location_text_id = $this->db->insert_id();
		if($location_text_id)
		{    return $location_text_id;
		}
		else
		{	 return '0';
		}
		
      }
	
	function insertDigitalMedia1($location_id,$media_type,$GroupList,$media_file_name)
 	  {
		  foreach($GroupLists as $key=> $listrow){
			if($listrow['media_file_name']!='') 
			{	$this->db->select('location_media_id');
				$this->db->from('slocation_digital_media');
				$this->db->where('language_id',$this->session->userdata('lang_id'));
				$this->db->where('media_type',$media_type);
				$this->db->where('media_file_name',$media_file_name);
				$digital_result = $this->db->get();
				if($digital_result->num_rows() == 0)
				{  
				     $data_type =array( 
						'language_id'   => $this->session->userdata('lang_id'),
						'location_id'    => $location_id,
						'media_type'    =>  $media_type,
						'media_file_name'    =>  $media_file_name,
						'created_on'      => date('Y-m-d H:i:s')
					  );
					  //$this->db->insert('slocation_digital_media',$data_type);
					  //$insertresult= $this->db->insert('slocation_digital_media',$data_type);	
					  $insertresult= $this->db->insert('slocation_digital_media',$data_type);	
					  $location_media_id  = $this->db->insert_id();
					  $done++;
					  $update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
					  $update_by_id = json_encode($update_by);
					  $table_name = "slocation_digital_media";
					  $operation = "Record added";
					  createLogFile($operation,$location_media_id,$update_by_id,$table_name);
		
				}else
				{	  $already++;
				}
			}
		  }
			if($insertresult)
				return $insertresult;
			else
				return 0;
	}
	
	 function insertLocationSection($data) {
        $result = $this->db->insert('slocation_sections', $data);
		$location_section_id = $this->db->insert_id();
		if($location_section_id)
		{    return $location_section_id;
		}
		else
		{	 return '0';
		}
		
      }
	  
	  
	 function insertDesignation($designation_name)
 	  {
		$this->db->select('*');
		$this->db->from('designation');
		$this->db->where('designation_name',$designation_name);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{ 
		  $desigrow = $query->row();
		  $designation_id = $desigrow->designation_id;
		}else
		{	 $data =array( 
				'designation_name' => $this->input->post("designation_name"),
			 );	
			 $result= $this->db->insert('designation',$data);	
			 $designation_id  = $this->db->insert_id();
		 }
		if($designation_id)
		 return $designation_id;
		else
		 return 0;
	} 
	
	
	 function insertDepartment($department_name)
 	  {
		$this->db->select('*');
		$this->db->from('department');
		$this->db->where('department_name',$department_name);
		$query = $this->db->get();
		if($query->num_rows() > 0)
		{ 
		  $deptrow = $query->row();
		  $department_id = $deptrow->department_id;
		}else
		{	 $data =array( 
				'department_name' => $this->input->post("department_name"),
			 );	
			 $result= $this->db->insert('department',$data);	
			 $department_id  = $this->db->insert_id();
		 }
		if($department_id)
		 return $department_id;
		else
		 return 0;
	}
	
	 function updateUserAddress($user_id,$user_address_id)
 	{			
			
			$address_data =array( 
				'country_id' => $this->input->post("country_id"),
				'state_id' => $this->input->post("state_id"),
				'city_id' => $this->input->post("city_id"),
				'address' => $this->input->post("address"),
				'pin_code' => $this->input->post("pin_code")
			 );	
			 $this->db->where('user_address_id', $user_address_id);
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_address', $address_data);
			if($result)
				return 1;
			else
				return 0;
	} 
	
	 /* function insertLocationCategory($location_id)
 	 {   
		   $data =array( 
		        'location_id' => $location_id,
				'category_type_id' => $this->input->post("category_type_id"),
				'category_id' => $this->input->post("category_id"),
				'created_on'  => date('Y-m-d H:i:s')
			);	
			//$this->db->insert('slocation_categories',$data);
			$result= $this->db->insert('slocation_categories',$data);	
			//$result= $this->db->insert('location_categories',$data);	
			if($result)
				return $result;
			else
				return 0;
	 } */
		
	function insertLocationCategory($location_id)
    {   
	   $location_category = $_POST['location_category'];
	   if(is_array($location_category))
	    {
	    foreach($location_category as $catkey=> $catval){
		 if($catval!='')
		  { 
			$this->db->select('*');
			$this->db->from('slocation_categories');
			$this->db->where('location_id',$location_id);
			$this->db->where('category_id',$catval);
			$this->db->order_by('location_category_id', 'ASC');
			$query = $this->db->get();
			if($query->num_rows() == 0)
			{
			   $data =array( 
					'location_id' => $location_id,
					'category_type_id' => $this->input->post("category_type_id"),
					'category_id' => $catval,
					'created_on'  => date('Y-m-d H:i:s')
				);	
				$result= $this->db->insert('slocation_categories',$data);
			}
		   }
		 }
		}
	  if($result)
		return $result;
	  else
		return 0;
	}

	
	function UpdateUserRole($user_id)
 	  {			
	    	if($this->input->post("current_role_id") !=$this->input->post("role_id"))
			{	$rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
			    $role_data =array( 
					'user_id' => $user_id,
					'role_id' => $this->input->post("role_id"),
					'role_rights' =>$rolerow->role_rights,
					'post_date'      => date('Y-m-d H:i:s')
				  );	
				 $result= $this->db->insert('user_roles',$role_data);	
				 $user_role_id  = $this->db->insert_id();
				 
			 $roledata =array( 
				'is_active' => '0'
			 );	
			 $this->db->where('role_id', $this->input->post("current_role_id"));
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_roles', $roledata);
			}
			elseif($this->input->post("current_role_id")=='0' && $this->input->post("current_role_id")=='')
			{
			   $rolerow = get_table_info('roles','role_id',$this->input->post("role_id"));
			   $role_data =array( 
					'user_id' => $user_id,
					'role_id' => $this->input->post("role_id"),
					'role_rights' =>$rolerow->role_rights,
					'post_date'      => date('Y-m-d H:i:s')
				 );	
				 $result= $this->db->insert('user_roles',$role_data);	
				 $user_role_id  = $this->db->insert_id();
			}else
			{
				$result=true;
			}
			if($result)
				return 1;
			else
				return 0;
	}
	
	function editOldFacilities($location_facility_id, $facility_name_no=NULL, $facility_description=NULL, $longitude=NULL,$latitude=NULL, $parking_ticket=NULL)
 	{

		
			
		if($parking_ticket!=''){
			
			$data_type =array( 
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude,
				'parking_type'    =>  $parking_ticket
			);

			
		} else {
			$data_type =array( 
				'facility_name_no'    =>  $facility_name_no,
				'facility_description'    => $facility_description,
				'longitude'    =>  $longitude,
				'latitude'    =>  $latitude
			);
		}
		$this->db->where('location_facility_id',$location_facility_id);	
		$this->db->update('slocation_facilities',$data_type);	
		
		return 1;
			
		
	}
	
	
		 function location_edit($location_id)
		 {
			if ($location_id == '') {
				redirect(base_url() . "employees/slocations/view");
			}
			$this->db->select('*');
			$this->db->from('slocations');
			$this->db->join('slocation_categories', 'slocation_categories.location_id = slocations.location_id');
			$this->db->where('slocations.location_id', $location_id);
			$query = $this->db->get();
	
			return $query->row();
	
		} //End of edit function
	
		function locationLog($location_id,$old_data,$new_data)
		 {
			 $data = array(
			 'user_id'=>$this->session->userdata('user_id'),
			 'location_id'=>$location_id,
			 'old_data'=>json_encode($old_data),
			 'new_data'=>json_encode($new_data),
			 'log_date'=>date('Y-m-d H:i:s'),
			 'ip_address '=>$_SERVER['REMOTE_ADDR']			 
			 );
			$this->db->insert('slocations_log',$data);
			return 1;
	
		} //End of edit function
		
		 function update_location($location_id,$working_hours,$direction_locations,$location_new_data=NULL)
		 {
			 
			 $ticket_fee_details =array();
		 	 $ticketdetails['adult_fee']= $this->input->post("adult_fee");
			 $location_new_data['adult_fee']= $this->input->post("adult_fee");
			 $ticketdetails['child_fee']= $this->input->post("child_fee"); 	
			 $location_new_data['child_fee']= $this->input->post("child_fee");
			 $ticketdetails['senior_citizen_fee']= $this->input->post("senior_citizen_fee"); 
			 $location_new_data['senior_citizen_fee']= $this->input->post("senior_citizen_fee");			 
			 $ticket_fee_details[] = $ticketdetails;
			    
			 if(is_array($ticket_fee_details))
			 $ticketfeedetails = json_encode($ticket_fee_details);
			 else
			 $ticketfeedetails = '';
			 
			 if(trim($this->input->post("locality_textbox")!='')){
				$location_new_data['locality_name']= $this->input->post("locality_textbox");	
				$location_new_data['city_id']= '3134';	
				$data    = array(
				'locality_name'     => $this->input->post("locality_textbox"),
				'city_id'     => '3134',
				'is_active'     => '1'
				);
				$this->db->insert('locality', $data);
				$locality_id  = $this->db->insert_id();
				$location_new_data['locality_id']= $locality_id;
			 } else {
				$locality_id  = $this->input->post("locality_id");
				$location_new_data['locality_id']=  $this->input->post("locality_id");
			 }
		    
			$location_new_data['location_name']=  $this->input->post("location_name");
			$location_new_data['short_name']=  $this->input->post("short_name");
			$location_new_data['address']=  $this->input->post("address");
			$location_new_data['description']=  $this->input->post("description");
			$location_new_data['pin_code']=  $this->input->post("pin_code");
			$location_new_data['estimated_visit_time']=  $this->input->post("estimated_visit_time");
			$location_new_data['website_url']=  $this->input->post("website_url");
			$location_new_data['entry_ticket']=  $this->input->post("entry_ticket");
			$location_new_data['longitude']=  $this->input->post("longitude");
			$location_new_data['latitude']=  $this->input->post("latitude");
			$location_new_data['north_area']=  $this->input->post("north_area");
			$location_new_data['east_area']=  $this->input->post("east_area");
			$location_new_data['south_area']=  $this->input->post("south_area");
			$location_new_data['west_area']=  $this->input->post("west_area");
			$location_new_data['north_area_title']=  $this->input->post("north_area_title");
			$location_new_data['south_area_title']=  $this->input->post("south_area_title");
			$location_new_data['east_area_title']=  $this->input->post("east_area_title");
			$location_new_data['west_area_title']=  $this->input->post("west_area_title");
			$location_new_data['airport_distance']=  $this->input->post("airport_distance");
			$location_new_data['railway_station_distance']=  $this->input->post("railway_station_distance");
			$location_new_data['bus_stand_distance']=  $this->input->post("bus_stand_distance");
			$location_new_data['city_centre_distance']=  $this->input->post("city_centre_distance");
			$location_new_data['wifi_availability']=  $this->input->post("wifi_availability");
			$location_new_data['headphn_availability']=  $this->input->post("headphn_availability");
			$location_new_data['rules_regulations']=  $this->input->post("rules_regulations");
			$location_new_data['visitors_in_month']=  $this->input->post("visitors_in_month");
			$location_new_data['surveyor_remarks']=  $this->input->post("surveyor_remarks");
			$location_new_data['location_review']=  $this->input->post("location_review");
			
			$data = array(
				'location_name'     => $this->input->post("location_name"),
				'short_name'     => $this->input->post("short_name"),
				'address'     => $this->input->post("address"),
				'description'     => $this->input->post("description"),
				'locality_id'    => $locality_id,
				'pin_code'     => $this->input->post("pin_code"),
				'estimated_visit_time'     => $this->input->post("estimated_visit_time"),
				'website_url'     => $this->input->post("website_url"),
				'entry_ticket'     => $this->input->post("location_entry_ticket"),
				'ticket_fee_details'     => $ticketfeedetails,
				'longitude'     => $this->input->post("longitude"),
				'latitude'     => $this->input->post("latitude"),
				'north_area'     => $this->input->post("north_area"),
				'north_area_title'     => $this->input->post("north_area_title"),
				'south_area'     => $this->input->post("south_area"),
				'south_area_title'     => $this->input->post("south_area_title"),
				'east_area'     => $this->input->post("east_area"),
				'east_area_title'     => $this->input->post("east_area_title"),
				'west_area'     => $this->input->post("west_area"),
				'west_area_title'     => $this->input->post("west_area_title"),
				'airport_distance'     => $this->input->post("airport_distance"),
				'railway_station_distance'     => $this->input->post("railway_station_distance"),
				'bus_stand_distance'     => $this->input->post("bus_stand_distance"),
				'city_centre_distance'     => $this->input->post("city_centre_distance"),
				'wifi_availability'     => $this->input->post("wifi_availability"),
				'headphn_availability'     => $this->input->post("headphn_availability"),
				'working_hours'     => $working_hours,
				'direction_locations'     => $direction_locations,
				'rules_regulations'     => $this->input->post("rules_regulations"),
				'visitors_in_month'     => $this->input->post("visitors_in_month"),
				'location_review'     => $this->input->post("location_review"),
				'surveyor_remarks'     => $this->input->post("surveyor_remarks")
			);
			$this->db->where('location_id', $location_id);
			$result = $this->db->update('slocations', $data);
			/* if($result > 0)
   		    {
				if(isset($_POST['category_id']))
		        {
					$updateresult = $this->updateLocationCategory($location_id);
				 }
				 
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "slocations";
				$operation = "Record updated";
				createLogFile($operation,$location_id,$update_by_id,$table_name);
		    }
			if ($result)
			   return 1;
			 else
			   return 0; */
			if($result > 0)
   		    {
				if(isset($_POST['location_category']))
		        {	
				$location_new_data['category_type_id']=  $this->input->post("category_type_id");
				
				$location_new_data = $this->updateLocationCategory($this->input->post("category_type_id"),$location_id,$_POST['location_category'],$location_new_data);
				}
				$update_by[] = array('uid' => $this->session->userdata('user_id'), 'dt' => date('Y-m-d H:i:s'));
				$update_by_id = json_encode($update_by);
				$table_name = "slocations";
				$operation = "Record updated";
				createLogFile($operation,$location_id,$update_by_id,$table_name);
		    }
			   
			/* if ($result)
			   return $location_new_data;
			 else
			   return 0; */
		   return $location_new_data;
		 } //End of Update function
		 
	
   	/* function updateLocationCategory($location_id)
 	  {		$data =array( 
				'category_type_id' => $this->input->post("category_type_id"),
				'category_id' => $this->input->post("category_id"),
			 );	
			 $this->db->where('location_id', $location_id);
			 $result = $this->db->update('slocation_categories', $data);
			if($result)
				return 1;
			else
			    return 0;
	  } */
	function updateLocationCategory($category_type_id,$location_id,$CategoryList,$location_new_data=NULL)
 	  {
	
	
		$insertresult=false;
		if(is_array($CategoryList))
		{
		 $done=0; 	
		 $already=0; 	
		 $fields=array('location_id'=>$location_id,'is_active'=>'1');
	     $categoryresult=gettableresult('slocation_categories',$fields);
	     if(is_array($categoryresult))
	     {
		  foreach($categoryresult as $grow){
			 if(!in_array($grow->category_id,$CategoryList)){
			
				$data = array(
					'is_active' => '0',
				);
			  $this->db->where('location_id', $location_id);
			  $this->db->where('category_id',$grow->category_id);
			  $updateresult = $this->db->update('slocation_categories', $data);
			}
		  }
		 }
		foreach($CategoryList as $key=> $listrow){
			 		if($listrow!='') 
					{   
						$this->db->select('location_category_id');
						$this->db->from('slocation_categories');
						$this->db->where('location_id',$location_id);
						$this->db->where('category_type_id',$category_type_id);
						$this->db->where('category_id',$listrow);
						$category_result = $this->db->get();
						if($category_result->num_rows() > 0)
						{  
					      $location_new_data['category_id'][]=  $listrow;
						  $data =array( 
							'is_active' => '1'
						   );	
						      $tgrow = $category_result->row();	
							  
						      $location_category_id = $tgrow->location_category_id;
							  $this->db->where('location_category_id', $location_category_id);
							  $this->db->where('location_id', $location_id);
							  $this->db->where('category_id',$listrow);
							  $updateresult = $this->db->update('slocation_categories', $data);
						}else
						{
							$this->db->select('location_category_id');
							$this->db->from('slocation_categories');
							$this->db->where('location_category_id', $location_category_id);
							$this->db->where('location_id',$location_id);
							$this->db->where('category_id',$listrow);
							$this->db->where('is_active','1');
							$games_result = $this->db->get();
							if($games_result->num_rows() == 0)
							{  
						      $location_new_data['category_id'][]=  $listrow;
							  $data_type =array( 
								'location_id'   =>  $location_id,
								'category_type_id'    =>  $category_type_id,
								'category_id'    =>  $listrow,
								'created_on'      => date('Y-m-d H:i:s')
							   );	
								  $insertresult= $this->db->insert('slocation_categories',$data_type);	
								  $done++;
							}else
							{	  $already++;
							}
						}
		  
					}
			    }
		     }
			/* if($insertresult)
			return 1;
			else
			return 0; */	
		return $location_new_data;
		
	}
	
	function viewDigitalMedia($location_id,$media_type)
     	{
			$this->db->select('slocation_digital_media.*');
			$this->db->from('slocation_digital_media');
			$this->db->join('slocations', 'slocations.location_id = slocation_digital_media.location_id');
			//$this->db->where('slocation_digital_media.is_primary', '1');
			$this->db->where('slocation_digital_media.location_id', $location_id);
			$this->db->where('slocation_digital_media.media_type', $media_type);
			$this->db->order_by('slocation_digital_media.created_on', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	 function viewLocationSection($location_id)
     	{	$this->db->select('*');
			$this->db->from('slocation_sections');
			$this->db->where('location_id', $location_id);
			$this->db->order_by('section_title ', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	     
	   function viewfacilities($location_id,$facility_type)
     	{
			$this->db->select('slocation_facilities.*');
			$this->db->from('slocation_facilities');
			$this->db->join('slocations', 'slocations.location_id = slocation_facilities.location_id');
			$this->db->where('slocation_facilities.location_id', $location_id);
			$this->db->where('slocation_facilities.facility_type', $facility_type);
			$this->db->order_by('slocation_facilities.location_facility_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function

	   
    function update_status($location_id, $status)
    {
		 if($status=='1')
		 {	$data = array(
				'is_active' => $status,
			);
		 }
		 else
		 {
			$data = array(
				'is_active' => $status,
			);
		 }
        $this->db->where('location_id', $location_id);
        $result = $this->db->update('slocations', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
 
	function setDefaultMedia($location_id,$location_media_id,$media_type){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_media_id',$location_media_id); 
	   $this->db->where('media_type',$media_type);
	   $query = $this->db->get('slocation_digital_media');
	   if($query->num_rows() > 0 ){
		 $update_data =array( 
			'default_media' => '0',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);	
		 $updateresult = $this->db->update('slocation_digital_media', $update_data);
		 
		  $updatedata =array( 
			'default_media' => '1',
			);	
		 $this->db->where('location_id', $location_id);
		 $this->db->where('media_type', $media_type);
		 $this->db->where('location_media_id', $location_media_id);	
		 $updateresult = $this->db->update('slocation_digital_media', $updatedata);
		 if($updateresult)
		 { return '1';
		 }
	    }
	  	 else{
		 return '0';
	   }
	}
	
	function deleteDigitalMedia($location_media_id){
		
	   $this->db->select('*'); 
	   $this->db->where('location_media_id',$location_media_id); 
	   $query = $this->db->get('slocation_digital_media');
	   if($query->num_rows() > 0 ){
		   $this->db->where('location_media_id',$location_media_id); 
		   $result = $this->db->delete('slocation_digital_media');
		   if($result)
			{
			  return '1';
			}
	   }
	}
	function deletefacilities($location_facility_id){
		
	   $this->db->where('location_facility_id',$location_facility_id); 
	   $query = $this->db->get('slocation_facilities');
	   if($query->num_rows() > 0 ){
		   $this->db->where('location_facility_id',$location_facility_id); 
		   $result = $this->db->delete('slocation_facilities');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   }
	}
	function deleteLocSection($location_section_id){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_section_id',$location_section_id); 
	   $query = $this->db->get('slocation_sections');
	   if($query->num_rows() > 0 ){
		   $this->db->where('location_section_id',$location_section_id); 
		   $result = $this->db->delete('slocation_sections');
		   if($result)
			{ return '1';
			}
	    }
	  	 else{
		 return '0';
	   }
	}
	
	
   function deleteFacility($location_facility_id,$facility_path){
	   // Check first record exists or not if not than no delete 	   
	   $this->db->where('location_facility_id',$location_facility_id); 
	   $query = $this->db->get('slocation_facilities');
	   if($query->num_rows() > 0 ){
		  $row_facility = $query->row();
		  if($row_facility->photo_name!='')
		  {	  $path_dir1 = $facility_path;
		      $shash=('\ '); 
			  $photo_path =$path_dir1.trim($shash).$row_facility->photo_name;
			 if (file_exists($photo_path)) {
				 chmod($path_dir1, 0777);
				$resultphoto=  @unlink($photo_path);
			  }
		  }
		  if($row_facility->map2d!='')
		  {	  $path_dir2 = $facility_path;
		      $shash=('\ '); 
			  $map2d_path =$path_dir2.trim($shash).$row_facility->map2d;
			 if (file_exists($map2d_path)) {
				 chmod($path_dir2, 0777);
				$resultmap2d=  @unlink($map2d_path);
			  }
		  }
		   $this->db->where('location_facility_id',$location_facility_id); 
		   $result = $this->db->delete('slocation_facilities');
		   if($result)
			{
			  return '1';
			}
	   }
	  	 else{
		 return '0';
	   }
	}
	//Beacons
	 function insertBeacon($data) {
        $result = $this->db->insert('sbeacon_locations', $data);
		$beacon_location_id = $this->db->insert_id();
		if($beacon_location_id)
		{    return $beacon_location_id;
		}
		else
		{	 return '0';
		}
	 }
	 
	 function insertBeaconlocations($data) {
        $result = $this->db->insert('sbeacon_location_actions', $data);
		$beacon_action_id = $this->db->insert_id();
		if($beacon_action_id)
		{    return $beacon_action_id;
		}
		else
		{	 return '0';
		}
	 }
	 
	 
	 function viewbeaconlocations($location_id)
     	{
			$this->db->select('sbeacon_locations.*,sbeacon_location_actions.action_plan_id,sbeacon_location_actions.instruction_id,sbeacon_location_actions.sound_file_id, sbeacon_location_actions.media_file');
			$this->db->from('sbeacon_locations');
			$this->db->join('sbeacon_location_actions', 'sbeacon_location_actions.beacon_location_id = sbeacon_locations.beacon_location_id');
			$this->db->where('sbeacon_locations.location_id', $location_id);
			$this->db->order_by('sbeacon_locations.beacon_location_id', 'ASC');
			$query = $this->db->get();
			$results = $query->result();
			//echo $this->db->last_query();
			return $results;

	   } //End of View function
	   
	   function deleteLocBeacon($beacon_location_id,$location_id){
		   // Check first record exists or not if not than no delete 	   
		   $this->db->where('beacon_location_id',$beacon_location_id); 
		   $this->db->where('location_id',$location_id);
		   $query = $this->db->get('sbeacon_locations');
		   if($query->num_rows() > 0 ){
			   $this->db->where('beacon_location_id',$beacon_location_id); 
			   $this->db->where('location_id',$location_id);
			   $result = $this->db->delete('sbeacon_locations');
			   
			   $this->db->where('beacon_location_id',$beacon_location_id); 
			   $queryaction = $this->db->get('sbeacon_location_actions');
			   if($queryaction->num_rows() > 0 ){
				   $this->db->where('beacon_location_id',$beacon_location_id); 
				   $resultaction = $this->db->delete('sbeacon_location_actions');
			   }
			   if($result)
				{ return '1';
				}
			}
			else{
				  return '0';
				}
		}
		
		function get_beacons_dropdown()
		{   
			$this->db->select('*');
			$this->db->from('beacons');
			$this->db->where('is_active','1');
			$this->db->order_by('beacon_id','desc');
			$result = $this->db->get();
			$return = array();
			if ($result->num_rows() > 0) {
				$return[''] = 'Select';
				foreach ($result->result_array() as $row) {
					$return[$row['beacon_unique_id']] = $row['beacon_unique_id'].' - '.$row['beacon_name'];
				}
			}
			return $return;
		}
}