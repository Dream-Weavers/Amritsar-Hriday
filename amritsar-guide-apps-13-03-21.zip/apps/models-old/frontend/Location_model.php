<?php 
class Location_model extends CI_Model
{

	function get_all_locations_module_Detail($language_id,$category_id){
		
		$visibility=array('web');
		$this->db->select('module_id,module_name,language_id,module_visibility,module_type,module_layout,no_of_records,is_latest,module_category_id');
		$this->db->where_in('module_visibility',$visibility);
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','2');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('modules');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
				$moduleid=$row['module_id'];
				$module_type=$row['module_type'];
				$is_latest=$row['is_latest'];
				$module_layout=$row['module_layout'];
				if($module_layout==6){
					$row['module_name']='';
				}
				if($is_latest==2){ // If it is custom field configuration
					if($module_type==2){
						$jointable='locations';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==3){
						$jointable='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->join('categories', 'categories.category_id = module_interlinks.category_id');
						$this->db->where('categories.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==1){
						$jointable='categories';
						$this->db->select('category_types.category_type,category_types.category_type_id,category_types.description,category_types.icon');
						$this->db->join('category_types', 'category_types.category_type_id = module_interlinks.category_type_id');
						$this->db->where('category_types.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==4){
						$jointable='categories';
						$this->db->select('slides.slide_title,slides.slide_file_name');
						$this->db->join('slides', 'slides.slide_id = module_interlinks.slide_id');
						$this->db->where('slides.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==4){
						$jointable='locations';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,locations.latitude,locations.longitude');
						$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else{
						$this->db->select('*');
					}
					$this->db->where('module_interlinks.module_id',$moduleid);
					$this->db->order_by("module_interlinks.weight", "asc");
					$query_attr=$this->db->get('module_interlinks');
					$module_attributes = $query_attr->result_array(); 
					if($query_attr->num_rows()>0){
						foreach($query_attr->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							$interlink_type=$row_info['interlink_type'];
							if($module_type==2){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
								    $filename=base_url().gallery_path.$getpath->media_file_name;
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
								/*if($row_info->map_icon!=''){
									$row_info['map_icon_path'] = base_url().'assets/static/locations/icons/'.$row_info->map_icon;
								}else{
									$row_info['map_icon_path'] = '';
								}*/
							}else if($module_type==3){
								if($row_info['icon']!=''){
								    $filename=base_url().category_icons_path.$row_info['icon'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] =base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type==1){
								if($row_info['icon']!=''){
								    $filename=base_url().categorytype_icons_path.$row_info['icon'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] =$pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type==4){
								if($row_info['slide_file_name']!=''){
								    $filename=base_url().slide_image_path.$row_info['slide_file_name'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}
							$rows[] = $row_info;
						}
					}
					$row['attributes']=$rows;
					$add_custom[]=$row;
					unset($rows);
				}
				else if($is_latest==1){  // If it is latest field configuration
					if($module_type==2){ 
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}
					else if($module_type==3){
						$tablename='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->where('categories.is_active','1');
						$this->db->where('language_id',$lang_id);
						$orderby='category_id';
					}else if($module_type==1){
						$tablename='category_types';
						$this->db->select('category_types.category_type,category_types.description,category_types.category_type_id,category_types.icon');
						$orderby='category_type_id';
						$this->db->where('category_types.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==4){
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,locations.latitude,locations.longitude');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}
					
					$this->db->order_by($orderby, "desc");
					$this->db->limit(10,0);
					$query_latest=$this->db->get($tablename);
					$module_latest = $query_latest->result_array(); 
					if($query_latest->num_rows()>0){
						foreach($query_latest->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							if($module_type==2){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
								    $filename=base_url().gallery_path.$getpath->media_file_name;
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type==3){
								if($row_info['icon']!=''){
								    $filename=base_url().category_icons_path.$row_info['icon'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] =base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type==1){
								if($row_info['icon']!=''){
								    $filename=base_url().categorytype_icons_path.$row_info['icon'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] =$pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}
							
							$rows[] = $row_info;
						}
					}
					
					
					$row['attributes']=$rows;
					$add_custom[] = $row; 
					unset($rows);
				}
				else if($is_latest==3){ // if is RAW ID from URL
				
					if($module_type==2){  // If it is location type
						
						//Get Category Details(Through category id in url)
						$category=$this->get_category($category_id);
						if($category['icon']!=''){
							$category['image_path'] = base_url().category_icons_path.$category['icon'];
						}else{
							$category['image_path'] = base_url().'assets/image-not-available.jpg';
						}
						$row['main_attributes']=$category;
						
						$listing=$this->get_category_locations_content($language_id,$category_id);
						$row['attributes']=$listing;
						
						
						$add_custom[] = $row; 
					}
					else if($module_type==3){  // If it is category
						
						$listing=$this->get_category_children_content($language_id,$category_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					else if($module_type==1){  // if it is category type.
						
						$listing=$this->get_categorytype_content($language_id,$category_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type==5){
						$listing=$this->get_locations_map_content($language_id,$category_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					//$row['attributes']=$rows;
					//$add_custom[] = $row; 
					//unset($rows);
				}
			}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_location_module_Detail($language_id,$location_id){
		
		$visibility=array('web');
		$this->db->select('module_id,module_name,language_id,module_visibility,module_type,module_layout,no_of_records,is_latest,module_category_id');
		$this->db->where_in('module_visibility',$visibility);
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','3');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('modules');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
				$moduleid=$row['module_id'];
				$module_type=$row['module_type'];
				$is_latest=$row['is_latest'];
				$module_layout=$row['module_layout'];
				if($module_layout==6){
					$row['module_name']='';
				}
				if($is_latest==2){ // If it is custom field configuration
					if($module_type==2){
						$jointable='locations';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==3){
						$jointable='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->join('categories', 'categories.category_id = module_interlinks.category_id');
						$this->db->where('categories.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==1){
						$jointable='categories';
						$this->db->select('category_types.category_type,category_types.category_type_id,category_types.description,category_types.icon');
						$this->db->join('category_types', 'category_types.category_type_id = module_interlinks.category_type_id');
						$this->db->where('category_types.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==4){
						$jointable='categories';
						$this->db->select('slides.slide_title,slides.slide_file_name');
						$this->db->join('slides', 'slides.slide_id = module_interlinks.slide_id');
						$this->db->where('slides.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==4){
						$jointable='locations';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,locations.latitude,locations.longitude');
						$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else{
						$this->db->select('*');
					}
					$this->db->where('module_interlinks.module_id',$moduleid);
					$this->db->order_by("module_interlinks.weight", "asc");
					$query_attr=$this->db->get('module_interlinks');
					$module_attributes = $query_attr->result_array(); 
					if($query_attr->num_rows()>0){
						foreach($query_attr->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							$interlink_type=$row_info['interlink_type'];
							if($module_type==2){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
								    $filename=base_url().gallery_path.$getpath->media_file_name;
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
								/*if($row_info->map_icon!=''){
									$row_info['map_icon_path'] = base_url().'assets/static/locations/icons/'.$row_info->map_icon;
								}else{
									$row_info['map_icon_path'] = '';
								}*/
							}else if($module_type==3){
								if($row_info['icon']!=''){
								    $filename=base_url().category_icons_path.$row_info['icon'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] =base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type==1){
								if($row_info['icon']!=''){
								    $filename=base_url().categorytype_icons_path.$row_info['icon'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] =$pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type==4){
								if($row_info['slide_file_name']!=''){
								    $filename=base_url().slide_image_path.$row_info['slide_file_name'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}
							$rows[] = $row_info;
						}
					}
					$row['attributes']=$rows;
					$add_custom[]=$row;
					unset($rows);
				}
				else if($is_latest==1){  // If it is latest field configuration
					if($module_type==2){ 
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}
					else if($module_type==3){
						$tablename='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->where('categories.is_active','1');
						$this->db->where('language_id',$lang_id);
						$orderby='category_id';
					}else if($module_type==1){
						$tablename='category_types';
						$this->db->select('category_types.category_type,category_types.description,category_types.category_type_id,category_types.icon');
						$orderby='category_type_id';
						$this->db->where('category_types.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type==4){
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,locations.latitude,locations.longitude');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}
					
					$this->db->order_by($orderby, "desc");
					$this->db->limit(10,0);
					$query_latest=$this->db->get($tablename);
					$module_latest = $query_latest->result_array(); 
					if($query_latest->num_rows()>0){
						foreach($query_latest->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							if($module_type==2){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
								    $filename=base_url().gallery_path.$getpath->media_file_name;
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type==3){
								if($row_info['icon']!=''){
								    $filename=base_url().category_icons_path.$row_info['icon'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] = $pathinfo;
								}else{
									$row_info['image_path'] =base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type==1){
								if($row_info['icon']!=''){
								    $filename=base_url().categorytype_icons_path.$row_info['icon'];
								    $pathinfo=$this->check_filexists($filename);
									$row_info['image_path'] =$pathinfo;
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}
							
							$rows[] = $row_info;
						}
					}
					
					
					$row['attributes']=$rows;
					$add_custom[] = $row; 
					unset($rows);
				}
				else if($is_latest==3){ // if is RAW ID from URL
				
					if($module_type==2){  // If it is location type
						
						//$listing= $this->get_locations_content($language_id,$location_id);
						$user_id= $this->session->userdata('user_id');
						$listing_all=$this->get_location_Details($language_id,$location_id,$user_id);
						//$media_type=$this->get('media_type');	
						$media_attributes=$this->get_location_media_Details($language_id,$location_id);	
						
						
						$row['media_attributes']=$media_attributes;
						$row['attributes']=$listing_all;
						$add_custom[] = $row; 
					}
					
					else if($module_type==5){
						$listing=$this->get_locations_map_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					//$row['attributes']=$rows;
					//$add_custom[] = $row; 
					//unset($rows);
				}
			}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_category_locations_content($language_id,$category_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.short_description as description,locations.map_icon,locations.city_id,locations.state_id,locations.pin_code,locations.address,locations.latitude,locations.longitude');
		$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('categories.language_id',$language_id);
		$this->db->where('categories.category_id',$category_id);
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('categories');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = '';
			}
			//$row_info['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$row_info['map_icon']));
			$row_info['map_icon']=base_url().icon_url_path.$row_info['map_icon'];
			
			$cityrow = get_table_info('city','city_id',$row_info['city_id']);
			$staterow = get_table_info('state','state_id',$row_info['state_id']);
			$countryrow = get_table_info('country','country_id',$staterow->country_id);
			$row_info['city_name']= $cityrow->city_name;
			$row_info['state_name']= $staterow->state_name;
			$row_info['country_name']=$countryrow->country_name;
			 
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	
	function get_category_children_content($language_id,$category_id){
		$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
		$this->db->where('is_active','1');
		$this->db->where('category_id',$category_id);
		$this->db->where('language_id',$language_id);
		$result = $this->db->get('categories');
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['category_id'];
				//$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($row_info['icon']!=''){
				     $filename=base_url().category_icons_path.$row_info['icon'];
					 $pathinfo=$this->check_filexists($filename);
					$row_info['image_path'] = $pathinfo;
				}else{
					$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
				}
				$rows[] = $row_info;
			}
			$add_custom[] = $rows; 
			unset($rows);
			$resultdata=$add_custom;
			unset($add_custom);
			return $resultdata;
		}else{
			return false;
		}
		
	}
	
	function get_locations_map_content($language_id,$location_id){
		//print 'asdsad';die;
		$this->db->select('locations.location_id,locations.location_name,locations.short_description as description,locations.latitude,locations.longitude,locations.map_icon');
		$this->db->where('locations.language_id',$language_id);
		$this->db->where('locations.location_id',$location_id);
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('locations');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$rows = array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
			     $filename=base_url().gallery_path.$getpath->media_file_name;
				$pathinfo=$this->check_filexists($filename);
				$row_info['image_path'] = $pathinfo;
			}else{
				$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$row_info['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$row_info['map_icon']));
			$rows[] = $row_info;
		}
		/*$add_custom[] = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;*/
		return $rows;
	}
	
	function get_locations_content($language_id,$location_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.description');
		$this->db->where('locations.language_id',$language_id);
		$this->db->where('locations.location_id',$location_id);
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('locations');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$rows = array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
			    $filename=base_url().gallery_path.$getpath->media_file_name;
				$pathinfo=$this->check_filexists($filename);
				$row_info['image_path'] = $pathinfo;
			}else{
				$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$rows[] = $row_info;
		}
		/*$add_custom[] = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;*/
		
		return $rows;
	}
	

	
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
	
	
	function DigitalMediaContent($location_id)
    {
		$this->db->select('media_file_name,media_type,default_media');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		//$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->order_by('location_digital_media.default_media', 'DESC');
		$this->db->order_by('location_digital_media.weight', 'ASC');
		$query = $this->db->get();
		$mediaresult=$query->result_array();
		$rows =array();
		foreach($mediaresult as $row_info)
		{
			if($row_info['media_type']==gallery_files)
			{	
			if($row_info['media_file_name']!=''){
					$row_info['media_url'] = base_url().gallery_path.$row_info['media_file_name'];
				}else{
					$row_info['media_url'] = '';
				}
				$row_info['media_text'] = 'Photos';
			}
			elseif($row_info['media_type']==video_files)
			{	
			    $row_info['media_url'] = $row_info['media_file_name'];
				$row_info['media_text'] = 'Video';
			}
			elseif($row_info['media_type']==vr_files)
			{	if($row_info['media_file_name']!=''){
					$row_info['media_url'] = base_url().location_path.'vr/'.$row_info['media_file_name'];
				}else{
					$row_info['media_url'] = '';
				}
				$row_info['media_text'] = 'VR';
			}
			elseif($row_info['media_type']==video360_files)
			{	if($row_info['media_file_name']!=''){
					$row_info['media_url'] = $row_info['media_file_name'];
				}else{
					$row_info['media_url'] = '';
				}
				$row_info['media_text'] = '360 View';
			}
			
			else
			{  $row_info['media_url'] = $row_info['media_file_name'];
			   $row_info['media_text'] = 'Other';
			}
			
			$rows[] = $row_info;
		}
		return $rows;
	
	} //End of View function
	
 	function gettableinfowithfields($table,$fields,$needed_fields)
    {   //echo $needed_fields;die;

        $this->db->select($needed_fields);
		if(is_array($fields)){
	     foreach($fields as $keys => $values) {
			 $this->db->where($keys, $values);
			 }         
	   }
        $this->db->from($table);
        $query = $this->db->get();
	//	echo $this->db->last_query();die;
        if($query -> num_rows() == 0)
			{		return '0';
			}
			else
			{		return $query->row();
			}

    }
	
	function FacilityContent($language_id,$location_id,$facility_type)
    {
		$this->db->select('facility_type,facility_name_no,facility_description,washroom_availability,longitude,latitude,parking_type,parking_fee,photo_name,map2d');
		$this->db->from('location_facilities');
		$this->db->where('location_facilities.location_id', $location_id);
		$this->db->where('location_facilities.facility_type', $facility_type);
		//$this->db->order_by('location_facilities.default_media', 'DESC');
		$this->db->order_by('location_facilities.facility_name_no', 'ASC');
		$query = $this->db->get();
		$mediaresult=$query->result_array();
		//print $this->db->last_query();die;
		$rows =array();
		foreach($mediaresult as $row_info)
		{
			  $fields = array('list_id'=>'facility_type','option_id'=>$row_info['facility_type'],'language_id'=>$language_id);
			  $listrow = gettableinfo('list_options',$fields);
			  $row_info['facility_title'] = trim($listrow->title);
			  if($row_info['parking_type']!='')
			  {
			   $parkingfields = array('list_id'=>'entry_ticket_type','option_id'=>$row_info['parking_type'],'language_id'=>$language_id);
			   $listrow = gettableinfo('list_options',$parkingfields);
			   $row_info['parking_type'] = trim($listrow->title);
			  }
			  else
			  { $row_info['parking_type'] = '';
			  }
			  
			  if($row_info['washroom_availability']!='')
			  {
				$washroomavailability = explode(',',$row_info['washroom_availability']);
			    $washroom_avail='';
				if(is_array($washroomavailability))
				{
				 foreach($washroomavailability as $val)
				 { 
				    $washroomfields = array('list_id'=>'washroom_availability','option_id'=>$val,'language_id'=>$language_id);
				    $listrow = gettableinfo('list_options',$washroomfields);
					$washroom_avail .= trim($listrow->title).', ';
					$wash_array[]=array('icon'=>'http://g4me.in/hriday/assets/static/locations/icons/user.svg','name'=>$listrow->title);
				 }
				   $washroom_availability = substr($washroom_avail,0,-2);
				}
			  }
			  else
			  {
			   $washroom_availability='';
			  }
			 if($washroom_availability!=''){
			    $row_info['availability'] = $wash_array;
			 }else{
			     $row_info['availability'] = $washroom_availability;
			 }
			 unset($wash_array);
			   
		   if($row_info['photo_name']!=''){
			    $filename= base_url().facility_path.$row_info['photo_name'];
			    $pathinfo=$this->check_filexists($filename); 
			    if($pathinfo!='')
				$row_info['photo_name'] = $pathinfo;
				else
				$row_info['photo_name'] = '';
			}else{
				$row_info['photo_name'] = '';
			}
			
			 if($row_info['map2d']!=''){
			    $filename= base_url().facility_path.$row_info['map2d'];
			    $pathinfo=$this->check_filexists($filename); 
			    if($pathinfo!='')
				$row_info['map2d'] =  $pathinfo;
				else
				$row_info['map2d'] = '';
			}else{
				$row_info['map2d'] = '';
			}
			   
			  //$row_info['photo_name'] = base_url().facility_path.$row_info['photo_name'];
			//  $row_info['map2d'] = base_url().facility_path.$row_info['map2d'];
			
			$rows[] = $row_info;
		}
		return $rows;
	
	} //End of View function
	
	function get_categorytype_content($language_id,$category_id){
		$this->db->where('is_active','1');
		$this->db->where('category_id',$category_id);
		$result = $this->db->get('category_filters')->num_rows();
		$parent_id=$this->get_category_parent($language_id,$category_id);
		if($result>=4){
			$this->db->select('categories.category_id as id,categories.category_name as title ,"filter" as `type`');
			$this->db->join('category_filters', 'category_filters.category_id = categories.category_id');
			$this->db->where('categories.language_id',$language_id);
			$this->db->where('category_filters.is_active','1');
			$this->db->where('categories.is_active','1');
			$this->db->where('categories.category_id',$category_id);
			$this->db->order_by("categories.weight", "asc");
			$query=$this->db->get('categories');
			$listing=$query->result_array();
		}else if($parent_id>0){ 
			
			//$this->db->where('language_id',$language_id);
			$this->db->where('category_id',$parent_id);
			$result_get = $this->db->get('category_filters')->num_rows();
			if($result_get>=4){
				$this->db->select('categories.category_id as id,categories.category_name as title ,"filter" as `type`');
				$this->db->join('category_filters', 'category_filters.category_id = categories.category_id');
				$this->db->where('categories.language_id',$language_id);
				$this->db->where('categories.category_id',$category_id);
				$this->db->where('category_filters.is_active','1');
				$this->db->where('categories.is_active','1');
				$this->db->order_by("categories.weight", "asc");
				$query=$this->db->get('categories');
				$listing=$query->result_array();
			}else{
				$listing=$this->get_category_types($language_id);
			} 
		}else{
			$listing=$this->get_category_types($language_id);
		}
		return $listing;
	}
	
	
	
	
	function get_category_parent($language_id,$category_id){
		
		$this->db->select('*');
		$this->db->where('language_id',$language_id);
		$this->db->where('category_id',$category_id);
		$this->db->where('is_active','1');
		$query = $this->db->get('categories');
		$result=$query->row();
		return $result->category_parent_id;
	}
	
	function get_category_types($language_id){
		$this->db->select('category_types.category_type as title,category_types.category_type_id as id ,"category_type" as `type`');
		$this->db->where('category_types.language_id',$language_id);
		$this->db->where('category_types.is_active','1');
		$query = $this->db->get('category_types');
		$result=$query->result_array();
		return $result;
	}
	
	
		function get_location_detail_content($language_id,$location_id,$needed_fields,$module_type,$user_id){
		
		$this->db->select($needed_fields);
		$this->db->where('locations.language_id',$language_id);
		$this->db->where('locations.location_id',$location_id);
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('locations');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$rows = array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			if($module_type=='1')
			{	$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
				    $filename=base_url().gallery_path.$getpath->media_file_name;
				    $pathinfo=$this->check_filexists($filename); 
					$row_info['image_path'] = $pathinfo;
				}else{
					$row_info['image_path'] = '';
				}
			 $cityrow = get_table_info('city','city_id',$row_info['city_id']);
			 $staterow = get_table_info('state','state_id',$row_info['state_id']);
			 $countryrow = get_table_info('country','country_id',$staterow->country_id);
			 $row_info['city_name']= $cityrow->city_name;
			 $row_info['state_name']= $staterow->state_name;
			 $row_info['country_name']=$countryrow->country_name;
			 if($row_info['wifi_availability']=='yes')
			  $row_info['wifi_avail_text']='Free Wifi';
			  else
			  $row_info['wifi_avail_text']='';
			  
			  $row_info['visited_text']='Visited';
			  
			 // echo "module_type---------------->".$module_type;
			   //echo "user_id---------------->".$user_id;
			  if($module_type=='1')
			  {
				  if($user_id!='0')
				  {   $fields = array('language_id'=>$language_id,'user_id'=>$user_id,'location_id'=>$location_id);
					  $userfavrow = $this->gettableinfowithfields('user_favorites_locations',$fields,'favorite_location_id');
					// print $userfavrow;
					// die();
					  if($userfavrow!='0')
					  $row_info['is_favorite']='1';
					  else
					  $row_info['is_favorite']='0';
				  }else
				  {
					   $row_info['is_favorite']='0';
				  }
			  }
			  //if($row_info['quiz_image']=='')
			  //$row_info['game_image']=base_url().'assets/static/locations/quiz/'.$row_info['quiz_image'];
			 $row_info['game_image']='https://dreambsys.in/codeigniter/hriday/assets/static/locations/quiz/1609471544_43_1490513985stardew.png';
			  //else
			  //$row_info['game_image']='';
			 // DigitalMediaContent
			  $row_info['photo_icon_text']='Photos';
			  $row_info['photo_api_url']=base_url()."api/locations/getLocation_media_details?language_id=".$language_id."&location_id=".$location_id."&media_type=".gallery_files."";
			  $row_info['video_icon_text']='Video';
			  $row_info['video_api_url']=base_url()."api/locations/getLocation_media_details?language_id=".$language_id."&location_id=".$location_id."&media_type=".video_files."";
			  $row_info['vr_icon_text']='VR';
			  $row_info['vr_api_url']=base_url()."api/locations/getLocation_media_details?language_id=".$language_id."&location_id=".$location_id."&media_type=".vr_files."";
			  $row_info['video360_icon_text']='360 View';
			  $row_info['video360_api_url']=base_url()."api/locations/getLocation_media_details?language_id=".$language_id."&location_id=".$location_id."&media_type=".video360_files."";
			  
			}
			if($module_type=='4')
			{  if($row_info['map_icon']!=''){
			    $filename=base_url().icon_url_path.$row_info['map_icon'];
			    $pathinfo=$this->check_filexists($filename);
			    if($pathinfo!=''){
			   $row_info['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$row_info['map_icon']));
			    }else{
			     $row_info['map_icon']='';
			    }
			}
			   else{
			   $row_info['map_icon']='';
			   }
			}
			if($module_type=='8')
			{
				$working_hours = json_decode($row_info['working_hours'],true);
				if(is_array($working_hours))
				{   $work_hrs_result=array();
					foreach($working_hours as $hrskey=> $hrsval) {
						
						$work_hrs_result[]=$hrsval;
					}
				}
				$row_info['working_hours'] = $work_hrs_result;
			}
			
			
			$rows[] = $row_info;
		}
		return $rows;
	}
	
	function get_location_places_content($language_id,$location_id){
		
		$this->db->select('category_id');
		$this->db->from('location_categories');
		$this->db->where('location_id',$location_id);
		$this->db->where('is_active','1');
		$this->db->group_by('category_id');
		$where_clause = $this->db->get_compiled_select();
		$currentlocid=array('location'=>$location_id);
		$this->db->select('locations.location_name,locations.short_name,locations.location_id,location_categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.is_active','1');
		$this->db->where('locations.language_id',$language_id);
		$this->db->where("`location_categories`.`category_id` IN ($where_clause)", NULL, FALSE);
		$this->db->where_not_in('locations.location_id', $currentlocid);
		$this->db->group_by('locations.location_id');
		$this->db->order_by('locations.location_name','ASC');
		$result = $this->db->get('location_categories');
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
				    $filename=base_url().gallery_path.$getpath->media_file_name;
				    $pathname=$this->check_filexists($filename);
					$row_info['image_path'] = $pathname;
					
				}else{
					$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return $rows;
		}
		
	}
	
	
	function get_location_related_places_content($language_id,$location_id){
		//Get Category Type Id
		$fields = array('location_id'=>$location_id,'is_active'=>'1');
		$cattyperow = gettableinfo('location_categories',$fields);
		$category_type_id = $cattyperow->category_type_id;
		
		//Get Master Category Id
		$fields = array('category_type_id'=>$category_type_id,'category_parent_id'=>'0','is_active'=>'1');
		$catrow = gettableinfo('categories',$fields);
		$category_id = $catrow->category_id;
		
		$currentlocid=array('location'=>$location_id);
		$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,location_categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('location_categories.category_id',$category_id);
		$this->db->where('locations.language_id',$language_id);
		$this->db->where_not_in('locations.location_id', $currentlocid);
		$this->db->group_by('locations.location_id');
		$this->db->order_by('locations.location_name','ASC');
		$result = $this->db->get('location_categories');
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
				    $filename=base_url().gallery_path.$getpath->media_file_name;
				    $pathinfo=$this->check_filexists($filename);
					$row_info['image_path'] = $pathinfo;
				}else{
					$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return $rows;
		}
		
	}


 function get_location_nearby_places_content($language_id,$location_id){
		//Get Category Type Id
		$fields = array('location_id'=>$location_id,'is_active'=>'1');
		$cattyperow = gettableinfo('location_categories',$fields);
		$category_type_id = $cattyperow->category_type_id;
		
		//Get Master Category Id
		$fields = array('category_type_id'=>$category_type_id,'category_parent_id'=>'0','is_active'=>'1');
		$catrow = gettableinfo('categories',$fields);
		$category_id = $catrow->category_id;
		
	/*	$fields = array('location_id'=>$location_id,'distance_calculate'=>'0');
		$locrow = gettableinfowithfields('locations',$fields,'distance_calculate');
		if($locrow=='0')
		{
			$fields = array('category_id'=>$category_id);
		    $cat_row = gettableinfowithfields('locations',$fields,'distance_calculate');
			$distance_calculate = $catrow->distance_calculate;
		}
		else
		{	$distance_calculate = $locrow->distance_calculate;
		}
		
		if($distance_calculate!='0')
		$distance_calculate = $distance_calculate;
		else
		$distance_calculate = default_distance_calculate;*/
		
		$currentlocid=array('location'=>$location_id);
		$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,location_categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('location_categories.category_id',$category_id);
		$this->db->where('locations.language_id',$language_id);
		$this->db->where_not_in('locations.location_id', $currentlocid);
		$this->db->group_by('locations.location_id');
		$this->db->order_by('locations.location_name','ASC');
		$result = $this->db->get('location_categories');
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
				    $filename=base_url().gallery_path.$getpath->media_file_name;
				    $pathinfo=$this->check_filexists($filename);
					$row_info['image_path'] = $pathinfo;
				}else{
					$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return $rows;
		}
		
		/*$currentlocid=array('location'=>$location_id);
		$this->db->select('locations.location_name,locations.short_name,locations.location_id,location_categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('location_categories.category_id',$category_id);
		$this->db->where('locations.language_id',$language_id);
		$this->db->where_not_in('locations.location_id', $currentlocid);
		$this->db->group_by('locations.location_id');
		$this->db->order_by('locations.location_name','ASC');
		$result = $this->db->get('location_categories');
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
					$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
				}else{
					$row_info['image_path'] = '';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return false;
		}*/

	}	
	
	
	function get_location_facility_content($language_id,$location_id){
		
		$this->db->select('list_options.option_id,list_options.title,location_facilities.language_id,location_facilities.location_id,location_facilities.facility_type');
		$this->db->join('list_options', 'list_options.option_id = location_facilities.facility_type');
		$this->db->where('location_facilities.is_active','1');
		$this->db->where('location_facilities.location_id',$location_id);
		$this->db->where('location_facilities.language_id',$language_id);
		$this->db->where('list_options.list_id','facility_type');
		$this->db->group_by('location_facilities.facility_type');
		$this->db->order_by('list_options.seq','asc');
		$result = $this->db->get('location_facilities');
	
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$fields = array('list_id'=>'facility_type','option_id'=>$row_info['facility_type'],'language_id'=>$language_id);
				$listrow = gettableinfo('list_options',$fields);
				if($listrow->icon_name!=''){
				    $filename=base_url().icon_url_path.$listrow->icon_name;
				    $pathinfo=$this->check_filexists($filename);
					$row_info['icon_path'] = $pathinfo;
				}else{
					$row_info['icon_path'] = base_url().'assets/image-not-available.jpg';
				}
				
				$resultfacility_type = $this->FacilityContent($language_id,$location_id,$row_info['facility_type']);
				$row_info['attributeresults']=$resultfacility_type;
				
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return $rows;
		}
		
	}
	
	
	function get_location_facility_type($language_id,$location_id,$facility_type)
    {
		$this->db->select('location_id,facility_type,longitude,latitude,photo_name');
		$this->db->from('location_facilities');
		$this->db->where('location_facilities.language_id', $language_id);
		$this->db->where('location_facilities.location_id', $location_id);
		$this->db->where('location_facilities.facility_type', $facility_type);
		$this->db->where('location_facilities.is_active','1');
		$this->db->order_by('location_facilities.created_on', 'ASC');
		$query = $this->db->get();
        $result = $query->result();
       // echo $this->db->last_query();
		return $result;

    } //End of View  function
	
	
	
	function get_location_Details($language_id,$location_id,$user_id){
		//print 'sss'.$user_id;
		$this->db->select('module_layout_id,language_id,module_type,module_layout,module_name,weight');
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','1');
		$this->db->where('is_active','1');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('module_layout');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			//$row = array();
			//$add_custom= array();
			foreach($resultdata as $skey=>$row){
				$moduleid=$row['module_layout_id'];
				$module_type=$row['module_type'];
				$module_layout=$row['module_layout'];
				     $locrow = get_table_info('locations','location_id',$location_id);
					if($module_type=='1'){  // If it is location type
						$needed_fields='locations.location_id,locations.location_name,locations.quiz_image,locations.short_name,locations.short_description,locations.description,locations.city_id,locations.state_id,locations.state_id,locations.wifi_availability';
						$listing=$this->get_location_detail_content($language_id,$location_id,$needed_fields,$module_type,$user_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type=='2'){  // If it is Places type
						$listing=$this->get_location_places_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='3'){  // If it is Distances type
						
						 $distance_listing=array();
						 $distance_type_array = get_list_options('distance_type','ASC'); 
						 unset($distance_type_array['']);
                         foreach($distance_type_array as $distancekey=>$disval){
							 
						  //echo "-------->".$distancekey;
						 if($distancekey== '1')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->airport_distance;
							 //$distancelisting['icon_path']= base_url().icon_url_path.'bus-stop.png';
							 $filename=base_url().icon_url_path.'bus-stop.svg';
							 $pathinfo=$this->check_filexists($filename);
							 
							 
							 $distancelisting['icon_path']= $pathinfo;
						  }
						 if($distancekey=='2')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->bus_stand_distance;
							// $distancelisting['icon_path']= base_url().icon_url_path.'airport.png';
							$filename=base_url().icon_url_path.'plane.svg';
							$pathinfo=$this->check_filexists($filename);   
							 $distancelisting['icon_path']= $pathinfo;
						  }
						  if($distancekey=='3')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->railway_station_distance;
							 //$distancelisting['icon_path']= base_url().icon_url_path.'railway.png';
							 $filename=base_url().icon_url_path.'train.svg';
							 $pathinfo=$this->check_filexists($filename);  
							 $distancelisting['icon_path']= $pathinfo;
						  } 
						  if($distancekey=='4')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->city_centre_distance;
							 //$distancelisting['icon_path']= base_url().icon_url_path.'shopping-center.png';
							 $filename= base_url().icon_url_path.'shopping-center.svg';
							$pathinfo=$this->check_filexists($filename);   
							 $distancelisting['icon_path']= $pathinfo;
						  } 
						  $distance_listing[] = $distancelisting;
				  
						 }
						
					
						$row['attributes']=$distance_listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='4'){  // if it is Location Map.
						
						$needed_fields='locations.location_id,locations.quiz_image,locations.location_name,locations.latitude,locations.longitude,locations.map_icon,locations.short_description as description';
						$listing=$this->get_location_detail_content($language_id,$location_id,$needed_fields,$module_type,$user_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='5'){  // if it is Surrounded Area
						 $area_listings=array();
						 $area_type_array = get_list_options('area_type','ASC'); 
						 unset($area_type_array['']);
                         foreach($area_type_array as $areakey=>$areaval){
						 $fields = array('is_active'=>'1');
						 $area_array = gettabledropdown('areas',$fields,'area_id','area_name','area_name','ASC');
						 unset($area_array['']);
						 if($areakey=='1')
						  {  $area_listing['facing']= $areaval;
						     $area_listing['facing_title']= $areaval.' Landmark';
							 $area_listing['area_name']= $area_array[$locrow->north_area];
						  }
						 if($areakey=='2')
						  {  $area_listing['facing']= $areaval;
						     $area_listing['facing_title']= $areaval.' Landmark';
							 $area_listing['area_name']= $area_array[$locrow->south_area];
						  }
						  if($areakey=='3')
						  {  $area_listing['facing']= $areaval;
						     $area_listing['facing_title']= $areaval.' Landmark';
							 $area_listing['area_name']= $area_array[$locrow->east_area];
						  }
						  if($areakey=='4')
						  {  $area_listing['facing']= $areaval;
						     $area_listing['facing_title']= $areaval.' Landmark';
							 $area_listing['area_name']= $area_array[$locrow->west_area];
						  }
						  $area_listings[] = $area_listing;
						
						 }
						 
				    	$row['attributes']=$area_listings;
						$add_custom[] = $row; 
					}
					elseif($module_type=='6'){  // if it is Facilities
						$listing=$this->get_location_facility_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='7'){  // if it is Rules & Regulations
						$needed_fields='locations.location_id,locations.rules_regulations';
						$listing=$this->get_location_detail_content($language_id,$location_id,$needed_fields,$module_type,$user_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='8'){  // if it is Opening Hours
						$needed_fields='locations.working_hours';
						$listing=$this->get_location_detail_content($language_id,$location_id,$needed_fields,$module_type,$user_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='9'){  // if it is Near By
						$listing=$this->get_location_nearby_places_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='10'){  // if it is Review & Rating
					    $listing=array();
					    $rev_Array=array('language_id'=>$language_id,'location_id'=>$location_id);
					    $reviewcount=$this->fetch_reviews_count($rev_Array);
					    $sumrating=$this->sum_rating($language_id,$location_id);
					    if($sumrating==0){
					        $avg_rating=0;
					    }else{
					        $avg_rating=$sumrating/$reviewcount;
					    }
					    $avgrating=number_format((float)$avg_rating, 1, '.', '');
						$listing['rating_score']= $avgrating;
						$listing['rating_title']= 'Stars';
						$listing['rating_desciption']= $reviewcount.' verified reviews & ratings';
						$listing['review_add_text']= 'Write Review';
						$row['attributes'][]=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='11'){  // if it is Related Places (Location Master Caregory Records Get)
						$listing=$this->get_location_related_places_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='12'){  // if it is Related Places (Location Master Category Records Get)
						$listing=$this->get_categorytype_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}elseif($module_type=='13'){  // if it is Review
						$listing=$this->get_reviews($language_id,$location_id);
						$postval['language_id']=$language_id;
						$postval['location_id']=$location_id;
						$row['count']=$this->fetch_reviews_count($postval);
						$row['attributes']=$listing;
						unset($postval);
						$add_custom[] = $row; 
					}
					
					
			
				 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			//print '<pre>';print_r($resultdata);die;
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_reviews($language_id,$location_id){
	    $offset=($page_no*$limit)-$limit;
        $this->db->select('*');
	    $this->db->where('language_id',$language_id);
	    $this->db->where('location_id', $location_id);
	    $this->db->order_by("review_id", "desc");
	    $this->db->limit(10, 0);
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('location_reviews');
		foreach($query->result_array() as $rowval){
		    $userid=$rowval['user_id'];
		    $postdate=$rowval['postdate'];
		    $fields=array('user_id'=>$userid);
		    $username = $this->gettableinfowithfields('users',$fields,'first_name,last_name');
		    $rowval['username']=$username->first_name.' '.$username->last_name;
		    $rowval['datetime']=date('d M Y',strtotime($postdate));
		    $add_custom[] = $rowval; 
		}
		$result=$add_custom;
		unset($add_custom);
	//	print $this->db->last_query();
		return $result;
	}

	
	function get_location_media_Details($language_id,$location_id){
		  $resultmedia = $this->DigitalMediaContent($location_id);
		
		  return $resultmedia;
	}
	
	
	function get_location_facility_Details($language_id,$location_id,$facility_type){
		  $resultmedia = $this->FacilityContent($language_id,$location_id,$facility_type);
		
		  return $resultmedia;
	}
	
	function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'assets/image-not-available.jpg';
        }
	
	}
	
    function add_reviews($postval){
        $result=$this->db->insert('location_reviews',$postval);
    	//print $this->db->last_query();
    	if($result){
    	    return True;
    	}else{
    	    return False;
    	}
    }
    
    function fetch_reviews($post_val,$page_no,$limit){
        $offset=($page_no*$limit)-$limit;
        $this->db->select('*');
	    $this->db->where('language_id', $post_val['language_id']);
	    $this->db->where('location_id', $post_val['location_id']);
	    $this->db->order_by("review_id", "desc");
	    $this->db->limit($limit, $offset);
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('location_reviews');
		foreach($query->result_array() as $rowval){
		    $userid=$rowval['user_id'];
		    $postdate=$rowval['postdate'];
		    $fields=array('user_id'=>$userid);
		    $username = $this->gettableinfowithfields('users',$fields,'first_name,last_name,user_photo');
		    $rowval['username']=$username->first_name.' '.$username->last_name;
		    $filename='http://dreambsys.in/codeigniter/hriday/assets/static/user_photos/original/'.$username->user_photo;
		        $pathinfo=$this->check_filexists($filename);
		    
		    $rowval['user_image']=$pathinfo;
		    $datetime=date('d M Y',strtotime($postdate));
		    $dateago=$this->time_elapsed_string($datetime);
		    $rowval['datetime']=$dateago;
		   // $rowval['datetime']=date('d M Y',strtotime($postdate));
		    $add_custom[] = $rowval; 
		}
		$result=$add_custom;
		unset($add_custom);
	//	print $this->db->last_query();
		return $result;
    }
     function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);
    
        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;
    
        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }
    
        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
    
    function ratingcount($location_id,$language_id,$counter){
    
        $this->db->select('*');
        $this->db->where('language_id', $language_id);
	    $this->db->where('location_id', $vendor_id);
	    $this->db->where('rating', $counter);
        $this->db->from('location_reviews');
        $query=$this->db->get();
        //print $this->db->last_query();
        $result= $query->num_rows();
        return $result;
    
    }
    
    function fetch_reviews_count($post_val){
        $this->db->select('*');
	    $this->db->where('language_id', $post_val['language_id']);
	    $this->db->where('location_id', $post_val['location_id']);
	    $this->db->order_by("review_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('location_reviews');
		//print $this->db->last_query();
		return $query->num_rows();
    }
    
    function sum_rating($lang,$locid){
        $this->db->select_sum('rating');
         $this->db->where('language_id', $lang);
	    $this->db->where('location_id', $locid);
        $this->db->from('location_reviews');
        $query=$this->db->get();
        //print $this->db->last_query();
        $result= $query->result_array();
        return $result[0]['rating'];
    }
	
	function location_tracking($language_id,$latitude,$longitude,$page_no,$limit){
	    $offset=($page_no*$limit)-$limit;
        $sql = 'SELECT * FROM (SELECT locations.is_active,locations.description,locations.language_id,locations.location_id,locations.location_name,locations.short_name,locations.address,locations.short_description,locations.latitude,locations.longitude,locations.alert1_distance,locations.alert1_sound_file_id,locations.alert1_sound_file_url,locations.alert2_distance,locations.alert2_sound_file_id,locations.alert2_sound_file_url,locations.alert3_distance,locations.alert3_sound_file_id,locations.alert3_sound_file_url,locations.alert4_distance,locations.alert4_sound_file_id,locations.alert4_sound_file_url,(((acos(sin(( '.$latitude.' * pi() / 180))*sin(( `latitude` * pi() / 180)) + cos(( '.$latitude.' * pi() /180 ))*cos(( `latitude` * pi() / 180)) *cos((( '.$longitude.' - `longitude`) * pi()/180)))) * 180/pi()) * 60 * 1.1515 * 1.609344) as distance FROM `locations` where is_active="1" order by distance asc) locations  where language_id='.$language_id.' and is_active="1" limit '.$offset. ' ,'.$limit.';';
    	//print $sql;  
    	$q = $this->db->query($sql);
    	$result= $q->result_array();
    	$beacons=array();
    	foreach($q->result_array() as $rowval){
    	    $loc_id=$rowval['location_id'];
    	    
    	    
            
    	    $rowval['beacons_listing']=$this->locations_beacons($loc_id,1);
    	    $distance=round($rowval['distance'],2);
		   $getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
			    $filename=base_url().gallery_path.$getpath->media_file_name;
			    $pathinfo=$this->check_filexists($filename);
				$rowval['image_path'] = $pathinfo;
			}else{ 
				$rowval['image_path'] = '';
			}
			$rowval['distance'] =$distance;
			$add_custom[] = $rowval;
		}
		$result=$add_custom;
		unset($add_custom);
    	return $result;  
    }
    
    function locations_beacons($loc_id,$lang_id){
        $this->db->select('*');
        $this->db->join('beacon_location_actions', 'beacon_locations.beacon_location_id = beacon_location_actions.beacon_location_id');
        $this->db->join('sound_files', 'beacon_location_actions.sound_file_id = sound_files.sound_file_id');
        $this->db->where('beacon_locations.language_id', $lang_id);
        $this->db->where('beacon_locations.location_id', $loc_id);
        $query=$this->db->get('beacon_locations');
	    $result= $query->result_array();
	    foreach($result as $rr){
	        $inst_id=$rr['instruction_id'];
	        if($inst_id==1){
	            $notficaition='Alert';
	        }else if($inst_id==2){
	            $notficaition='Pop Up';
	        }else if($inst_id==3){
	            $notficaition='Video';
	        }else if($inst_id==4){
	            $notficaition='Text/Sound';
	        }else if($inst_id==5){
	            $notficaition='Notification';
	        }else if($inst_id==6){
	            $notficaition='360';
	        }
	         $rr['not_type']=$notficaition;
	        $rr['soundfiles']=base_url().'assets/static/locations/soundfiles/'.$rr['file_name'];
	    }
        return $rr;
    }
    function location_tracking_count($language_id,$latitude,$longitude){
        $sql = 'SELECT * FROM (SELECT locations.is_active,locations.description,locations.language_id,locations.location_id,locations.location_name,locations.short_name,locations.address,locations.short_description,locations.latitude,locations.longitude,locations.alert1_distance,locations.alert1_sound_file_id,locations.alert1_sound_file_url,locations.alert2_distance,locations.alert2_sound_file_id,locations.alert2_sound_file_url,locations.alert3_distance,locations.alert3_sound_file_id,locations.alert3_sound_file_url,locations.alert4_distance,locations.alert4_sound_file_id,locations.alert4_sound_file_url,(((acos(sin(( '.$latitude.' * pi() / 180))*sin(( `latitude` * pi() / 180)) + cos(( '.$latitude.' * pi() /180 ))*cos(( `latitude` * pi() / 180)) *cos((( '.$longitude.' - `longitude`) * pi()/180)))) * 180/pi()) * 60 * 1.1515 * 1.609344) as distance FROM `locations` where is_active="1" order by distance asc) locations  where language_id='.$language_id.' and is_active="1"';
    	$q = $this->db->query($sql);
    	$count= $q->num_rows();
    	return $count;
    }
    
    function all_location_info(){
        $this->db->select('latitude,longitude,location_id,language_id,location_name,alert1_distance,alert1_sound_file_url,alert2_distance,alert2_sound_file_url');
	    $this->db->order_by("location_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('locations');
		//print $this->db->last_query();
		return $query->result_array();
        
    }
    function all_location_info_count(){
        $this->db->select('latitude,longitude,location_id,language_id,location_name,alert1_distance,alert1_sound_file_url,alert2_distance,alert2_sound_file_url');
	    $this->db->order_by("location_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('locations');
		//print $this->db->last_query();
		return $query->num_rows();
        
    }
	function get_category($category_id){
		$this->db->select('category_name as title,icon');
		$this->db->where('category_id',$category_id);
		$query=$this->db->get('categories');
		$listing=$query->row_array();
		return $listing;
	}
    
}
?>