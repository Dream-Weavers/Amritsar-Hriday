<?php 
class Plantrip_model extends CI_Model
{
	
	function get_all_locations($lang_id){
		
		$tablename='locations';
		$orderby='location_id';
		$this->db->select('locations.location_name,locations.short_name,locations.estimated_visit_time ,locations.location_id, locations.latitude,locations.longitude');
		$this->db->where('locations.is_active','1');
		$this->db->where('language_id',$lang_id);
		$this->db->where('estimated_visit_time!=','');
		$this->db->order_by($orderby, "desc");
		$query_latest=$this->db->get($tablename);
	
		foreach($query_latest->result_array() as $row_info)
		{
			$getpath=$this->defaultDigitalMedia($row_info['location_id'],gallery_files);
			if($getpath!=''){
				$filename=base_url().gallery_path.$getpath->media_file_name;
				$pathinfo=$this->check_filexists($filename);
				$row_info['image_path'] = $pathinfo;
			}else{
				$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$add_custom[]=$row_info;
		}
		
		return $add_custom;
	}
	function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'assets/image-not-available.jpg';
        }
	
	}
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
    
}
?>