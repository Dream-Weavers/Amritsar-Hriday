<?php 
class Search_model extends CI_Model
{
	function get_location($lang_id,$search_by,$search_code)
	{   $this->db->select('locations.location_id,locations.location_name,locations.short_name,locations.qr_code');
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
	    if($search_by=='serial_no')
	    $this->db->where('locations.serial_no',$search_code);
		elseif($search_by=='qr_code')
	    $this->db->where('locations.qr_code',$search_code);
	    $this->db->where('locations.language_id',$lang_id);
		$this->db->where('locations.is_active','1');
		$this->db->order_by("locations.created_on", "asc");
		$this->db->limit(1);
	    $query=$this->db->get('locations');
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
			
		    $loc_id=$row['location_id'];
			/*//Get Location Sections
			$sectionrow=$this->getlocationSections($loc_id);
			if($sectionrow!=''){
			  $row['section_title'] = $sectionrow->section_title;
			  $row['section_description'] = $sectionrow->section_description;
			}
			else
			{
			  $row['section_title'] = '';
			  $row['section_description'] = '';
			}
			//Get Gallery Digital Media
		    $getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$row['image_path'] = '';
			}
			//Get Audio Digital Media
			 $audiopath=$this->defaultDigitalMedia($loc_id,audio_files);
			if($audiopath!=''){
				$row['audio_path'] =  base_url().audio_path.$audiopath->media_file_name;
			}else{
				$row['audio_path'] = '';
			}
			//Get Video Digital Media
			 $videopath=$this->defaultDigitalMedia($loc_id,video_files);
			if($videopath!=''){
				$row['video_path'] = $videopath->media_file_name;
			}else{
				$row['video_path'] = '';
			}*/
				
			 $row_info[] = $row;	
			 
			}
			return $row_info;
		} else {
			return $row_info;
		}
		
	}

	function getlocationSections($location_id)
    {
		$this->db->select('section_title,section_description');
		$this->db->from('location_sections');
		$this->db->where('location_id', $location_id);
		$this->db->where('is_active','1');
		$this->db->order_by('location_section_id', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
	
	
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		///echo $this->db->last_query();die;
		return $results;

	} //End of View function
	
	function get_search_keywords($language_id,$search_by,$search_keyword)
	{  
	
	 $this->db->select('locations.location_id,locations.location_name,locations.short_name,locations.qr_code,categories.category_name,categories.category_id');
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
	    if($search_by=='location')
	    $this->db->or_like('locations.location_name',$search_keyword);
		elseif($search_by=='category')
	    $this->db->or_like('categories.category_name',$search_keyword);
	    $this->db->where('locations.language_id',$language_id);
		$this->db->where('categories.language_id',$language_id);
		$this->db->where('locations.is_active','1');
		if($search_by=='category')
		{
		$this->db->group_by("categories.category_name");	
		$this->db->order_by("categories.category_name", "asc");
		}
		else
		{
		$this->db->group_by("locations.location_name");		
		$this->db->order_by("locations.location_name", "asc");
		}
		$this->db->limit(20);
	    $query=$this->db->get('locations');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query();die;
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
					
			 $row_info[] = $row;	
			 
			}
			return $row_info;
		} else {
			return $row_info;
		}
		
	}
	

	
}
?>