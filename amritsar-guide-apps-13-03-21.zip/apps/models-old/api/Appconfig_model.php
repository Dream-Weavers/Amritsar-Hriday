<?php 
class Appconfig_model extends CI_Model
{
	function get_legalinfo($lang_id)
	{   
		$this->db->select('config_name,config_value');
		$this->db->where('language_id',$lang_id);
		$this->db->where('config_name','legalinfo');
		$this->db->where('is_active','1');
		$this->db->order_by("app_config_id", "asc");
	    $query=$this->db->get('app_configuration');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query();
		$row_main=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
			 $row_main[] = $row;	
			}
			return $row_main;
		} else {
			return $row_main;
		}
		
	}

}
?>