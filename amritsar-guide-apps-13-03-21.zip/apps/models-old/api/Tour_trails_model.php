<?php
class Tour_trails_model extends CI_Model{
	
	function get_Categorytypes_Locations($lang_id){
		$this->db->select('category_types.category_type,category_types.category_type_id');
		$this->db->join('category_types', 'category_types.category_type_id = location_categories.category_type_id');
		$this->db->where('category_types.is_active','1');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('category_types.language_id',$lang_id);
		$this->db->order_by('category_types.weight', 'ASC');
		$this->db->group_by('category_types.category_type_id');
		$query = $this->db->get('location_categories');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $category_type_id = $row['category_type_id'];
				
						$listing=$this->get_categorytype_locations_content($lang_id,$category_type_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_categorytype_locations_content($lang_id,$category_type_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.longitude,locations.latitude,locations.short_description as description,locations.estimated_visit_time');
		$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('categories.language_id',$lang_id);
		$this->db->where('location_categories.category_type_id',$category_type_id);
		$this->db->where('location_categories.is_active','1');
		$query=$this->db->get('categories');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$minutes=$row_info['estimated_visit_time'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = '';
			}
			$hours = floor($minutes / 60).':'.($minutes -   floor($minutes / 60) * 60);
			$row_info['est_time']=$hours;
			
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	
   function defaultDigitalMedia($location_id,$media_type)
	{
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;
		
	}
	



  function insert_tour_trails($tour_trail_data){
	 	$result=$this->db->insert('tour_trails',$tour_trail_data);
		$tour_trail_id = $this->db->insert_id();
		return $tour_trail_id;
	}
	
	function insert_tour_trail_locations($tour_trail_location_data){
	 	$result=$this->db->insert('tour_trail_locations',$tour_trail_location_data);
		return $result;
	}
	
   function update_tour_trails($tour_trail_id,$user_id,$tour_trail_data){
	    $this->db->where('tour_trail_id',$tour_trail_id);
		$this->db->where('user_id',$user_id);
	 	$updateresult=$this->db->update('tour_trails',$tour_trail_data);
		return $updateresult;
	}
	
	function update_tour_trail_locations($tour_trail_id,$tour_trail_location_data){
	     $updateresult=$this->db->insert('tour_trail_locations',$tour_trail_location_data);
		 return $updateresult;
	}
	
	function delete_tour_trail_location($language_id,$user_id,$tour_trail_id){
		//print $user_id;
		$this->db->select('*');
	//	$this->db->join('tour_trails', 'tour_trails.tour_trail_id = tour_trail_locations.tour_trail_id');
		$this->db->where('tour_trails.tour_trail_id',$tour_trail_id);
		$this->db->where('tour_trails.user_id',$user_id);
		$this->db->where('tour_trails.language_id',$language_id);
	//	$this->db->where('tour_trail_locations.tour_trail_location_id',$tour_trail_location_id);
	    $query = $this->db->get('tour_trails');
	   
	   if($query->num_rows() > 0 ){
		//  $this->db->where('tour_trail_location_id',$tour_trail_location_id); 
		
		
		$this->db->where('tour_trail_id',$tour_trail_id); 
		 // $this->db->where('language_id',$language_id); 
		  $deleteresult = $this->db->delete('tour_trails');
		
		  $this->db->where('tour_trail_id',$tour_trail_id); 
		 // $this->db->where('language_id',$language_id); 
		  $deleteresult = $this->db->delete('tour_trail_locations');
		//  print $this->db->last_query();
		  return $deleteresult;
	   }
	   else
	   {  return '0';
	   }
	}
	
		function user_tour_trails_count($user_id,$language_id){
	    $offset=($page_no*$limit)-$limit;
		$this->db->select('tour_trail_id,language_id,user_id,tour_trail_name');
	//	$this->db->join('tour_trails', 'tour_trails.tour_trail_id = tour_trail_locations.tour_trail_id');
		$this->db->where('tour_trails.user_id',$user_id);
		$this->db->where('tour_trails.language_id',$language_id);
	//	$this->db->limit($limit, $offset);
	    $query = $this->db->get('tour_trails');
		$resultdata = $query->result_array(); 
	//	echo $this->db->last_query();
		return $query->num_rows();
		
	}
		
	function user_tour_trails($user_id,$language_id,$page_no,$limit){
	    $offset=($page_no*$limit)-$limit;
		$this->db->select('tour_trail_id,language_id,user_id,tour_trail_name,tour_trails.predefined,tour_trails.userdefine_time,tour_trails.travel_time');
	//	$this->db->join('tour_trails', 'tour_trails.tour_trail_id = tour_trail_locations.tour_trail_id');
		$this->db->where('tour_trails.user_id',$user_id);
		$this->db->where('tour_trails.language_id',$language_id);
		$this->db->limit($limit, $offset);
	    $query = $this->db->get('tour_trails');
		$resultdata = $query->result_array(); 
	//	echo $this->db->last_query();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $tour_trail_id = $row['tour_trail_id'];
				       $travel_time = $row['travel_time'];
				       $userdefine_time = $row['userdefine_time'];
				       $traveltime=date('H:i',strtotime($travel_time));
				       $userdefinetime=date('H:i',strtotime($userdefine_time));
				       // print $tour_trail_id;
						$listing=$this->get_user_tour_trail_locations($tour_trail_id);
						//print '<pre>';print_r($listing);
						if(is_array($listing)){
						    $location=array();
						    foreach($listing as $locs){
						        $location[]=$locs['location_id'];
						    }
						    
						    $locationids=implode(',',$location);
						}
						$row['locationids']=$locationids;
						$row['travel_time']=$traveltime;
						$row['userdefine_time']=$userdefinetime;
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	/*function user_tour_trail_info($user_id,$language_id,$tour_trail_id){
	   // $offset=($page_no*$limit)-$limit;
		$this->db->select('tour_trail_id,language_id,user_id,tour_trail_name');
	//	$this->db->join('tour_trails', 'tour_trails.tour_trail_id = tour_trail_locations.tour_trail_id');
		$this->db->where('tour_trails.user_id',$user_id);
		$this->db->where('tour_trails.language_id',$language_id);
		//$this->db->limit($limit, $offset);
	    $query = $this->db->get('tour_trails');
		$resultdata = $query->result_array(); 
	//	echo $this->db->last_query();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $tour_trail_id = $row['tour_trail_id'];
				       // print $tour_trail_id;
						$listing=$this->get_user_tour_trail_locations($tour_trail_id);
						//print '<pre>';print_r($listing);
						if(is_array($listing)){
						    $location=array();
						    foreach($listing as $locs){
						        $location[]=$locs['location_id'];
						    }
						    $locationids=implode(',',$location);
						}
						$row['locationids']=$locationids;
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}*/
	function user_tour_trail_info($user_id,$language_id,$tour_trail_id){
		/*$this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_id,tour_trails.language_id,tour_trails.user_id');
		$this->db->join('tour_trails', 'tour_trails.tour_trail_id = tour_trail_locations.tour_trail_id');
		$this->db->where('tour_trails.user_id',$user_id);
		$this->db->where('tour_trails.tour_trail_id',$tour_trail_id);
		$this->db->where('tour_trails.language_id',$language_id);
	    $query = $this->db->get('tour_trail_locations');*/
	    $this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_id,tour_trails.language_id,tour_trails.user_id,tour_trails.predefined,tour_trails.userdefine_time,tour_trails.travel_time');
	//	$this->db->join('tour_trails', 'tour_trails.tour_trail_id = tour_trail_locations.tour_trail_id');
		//$this->db->where('tour_trails.user_id',$user_id);
		$this->db->where('tour_trails.language_id',$language_id);
		$this->db->where('tour_trails.tour_trail_id',$tour_trail_id);
		$this->db->limit($limit, $offset);
	    $query = $this->db->get('tour_trails');
		$resultdata = $query->result_array(); 
		//$resultdata = $query->result_array(); 
		//echo $this->db->last_query();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $tour_trail_id = $row['tour_trail_id'];
				        $travel_time = $row['travel_time'];
				       $userdefine_time = $row['userdefine_time'];
				       $traveltime=date('H:i',strtotime($travel_time));
				       $userdefinetime=date('H:i',strtotime($userdefine_time));
				       $row['travel_time']=$traveltime;
						$row['userdefine_time']=$userdefinetime;
						$listing=$this->get_user_tour_trail_location_info($tour_trail_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	
	function get_user_tour_trail_locations($tour_trail_id){
		$this->db->select('tour_trail_locations.tour_trail_id,tour_trail_locations.location_id,tour_trail_locations.weight,tour_trail_locations.visit_status,locations.location_id,locations.location_name,locations.short_description,locations.latitude,locations.longitude,locations.estimated_visit_time');
		$this->db->join('tour_trail_locations', 'tour_trail_locations.location_id = locations.location_id');
		$this->db->where('tour_trail_locations.tour_trail_id',$tour_trail_id);
		$this->db->order_by("tour_trail_locations.weight", "asc");
	    $query = $this->db->get('locations');
		$resultdata = $query->result_array(); 
		$row_main=array();
		if($query->num_rows()>0){
		  foreach($resultdata as $trailkey=>$trailrow){
			$loc_id = $trailrow['location_id'];
			$minutes= $trailrow['estimated_visit_time'];
			$hours = floor($minutes / 60).':'.($minutes -   floor($minutes / 60) * 60);
			//$trailrow['estimated_visit_time']=$hours;
			$trailrow['estimated_visit_time']=$minutes;
            $this->db->select('*');
            $this->db->from('location_categories');
            $this->db->where('location_categories.location_id', $loc_id);
            $query = $this->db->get();
			$resultinfo=$query->result_array();
			$loc_cattype=array();
			$loc_cat=array();
			foreach($resultinfo as $locrow){
			    $cattype=$locrow['category_type_id'];
			    $loc_cattype[$cattype]=$locrow['category_type_id'];
			    $loc_cat[]=$locrow['category_id'];
			}
	    	array_unique($loc_cattype);
	    //	print '<pre>';print_r($loc_cattype);
			$loccattype=implode(',',$loc_cattype);
			$loc_catstring=implode(',',$loc_cat);
			unset($loc_cattype);
			unset($loc_cat);
		//	print $loc_id;
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$trailrow['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$trailrow['image_path'] = '';
			}
	    	$trailrow['cat_types_id']=$loccattype;
	    	$trailrow['cat_id']=$loc_catstring;
	    	$loccattype='';
	    	$loc_catstring='';
			 $row_main[] = $trailrow;	
			}
			return $row_main;
		} else {
			return $row_main;
		}
	}
	
	
	function get_user_tour_trail_location_info($tour_trail_id){
		$this->db->select('tour_trail_locations.tour_trail_id,tour_trail_locations.location_id,tour_trail_locations.weight,tour_trail_locations.visit_status,locations.location_id,locations.location_name,locations.short_description,locations.latitude,locations.longitude,locations.map_icon');
		$this->db->join('tour_trail_locations', 'tour_trail_locations.location_id = locations.location_id');
		$this->db->where('tour_trail_locations.tour_trail_id',$tour_trail_id);
		$this->db->order_by("tour_trail_locations.weight", "asc");
	    $query = $this->db->get('locations');
		$resultdata = $query->result_array(); 
		$row_main=array();
		if($query->num_rows()>0){
		  foreach($resultdata as $trailkey=>$trailrow){
			$loc_id = $trailrow['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$trailrow['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$trailrow['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			// $trailrow['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$trailrow['map_icon']));
			
			 $row_main[] = $trailrow;	
			}
			return $row_main;
		} else {
			return $row_main;
		}
	}
	
	function predefined_tours($language_id,$page_no,$limit){
	    $offset=($page_no*$limit)-$limit;
		
		$this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_id,tour_trails.language_id,tour_trails.user_id,tour_trails.predefined,tour_trails.userdefine_time,tour_trails.travel_time');
		$this->db->where('tour_trails.user_id','1');
		$this->db->where('tour_trails.is_active','1');
		$this->db->order_by("tour_trails.tour_trail_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('tour_trails');
		//print $this->db->last_query();die;
		$resultdata = $query->result_array(); 
		//$resultdata = $query->result_array(); 
		//echo $this->db->last_query();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
                $tour_trail_id = $row['tour_trail_id'];
                $travel_time = $row['travel_time'];
                $userdefine_time = $row['userdefine_time'];
                $traveltime=date('H:i',strtotime($travel_time));
                $userdefinetime=date('H:i',strtotime($userdefine_time));
                $row['travel_time']=$traveltime;
                $row['userdefine_time']=$userdefinetime;
                $listing=$this->get_user_tour_trail_location_info($tour_trail_id);
                $row['attributes']=$listing;
                $add_custom[] = $row; 
			}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	
	function predefined_tours_count(){
	    $this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_id,tour_trails.language_id,tour_trails.user_id,tour_trails.predefined,tour_trails.userdefine_time,tour_trails.travel_time');
		$this->db->where('tour_trails.user_id','1');
		$this->db->where('tour_trails.is_active','1');
		$this->db->order_by("tour_trails.tour_trail_id", "desc");
		$query=$this->db->get('tour_trails');
		return $query->num_rows();
	}
	
}
?>