<?php
class Sharepage_model extends CI_Model
{
    function add_sharepage($post_val){
    	$result=$this->db->insert('sharePageToUser',$post_val);
    	//print $this->db->last_query();
    	if($result){
    	    return True;
    	}else{
    	    return False;
    	}
    }
    
    function story_detail($user_id,$story_id){
        $this->db->select('*');
	    $this->db->where('story_id', $story_id);
		$query=$this->db->get('stories');
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $created_date=$row['postdate'];
		    
		    $date=date('d M Y',strtotime($created_date));
		    
			//Get User Photo Path 
			$row['postdate']=$date;
			
		    if($row!='image_url'){
				$row['image_url'] = base_url().'images/story/'.$row['image_url'];
			}else{
				 
				  $row['image_url'] =base_url().'assets/image-not-available.jpg';
			    }
				$fileexist=$this->check_filexists($row['image_url']);
				$row['story_path'] =$fileexist;
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
    }
    function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'assets/image-not-available.jpg';
        }
	
	}
	
	function sharepage_listing($user_id,$language_id,$page_no,$limit)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('*');
	    $this->db->where('language_id', $language_id);
	    $this->db->where('shareto', $user_id);
	    $this->db->order_by("share_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('sharePageToUser');
		$resultdata = $query->result_array(); 
		
		if($query->num_rows()>0){
			$row_info=array();
			foreach($resultdata as $key=>$row){
		    $created_date=$row['postdate'];
		    $user_id=$row['user_id'];
		    $date=date('d M Y',strtotime($created_date));
		    $userinfo=$this->user_getinfo($user_id);
		     $row['firstname']=$userinfo['first_name'];
		      $row['last_name']=$userinfo['last_name'];
		       $row['user_photo']=$userinfo['user_photo'];
			//Get User Photo Path 
			$row['postdate']=$date;
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
	
	function user_getinfo($user_id){
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('user_type','U');
		$this->db->where('user_id', $user_id);
		$this->db->limit(1);
		$query = $this->db->get();
		$userarr=array();
		if($query->num_rows() == 1){
			$row = $query->row();
			if($row->user_photo!=''){
				//$photo=base64_encode(base_url().users_photo_path.$row->user_photo);
				$filename=users_photo_path.$row->user_photo;
				$pathinfo=$this->check_filexists($filename);
				$photo=$pathinfo;
			}else{
				$photo=base_url().'assets/userdefault.png';
			}
			
		
			
			if($row->last_name!="")
			{
			    $lastname=$row->last_name;
			}else{
		        $lastname='';
			}
			$userarr=array('first_name'=>$row->first_name,
			'last_name'=>$lastname,
			'user_photo'=>$photo,
			);				
		}
	//	return json_encode($userarr);		
		return $userarr;		
	}
	
	
	function sharepage_listing_count($user_id,$language_id,$page_no,$limit)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('*');
	    $this->db->where('language_id', $language_id);
	    $this->db->where('shareto', $user_id);
	    $this->db->order_by("share_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('sharePageToUser');
		return $query->num_rows();
		
	}
}