<?php
class Blogs_model extends CI_Model
{
    function add_blog($post_val){
    	$result=$this->db->insert('blogs',$post_val);
    	//print $this->db->last_query();
    	if($result){
    	    return True;
    	}else{
    	    return False;
    	}
    }
    function getuser_info($user_id){
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('user_id', $user_id);
        //$this->db->where('user_type', 'E');
       // $this->db->limit(1);
        $query = $this -> db -> get();
        return $query->row();
    }
    
    function blog_category($language_id){
         $this->db->select('*');
        $this->db->from('blog_categories');
        $this->db->where('language_id', $language_id);
        $this->db->where('is_active', '1');
        //$this->db->where('user_type', 'E');
       // $this->db->limit(1);
        $query = $this -> db -> get();
        return $query->result_array();
    }
    
    function blog_listing($user_id,$category_id,$language_id,$page_no,$limit)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('*');
	    if($category_id!=''){
	         $this->db->where('category_id', $category_id);
	    }
	    $this->db->where('language_id', $language_id);
	    //$this->db->where('status', '1');
	    $this->db->where('created_by',$user_id);
	    $this->db->order_by("blog_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('blogs');
		$resultdata = $query->result_array(); 
		//print $this->db->last_query();die;
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $created_date=$row['created_date'];
		    
		    $date=date('d M Y',strtotime($created_date));
		    if($row['modified_date']!=''){
		        $modified_date=$row['modified_date'];
		        $mdate=date('d M Y',strtotime($modified_date));
		        $row['modified_date']=$mdate;
		    }
			//Get User Photo Path 
			$row['created_date']=$date;
			
		    if($row!='image_url'){
				$row['image_url'] = base_url().'images/blogs/'.$row['image_url'];
			}else{
				 
				  $row['image_url'] = base_url().'assets/image-not-available.jpg';
			    }
				$fileexist=$this->check_filexists($row['image_url']);
				$row['blog_path'] =$fileexist;
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
	
	function blog_listing_count($user_id,$category_id,$language_id,$page_no,$limit)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('*');
	     if($category_id!=''){
	         $this->db->where('category_id', $category_id);
	    }
	    //$this->db->where('status', '1');
	    $this->db->where('created_by',$user_id);
	    $this->db->where('language_id', $language_id);
	    $this->db->order_by("blog_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('blogs');
		return $query->num_rows();
		
	}
	
	function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'assets/image-not-available.jpg';
        }
	
	}
	
	public function blog_detail($user_id,$blog_id){
	    $this->db->select('*');
	    $this->db->where('blog_id', $blog_id);
		$query=$this->db->get('blogs');
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $created_date=$row['created_date'];
		    
		    $date=date('d M Y',strtotime($created_date));
		    if($row['modified_date']!=''){
		        $modified_date=$row['modified_date'];
		        $mdate=date('d M Y',strtotime($modified_date));
		        $row['modified_date']=$mdate;
		    }
			//Get User Photo Path 
			$row['created_date']=$date;
			
		    if($row!='image_url'){
				$row['image_url'] = base_url().'images/blogs/'.$row['image_url'];
			}else{
				 
				  $row['image_url'] = base_url().'assets/image-not-available.jpg';
			    }
				$fileexist=$this->check_filexists($row['image_url']);
				$row['blog_path'] =$fileexist;
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
    
}