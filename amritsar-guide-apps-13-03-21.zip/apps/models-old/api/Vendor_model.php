<?php 
class Vendor_model extends CI_Model
{

	function all_vendor_details_count(){
		
	//	$offset=($page_no*$limit)-$limit;
		
		$this->db->select('vendor_details.user_id,vendor_details.shop_title,vendor_details.shop_address ,users.mobile_no1 as mobile,  users.user_photo as image_name, vendor_reviews.rating, vendor_reviews.comment');
		$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','left');
		$this->db->join('vendor_reviews', 'vendor_reviews.user_id = users.user_id','left');
		$this->db->where('users.user_type','V');
		$this->db->where('users.is_active','1');
		$this->db->order_by("users.user_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('users');
		return $query->num_rows();
	}
	
	function all_vendor_details($page_no,$limit){
		
		$offset=($page_no*$limit)-$limit;
		
		$this->db->select('vendor_details.user_id,vendor_details.shop_title,vendor_details.shop_address ,users.mobile_no1 as mobile,  users.user_photo as image_name, vendor_reviews.rating, vendor_reviews.comment');
		$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','left');
		$this->db->join('vendor_reviews', 'vendor_reviews.user_id = users.user_id','left');
		$this->db->where('users.user_type','V');
		$this->db->where('users.is_active','1');
		$this->db->order_by("users.user_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('users');
		//print $this->db->last_query();die;
		$row=$query->result_array();
		
		if(!empty($row))
		{
			foreach($row as $key => $val)
			{
			    if($val['image_name']!=''){
				$row[$key]['media_url'] = base_url().'/assets/vendors/original/'.$val['image_name'];
				}else{
				    $row[$key]['media_url'] = base_url().'assets/userdefault.png';
				    
				}
				
				if($val['rating']!=''){
				    	$row[$key]['rating'] ='';
				}else{
				    $row[$key]['rating'] ='';
				}
				if($val['comment']!=''){
				    	$row[$key]['comment'] ='';
				}else{
				    $row[$key]['comment'] ='';
				}
				$row[$key]['image_name']=base_url().'assets/image-not-available.jpg';
			}
		}
		
		return $row;
		
	}
	/*function particular_vendor_details($vendor_id,$page_no,$limit){
		
		$offset=($page_no*$limit)-$limit;
		
		$this->db->select('vendor_details.shop_title,vendor_details.shop_address ,users.mobile_no1 as mobile,  users.user_photo as image_name, vendor_reviews.rating, vendor_reviews.comment');
		$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','left');
		$this->db->join('vendor_reviews', 'vendor_reviews.user_id = users.user_id','left');
		$this->db->where('users.user_id',$vendor_id);
		$this->db->where('users.user_type','V');
		$this->db->where('users.is_active','1');
		$this->db->order_by("users.user_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('users');
	//	print $this->db->last_query();die;
		$row=$query->result_array();
		if($row[0]['image_name']!=''){
				$row[0]['media_url'] = base_url().'/assets/vendors/original/'.$row[0]['image_name'];
		}
		//print_r($row);DIE;
		$datainfo=array();
		$datainfo['module_layout_id']=1;
		return $row;
		
	}*/
	
	
		function get_location_places_content($language_id,$vendor_id){
		
		
		$this->db->select('vendor_details.shop_title as title,vendor_details.vendor_description as desc,vendor_details.shop_address as address,users.mobile_no1 as mobile,  users.user_photo as image_name, vendor_reviews.rating, vendor_reviews.comment');
		$this->db->join('vendor_details', 'vendor_details.user_id = users.user_id','left');
		$this->db->join('vendor_reviews', 'vendor_reviews.user_id = users.user_id','left');
		$this->db->where('users.user_id',$vendor_id);
		$this->db->where('users.user_type','V');
		$this->db->where('users.is_active','1');
		$this->db->order_by("users.user_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('users');
		//print $this->db->last_query();die;
		$row=$query->result_array();
		if($row[0]['image_name']!=''){
				$row[0]['media_url'] = base_url().'/assets/vendors/original/'.$row[0]['image_name'];
				$row[0]['image_path'] = base_url().'/assets/vendors/original/'.$row[0]['image_name'];
		}
		//print_r($row);DIE;
		//$row[0]['description']='This is test description about vendor. This is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendorThis is test description about vendor';
		$row[0]['description']=$row[0]['desc'];
		$datainfo=array();
		$datainfo['module_layout_id']=1;
		return $row;
		
	}
	
	function particular_vendor_details($language_id,$vendor_id){
		
		$this->db->select('vendor_layout_id,language_id,module_type,module_layout,module_name,weigth');
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','1');
		$this->db->where('is_active','1');
		$this->db->order_by("weigth", "asc");
	    $query=$this->db->get('vendor_layout');
	    //print $this->db->last_query();
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			//$row = array();
			//$add_custom= array();
			foreach($resultdata as $skey=>$row){
				$moduleid=$row['vendor_layout_id'];
				$module_type=$row['module_type'];
				$module_layout=$row['module_layout'];
				     //$locrow = get_table_info('vendor_distance_timings','vendor_id',$vendor_id);
                        $this->db->select('*');
                        $this->db->where('vendor_id',$vendor_id);
                        $query=$this->db->get('vendor_distance_timings');
				        $locrow = $query->row();
				      //  print '<pre>';print_R($locrow);
					if($module_type=='1'){  // If it is location type
					
					}else if($module_type=='2'){  // If it is Places type
						$listing=$this->get_location_places_content($language_id,$vendor_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
				elseif($module_type=='3'){  // If it is Distances type
						
						 $distance_listing=array();
						 $distance_type_array = get_list_options('distance_type','ASC'); 
						 unset($distance_type_array['']);
                         foreach($distance_type_array as $distancekey=>$disval){
							 
						  //echo "-------->".$distancekey;
						 if($distancekey== '1')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->airport_distance;
							 //$distancelisting['icon_path']= base_url().icon_url_path.'bus-stop.png';
							 $filename=base_url().icon_url_path.'bus-stop.svg';
							 $pathinfo=$this->check_filexists($filename);
							 
							 
							 $distancelisting['icon_path']= $pathinfo;
						  }
						 if($distancekey=='2')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->bus_stand_distance;
							// $distancelisting['icon_path']= base_url().icon_url_path.'airport.png';
							$filename=base_url().icon_url_path.'plane.svg';
							$pathinfo=$this->check_filexists($filename);   
							 $distancelisting['icon_path']= $pathinfo;
						  }
						  if($distancekey=='3')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->railway_station_distance;
							 //$distancelisting['icon_path']= base_url().icon_url_path.'railway.png';
							 $filename=base_url().icon_url_path.'train.svg';
							 $pathinfo=$this->check_filexists($filename);  
							 $distancelisting['icon_path']= $pathinfo;
						  } 
						  if($distancekey=='4')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->city_centre_distance;
							 //$distancelisting['icon_path']= base_url().icon_url_path.'shopping-center.png';
							 $filename= base_url().icon_url_path.'shopping-center.svg';
							$pathinfo=$this->check_filexists($filename);   
							 $distancelisting['icon_path']= $pathinfo;
						  } 
						  $distance_listing[] = $distancelisting;
				  
						 }
						
					
						$row['attributes']=$distance_listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='4'){  // if it is Location Map.
						$needed_fields='vendor_details.user_id,vendor_details.shop_title,vendor_details.latitude,vendor_details.longitude';
						//$needed_fields='locations.location_id,locations.location_name,locations.latitude,locations.longitude,locations.map_icon,locations.short_description as description';
						$listing=$this->get_location_detail_content($language_id,$vendor_id,$needed_fields,$module_type);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}elseif($module_type=='8'){  // if it is Opening Hours
						$needed_fields='vendor_distance_timings.working_hours';
						$listing=$this->vendor_working_hours($language_id,$vendor_id,$needed_fields,$module_type,$user_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					
					elseif($module_type=='10'){  // if it is Review & Rating
					    $listing=array();
					    $rev_Array=array('language_id'=>$language_id,'vendor_id'=>$vendor_id);
					    $reviewcount=$this->fetch_reviews_count($rev_Array);
					    $sumrating=$this->sum_rating($language_id,$vendor_id);
					    if($sumrating==0){
					        $avg_rating=0;
					    }else{
					        $avg_rating=$sumrating/$reviewcount;
					    }
					    $avgrating=number_format((float)$avg_rating, 1, '.', '');
						$listing['rating_score']= $avgrating;
						$listing['rating_title']= 'Stars';
						$listing['rating_desciption']= $reviewcount.' verified reviews & ratings';
						$listing['review_add_text']= 'Write Review';
						$row['attributes'][]=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='12'){  // if it is Related Places (Location Master Category Records Get)
						$listing=$this->get_category_types($language_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}/*elseif($module_type=='13'){  // if it is Related Places (Location Master Category Records Get)
						$listing=$this->get_reviews($language_id,$location_id);
						$postval['language_id']=$language_id;
						$postval['location_id']=$location_id;
						$row['count']=$this->fetch_reviews_count($postval);
						$row['attributes']=$listing;
						unset($postval);
						$add_custom[] = $row; 
					}*/
					
					
			
				
				}
			$resultdata=$add_custom;
			unset($add_custom);
			//print '<pre>';print_r($resultdata);die;
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_category_types($language_id){
		$this->db->select('category_types.category_type as title,category_types.category_type_id as id ,"category_type" as `type`');
		$this->db->where('category_types.language_id',$language_id);
		$this->db->where('category_types.is_active','1');
		$query = $this->db->get('category_types');
		$result=$query->result_array();
		return $result;
	}
	
	function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'assets/image-not-available.jpg';
        }
	
	}
	
	
	function get_location_detail_content($language_id,$vendor_id,$needed_fields,$module_type){
		
		$this->db->select($needed_fields);
		//$this->db->where('vendor_details.language_id',$language_id);
		$this->db->where('vendor_details.user_id',$vendor_id);
		//$this->db->where('vendor_details.is_active','1');
		$query=$this->db->get('vendor_details');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$rows = array();
		foreach($listing as $row_info)
		{
		if($module_type=='4'){
	    	$row_info['map_icon']='';
		}
			   
				$rows[] = $row_info;
		    
		}
		return $rows;
	}
	
	function vendor_working_hours($language_id,$vendor_id,$needed_fields,$module_type){
		
		$this->db->select($needed_fields);
		//$this->db->where('vendor_details.language_id',$language_id);
		$this->db->where('vendor_distance_timings.vendor_id',$vendor_id);
		//$this->db->where('vendor_details.is_active','1');
		$query=$this->db->get('vendor_distance_timings');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$listing=$query->result_array();
		$rows = array();
		foreach($listing as $row_info)
		{
		if($module_type=='8')
			{
				$working_hours = json_decode($row_info['working_hours'],true);
				if(is_array($working_hours))
				{   $work_hrs_result=array();
					foreach($working_hours as $hrskey=> $hrsval) {
						
						$work_hrs_result[]=$hrsval;
					}
				}
				$row_info['working_hours'] = $work_hrs_result;
			}
			   
				$rows[] = $row_info;
		    
		}
		return $rows;
	}
	
	function fetch_reviews_count($post_val){
        $this->db->select('*');
	    $this->db->where('language_id', $post_val['language_id']);
	    $this->db->where('vendor_id', $post_val['vendor_id']);
	    $this->db->order_by("review_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('vendor_reviews');
		//print $this->db->last_query();
		return $query->num_rows();
    }
    
    function sum_rating($lang,$locid){
        $this->db->select_sum('rating');
         $this->db->where('language_id', $lang);
	    $this->db->where('vendor_id', $locid);
        $this->db->from('vendor_reviews');
        $query=$this->db->get();
        //print $this->db->last_query();
        $result= $query->result_array();
        return $result[0]['rating'];
    }
	
	
	function add_reviews($postval){
        $result=$this->db->insert('vendor_reviews',$postval);
    	//print $this->db->last_query();die;
    	if($result){
    	    return True;
    	}else{
    	    return False;
    	}
    }
    
    function fetch_reviews($post_val,$page_no,$limit){
        $offset=($page_no*$limit)-$limit;
        $this->db->select('*');
	    $this->db->where('language_id', $post_val['language_id']);
	    $this->db->where('vendor_id', $post_val['vendor_id']);
	    $this->db->order_by("review_id", "desc");
	    $this->db->limit($limit, $offset);
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('vendor_reviews');
		foreach($query->result_array() as $rowval){
		    $userid=$rowval['user_id'];
		    $postdate=$rowval['postdate'];
		    $fields=array('user_id'=>$userid);
		    $username = $this->gettableinfowithfields('users',$fields,'first_name,last_name');
		    $rowval['username']=$username->first_name.' '.$username->last_name;
		   
		    $datetime=date('d M Y',strtotime($postdate));
		    $dateago=$this->time_elapsed_string($datetime);
		    $rowval['datetime']=$dateago;
		    $add_custom[] = $rowval; 
		}
		$result=$add_custom;
		unset($add_custom);
	//	print $this->db->last_query();
		return $result;
    }
   
    
    function gettableinfowithfields($table,$fields,$needed_fields)
    {   //echo $needed_fields;die;

        $this->db->select($needed_fields);
		if(is_array($fields)){
	     foreach($fields as $keys => $values) {
			 $this->db->where($keys, $values);
			 }         
	   }
        $this->db->from($table);
        $query = $this->db->get();
	//	echo $this->db->last_query();die;
        if($query -> num_rows() == 0)
			{		return '0';
			}
			else
			{		return $query->row();
			}

    }
    
    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);
    
        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;
    
        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }
    
        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
    
    function ratingcount($vendor_id,$language_id,$counter){
    
        $this->db->select('*');
        $this->db->where('language_id', $language_id);
	    $this->db->where('vendor_id', $vendor_id);
	    $this->db->where('rating', $counter);
        $this->db->from('vendor_reviews');
        $query=$this->db->get();
        //print $this->db->last_query();
        $result= $query->num_rows();
        return $result;
    
    }
	
}
?>