<?php 
class Menu_model extends CI_Model
{
	function get_main_menu($lang_id,$menu_type)
	{   
		$this->db->select('menu_id,app_menu_id,language_id,menu_name,view_type');
		$this->db->where('language_id',$lang_id);
		$this->db->where('menu_type',$menu_type);
		$this->db->where('user_type','U');
		$this->db->order_by("set_order", "asc");
	    $query=$this->db->get('navigation_menus');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query();
		$row_main=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
			 $row_main[] = $row;	
			}
			return $row_main;
		} else {
			return $row_main;
		}
		
	}
	
	
	function get_app_label($lang_id,$menu_type)
	{   $this->db->select('label_name,label_text');
		$this->db->where('language_id',$lang_id);
		$this->db->where('is_active','1');
		$this->db->order_by("label_id", "asc");
	    $query=$this->db->get('app_labels');
		$resultdata = $query->result_array(); 
		$row_main=array();
		if($query->num_rows()>0){
			$new_row =array();
			foreach($resultdata as $key=>$row){
		 	 $new_row[$row['label_name']] =$row['label_text'];
			 
			 $row_main = $new_row;	
			}
			return $row_main;
		} else {
			return $row_main;
		}
	}
	
	
 function get_app_languages()
	{   $this->db->select('language_id,language_short_name,language_name');
		$this->db->where('is_active','1');
		$this->db->order_by("language_id", "asc");
	    $query=$this->db->get('languages');
		$resultdata = $query->result_array(); 
		$row_main=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
			 $row_main[] = $row;	
			}
			return $row_main;
		} else {
			return $row_main;
		}
	}
	
	
	function get_app_font_mode($lang_id)
	{   $this->db->select('list_id,option_id,title,short_name,language_id');
	    $this->db->where('language_id',$lang_id);
		$this->db->where('list_id','font_mode');
		$this->db->order_by("seq", "asc");
	    $query=$this->db->get('list_options');
		//echo $this->db->last_query();
		$resultdata = $query->result_array(); 
		$row_main=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
			 $row_main[] = $row;	
			}
			return $row_main;
		} else {
			return $row_main;
		}
	}
	
	
	function location_service_hrs_data($lang_id)
	{   $this->db->select('list_id,option_id,title,short_name,language_id');
	    $this->db->where('language_id',$lang_id);
		$this->db->where('list_id','location_service_hrs');
		$this->db->order_by("seq", "asc");
	    $query=$this->db->get('list_options');
		$resultdata = $query->result_array(); 
		$row_main=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
			 $row_main[] = $row;	
			}
			return $row_main;
		} else {
			return $row_main;
		}
	}
	
	
}
?>