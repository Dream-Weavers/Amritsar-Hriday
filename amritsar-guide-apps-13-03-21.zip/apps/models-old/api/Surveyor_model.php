<?php 
class Surveyor_model extends CI_Model
{
	function getRecords($id=NULL)
	{
		   $this->db->select('*');
		   if($id!=''){
			   $this->db->where('user_id', $id);
		   }
		   $query=$this->db->get('survey');
			//echo $this->db->last_query();die;
			$result = $query->result(); 
			return $result;
		   
	} 
	function get_survey_id()
	{   	
		$this->db->select('MAX(survey_number) AS survey_number');
	    $query=$this->db->get('survey');
		$survey_number = $query->row(); 
		if($survey_number->survey_number==''){
			return 1;
		} else {
			return $survey_number->survey_number+1;
		}
		
	}
	
	function insert($surveyData)
	{   	
		try {
			$this->db->trans_start();
			$data        = array(
				'survey_number'     => $surveyData["survey_number"],
				'name'     => $surveyData["customer_name"],
				'gender'   => $surveyData["gender"],
				'age'     => $surveyData["age"],
				'city'     => $surveyData["city"],
				'city2'     => $surveyData["city2"],
				'state'     => $surveyData["state"],
				'address'     => $surveyData["address"],
				'address'     => $surveyData["address"],
				'area'     => $surveyData["area"],
				'staying_amritsar_before_independence'     => $surveyData["staying_amritsar_before_independence"],
				'staying_amritsar_after_independence'     => $surveyData["staying_amritsar_after_independence"],
				'years_staying_in_amritsar_after_independence'     => $surveyData["years_staying_in_amritsar_after_independence"],
				'know_place_not_exists_now'     => $surveyData["know_place_not_exists_now"],
				'place_exact_location'     => $surveyData["place_exact_location"],
				'place_longitude'     => $surveyData["place_longitude"],
				'place_latitude'     => $surveyData["place_latitude"],
				'place_remarks'     => $surveyData["place_remarks"],
				'event_not_exists_now'     => $surveyData["event_not_exists_now"],
				'event_exact_location'     => $surveyData["event_exact_location"],
				'event_longitude'     => $surveyData["event_longitude"],
				'event_latitude'     => $surveyData["event_latitude"],
				'event_remarks'     => $surveyData["event_remarks"],
				'site_alteration'     => $surveyData["site_alteration"],
				'site_exact_location'     => $surveyData["site_exact_location"],
				'site_latitude'     => $surveyData["site_latitude"],
				'site_longitude'     => $surveyData["site_longitude"],
				'site_remarks'     => $surveyData["site_remarks"],
				'remarks'     => $surveyData["remarks"],
				'survey_number'     => '',
				'created_date'      => date('Y-m-d H:i:s')
			);
			$result   = $this->db->insert('survey', $data);
			$id=$this->db->last_query();
			$this->db->trans_complete();
			$db_error = $this->db->error();
			//print '<pre>';print_r($db_error);die;
			$message=array();
			if ($db_error['code']!='0') {
				//print $db_error['message'];die;
				//throw new Exception('Database error! Error Code [' . $db_error['code'] . '] Error: ' . $db_error['message']);
				$message['status']=False;
				$message['message']='Database entity error. Please contact to administrator';
				$message['surveyid']=$id;
				return $message; // unreachable retrun statement !!!
			}
			$message['status']=True;
			$message['message']='Record has been added successfully.';
			$message['surveyid']=$id;
			return $message;
		} catch (Exception $e) {
			// this will not catch DB related errors. But it will include them, because this is more general. 
			//log_message('error: ',$e->getMessage());
			$message['status']=False;
			$message['message']=$e->getMessage();
			$message['surveyid']=NULL;
			return $message;
		}
    } //End of add function	
}
?>