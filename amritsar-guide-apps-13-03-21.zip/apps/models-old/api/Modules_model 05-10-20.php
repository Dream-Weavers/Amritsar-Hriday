<?php 
class Modules_model extends CI_Model
{
	function get_modules($lang_id)
	{   
		$visibility=array('all','app');
		$this->db->select('module_id,module_name,language_id,module_visibility,module_type,module_layout,no_of_records,is_latest');
		$this->db->where_in('module_visibility',$visibility);
		$this->db->where('language_id',$lang_id);
		$this->db->where('module_category_id','1');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('modules');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
				$moduleid=$row['module_id'];
				$module_type=$row['module_type'];
				$is_latest=$row['is_latest'];
				$module_layout=$row['module_layout'];
				if($module_layout=='6'){
					$row['module_name']='';
				}
				//echo "----------->".$module_type;
				  /*if($module_type=='6'){
				  $this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_image,locations.location_name,locations.short_name,locations.short_description,locations.location_id');
					$this->db->join('tour_trails', 'tour_trails.tour_trail_id = tour_trail_locations.tour_trail_id');
					$this->db->join('locations', 'locations.location_id = tour_trail_locations.location_id');
					$this->db->where('tour_trails.predefined','1');
					$this->db->where('tour_trails.is_active','1');
					$this->db->where('locations.is_active','1');
					$this->db->where('tour_trails.language_id',$lang_id);
					$this->db->order_by("tour_trails.tour_trail_name", "asc");
					$query_attr=$this->db->get('tour_trails');
					$module_attributes = $query_attr->result_array(); 
					 echo "----------->". $this->db->last_query();
					 die();*/
					
					/*if($query_attr->num_rows()>0){
						foreach($query_attr->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							$interlink_type=$row_info['interlink_type'];
							if($module_type=='2'){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
									$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type=='3'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().category_icons_path.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type=='1'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().categorytype_icons_path.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type=='4'){
								if($row_info['slide_file_name']!=''){
									$row_info['image_path'] = base_url().slide_image_path.$row_info['slide_file_name'];
								}else{
									$row_info['image_path'] = '';
								}
							}
							$rows[] = $row_info;
						}
					}
					$row['attributes']=$rows;
					$add_custom[]=$row;
					unset($rows);
					
					
						
				}*/
				if($is_latest=='2'){
					if($module_type=='2'){
						$jointable='locations';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
						$this->db->where('locations.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type=='3'){
						$jointable='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->join('categories', 'categories.category_id = module_interlinks.category_id');
						$this->db->where('categories.is_active','1');
						$this->db->where('language_id',$lang_id);
					}else if($module_type=='1'){
						$jointable='categories';
						$this->db->select('category_types.category_type,category_types.category_type_id,category_types.description,category_types.icon');
						$this->db->join('category_types', 'category_types.category_type_id = module_interlinks.category_type_id');
						$this->db->where('category_types.language_id',$lang_id);
						$this->db->where('category_types.is_active','1');
					}else if($module_type=='4'){
						$jointable='categories';
						$this->db->select('slides.slide_title,slides.slide_file_name');
						$this->db->join('slides', 'slides.slide_id = module_interlinks.slide_id');
						$this->db->where('language_id',$lang_id);
						$this->db->where('slides.is_active','1');
					}else{
						$this->db->select('*');
					}
					$this->db->where('module_interlinks.module_id',$moduleid);
					$this->db->order_by("module_interlinks.weight", "asc");
					$query_attr=$this->db->get('module_interlinks');
					$module_attributes = $query_attr->result_array(); 
					//print $this->db->last_query();
					//echo "<br><br>";
					
					if($query_attr->num_rows()>0){
						foreach($query_attr->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							$interlink_type=$row_info['interlink_type'];
							if($module_type=='2'){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
									$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type=='3'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().category_icons_path.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type=='1'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().categorytype_icons_path.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type=='4'){
								if($row_info['slide_file_name']!=''){
									$row_info['image_path'] = base_url().slide_image_path.$row_info['slide_file_name'];
								}else{
									$row_info['image_path'] = '';
								}
							}
							$rows[] = $row_info;
						}
					}
					$row['attributes']=$rows;
					$add_custom[]=$row;
					unset($rows);
				}else if($is_latest=='1'){
					if($module_type=='2'){
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->where('language_id',$lang_id);
						$this->db->where('locations.is_active','1');
					}else if($module_type=='3'){
						$tablename='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->where('language_id',$lang_id);
						$this->db->where('categories.is_active','1');
						$orderby='category_id';
					}else if($module_type=='1'){
						$tablename='category_types';
						$this->db->select('category_types.category_type,category_types.description,category_types.category_type_id,category_types.icon');
						$this->db->where('language_id',$lang_id);
						$this->db->where('category_types.is_active','1');
						$orderby='category_type_id';
					}
					
					$this->db->order_by($orderby, "desc");
					$this->db->limit(10,0);
					$query_latest=$this->db->get($tablename);
					$module_latest = $query_latest->result_array(); 
					if($query_latest->num_rows()>0){
						foreach($query_latest->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							if($module_type=='2'){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
									$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type=='3'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().category_icons_path.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type=='1'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().categorytype_icons_path.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}
							
							$rows[] = $row_info;
						}
					}
					
					
					$row['attributes']=$rows;
					$add_custom[] = $row; 
					unset($rows);
				}
			}
			
			$resultdata=$add_custom;
			unset($add_custom);
			//print '<pre>';print_r($resultdata);die;
			return $resultdata;
		} else {
			return false;
		}
		
	}
	
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		//echo $this->db->last_query();
		return $results;

	} //End of View function
}
?>