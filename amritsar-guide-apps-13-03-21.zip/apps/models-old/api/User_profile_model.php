<?php
class User_profile_model extends CI_Model{
	
	function update_profile($user_id,$profile_fields){
		$data=$profile_fields;
		$this->db->where('user_id',$user_id);
		$this->db->where('user_type','U');
		$result=$this->db->update('users',$data);
		return $result;
	}
	
	function update_address($user_id,$address_field){
		$data=$address_field;
		$this->db->select('*');
		$this->db->from('user_address');
		$this->db->where('user_id',$user_id);
		$this->db->where('language_id',$address_field['language_id']);
		//$result=$this->db->update('user_address',$data);
		$query = $this->db->get();
		//print $query->num_rows();
		if($query->num_rows() > 0)
		{ 
			$this->db->where('user_id',$user_id);
			$result=$this->db->update('user_address',$data);
		}else{
			//print '<pre>';print_r($data);die;
			 $result= $this->db->insert('user_address',$data);
		}
		return $result;
	}
	
	function change_password($user_id,$new_password){
		$salt           = create_salt($password=NULL);
		$password  = $new_password;	
		$data=array('password'=>SHA1($password.$salt),'salt'=>$salt);
		$this->db->where('user_id',$user_id);
		$this->db->where('user_type','U');
		$result=$this->db->update('users',$data);
		return $result;
	}
	
	function verify_old_pwd($user_id,$old_password){
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('user_type','U');
		$this->db->where('user_id', $user_id);
		$this->db->limit(1);
		$query = $this->db->get();
		if($query->num_rows() == 1){
			$row = $query->row();
			if(SHA1($old_password.$row->salt) == $row->password){ 
				return True;
			}else{
				return False;
			}				
		}  
	}
	
	function user_getinfo($user_id){
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('user_type','U');
		$this->db->where('user_id', $user_id);
		$this->db->limit(1);
		$query = $this->db->get();
		$userarr=array();
		if($query->num_rows() == 1){
			$row = $query->row();
			/*if($row->user_photo!=''){
				//$photo=base64_encode(base_url().users_photo_path.$row->user_photo);
				$filename=users_photo_path.$row->user_photo;
				$pathinfo=$this->check_filexists($filename);
				$photo=$pathinfo;
			}else{
				$photo=base_url().'assets/userdefault.png';
			}*/
			
				$photo= $row->user_photo;
			   $resp=$row->response_code;
			
			if($row!='response_code'){    
    			if($row->response_code!=NULL){
    			    $responsedecode=json_decode($row->response_code,true);
    			    if($responsedecode['user_dp']!='')
    			    $photo=$responsedecode['user_dp'];
    			}
			}
		
			if($row!='user_photo'){    
		        if($row->user_photo!=NULL){
			    	$photo=users_photo_path.$row->user_photo;
			    }
			}
			//print $photo;
			$fileexist=$this->check_filexists($photo);
			$photo =$fileexist;
			if($photo=='' || $photo==null){
			    $photo =base_url().'images/male.jpg';
			}
			
			$this->db->select('*');
			$this->db->from('user_address');
			$this->db->where('user_id', $user_id);
			$this->db->limit(1);
			$useraddress = $this->db->get();
			if($useraddress->num_rows() == 1){
				$user_address = $useraddress->row();
				$country_id=$user_address->country_id;
				$state_id=$user_address->state_id;
				$city_id=$user_address->city_id;
				$uaddress=$user_address->address;
				$pin_code=$user_address->pin_code;
				
				$this->db->select('*');
			    $this->db->from('country');
			    $this->db->where('country_id', $country_id);
			    $countryinfo = $this->db->get();
				$cname=$countryinfo->row()->country_name;
				
				$this->db->select('*');
			    $this->db->from('state');
			    $this->db->where('state_id', $state_id);
			    $stateinfo = $this->db->get();
				$sname=$stateinfo->row()->state_name;
				
				$this->db->select('*');
			    $this->db->from('city');
			    $this->db->where('city_id', $city_id);
			    $stateinfo = $this->db->get();
				$ciname=$stateinfo->row()->city_name;
			}else{
				$country_id='';
				$state_id='';
				$city_id='';
				$uaddress='';
				$pin_code='';
				$cname='';
				$sname='';
				$ciname='';
			}
			if($row->last_name!="")
			{
			    $lastname=$row->last_name;
			}else{
		        $lastname='';
			}
			$userarr=array('first_name'=>$row->first_name,
			'last_name'=>$lastname,
			'user_id'=>$row->user_id,
			'gender'=>$row->gender,
			'dob'=>$row->date_of_birth,
			'mobile'=>$row->mobile_no1,
			'email'=>$row->email,
			'user_photo'=>$photo,
			'address'=>$uaddress,
			'state_id'=>$state_id,
			'city_id'=>$city_id,
			'pin_code'=>$pin_code,
			'country_id'=>$country_id,
			'country_name'=>$cname,
			'state_name'=>$sname,
			'city_name'=>$ciname,
			);				
		}
	//	return json_encode($userarr);		
		return $userarr;		
	}
	
	function online_status($user_id,$status){
	    $data=array('user_online_status'=>$status);
		$this->db->where('user_id',$user_id);
		$result=$this->db->update('users',$data);
		return $result;
	}
	
    function user_latlng_status($user_id,$lat,$lng){
        $data=array('latitude'=>$lat,'longitude'=>$lng);
        $this->db->where('user_id',$user_id);
        $result=$this->db->update('users',$data);
        return $result;
    }
    
    function user_profile_image_update($user_id,$filename){
        $data=array('user_photo'=>$filename);
        $this->db->where('user_id',$user_id);
        $result=$this->db->update('users',$data);
        return $result;
    }
    
    function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
            return base_url().'assets/userdefault.png';
             //return false;
             //return '';
        }
	
	}
    
}
?>