<?php

class Login_model extends CI_Model
{
	 function user_login_via_email($user_input,$password){
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('email', $user_input);
		$this->db->where('user_type','U');
		$this->db->limit(1);
		$query = $this -> db -> get();
		//print $this->db->last_query();
		if($query -> num_rows() == 1)
		{
		    
			$row = $query->row();	
			if (SHA1($password.$row->salt) == $row->password)
			{ 
				if($row->is_active=='0')
				{
					return 3;
					exit();
				}
				else{
					return True;
				}
			}  
		}  
		// echo $this->db->last_query();
	 }
	 function user_login_via_mobile($user_input,$password){
		$this->db->select('*');
		$this->db->from('users');
		$this->db->where('user_type','U');
		$this->db->where('mobile_no1', $user_input);
		$this->db->limit(1);
		$query = $this -> db -> get();
		if($query -> num_rows() == 1)
		{
			$row = $query->row();	
			if (SHA1($password.$row->salt) == $row->password)
			{ 
				if($row->is_active=='0')
				{
					return 3;
					exit();
				}
				else{
					return True;
				}
			}  
		}  
		// echo $this->db->last_query();
	 }
}

?>