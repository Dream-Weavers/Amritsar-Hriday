<?php 
class Location_model extends CI_Model
{

	function get_locations_module_Detail($language_id,$location_id){
		
		
		$visibility=array('all','app');
		$this->db->select('module_id,module_name,language_id,module_visibility,module_type,module_layout,no_of_records,is_latest,module_category_id');
		$this->db->where_in('module_visibility',$visibility);
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','3');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('modules');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
				$moduleid=$row['module_id'];
				$module_type=$row['module_type'];
				$is_latest=$row['is_latest'];
				$module_layout=$row['module_layout'];
				if($module_layout==6){
					$row['module_name']='';
				}
				if($is_latest==2){ // If it is custom field configuration
					if($module_type==2){
						$jointable='locations';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
						$this->db->where('locations.is_active','1');
					}else if($module_type==3){
						$jointable='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->join('categories', 'categories.category_id = module_interlinks.category_id');
						$this->db->where('categories.is_active','1');
					}else if($module_type==1){
						$jointable='categories';
						$this->db->select('category_types.category_type,category_types.category_type_id,category_types.description,category_types.icon');
						$this->db->join('category_types', 'category_types.category_type_id = module_interlinks.category_type_id');
						$this->db->where('category_types.is_active','1');
					}else if($module_type==4){
						$jointable='categories';
						$this->db->select('slides.slide_title,slides.slide_file_name');
						$this->db->join('slides', 'slides.slide_id = module_interlinks.slide_id');
						$this->db->where('slides.is_active','1');
					}else if($module_type==4){
						$jointable='locations';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,locations.latitude,locations.longitude');
						$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
						$this->db->where('locations.is_active','1');
					}else{
						$this->db->select('*');
					}
					$this->db->where('module_interlinks.module_id',$moduleid);
					$this->db->order_by("module_interlinks.weight", "asc");
					$query_attr=$this->db->get('module_interlinks');
					$module_attributes = $query_attr->result_array(); 
					if($query_attr->num_rows()>0){
						foreach($query_attr->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							$interlink_type=$row_info['interlink_type'];
							if($module_type==2){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
									$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
								}else{
									$row_info['image_path'] = '';
								}
								/*if($row_info->map_icon!=''){
									$row_info['map_icon_path'] = base_url().'assets/static/locations/icons/'.$row_info->map_icon;
								}else{
									$row_info['map_icon_path'] = '';
								}*/
							}else if($module_type==3){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().'images/category-icons/'.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type==1){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().'images/categorytype-icons/'.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type==4){
								if($row_info['slide_file_name']!=''){
									$row_info['image_path'] = base_url().slide_image.$row_info['slide_file_name'];
								}else{
									$row_info['image_path'] = '';
								}
							}
							$rows[] = $row_info;
						}
					}
					$row['attributes']=$rows;
					$add_custom[]=$row;
					unset($rows);
				}else if($is_latest==1){  // If it is latest field configuration
					if($module_type==2){ 
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->where('locations.is_active','1');
					}else if($module_type==3){
						$tablename='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->where('categories.is_active','1');
						$orderby='category_id';
					}else if($module_type==1){
						$tablename='category_types';
						$this->db->select('category_types.category_type,category_types.description,category_types.category_type_id,category_types.icon');
						$orderby='category_type_id';
						$this->db->where('category_types.is_active','1');
					}else if($module_type==4){
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,locations.latitude,locations.longitude');
						$this->db->where('locations.is_active','1');
					}
					
					$this->db->order_by($orderby, "desc");
					$this->db->limit(10,0);
					$query_latest=$this->db->get($tablename);
					$module_latest = $query_latest->result_array(); 
					if($query_latest->num_rows()>0){
						foreach($query_latest->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							if($module_type==2){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
									$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type==3){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().'images/category-icons/'.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}else if($module_type==1){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().'images/categorytype-icons/'.$row_info['icon'];
								}else{
									$row_info['image_path'] = '';
								}
							}
							
							$rows[] = $row_info;
						}
					}
					
					
					$row['attributes']=$rows;
					$add_custom[] = $row; 
					unset($rows);
				}else if($is_latest==3){ // if is RAW ID from URL
				
					if($module_type==2){  // If it is location type
						
						$listing=$this->get_locations_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type==3){  // If it is category type
						
						$listing=$this->get_category_children_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type==1){  // if it is category type.
						
						$listing=$this->get_categorytype_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type==5){
						$listing=$this->get_locations_map_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					//$row['attributes']=$rows;
					//$add_custom[] = $row; 
					//unset($rows);
				}
			}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	
	
	
	
	
	function get_category_children_content($language_id,$category_id){
		$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
		$this->db->where('is_active','1');
		$this->db->where('category_id',$category_id);
		$this->db->where('language_id',$language_id);
		$result = $this->db->get('categories');
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['category_id'];
				//$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($row_info['icon']!=''){
					$row_info['image_path'] = base_url().'images/category-icons/'.$row_info['icon'];
				}else{
					$row_info['image_path'] = '';
				}
				$rows[] = $row_info;
			}
			$add_custom[] = $rows; 
			unset($rows);
			$resultdata=$add_custom;
			unset($add_custom);
			return $resultdata;
		}else{
			return false;
		}
		
	}
	
	function get_locations_map_content($language_id,$location_id){
		//print 'asdsad';die;
		$this->db->select('locations.location_id,locations.location_name,locations.description,locations.latitude,locations.longitude');
		$this->db->where('locations.language_id',$language_id);
		$this->db->where('locations.location_id',$location_id);
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('locations');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = '';
			}
			$rows[] = $row_info;
		}
		$add_custom[] = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	function get_locations_content($language_id,$location_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.description');
		$this->db->where('locations.language_id',$language_id);
		$this->db->where('locations.location_id',$location_id);
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('locations');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = '';
			}
			$rows[] = $row_info;
		}
		$add_custom[] = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	

	
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
	
	function get_categorytype_content($language_id,$category_id){
		$this->db->where('is_active','1');
		$this->db->where('category_id',$category_id);
		$result = $this->db->get('category_filters')->num_rows();
		$parent_id=$this->get_category_parent($language_id,$category_id);
		if($result>=4){
			$this->db->select('categories.category_id as id,categories.category_name as title ,"filter" as `type`');
			$this->db->join('category_filters', 'category_filters.category_id = categories.category_id');
			$this->db->where('categories.language_id',$language_id);
			$this->db->where('category_filters.is_active','1');
			$this->db->where('categories.is_active','1');
			$this->db->where('categories.category_id',$category_id);
			$this->db->order_by("categories.weight", "asc");
			$query=$this->db->get('categories');
			$listing=$query->result_array();
		}else if($parent_id>0){ 
			
			//$this->db->where('language_id',$language_id);
			$this->db->where('category_id',$parent_id);
			$result_get = $this->db->get('category_filters')->num_rows();
			if($result_get>=4){
				$this->db->select('categories.category_id as id,categories.category_name as title ,"filter" as `type`');
				$this->db->join('category_filters', 'category_filters.category_id = categories.category_id');
				$this->db->where('categories.language_id',$language_id);
				$this->db->where('categories.category_id',$category_id);
				$this->db->where('category_filters.is_active','1');
				$this->db->where('categories.is_active','1');
				$this->db->order_by("categories.weight", "asc");
				$query=$this->db->get('categories');
				$listing=$query->result_array();
			}else{
				$listing=$this->get_category_types($language_id);
			} 
		}else{
			$listing=$this->get_category_types($language_id);
		}
		return $listing;
	}
	
	
	
	
	function get_category_parent($language_id,$category_id){
		
		$this->db->select('*');
		$this->db->where('language_id',$language_id);
		$this->db->where('category_id',$category_id);
		$this->db->where('is_active','1');
		$query = $this->db->get('categories');
		$result=$query->row();
		return $result->category_parent_id;
	}
	
	function get_category_types($language_id){
		$this->db->select('category_types.category_type as title,category_types.category_type_id as id ,"category_type" as `type`');
		$this->db->where('category_types.language_id',$language_id);
		$this->db->where('category_types.is_active','1');
		$query = $this->db->get('category_types');
		$result=$query->result_array();
		return $result;
	}
	
	
		function get_location_detail_content($language_id,$location_id,$needed_fields,$module_type){
		
		$this->db->select($needed_fields);
		$this->db->where('locations.language_id',$language_id);
		$this->db->where('locations.location_id',$location_id);
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('locations');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$rows = array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			if($module_type=='1')
			{
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
					$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
				}else{
					$row_info['image_path'] = '';
				}
			
			 $cityrow = get_table_info('city','city_id',$row_info['city_id']);
			 $staterow = get_table_info('state','state_id',$row_info['state_id']);
			 $countryrow = get_table_info('country','country_id',$staterow->country_id);
			 $row_info['city_name']= $cityrow->city_name;
			 $row_info['state_name']= $staterow->state_name;
			 $row_info['country_name']=$countryrow->country_name;
			}
			if($module_type=='8')
			{
				$working_hours = json_decode($row_info['working_hours'],true);
				if(is_array($working_hours))
				{   $work_hrs_result=array();
					foreach($working_hours as $hrskey=> $hrsval) {
						
						$work_hrs_result[]=$hrsval;
					}
				}
				$row_info['working_hours'] = $work_hrs_result;
			}
			
			$rows = $row_info;
		}
		/*$add_custom[] = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);*/
		return $rows;
	}
	
	function get_location_places_content($language_id,$location_id){
		
		$this->db->select('category_id');
		$this->db->from('location_categories');
		$this->db->where('location_id',$location_id);
		$this->db->where('is_active','1');
		$this->db->group_by('category_id');
		$where_clause = $this->db->get_compiled_select();
		$currentlocid=array('location'=>$location_id);
		$this->db->select('locations.location_name,locations.short_name,locations.location_id,location_categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.is_active','1');
		$this->db->where('locations.language_id',$language_id);
		$this->db->where("`location_categories`.`category_id` IN ($where_clause)", NULL, FALSE);
		$this->db->where_not_in('locations.location_id', $currentlocid);
		$this->db->group_by('locations.location_id');
		$this->db->order_by('locations.location_name','ASC');
		$result = $this->db->get('location_categories');
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
					$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
				}else{
					$row_info['image_path'] = '';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return false;
		}
		
	}
	
	
	function get_location_related_places_content($language_id,$location_id){
		//Get Category Type Id
		$fields = array('location_id'=>$location_id,'is_active'=>'1');
		$cattyperow = gettableinfo('location_categories',$fields);
		$category_type_id = $cattyperow->category_type_id;
		
		//Get Master Category Id
		$fields = array('category_type_id'=>$category_type_id,'category_parent_id'=>'0','is_active'=>'1');
		$catrow = gettableinfo('categories',$fields);
		$category_id = $catrow->category_id;
		
		$currentlocid=array('location'=>$location_id);
		$this->db->select('locations.location_name,locations.short_name,locations.location_id,location_categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('location_categories.category_id',$category_id);
		$this->db->where('locations.language_id',$language_id);
		$this->db->where_not_in('locations.location_id', $currentlocid);
		$this->db->group_by('locations.location_id');
		$this->db->order_by('locations.location_name','ASC');
		$result = $this->db->get('location_categories');
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
					$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
				}else{
					$row_info['image_path'] = '';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return false;
		}
		
	}


 function get_location_nearby_places_content($language_id,$location_id){
		//Get Category Type Id
		$fields = array('location_id'=>$location_id,'is_active'=>'1');
		$cattyperow = gettableinfo('location_categories',$fields);
		$category_type_id = $cattyperow->category_type_id;
		
		//Get Master Category Id
		$fields = array('category_type_id'=>$category_type_id,'category_parent_id'=>'0','is_active'=>'1');
		$catrow = gettableinfo('categories',$fields);
		$category_id = $catrow->category_id;
		
	/*	$fields = array('location_id'=>$location_id,'distance_calculate'=>'0');
		$locrow = gettableinfowithfields('locations',$fields,'distance_calculate');
		if($locrow=='0')
		{
			$fields = array('category_id'=>$category_id);
		    $cat_row = gettableinfowithfields('locations',$fields,'distance_calculate');
			$distance_calculate = $catrow->distance_calculate;
		}
		else
		{	$distance_calculate = $locrow->distance_calculate;
		}
		
		if($distance_calculate!='0')
		$distance_calculate = $distance_calculate;
		else
		$distance_calculate = default_distance_calculate;*/
		
		$currentlocid=array('location'=>$location_id);
		$this->db->select('locations.location_name,locations.short_name,locations.location_id,location_categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('location_categories.category_id',$category_id);
		$this->db->where('locations.language_id',$language_id);
		$this->db->where_not_in('locations.location_id', $currentlocid);
		$this->db->group_by('locations.location_id');
		$this->db->order_by('locations.location_name','ASC');
		$result = $this->db->get('location_categories');
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
					$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
				}else{
					$row_info['image_path'] = '';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return false;
		}
		
		/*$currentlocid=array('location'=>$location_id);
		$this->db->select('locations.location_name,locations.short_name,locations.location_id,location_categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('location_categories.category_id',$category_id);
		$this->db->where('locations.language_id',$language_id);
		$this->db->where_not_in('locations.location_id', $currentlocid);
		$this->db->group_by('locations.location_id');
		$this->db->order_by('locations.location_name','ASC');
		$result = $this->db->get('location_categories');
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
					$row_info['image_path'] = base_url().'assets/static/locations/gallery/'.$getpath->media_file_name;
				}else{
					$row_info['image_path'] = '';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return false;
		}*/

	}	
	
	
	function get_location_facility_content($language_id,$location_id){
		
		$this->db->select('list_options.option_id,list_options.title,location_facilities.language_id,location_facilities.location_id,location_facilities.facility_type');
		$this->db->join('list_options', 'list_options.option_id = location_facilities.facility_type');
		$this->db->where('location_facilities.is_active','1');
		$this->db->where('location_facilities.location_id',$location_id);
		$this->db->where('location_facilities.language_id',$language_id);
		$this->db->where('list_options.list_id','facility_type');
		$this->db->group_by('location_facilities.facility_type');
		$this->db->order_by('list_options.seq','asc');
		$result = $this->db->get('location_facilities');
	
		//echo $this->db->last_query();die;
		$rows = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['location_id'];
				$fields = array('list_id'=>'facility_type','option_id'=>$row_info['facility_type'],'language_id'=>$language_id);
				$listrow = gettableinfo('list_options',$fields);
				if($listrow->icon_name!=''){
					$row_info['icon_path'] = base_url().icon_url.$listrow->icon_name;
				}else{
					$row_info['icon_path'] = '';
				}
				$rows[] = $row_info;
			}
			return $rows;
		}else{
			return $rows;
		}
		
	}
	
	
	function get_location_facility_type($language_id,$location_id,$facility_type)
    {
		$this->db->select('location_id,facility_type,longitude,latitude,photo_name');
		$this->db->from('location_facilities');
		$this->db->where('location_facilities.language_id', $language_id);
		$this->db->where('location_facilities.location_id', $location_id);
		$this->db->where('location_facilities.facility_type', $facility_type);
		$this->db->where('location_facilities.is_active','1');
		$this->db->order_by('location_facilities.created_on', 'ASC');
		$query = $this->db->get();
        $result = $query->result();
       // echo $this->db->last_query();
		return $result;

    } //End of View  function
	
	
	
	function get_location_Details($language_id,$location_id){
		
		$this->db->select('module_layout_id,language_id,module_type,module_layout,module_name,weight');
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','1');
		$this->db->where('is_active','1');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('module_layout');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			//$row = array();
			//$add_custom= array();
			foreach($resultdata as $skey=>$row){
				$moduleid=$row['module_layout_id'];
				$module_type=$row['module_type'];
				$module_layout=$row['module_layout'];
				     $locrow = get_table_info('locations','location_id',$location_id);
					if($module_type=='1'){  // If it is location type
						$needed_fields='locations.location_id,locations.location_name,locations.short_name,locations.short_description,locations.description,locations.city_id,locations.state_id,locations.state_id';
						$listing=$this->get_location_detail_content($language_id,$location_id,$needed_fields,$module_type);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type=='2'){  // If it is Places type
						$listing=$this->get_location_places_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='3'){  // If it is Distances type
						
						 $distancelisting=array();
						 $distance_type_array = get_list_options('distance_type','ASC'); 
						 unset($distance_type_array['']);
                         foreach($distance_type_array as $distancekey=>$disval){
						 if($distancekey== '1')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->airport_distance;
							 $distancelisting['icon_path']= base_url().icon_url.'bus-stop.png';
						  }
						 if($distancekey=='2')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->bus_stand_distance;
							 $distancelisting['icon_path']= base_url().icon_url.'airport.png';
						  }
						  if($distancekey=='3')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->railway_station_distance;
							 $distancelisting['icon_path']= base_url().icon_url.'railway.png';
						  }
						  if($distancekey=='4')
						  {  $distancelisting['title']= $disval;
							 $distancelisting['distance']= $locrow->city_centre_distance;
							 $distancelisting['icon_path']= base_url().icon_url.'shopping-center.png';
						  }
						  $distance_listing[] = $distancelisting;
						
						 }
						 
						$row['attributes']=$distance_listing;
						$add_custom[] = $row; 
						
					}
					elseif($module_type=='4'){  // if it is Location Map.
						
						$needed_fields='locations.location_id,locations.location_name,locations.latitude,locations.longitude';
						$listing=$this->get_location_detail_content($language_id,$location_id,$needed_fields,$module_type);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='5'){  // if it is Surrounded Area
						
						 $listing=array();
						 $area_type_array = get_list_options('area_type','ASC'); 
						 unset($area_type_array['']);
                         foreach($area_type_array as $key=>$val){
						 $fields = array('is_active'=>'1');
						 $area_array = gettabledropdown('areas',$fields,'area_id','area_name','area_name','ASC');
						 unset($area_array['']);
						 if($key=='1')
						  {  $listing['facing']= $val;
						     $listing['facing_title']= $val.' Landmark';
							 $listing['area_name']= $area_array[$locrow->north_area];
						  }
						 if($key=='2')
						  {  $listing['facing']= $val;
						     $listing['facing_title']= $val.' Landmark';
							 $listing['area_name']= $area_array[$locrow->south_area];
						  }
						  if($key=='3')
						  {  $listing['facing']= $val;
						     $listing['facing_title']= $val.' Landmark';
							 $listing['area_name']= $area_array[$locrow->east_area];
						  }
						  if($key=='4')
						  {  $listing['facing']= $val;
						     $listing['facing_title']= $val.' Landmark';
							 $listing['area_name']= $area_array[$locrow->west_area];
						  }
						  $listings[] = $listing;
						
						 }
						 
				    	$row['attributes']=$listings;
						$add_custom[] = $row; 
					}
					elseif($module_type=='6'){  // if it is Facilities
						$listing=$this->get_location_facility_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='7'){  // if it is Rules & Regulations
						$needed_fields='locations.location_id,locations.rules_regulations';
						$listing=$this->get_location_detail_content($language_id,$location_id,$needed_fields,$module_type);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='8'){  // if it is Opening Hours
						$needed_fields='locations.working_hours';
						$listing=$this->get_location_detail_content($language_id,$location_id,$needed_fields,$module_type);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='9'){  // if it is Near By
						$listing=$this->get_location_nearby_places_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='10'){  // if it is Review & Rating
					    $listing=array();
						$listing['rating_score']= '4.1';
						$listing['rating_title']= 'Stars';
						$listing['rating_desciption']= '250 verified reviews & 180 ratings';
						$listing['review_add_text']= 'Write Review';
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='11'){  // if it is Related Places (Location Master Caregory Records Get)
						$listing=$this->get_location_related_places_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
				
				
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
}
?>