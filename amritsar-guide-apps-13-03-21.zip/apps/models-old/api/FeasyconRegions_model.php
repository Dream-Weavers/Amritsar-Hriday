<?php
class FeasyconRegions_model extends CI_Model
{
	
	/*function region_listing()
	{   
	    $this->db->select('*');
	    //$this->db->order_by("region_id", "asc");
		$query=$this->db->get('feasycon_regions');
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
			 $row['soundfile']=base_url().'assets/static/locations/beacons/'.$row['soundfile'];
			   $row_info[] = $row;	
			}
			return $row_info;
		 } else {
			return $row_info;
		 }
	}*/
	
	function region_listing()
	{   
	    //$this->db->select_min('beacon_locations.beacon_location_id');
	    //$this->db->select('beacon_locations.location_id,beacon_locations.beacon_unique_id,beacon_location_actions.beacon_audio_file');
	    //$this->db->order_by("region_id", "asc");
	    //$this->db->join('beacon_location_actions', 'beacon_location_actions.beacon_location_id = beacon_locations1.type_id');
	    //$this->db->group_by("beacon_locations.location_id");
	    $this->db->order_by("beacon_locations1.beacon_auto_id", "asc");
		$query=$this->db->get('beacon_locations1');
		$resultdata = $query->result_array(); 
		//print $this->db->last_query();
		$row_info=array();
		if($query->num_rows()>0){
		    $getID3 = new GetID3;
			foreach($resultdata as $key=>$row){
			   $type=$row['assigned_to']; 
			   if($type=='L'){
			       $id=$row['type_id'];
			       $name=$this->location_info($id);
			   }if($type=='V'){
			       $id=$row['type_id'];
			       $name=$this->vendor_info($id);
			   }
			   $row['region_id']=$id;
			   $row['mac_address']=$row['beacon_unique_id'];
			   $row['region_name']=$name;
			   $beacon_auto_id=$row['beacon_auto_id'];
			   $beacon_auto_soundfile=$this->beacon_initial_sound($beacon_auto_id);
			   $soundfile=$beacon_auto_soundfile[0]['files'];
			   
			   $aud_file = '/home/dsysin607/public_html/codeigniter/hriday/assets/static/locations/beacons/'.$soundfile; //Enter File Name mp3/wav
               // $file_in_seconds=$this->calculateFileSize($aud_file);
			   $ThisFileInfo = $getID3->analyze($aud_file);
			   $row['soundfile']=base_url().'assets/static/locations/beacons/'.$soundfile;
			   $row['audio_duration']=intval($ThisFileInfo['playtime_seconds']);
			   unset($row['beacon_unique_id']);
			   unset($row['beacon_auto_id']);
			   unset($row['type_id']);
			   unset($row['assigned_to']);
			   unset($row['post_date']);
			   unset($row['user_id']);
			 //$row['soundfile']=base_url().'assets/static/locations/beacons/'.$row['soundfile'];
			   $row_info[] = $row;	
			}
			return $row_info;
		 } else {
			return $row_info;
		 }
	}
	
	function calculateFileSize($file){

        $ratio = 16000; //bytespersec
    
        if (!$file) {
    
            exit("Verify file name and it's path");
    
        }
    
        $file_size = filesize($file);
    
        if (!$file_size)
            exit("Verify file, something wrong with your file");
    
        $duration = ($file_size / $ratio);
        $minutes = floor($duration / 60);
        $seconds = $duration - ($minutes * 60);
        $seconds = round($seconds);
        $totalSecs   = ($minutes * 60) + $seconds; 
        return $totalSecs;
    }
	
	
	function location_info($loc_id){
	    $last_row=$this->db->select('*')->where('location_id',$loc_id)->limit(1)->get('locations')->row();
	    return $last_row->location_name;
	}
	function vendor_info($id){
	    $last_row=$this->db->select('*')->where('user_id',$id)->limit(1)->get('users')->row();
	    return $last_row->first_name.' '.$last_row->first_name;
	}
	function beacon_initial_sound($id){
	    $last_row=$this->db->select('*')->where('beacon_auto_id',$id)->limit(1)->get('beacon_location_actions1')->row();
	    return json_decode($last_row->beacon_actions,true);
	}
	
	function region_listing_count()
	{   
	    //$this->db->select('region_id');
		//$query=$this->db->get('feasycon_regions');
		/*$this->db->select_min('beacon_locations.beacon_location_id');
	    $this->db->select('beacon_locations.location_id,beacon_locations.beacon_unique_id,beacon_location_actions.beacon_audio_file');
	    //$this->db->order_by("region_id", "asc");
	    $this->db->join('beacon_location_actions', 'beacon_location_actions.beacon_location_id = beacon_locations.beacon_location_id');
	    $this->db->group_by("beacon_locations.location_id");
	    $this->db->order_by("beacon_locations.beacon_location_id", "asc");
		$query=$this->db->get('beacon_locations');*/
		$this->db->order_by("beacon_locations1.beacon_auto_id", "asc");
		$query=$this->db->get('beacon_locations1');
		$resultdata = $query->result_array(); 
		return $query->num_rows();
		
	}
	function get_version()
	{   
		$last_row=$this->db->select('*')->order_by('app_version_id',"desc")->limit(1)->get('app_version')->row();
		$version_id=$last_row->version_id;
		return $version_id;
	}
}