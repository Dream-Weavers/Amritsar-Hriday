<?php
class Product_model extends CI_Model
{
    function add_blog($post_val){
    	$result=$this->db->insert('blogs',$post_val);
    	//print $this->db->last_query();
    	if($result){
    	    return True;
    	}else{
    	    return False;
    	}
    }
    function getuser_info($user_id){
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('user_id', $user_id);
        //$this->db->where('user_type', 'E');
       // $this->db->limit(1);
        $query = $this -> db -> get();
        return $query->row();
    }
    
    function blog_category($language_id){
         $this->db->select('*');
        $this->db->from('blog_categories');
        $this->db->where('language_id', $language_id);
        $this->db->where('is_active', '1');
        //$this->db->where('user_type', 'E');
       // $this->db->limit(1);
        $query = $this -> db -> get();
        return $query->result_array();
    }
    
    function all_product_details($language_id,$page_no,$limit,$user_id)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('products.product_id,products.product_name,products.product_desc,products.post_date,products.price');
	    //$this->db->join('product_attributes', );
	    //$this->db->join('product_attributes', 'product_attributes.product_id = products.product_id');
   // $this->db->join('product_digital_media', 'product_digital_media.product_id = products.product_id');
	    //$this->db->where('product_digital_media.media_type', 2);
	    //$this->db->where('product_digital_media.default_media', 1);
	     $this->db->where('products.language_id', $language_id);
	    $this->db->order_by("products.product_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('products');
	//print $this->db->last_query();
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $created_date=$row['post_date'];
		    $prod=$row['product_id'];
		    $date=date('d M Y',strtotime($created_date));
		    $where_array=array('product_id'=>$prod,'language_id'=>$language_id,'default_media'=>1);
		    $productinfo=$this->gettableinfowithfields('product_digital_media',$where_array,'media_file_name');
		    //print '<pre>';print_r($productinfo);die;
		   unset($where_array);
			//Get User Photo Path 
			$row['created_date']=$date;
			
		    if($row!='media_file_name'){
				$row['image_url'] = base_url().'assets/products/gallery/'.$productinfo->media_file_name;
			}else{
				 
				  $row['image_url'] = base_url().'assets/image-not-available.jpg';
			    }
				$fileexist=$this->check_filexists($row['image_url']);
				$row['image_url'] =$fileexist;
				$row['photo_icon_text']='Photos';
			  $row['photo_api_url']=base_url()."api/products/getproduct_media_details?language_id=".$language_id."&product_id=".$prod."&media_type=2";
			  //print $user_id;
			  if($user_id>0){
		          $check_fav=$this->check_favt($user_id,$prod,$language_id);
		          $row['favorites']=$check_fav;
		      }else{
		          $row['favorites']=0;
		      }
			  
			   $row_info[] = $row;	
			   
			}
			
			
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
	
	
	
	function all_product_details_count($language_id)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('*');
	    $this->db->where('language_id', $language_id);
	    $this->db->order_by("product_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('products');
		return $query->num_rows();
		
	}
	
	function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'assets/image-not-available.jpg';
        }
       
	}
	
	
	function particular_product_details($language_id,$product_id,$user_id){
		
        $this->db->select('*');
        $this->db->where('product_id', $product_id);
        $this->db->where('language_id', $language_id);
        $query=$this->db->get('products');
        $resultdata = $query->result_array(); 
        $row_info=array();
        $attributes=array();
        if($query->num_rows()>0){
            foreach($resultdata as $row){
		      $row['mobile_no']=$username->mobile_no1;
		      
		      $fields=array('product_id'=>$product_id);
		       //$pro_detail = $this->gettableinfowithfields('product_attributes',$fields,'price');
		       //$row['price']=$pro_detail->price;
		       $getpath=$this->defaultDigitalMedia($product_id,gallery_files,$language_id);
		       //print $getpath->media_file_name;
		       if($getpath!=''){
				    $filename=base_url().'assets/products/gallery/'.$getpath->media_file_name;
				    $pathinfo=$this->check_filexists($filename); 
					$row['image_path'] = $pathinfo;
				}else{
					$row['image_path'] = base_url().'assets/image-not-available.jpg';
				}
		       //$row['image_path']=$this->defaultDigitalMedia($product_id,gallery_files);
		       
		       $rev_Array=array('language_id'=>$language_id,'product_id'=>$product_id);
					    $reviewcount=$this->fetch_reviews_count($rev_Array);
					    $sumrating=$this->sum_rating($language_id,$product_id);
					    if($sumrating==0){
					        $avg_rating=0;
					    }else{
					        $avg_rating=$sumrating/$reviewcount;
					    }
					    $avgrating=number_format((float)$avg_rating, 1, '.', '');
						/*$listing['rating_score']= $avgrating;
						$listing['rating_title']= 'Stars';
						$listing['rating_desciption']= $reviewcount.' verified reviews & ratings';
						$listing['review_add_text']= 'Write Review';
						$row['rating'][]=$listing;*/
						$row['rating']=$avgrating;
						$row['counter']=$reviewcount;
						$row['photo_icon_text']='Photos';
			  //$row['photo_api_url']=base_url()."api/products/getproduct_media_details?language_id=".$language_id."&product_id=".$product_id."&media_type=2";
			  $row['photo_api_url']=$this->DigitalMediaContent($product_id,2,$language_id);
						//$add_custom[] = $row; 
		      // $row['attributes'][]=$this->particular_product_details(1,3);
		      
		      if($user_id>0){
		          $check_fav=$this->check_favt($user_id,$product_id,$language_id);
		          $row['favorites']=$check_fav;
		      }else{
		          $row['favorites']=0;
		      }
		     $add_custom = $row; 
            }
            $add_custom['related_product']=$this->related_products($language_id,$product_id,$user_id);
           // $row['attributes'][]=$this->particular_product_details(1,2);
            // $add_custom[] = $row; 
            return array($add_custom);
        }
	}
	
	function related_products($language_id,$product_id,$user_id){
	    $this->db->select('*');
        //$this->db->where('product_id', $product_id);
        $this->db->where_not_in('product_id', $product_id);
        $this->db->where('language_id', $language_id);
        $query=$this->db->get('products');
        $resultdata = $query->result_array(); 
        $row_info=array();
        $attributes=array();
        if($query->num_rows()>0){
            foreach($resultdata as $row){
                $vendor_id=$row['vendor_id'];
                $prod=$row['product_id'];
                 $fields=array('user_id'=>$vendor_id);
		    $username = $this->gettableinfowithfields('users',$fields,'first_name,last_name,user_photo,mobile_no1');
		     $row['username']=$username->first_name.' '.$username->last_name;
		      $vendor_detail = $this->gettableinfowithfields('vendor_details',$fields,'shop_title,shop_address,latitude,longitude');
		      $row['shop_title']=$vendor_detail->shop_title;
		      $row['latitude']=$vendor_detail->latitude;
		      $row['longitude']=$vendor_detail->longitude;
		      $row['shop_address']=$vendor_detail->shop_address;
		      $row['mobile_no']=$username->mobile_no1;
		      $fields=array('product_id'=>$prod);
		       $pro_detail = $this->gettableinfowithfields('product_attributes',$fields,'price');
		       $row['price']=$pro_detail->price;
		       //print gallery_files;
		       $getpath=$this->defaultDigitalMedia($prod,gallery_files,$language_id);
		       //print '<pre>';print_r($getpath);print '</pre>';
		       if($getpath!=''){
				    $filename=base_url().'assets/products/gallery/'.$getpath->media_file_name;
				    $pathinfo=$this->check_filexists($filename); 
					$row['image_path'] = $pathinfo;
				}else{
					$row['image_path'] = base_url().'assets/image-not-available.jpg';
				}
		       //$row['image_path']=$this->defaultDigitalMedia($product_id,gallery_files);
		       $rev_Array=array('language_id'=>$language_id,'product_id'=>$prod);
					    $reviewcount=$this->fetch_reviews_count($rev_Array);
					    $sumrating=$this->sum_rating($language_id,$prod);
					    if($sumrating==0){
					        $avg_rating=0;
					    }else{
					        $avg_rating=$sumrating/$reviewcount;
					    }
					    $avgrating=number_format((float)$avg_rating, 1, '.', '');
						/*$listing['rating_score']= $avgrating;
						$listing['rating_title']= 'Stars';
						$listing['rating_desciption']= $reviewcount.' verified reviews & ratings';
						$listing['review_add_text']= 'Write Review';
						$row['rating'][]=$listing;*/
						$row['rating']=$avgrating;
						$row['counter']=$reviewcount;
		       
		            $row['photo_icon_text']='Photos';
			  //$row['photo_api_url']=base_url()."api/products/getproduct_media_details?language_id=".$language_id."&product_id=".$prod."&media_type=2";
			  $row['photo_api_url']=$this->DigitalMediaContent($prod,2);
		      // $row['attributes'][]=$this->particular_product_details(1,3);
		      if($user_id>0){
		          $check_fav=$this->check_favt($user_id,$prod,$language_id);
		          $row['favorites']=$check_fav;
		      }else{
		          $row['favorites']=0;
		      }
		     $add_custom[] = $row; 
            }
           // $row['attributes'][]=$this->particular_product_details(1,2);
            // $add_custom[] = $row; 
            return $add_custom;
        }
	}
	
	function DigitalMediaContent($product_id,$media_type,$language_id)
    {
		$this->db->select('media_file_name,media_type,default_media');
		$this->db->from('product_digital_media');
		$this->db->where('product_digital_media.product_id', $product_id);
		$this->db->where('product_digital_media.language_id', $language_id);
		$this->db->where('product_digital_media.media_type', $media_type);
		$this->db->order_by('product_digital_media.default_media', 'DESC');
		//$this->db->order_by('product_digital_media.weight', 'ASC');
		$query = $this->db->get();
		//print $this->db->last_query();die;
		$mediaresult=$query->result_array();
		$rows =array();
		foreach($mediaresult as $row_info)
		{
			if($media_type==gallery_files)
			{	
			if($row_info['media_file_name']!=''){
					$row_info['media_url'] = base_url()."assets/products/gallery/".$row_info['media_file_name'];
				}else{
					$row_info['media_url'] = '';
				}
				$row_info['media_text'] = 'Photos';
			}
			elseif($media_type==video_files)
			{	
			    $row_info['media_url'] = $row_info['media_file_name'];
				$row_info['media_text'] = 'Video';
			}
			elseif($media_type==vr_files)
			{	if($row_info['media_file_name']!=''){
					$row_info['media_url'] = base_url().location_path.'vr/'.$row_info['media_file_name'];
				}else{
					$row_info['media_url'] = '';
				}
				$row_info['media_text'] = 'VR';
			}
			elseif($media_type==video360_files)
			{	if($row_info['media_file_name']!=''){
					$row_info['media_url'] = base_url().location_path.'vr/'.$row_info['media_file_name'];
				}else{
					$row_info['media_url'] = '';
				}
				$row_info['media_text'] = '360 View';
			}
			
			else
			{  $row_info['media_url'] = $row_info['media_file_name'];
			   $row_info['media_text'] = 'Other';
			}
			
			$rows[] = $row_info;
		}
		return $rows;
	
	} //End of View function
	
	function gettableinfowithfields($table,$fields,$needed_fields)
    {   //echo $needed_fields;die;

        $this->db->select($needed_fields);
		if(is_array($fields)){
	     foreach($fields as $keys => $values) {
			 $this->db->where($keys, $values);
			 }         
	   }
        $this->db->from($table);
        $query = $this->db->get();
	//	echo $this->db->last_query();die;
        if($query -> num_rows() == 0)
			{		return '0';
			}
			else
			{		return $query->row();
			}

    }
    
    function defaultDigitalMedia($product_id,$media_type,$language_id)
    {
		$this->db->select('media_file_name');
		$this->db->from('product_digital_media');
		$this->db->where('product_digital_media.product_id', $product_id);
		$this->db->where('product_digital_media.media_type', $media_type);
		$this->db->where('product_digital_media.language_id', $language_id);
		$this->db->where('product_digital_media.default_media','1');
		$this->db->order_by('product_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		//print $this->db->last_query();
		$results = $query->row();
		return $results;

	}
	
	
	function fetch_reviews_count($post_val){
        $this->db->select('*');
	    $this->db->where('language_id', $post_val['language_id']);
	    $this->db->where('product_id', $post_val['product_id']);
	    $this->db->order_by("product_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('product_reviews');
		//print $this->db->last_query();
		return $query->num_rows();
    }
    
    function sum_rating($lang,$locid){
        $this->db->select_sum('rating');
         $this->db->where('language_id', $lang);
	    $this->db->where('product_id', $locid);
        $this->db->from('product_reviews');
        $query=$this->db->get();
        //print $this->db->last_query();
        $result= $query->result_array();
        return $result[0]['rating'];
    }
	
	
	function add_reviews($postval){
        $result=$this->db->insert('product_reviews',$postval);
    	//print $this->db->last_query();die;
    	if($result){
    	    return True;
    	}else{
    	    return False;
    	}
    }
    

    
    function fetch_reviews($post_val,$page_no,$limit){
        $offset=($page_no*$limit)-$limit;
        $this->db->select('*');
	    $this->db->where('language_id', $post_val['language_id']);
	    $this->db->where('product_id', $post_val['product_id']);
	    $this->db->order_by("pro_review_id", "desc");
	    $this->db->limit($limit, $offset);
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('product_reviews');
		foreach($query->result_array() as $rowval){
		    $userid=$rowval['user_id'];
		    $postdate=$rowval['postdate'];
		    $fields=array('user_id'=>$userid);
		    $username = $this->gettableinfowithfields('users',$fields,'first_name,last_name,user_photo');
		    $rowval['username']=$username->first_name.' '.$username->last_name;
		    $filename=base_url().'assets/static/user_photos/original/'.$username->user_photo;
		    if($username->user_photo!=''){
		        $pathinfo=$this->check_filexists($filename);
		        $rowval['user_image']=$pathinfo;
		    }else{
		        $rowval['user_image']='';
		    }
		    
		    $datetime=date('d M Y',strtotime($postdate));
		    $dateago=$this->time_elapsed_string($datetime);
		    $rowval['datetime']=$dateago;
		   // $rowval['datetime']=date('d M Y',strtotime($postdate));
		    $add_custom[] = $rowval; 
		}
		$result=$add_custom;
		unset($add_custom);
	//	print $this->db->last_query();
		return $result;
    }
    
    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);
    
        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;
    
        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }
    
        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
    
    function ratingcount($product_id,$language_id,$counter){
    
        $this->db->select('*');
        $this->db->where('language_id', $language_id);
	    $this->db->where('product_id', $product_id);
	    $this->db->where('rating', $counter);
        $this->db->from('product_reviews');
        $query=$this->db->get();
        //print $this->db->last_query();
        $result= $query->num_rows();
        return $result;
    
    }
    
     
    function get_product_media_Details($language_id,$product_id,$media_type){
		  $resultmedia = $this->DigitalMediaContent($product_id,$media_type,$language_id);
		
		  return $resultmedia;
	}
	
	function add_as_favt($postval){
        $result=$this->db->insert('user_favorites_products',$postval);
    	//print $this->db->last_query();die;
    	if($result){
    	    return True;
    	}else{
    	    return False;
    	}
    }
    
    function check_favt($user_id,$product_id,$lang_id){
        $this->db->select('*');
        $this->db->where('language_id', $lang_id);
	    $this->db->where('product_id', $product_id);
	    $this->db->where('user_id', $user_id);
        $this->db->from('user_favorites_products');
        $query=$this->db->get();
       //print $this->db->last_query();
        $result= $query->num_rows();
        if($result>0){
            return "1";
        }else{
            return "0";
        }
       // return $result;
    }
    
    function deleteuser_favt($user_id,$product_id,$lang_id){
        $tables = array('user_favorites_products');
        $this->db->where('language_id', $lang_id);
        $this->db->where('product_id', $product_id);
        $this->db->where('user_id', $user_id);
        $this->db->delete($tables);
        //print $this->db->last_query();
        return true;
    }
    
    
    function all_product_details_favt($language_id,$page_no,$limit,$user_id)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('products.product_id,products.product_name,products.product_desc,products.post_date,products.price');
	    //$this->db->join('product_attributes', );
	    //$this->db->join('product_attributes', 'product_attributes.product_id = products.product_id');
        $this->db->join('user_favorites_products', 'user_favorites_products.product_id = products.product_id');
	    //$this->db->where('product_digital_media.media_type', 2);
	    $this->db->where('user_favorites_products.user_id', $user_id);
	     $this->db->where('products.language_id', $language_id);
	    $this->db->order_by("products.product_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('products');
	//print $this->db->last_query();
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $created_date=$row['post_date'];
		    $prod=$row['product_id'];
		    $date=date('d M Y',strtotime($created_date));
		    $where_array=array('product_id'=>$prod,'language_id'=>$language_id,'default_media'=>1);
		    $productinfo=$this->gettableinfowithfields('product_digital_media',$where_array,'media_file_name');
		    //print '<pre>';print_r($productinfo);die;
		   unset($where_array);
			//Get User Photo Path 
			$row['created_date']=$date;
			
		    if($row!='media_file_name'){
				$row['image_url'] = base_url().'assets/products/gallery/'.$productinfo->media_file_name;
			}else{
				 
				  $row['image_url'] = base_url().'assets/image-not-available.jpg';
			    }
				$fileexist=$this->check_filexists($row['image_url']);
				$row['image_url'] =$fileexist;
				$row['photo_icon_text']='Photos';
			  $row['photo_api_url']=base_url()."api/products/getproduct_media_details?language_id=".$language_id."&product_id=".$prod."&media_type=2";
			  //print $user_id;
			  if($user_id>0){
		          $check_fav=$this->check_favt($user_id,$prod,$language_id);
		          $row['favorites']=$check_fav;
		      }else{
		          $row['favorites']=0;
		      }
			  
			   $row_info[] = $row;	
			   
			}
			
			
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
	
	
	
	function all_product_details_favt_count($language_id,$user_id)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('*');
	    $this->db->where('products.language_id', $language_id);
	    $this->db->join('user_favorites_products', 'user_favorites_products.product_id = products.product_id');
	    $this->db->where('user_favorites_products.user_id', $user_id);
	    $this->db->order_by("products.product_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('products');
		//print $this->db->last_query();
		return $query->num_rows();
		
	}
    
    
}