<?php
class Favorites_locations_model extends CI_Model{
	
   function defaultDigitalMedia($location_id,$media_type)
	{
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;
		
	}
	

  function insert_favorite_location($language_id,$user_id,$location_id){
		$this->db->select('favorite_location_id');
		$this->db->where('language_id',$language_id);
		$this->db->where('user_id',$user_id);
		$this->db->where('location_id',$location_id);
		$query = $this->db->get('user_favorites_locations');
		//echo "-------->".$this->db->last_query();
		if($query->num_rows() > 0 ){
		 return '2';
		 exit();
		}else
		{
			 $favorite_data=array(
			'language_id'=>$language_id,
			'user_id'=>$user_id,
			'location_id'=>$location_id,
			'created_on'=>date('Y-m-d H:i:s')
		   );
		  $result=$this->db->insert('user_favorites_locations',$favorite_data);
		  return $result;
		  exit();
		}
	
	 
	}
	
 	
	function remove_favorite_location($language_id,$favorite_location_id,$location_id,$user_id){
		$this->db->select('favorite_location_id');
		$this->db->where('language_id',$language_id);
		$this->db->where('user_id',$user_id);
		$this->db->where('location_id',$location_id);
		$this->db->where('favorite_location_id',$favorite_location_id);
	    $query = $this->db->get('user_favorites_locations');
	    //echo "-------->".$this->db->last_query();
		//echo "-------->num_rows".$query->num_rows();
		///die();
	   if($query->num_rows() > 0 ){
		  $this->db->where('language_id',$language_id);
	 	  $this->db->where('user_id',$user_id);
		  $this->db->where('location_id',$location_id);
		  $this->db->where('favorite_location_id',$favorite_location_id);
		  $deleteresult = $this->db->delete('user_favorites_locations');
		  return $deleteresult;
	   }
	   else
	   {  return false;
	   }
	}
		
	function user_favorite_locations($user_id,$language_id){
		$this->db->select('category_types.category_type,category_types.category_type_id');
		$this->db->join('category_types', 'category_types.category_type_id = location_categories.category_type_id');
		$this->db->join('user_favorites_locations', 'user_favorites_locations.location_id = location_categories.location_id');
		$this->db->where('user_favorites_locations.is_active','1');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('user_favorites_locations.language_id',$language_id);
		$this->db->where('user_favorites_locations.user_id',$user_id);
		$this->db->order_by('category_types.weight', 'ASC');
		$this->db->group_by('category_types.category_type_id');
		$query = $this->db->get('location_categories');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query().'dgdfgd';
		//print $query->num_rows();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $category_type_id = $row['category_type_id'];
				
						$listing=$this->get_user_categorytype_favorite_locations($language_id,$category_type_id,$user_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	
	function share_favorite_locations($language_id,$locationids){
		$this->db->select('category_types.category_type,category_types.category_type_id');
		$this->db->join('category_types', 'category_types.category_type_id = location_categories.category_type_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('category_types.language_id',$language_id);
		$this->db->where_in('location_categories.location_id',$locationids);
		$this->db->order_by('category_types.weight', 'ASC');
		$this->db->group_by('category_types.category_type_id');
		$query = $this->db->get('location_categories');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query().'dgdfgd';
		//die();
		//print $query->num_rows();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $category_type_id = $row['category_type_id'];
				
						$listing=$this->get_user_categorytype_locations($language_id,$category_type_id,$locationids);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function share_favorite_locations_old($user_id,$language_id,$cat_type){
	    //print $cat_type;
		$this->db->select('category_types.category_type,category_types.category_type_id');
		$this->db->join('category_types', 'category_types.category_type_id = location_categories.category_type_id');
		$this->db->join('user_favorites_locations', 'user_favorites_locations.location_id = location_categories.location_id');
		$this->db->where('user_favorites_locations.is_active','1');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('user_favorites_locations.language_id',$language_id);
		$this->db->where('user_favorites_locations.user_id',$user_id);
		$this->db->where_in('category_types.category_type_id',$cat_type);
		$this->db->order_by('category_types.weight', 'ASC');
		$this->db->group_by('category_types.category_type_id');
		$query = $this->db->get('location_categories');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query();
		//print $query->num_rows();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $category_type_id = $row['category_type_id'];
				
						$listing=$this->get_user_categorytype_favorite_locations($language_id,$category_type_id,$user_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	
	
	function get_user_categorytype_favorite_locations($language_id,$category_type_id,$user_id){
		
		$this->db->select('user_favorites_locations.favorite_location_id,locations.location_id,locations.location_name,locations.short_description as description,locations.latitude,locations.longitude');
		$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->join('user_favorites_locations', 'user_favorites_locations.location_id = locations.location_id');
		$this->db->where('categories.language_id',$language_id);
		$this->db->where('user_favorites_locations.user_id',$user_id);
		$this->db->where('location_categories.category_type_id',$category_type_id);
		$this->db->where('location_categories.is_active','1');
		$query=$this->db->get('categories');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = '';
			}
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	
	function get_user_categorytype_locations($language_id,$category_type_id,$locationids){
		
		$this->db->select('locations.location_id,locations.location_name,locations.short_description as description,locations.latitude,locations.longitude');
		$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('categories.language_id',$language_id);
		$this->db->where('location_categories.category_type_id',$category_type_id);
		$this->db->where_in('locations.location_id',$locationids);
		$this->db->where('location_categories.is_active','1');
		$query=$this->db->get('categories');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$resultdata=array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = '';
			}
			$resultdata[] = $row_info;
		}
		
		return $resultdata;
	}
	
	
}
?>