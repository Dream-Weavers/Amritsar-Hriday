<?php
class Pinme_locations_model extends CI_Model{
	
	
  function insert_pinme_location($pinme_data){
	 	$result=$this->db->insert('user_pinme_locations',$pinme_data);
		$pinme_location_id = $this->db->insert_id();
		return $pinme_location_id;
	}
	
	 function update_pinme_tagimage($pinme_location_id,$user_id,$fname){
	   $pinmeimage_data=array(
		'tag_image'=>$fname
		);
		$this->db->where('pinme_location_id',$pinme_location_id);
		$this->db->where('user_id',$user_id);
		$updateresult=$this->db->update('user_pinme_locations',$pinmeimage_data);
		return $updateresult;
	}
	
   function update_pinme_location($pinme_location_id,$user_id,$pinme_data){
	    $this->db->where('pinme_location_id',$pinme_location_id);
		$this->db->where('user_id',$user_id);
	 	$updateresult=$this->db->update('user_pinme_locations',$pinme_data);
		return $updateresult;
	}
	
	function delete_pinme_location($language_id,$user_id,$pinme_location_id){
		$this->db->select('pinme_location_id');
		$this->db->where('pinme_location_id',$pinme_location_id);
		$this->db->where('user_id',$user_id);
		$this->db->where('language_id',$language_id);
		$query = $this->db->get('user_pinme_locations');
	   if($query->num_rows() > 0 ){
		  $this->db->where('pinme_location_id',$pinme_location_id); 
		  $this->db->where('user_id',$user_id); 
		  $this->db->where('language_id',$language_id); 
		  $deleteresult = $this->db->delete('user_pinme_locations');
		  return $deleteresult;
	   }
	   else
	   {  return '0';
	   }
	   
	}
		
	function user_pinme_location_details($user_id,$language_id){
		$this->db->select('*');
		$this->db->where('user_id',$user_id);
		$this->db->where('language_id',$language_id);
	    $query = $this->db->get('user_pinme_locations');
		$resultdata = $query->result_array(); 
		$row_main=array();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				if($row['tag_image']!=''){
				$row['image_path'] = base_url().'assets/users/'.$user_id.'/pinme/'.$row['tag_image'];
			    }else{
				$row['image_path'] = base_url().'assets/image-not-available.jpg';
			     }
			
				$row_main[] = $row;	    
				}
			return $row_main;
		}  else {
			return $row_main;
		      }
	}
		
	
}
?>