<?php
class Forgot_password_model extends CI_Model{
	function email_validate($user_input=NULL)
	{
		   $this->db->select('*');
		   if($user_input!=''){
			   $this->db->where('email', $user_input);
		   }
		   $this->db->where('user_type', 'U');
		   $query=$this->db->get('users');
			//echo $this->db->last_query();die;
			$result = $query->num_rows(); 
			return $result;
	}
	function mobile_validate($user_input=NULL)
	{
		   $this->db->select('*');
		   if($user_input!=''){
			   $this->db->where('mobile_no1', $user_input);
		   }
		   $this->db->where('user_type', 'U');
		   $query=$this->db->get('users');
			//echo $this->db->last_query();die;
			$result = $query->num_rows(); 
			return $result;
	} 
	
	function otp_log($userinput,$otp){
		$data        = array(
			'otp'     => $otp,
			'user_input'     => $userinput,
			'otp_type'     => 2,
		);
		$result   = $this->db->insert('user_otp', $data);
		return $result;
	}
	
	function match_user_otp($user_input,$otp){
		$this->db->select('*');
		$this->db->where('user_input', $user_input);
		$this->db->where('otp', $otp);
		$this->db->where('otp_type',2);
		$this->db->where('otp_status', 0);
		$this->db->order_by('otp_no', 'DESC');
		$this->db->limit('1');
		$query=$this->db->get('user_otp');
		$result = $query->num_rows(); 
		return $result;
	}
	
	
	function update_user_otp_log($user_input,$otp){
		date_default_timezone_set("Asia/Calcutta"); 
		$data=array('otp_implement_time'=>date('Y-m-d H:i:s'),'otp_status'=>1);
		$this->db->where('user_input',$user_input);
		$this->db->where('otp',$otp);
		$result=$this->db->update('user_otp',$data);
		return $result;
	}
	
	function change_password($user_id,$new_password){
		$salt           = create_salt($password=NULL);
		$password  = $new_password;	
		$data=array('password'=>SHA1($password.$salt),'salt'=>$salt);
		$this->db->where('user_id',$user_id);
		$this->db->where('user_type','U');
		$result=$this->db->update('users',$data);
		return $result;
	}
	
}