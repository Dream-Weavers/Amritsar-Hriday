<?php
class Popular_search_model extends CI_Model
{
	function get_locations($language_id){
		$this->db->select('locations.*');
		$this->db->join('locations', 'locations.location_id = popular_search.location_id');
		$this->db->where('locations.is_active','1');
		$this->db->where('language_id',$language_id);
		$query_attr=$this->db->get('popular_search');
		//print $this->db->last_query();die;
		$forget=$query_attr->result();
		$moduleinfo=array();
		$getname=array();
		foreach($forget as $row){
			$location_name=$row->location_name;
			$short_name=$row->short_name;
			$short_description=$row->short_description;
			$location_id=$row->location_id;
			$image_path=$row->image_path;
			$getpath=$this->defaultDigitalMedia($location_id,gallery_files);
			if($getpath!=''){
					$getimgpath = base_url().gallery_path.$getpath->media_file_name;
				}else{
					$getimgpath =base_url().'assets/image-not-available.jpg';
				}
			$getname=array('location_name'=>$location_name,'short_name'=>$short_name,'short_description'=>$short_description,'location_id'=>$location_id,'image_path'=>$getimgpath);
			$moduleinfo[]=$getname;
		}
		return $moduleinfo; 
	}
	
	
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
	
}
?>