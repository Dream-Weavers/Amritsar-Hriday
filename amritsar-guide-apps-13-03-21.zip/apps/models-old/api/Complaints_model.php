<?php
class Complaints_model extends CI_Model{
	
  function insert_complaint($complaint_data){
	  	 $result=$this->db->insert('complaints',$complaint_data);
		 $complaint_id = $this->db->insert_id();
		return $complaint_id;
	}
	
	
  function insert_feedback($feedback_data){
	  	 $result=$this->db->insert('complaints',$feedback_data);
		 $complaint_id = $this->db->insert_id();
		return $complaint_id;
	}	
	

  function update_complaint_image1($complaint_id,$user_id,$image_data){
	    $this->db->where('complaint_id',$complaint_id);
		$this->db->where('post_user_id',$user_id);
		$updateresult=$this->db->update('complaints',$image_data);
		return $updateresult;
	}
	
	function update_complaint_image($complaint_id,$user_id,$image_data){
	    $this->db->where('complaint_id',$complaint_id);
		$this->db->where('post_user_id',$user_id);
		$updateresult=$this->db->update('complaints',$image_data);
		return true;
	}
	
	function complaint_data($complaint_id){
		$this->db->select('*');
		$this->db->from('complaints');
		$this->db->where('complaints.complaint_id', $complaint_id);
		$query = $this->db->get();
		$results = $query->row();
		$moduleinfo=array();
		$getname=array('complaint_id'=>$complaint_id,'complaint_title'=>$results->complaint_title,'complaint_description'=>$results->complaint_description,'language_id'=>$results->language_id,'image_file'=>live_complaint_image.''.$results->image_file,'audio_file'=>live_complaint_audio.''.$results->audio_file,'video_file'=>live_complaint_video.''.$results->video_file);
		$moduleinfo=$getname;
		return array($moduleinfo);
	}	
	
	
}
?>