<?php
// Load the Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

//use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

class Pinme_locations extends REST_Controller {

    public function __construct() {
       parent::__construct();
       $this->load->model('api/Pinme_locations_model');
	   $this->load->helper(['jwt', 'authorization']);  
    }
	
	
	private function verify_request(){
    // Get all the headers
    $headers = $this->input->request_headers();
    // Extract the token
	//print '<pre>';print_r($headers);die;
    $token = $headers['Authorization'];
    // Use try-catch
    // JWT library throws exception if the token is not valid
    try {
        // Validate the token
        // Successfull validation will return the decoded user data else returns false
        $data = AUTHORIZATION::validateToken($token);
        if ($data === false) {
            $status = parent::HTTP_UNAUTHORIZED;
            $response = ['status' => $status, 'msg' => 'Unauthorized Access!'];
            $this->response($response, $status);
            exit();
        } else {
            return $data;
        }
    } catch (Exception $e) {
        // Token is invalid
        // Send the unathorized access message
        $status = parent::HTTP_UNAUTHORIZED;
        $response = ['status' => $status, 'msg' => 'Unauthorized Access! '];
        $this->response($response, $status);
    }
}

  	public function user_pinme_location_details_post(){
		$data = $this->verify_request();
		//print '<pre>';print_r($data);die;
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$language_id = $this->post('language_id');
			$user_tour_trails_result = $this->Pinme_locations_model->user_pinme_location_details($user_id,$language_id);
			if($user_tour_trails_result){
				$status = parent::HTTP_OK;
				 $response = ['status' => $status,
				 'message' => 'User Pinme Location Details',
				 'data' => $user_tour_trails_result];
				$this->response($response, $status);
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
				$this->response($response, $status);
			}				
		}
		
	}
	
	public function add_pinme_location_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
		    $language_id = $this->post('language_id');
			$longitude  = $this->post('longitude');
			$latitude = $this->post('latitude');
			$tag_name = $this->post('tag_name');
			$description = $this->post('description');
			//$tag_photo = base64_decode($this->post('tag_photo'));
			$tag_photo = '';
			
			$pinme_data=array('language_id'=>$language_id,'user_id'=>$user_id,'longitude'=>$longitude,'latitude'=>$latitude,'tag_name'=>$tag_name,'description'=>$description,'tag_photo'=>$tag_photo,'created_on'=>date('Y-m-d H:i:s'));
			$pinmeresult = $this->Pinme_locations_model->insert_pinme_location($pinme_data);
			if($pinmeresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data inserted successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function edit_pinme_location_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$pinme_location_id = $this->post('pinme_location_id');
			$language_id = $this->post('language_id');
			$tag_name = $this->post('tag_name');
			$description = $this->post('description');
			//$tag_photo = base64_decode($this->post('tag_photo'));
			$tag_photo = '';
			
			$pinme_data=array('pinme_location_id'=>$pinme_location_id,'language_id'=>$language_id,'tag_name'=>$tag_name,'description'=>$description,'tag_photo'=>$tag_photo,'created_on'=>date('Y-m-d H:i:s'));
			$updatepinmeresult = $this->Pinme_locations_model->update_pinme_location($pinme_location_id,$user_id,$pinme_data);
			if($updatepinmeresult==TRUE){
			$status = parent::HTTP_OK;
			$response = ['status' => $status, 'data' => 'Data updated successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}
	
	public function delete_pinme_location_post()
	{
		// Call the verification method and store the return value in the variable
		$data = $this->verify_request();
		// Send the return data as reponse
		if($data==TRUE){
			$user_input=$data->user_input;
			if (filter_var($user_input, FILTER_VALIDATE_EMAIL)) {
				$fildarr=array('email'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}else{
				$fildarr=array('mobile_no1'=>$user_input,'user_type'=>'U');
				$getuser_arr=gettableinfo('users',$fildarr);
				$user_id=$getuser_arr->user_id;
			}
			$pinme_location_id = $this->post('pinme_location_id');
			$language_id = $this->post('language_id');
			
			$deletepinmelocationresult = $this->Pinme_locations_model->delete_pinme_location($language_id,$user_id,$pinme_location_id);
			if($deletepinmelocationresult==TRUE){
				$status = parent::HTTP_OK;
				$response = ['status' => $status, 'data' => 'Data Deleted successfully.'];
			}else{
				$status = parent::HTTP_UNAUTHORIZED;
				$response = ['status' => $status, 'msg' => 'Error'];
			} 
			$this->response($response, $status);
		}
	}


}