<?php
class Common_model extends CI_Model{
	function country_list($language_id){
		$this->db->select('*');
		$this->db->from('country');
		$this->db->where('language_id',$language_id);
		$this->db->where('is_active','1');
		$query = $this->db->get();
		return $result=$query->result(); 
	}
	
	function state_list($language_id,$country_id){
		$this->db->select('*');
		$this->db->from('state');
		$this->db->where('language_id',$language_id);
		$this->db->where('country_id',$country_id);
		$this->db->where('is_active','1');
		$query = $this->db->get();
		return $result=$query->result(); 
	}
	
	function city_list($language_id,$state_id){
		$this->db->select('*');
		$this->db->from('city');
		$this->db->where('language_id',$language_id);
		$this->db->where('state_id',$state_id);
		$this->db->where('is_active','1');
		$query = $this->db->get();
		return $result=$query->result(); 
	}
	
	function department_list($language_id){
		$this->db->select('*');
		$this->db->from('department');
		$this->db->where('language_id',$language_id);
		$this->db->where('is_active','1');
		$this->db->order_by("department_name", "asc");
		$query = $this->db->get();
		//echo "-------->".$this->db->last_query();
		return $result=$query->result(); 
	}
}