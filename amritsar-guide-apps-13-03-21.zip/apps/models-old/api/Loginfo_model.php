<?php
class Loginfo_model extends CI_Model
{
    function add_log($post_val){
    	$result=$this->db->insert('sounds_log_tracking',$post_val);
    	//print $this->db->last_query();
    	if($result){
    	    return $this->db->insert_id();
    	}else{
    	    return False;
    	}
    }
    
    /*function response_log($response){
        $this->db->select('locations.location_name,beacon_location_actions.media_file,beacon_location_actions.instruction_id,beacon_location_actions.instruction_option_selection,beacon_location_actions.text_to_speech_description,beacon_location_actions.sound_file_id,beacon_location_actions.media_file,beacon_location_actions.beacon_audio_file,beacon_location_actions.video_url,beacon_location_actions.beacon_video_file,locations.location_id');
	    $this->db->join('beacon_locations', 'beacon_locations.location_id = locations.location_id');
	    $this->db->join('beacon_location_actions', 'beacon_location_actions.beacon_location_id = beacon_locations.beacon_location_id');
	    $this->db->where('beacon_locations.language_id', $response['language_id']);
	    $this->db->where('beacon_locations.beacon_unique_id', $response['beacon_id']);
	    //$this->db->where('beacon_location_actions.action_plan_id', $response['counter']);
		$query=$this->db->get('locations');
		$resultdata = $query->result_array(); 
		//print $this->db->last_query();
		$i=0;
		$v=0;
		$video_url='';
		$media_url='';
		if($query->num_rows()>0){
    		foreach($resultdata as $row){
    		    $row['alert']='on';
    		    
    		    $row['instruction_option_selection']=$row['instruction_option_selection'];
    		    if($row['instruction_id']==1 || $row['instruction_id']==7){
    		        if($row['instruction_option_selection']=="text_to_speech"){
        		        $row['description']=$row['text_to_speech_description'];
        		        $description=$row['text_to_speech_description'];
        		        unset($row['text_to_speech_description']);
        		        $row['type']='T';
        		    }elseif($row['instruction_option_selection']=="upload_file"){
        		        $row['beacon_audio_file']=base_url().'assets/static/locations/beacons/'.$row['beacon_audio_file'];
        		        $row['type']='M';
        		        $audiopl=$row['beacon_audio_file'];
        		        //print $row['beacon_audio_file'];die;
        		       // $row['beacon_audio_file']=$row['beacon_audio_file'];
        		    }
    		    }elseif($row['instruction_id']==3){
    		        $row['type']='V';
    		        $video_url=$row['video_url'];
    		        $v++;
    		    }elseif($row['instruction_id']==2){
    		        $row['type']='P';
    		        $row['media_file']=base_url().'assets/static/locations/beacons/'.$row['media_file'];
    		        $media_url= $row['media_file'];
    		        $row['description']='This is poup description';
    		         $row['title']='This is poup title';

    		    }elseif($row['instruction_id']==5){
    		        $row['type']='N';
    		        //$row['media_file']=base_url().'assets/static/locations/beacons/'.$row['media_file'];
    		        $row['description']='This is noti description';
    		        $row['title']='This is noti title';
    		    }
    		    
    		    $row_info[] = $row;	
    		    $loc_id=$row['location_id'];
    		    $location_name=$row['location_name'];
    		    $i++;
    		}
    		//print $video_url;die;
    		$inforesponse['title']=$location_name;
    		$inforesponse['location_name']=$location_name;
    		$inforesponse['location_id']=$loc_id;
    		$inforesponse['video_url']=$video_url;
    		$inforesponse['content']=$description;
    		//$inforesponse['text_to_speech']=$description;
    		$inforesponse['description']='This is noti description';
    		$inforesponse['media_url']=$media_url;
    		$inforesponse['audio']=$audiopl;
    		return $inforesponse;
		}else{
		    $row_info['alert']='off';
		    $row_info['type']='';
		}
		return $row_info;
    }*/
    
    
    function last_beaconresponse_log($response){
		 $this->db->order_by("beacon_locations1.beacon_auto_id", "asc");
		 $this->db->where('beacon_locations1.beacon_unique_id', $response['beacon_id']);
		 $this->db->where('beacon_locations1.language_id', $response['language_id']);
		$query=$this->db->get('beacon_locations1');
		$resultdata = $query->result_array(); 
		//print $this->db->last_query();
		$row_info=array();
		//print $this->db->last_query();
		$i=0;
		$v=0;
		$video_url='';
		$media_url='';
		if($query->num_rows()>0){
    		foreach($resultdata as $row1){
    		    
    		    
    		    $type=$row1['assigned_to']; 
			   if($type=='L'){
			       $id=$row1['type_id'];
			       $name=$this->location_info($id);
			   }if($type=='V'){
			       $id=$row1['type_id'];
			       $name=$this->vendor_info($id);
			   }
    		    $beacon_auto_id=$row1['beacon_auto_id'];
    		    $beacon_auto_soundfile=$this->beacon_initial_sound($beacon_auto_id);

    		    foreach($beacon_auto_soundfile as $row){
        		    //$row['alert']='on';
        		    
        		    $row['instruction_option_selection']=$row['choose_opt'];
        		    if($row['instruction_id']==1 || $row['instruction_id']==7){
        		        if($row['instruction_option_selection']=="text_to_speech"){
            		        $row['description']=$row['text_to_speech_description'];
            		        $description=$row['text_to_speech_description'];
            		        unset($row['text_to_speech_description']);
            		        $row['type']='T';
            		    }elseif($row['instruction_option_selection']=="upload_file"){
            		        $row['beacon_audio_file']='assets/static/locations/beacons/'.$row['files'];
            		        $row['type']='M';
            		        $audiopl=$row['beacon_audio_file'];
            		        //print $row['beacon_audio_file'];die;
            		       // $row['beacon_audio_file']=$row['beacon_audio_file'];
            		    }
        		    }elseif($row['instruction_id']==3){
        		        $row['type']='V';
        		        $video_url=$row['video_url'];
        		        $video_title=$row['video_title'];
        		        $v++;
        		    }elseif($row['instruction_id']==2){
        		        $row['type']='P';
        		        $row['media_file']=base_url().'assets/static/locations/beacons/'.$row['files'];
        		        $media_url= $row['media_file'];
        		        $row['description']='This is poup description';
        		         $row['title']='This is poup title';
    
        		    }elseif($row['instruction_id']==5){
        		        $row['type']='N';
        		        //$row['media_file']=base_url().'assets/static/locations/beacons/'.$row['media_file'];
        		        $row['description']='This is noti description';
        		        $row['title']='This is noti title';
        		    }
    		    
        		    $row_info[] = $row;	
        		    $loc_id=$row['location_id'];
        		    $location_name=$row['location_name'];
        		    $i++;
    	    	}
    		}
    		//print $video_url;die;
    		$inforesponse['alert']='On';
    		$inforesponse['autoplay_audio']='On';
    		$inforesponse['title']=$name;
    		$inforesponse['location_name']=$name;
    		$inforesponse['location_id']=$id;
    		$inforesponse['video_url']=$video_url;
    		$inforesponse['video_title']=$video_title;
    		$inforesponse['content']=$description;
    		//$inforesponse['text_to_speech']=$description;
    		$inforesponse['description']='This is noti description';
    		$inforesponse['media_url']=$media_url;
    		$inforesponse['audio']=$audiopl;
    		return $inforesponse;
		}else{
		    $row_info['alert']='off';
		    $row_info['type']='';
		}
		return $row_info;
    }
    
    
    function response_log($response,$autoplay,$mobileId){
		 $this->db->order_by("beacon_locations1.beacon_auto_id", "asc");
		 $this->db->where('beacon_locations1.beacon_unique_id', $response['beacon_id']);
		 $this->db->where('beacon_locations1.language_id', $response['language_id']);
		$query=$this->db->get('beacon_locations1');
		$resultdata = $query->result_array(); 
		//print $this->db->last_query();
		$row_info=array();
		//print $this->db->last_query();
		$i=0;
		$v=0;
		$video_url='';
		$media_url='';
		if($query->num_rows()>0){
    		foreach($resultdata as $row1){
    		    
    		    
    		    $type=$row1['assigned_to']; 
			   if($type=='L'){
			       $id=$row1['type_id'];
			       $nameget=$this->location_info($id);
			       $name=$nameget->location_name;
			       $noti_decription=$nameget->short_description;
			   }if($type=='V'){
			       $id=$row1['type_id'];
			       $name=$this->vendor_info($id);
			       $noti_decription="this is test description in API.";
			       
			   }
    		    $beacon_auto_id=$row1['beacon_auto_id'];
    		    $beacon_auto_soundfile=$this->beacon_initial_sound($beacon_auto_id);
    		    //print '<pre>';print_r($beacon_auto_soundfile);die;
			   //$soundfile=$beacon_auto_soundfile[0]['files'];
			   //require_once('/home/dsysin607/public_html/codeigniter/hriday/libraries/getid3/getid3.php');
			   $getID3 = new GetID3;

                // Analyze file and store returned data in $ThisFileInfo
                
    		    foreach($beacon_auto_soundfile as $row){
        		    //$row['alert']='on';
        		    
        		    $row['instruction_option_selection']=$row['choose_opt'];
        		    if($row['instruction_id']==1 || $row['instruction_id']==7){
        		        if($row['instruction_option_selection']=="text_to_speech"){
            		        $row['description']=$row['text_to_speech_description'];
            		        $description=$row['text_to_speech_description'];
            		        unset($row['text_to_speech_description']);
            		        $row['type']='T';
            		    }elseif($row['instruction_option_selection']=="upload_file"){
            		        $row['beacon_audio_file']=base_url().'assets/static/locations/beacons/'.$row['files'];
            		        $row['type']='M';
            		        
            		        $aud_file = '/home/dsysin607/public_html/codeigniter/hriday/assets/static/locations/beacons/'.$row['files']; //Enter File Name mp3/wav
                            //$file_in_seconds=$this->calculateFileSize($aud_file);
            		        
            		        $audiopl=$row['beacon_audio_file'];
            		        $ThisFileInfo = $getID3->analyze($aud_file);
                            //echo ;
            		        //print $row['beacon_audio_file'];die;
            		       // $row['beacon_audio_file']=$row['beacon_audio_file'];
            		    }
        		    }elseif($row['instruction_id']==3){
        		        $row['type']='V';
        		        $video_url=$row['video_url'];
        		        $video_title=$row['video_title'];
        		        $v++;
        		    }elseif($row['instruction_id']==2){
        		        $row['type']='P';
        		        $row['media_file']=base_url().'assets/static/locations/beacons/'.$row['files'];
        		        $media_url= $row['media_file'];
        		        $row['description']='This is poup description';
        		         $row['title']='This is poup title';
    
        		    }elseif($row['instruction_id']==5){
        		        $row['type']='N';
        		        //$row['media_file']=base_url().'assets/static/locations/beacons/'.$row['media_file'];
        		        $row['description']='This is noti description';
        		        $row['title']='This is noti title';
        		    }
    		    
        		    $row_info[] = $row;	
        		    $loc_id=$row['location_id'];
        		    $location_name=$row['location_name'];
        		    $i++;
    	    	}
    		}
    		//print $video_url;die;
    		$inforesponse['alert']=$autoplay;
    		$inforesponse['autoplay_audio']=$autoplay;
    		/*$inforesponse['title']=$name;
    		$inforesponse['location_name']=$name;
    		$inforesponse['location_id']=$id;
    		$inforesponse['video_url']=$video_url;
    		$inforesponse['video_title']=$video_title;
    		$inforesponse['content']=$description;
    		//$inforesponse['text_to_speech']=$description;
    		$inforesponse['description']='This is noti description';
    		$inforesponse['media_url']=$media_url;*/
    		$inforesponse['audio']=$audiopl;
    		$inforesponse['notification_title']=$name;
    		$inforesponse['notification_content']=$noti_decription;
    		$inforesponse['audio_duration']=intval($ThisFileInfo['playtime_seconds']);
    		
    		$datetime=date('Y-m-d H:i:s');
    		$beacon_assoc=$this->beacon_associated($response['beacon_id'],$response['language_id']);
    		if($autoplay=='On'){
        		$post_vl['device_id']=$response['beacon_id'];
                $post_vl['assigned']=$beacon_assoc->assigned_to;
                $post_vl['type_id']=$beacon_assoc->type_id;
                $post_vl['playing_type']='B';
                $post_vl['datetime']=$datetime;
                $post_vl['language_id']=$response['language_id'];
                $post_vl['mobileId']=$mobileId;
                $post_vl['post_response']=json_encode($_POST);
        		$this->add_log($post_vl);
    		}
    		 unset($post_vl);
    		return $inforesponse;
		}else{
		    $row_info['alert']='off';
		    $row_info['type']='';
		}
		return $row_info;
    }
    
    
    function location_info($loc_id){
	    $last_row=$this->db->select('*')->where('location_id',$loc_id)->limit(1)->get('locations')->row();
	    return $last_row;
	}
	function vendor_info($id){
	    $last_row=$this->db->select('*')->where('user_id',$id)->limit(1)->get('users')->row();
	    return $last_row->first_name.' '.$last_row->first_name;
	}
	function beacon_initial_sound($id){
	    $last_row=$this->db->select('*')->where('beacon_auto_id',$id)->limit(1)->get('beacon_location_actions1')->row();
	    return json_decode($last_row->beacon_actions,true);
	}
	
	function getlast_playbeacon($id){    
	    $last_row=$this->db->select('*')->where('playing_type','B')->where('mobileId',$id)->limit(1)->order_by('sounds_log_id','desc')->get('sounds_log_tracking')->row();
	    //return json_decode($last_row->beacon_actions,true);
	    return $last_row;
	}
    
    
    function gps_sound_files($id){
	    $last_row=$this->db->select('*')->where('sound_file_id',$id)->limit(1)->get('sound_files')->row();
	    return $last_row->file_name;
	}
	
    function gps_get_tracking($loc_id,$mobileid,$language_id,$distance){
	    $last_row=$this->db->select('*')->where('mobileId',$mobileid)->where('type_id',$loc_id)->where('get_distance',$distance)->where('language_id',$language_id)->order_by('sounds_log_id','desc')->limit(1)->get('sounds_log_tracking');
	    //print $this->db->last_query();
	    if($last_row->num_rows() != 0){
          return $last_row->row();
        }
        else{
            return false;
        }
	}
    
    function get_tracking($post_val,$mobileid){
        //$language_id,$latitude,$longitude
        $language_id=$post_val['lang_id'];
        $latitude=$post_val['lat'];
        $longitude=$post_val['lng'];
        //$offset=($page_no*$limit)-$limit;
        $sql = 'SELECT * FROM (SELECT locations.gps_location_enab_on_off,locations.gps_location_noti_on_off,locations.is_active,locations.language_id,locations.description,locations.location_id,locations.location_name,locations.short_name,locations.address,locations.short_description,locations.latitude,locations.longitude,locations.alert1_distance,locations.alert1_sound_file_id,locations.alert1_sound_file_url,locations.alert2_distance,locations.alert2_sound_file_id,locations.alert2_sound_file_url,(((acos(sin(( '.$latitude.' * pi() / 180))*sin(( `latitude` * pi() / 180)) + cos(( '.$latitude.' * pi() /180 ))*cos(( `latitude` * pi() / 180)) *cos((( '.$longitude.' - `longitude`) * pi()/180)))) * 180/pi()) * 60 * 1.1515 * 1.609344) as distance FROM `locations` where is_active="1" order by distance asc) locations  where gps_location_enab_on_off=1 and language_id='.$language_id.' and is_active="1" and  distance <=0.500 limit 0,5;';
    	//$sql = 'SELECT *, (((acos(sin(('.$latitude.'*pi()/180)) * sin((latitude*pi()/180)) + cos(('.$latitude.'*pi()/180)) * cos((latitude*pi()/180)) * cos((('.$longitude.'- longitude) * pi()/180)))) * 180/pi()) * 60 * 1.1515 * 1.609344) as distance FROM locations';
        $user_id=0;
        $sql_history = "INSERT INTO `user_location_trackings`(`latitude`,`longitude`,`deviceId`,`user_id`,`track_date`,`created_on`) VALUES ('".$latitude."','".$longitude."','".$mobileid."','".$user_id."',now(),now())";
        $history_update = $this->db->query($sql_history);
        //print $sql;
        
    	//print $sql;  
    	$q = $this->db->query($sql);
    	$result= $q->result_array();
    	$beacons=array();
    	$getID3 = new GetID3;
        
    	foreach($q->result_array() as $rowval){
    	    $loc_id=$rowval['location_id'];
    	  $distance=$rowval['distance'];  // in km
    	   $in_meter=$distance*1000;
		   $getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
			    $filename=base_url().gallery_path.$getpath->media_file_name;
			    $pathinfo=$this->check_filexists($filename);
				$rowval['image_path'] = $pathinfo;
			}else{ 
				$rowval['image_path'] = '';
			} 
			
			$get_id_500=$this->gps_get_tracking($loc_id,$mobileid,$language_id,500);
			$diff_500=1;
			//print $get_id;
			$getdistance=0;
			if($get_id_500){
			    $dateget=date('Y-m-d');
			    $get_time=date('Y-m-d',strtotime($get_id_500->datetime));
			    $first_date = new DateTime($dateget);
                $second_date = new DateTime($get_time); 
                $diff_500 = $this->date_difference($first_date,$second_date); 
                $getdistance=$get_id_500->get_distance;
			}
			
			$get_id_0=$this->gps_get_tracking($loc_id,$mobileid,$language_id,0);
			$diff_0=1;
			if($get_id_0){
			    $dateget=date('Y-m-d');
			    $get_time=date('Y-m-d',strtotime($get_id_0->datetime));
			    $first_date = new DateTime($dateget);
                $second_date = new DateTime($get_time); 
                $diff_0 = $this->date_difference($first_date,$second_date); 
                $getdistance=$get_id_0->get_distance;
			}
			
			
			     
			
    			unset($rowval['gps_location_enab_on_off']);
    			unset($rowval['gps_location_noti_on_off']);
    			unset($rowval['is_active']);
    			unset($rowval['language_id']);
    			$rowval['distance'] =$in_meter;
    			//print 'loc='.$loc_id.'(500='.$diff_500.' 100='.$diff_0.' dis='.$in_meter.') ';
    			//print 'loc=(500='.$diff_500.' 100='.$diff_0.')';
    			$i=0;
    			$diff_0=1;
    			$diff_500=1;
    			if($diff_0>0){
    			    if($in_meter<=30){
    			        $location_beacon_onspot=$this->locations_gps_info($loc_id,$language_id);
            		    //$row['alert']='on';
            		    $alert1_sound_file_url=$rowval['alert1_sound_file_id'];
            		    $soundfileurl=$this->gps_sound_files($alert1_sound_file_url); 
            		    unset($rowval['alert1_sound_file_id']);
        		        unset($rowval['alert2_distance']);
        		        unset($rowval['alert2_distance']);
        		        unset($rowval['alert2_sound_file_id']);
        		        unset($rowval['alert2_sound_file_url']);
        		        unset($rowval['description']);
        		        unset($rowval['location_name']);
        		        unset($rowval['short_name']);
        		        unset($rowval['address']);
        		        unset($rowval['short_description']);
            		    //https://dreambsys.in/codeigniter/hriday/assets/static/locations/soundfiles/soundfile3.mp3
            		    //print $soundfileurl;die;
            		    $inforesponse['alert']='On';
                		$inforesponse['autoplay_audio']='On';
                	/*	$inforesponse['title']=$rowval['location_name'];
                		$inforesponse['location_name']=$rowval['location_name'];
                		$inforesponse['location_id']=$loc_id;
                		$inforesponse['video_url']=$location_beacon_onspot['video_link'];
                		$inforesponse['video_title']=$location_beacon_onspot['video_title'];;
                		$inforesponse['content']="";
                		//$inforesponse['text_to_speech']=$description;
                		$rowval['alert1_sound_file_url']=base_url().'assets/static/locations/soundfiles'.$soundfileurl; 
                		$inforesponse['description']='This is notification description';
                		$inforesponse['media_url']=base_url().'assets/static/locations/gps_path/'.$location_beacon_onspot['media_file']; */
                		$aud_file = '/home/dsysin607/public_html/codeigniter/hriday/assets/static/locations/gps_path/'.$location_beacon_onspot['initial']; 
                		$ThisFileInfo = $getID3->analyze($aud_file);
                		$inforesponse['audio']=base_url().'assets/static/locations/gps_path/'.$location_beacon_onspot['initial'];
                		$inforesponse['audio_duration']=intval($ThisFileInfo['playtime_seconds']);
                		//
                		//return $inforesponse;
        		        //return $inforesponse;
            		    /*$row_info[] = $row;	
            		    $loc_id=$row['location_id'];
            		    $location_name=$row['location_name'];*/
            		    
            		    $datetime=date('Y-m-d H:i:s');
            			$post_vl['device_id']='0';
                        $post_vl['assigned']='L';
                        $post_vl['type_id']=$loc_id;
                        $post_vl['playing_type']='G';
                        $post_vl['datetime']=$datetime;
                        $post_vl['language_id']=$language_id;
                        $post_vl['mobileId']=$mobileid;
                        $post_respone=array('latitude'=>$latitude,'longitude'=>$longitude,'distance'=>$in_meter);
                        $post_vl['post_response']=json_encode($post_respone);
                        $post_vl['get_distance']=0;
            			$addlog=$this->add_log($post_vl);
            			unset($post_vl);
            		    $i++;
    			   // $rowval['on_spot'] = $inforesponse;
    			    $add_custom[] = $inforesponse;
    			    //continue;
    			    $i=1;
    			}
			}
			if($diff_500>0){
    			if($in_meter<=500 && $i==0){
    			    $alert1_sound_file_url=$rowval['alert1_sound_file_id'];
            		$soundfileurl=$this->gps_sound_files($alert1_sound_file_url); 
            		$location_beacon_onspot=$this->locations_gps_info($loc_id,$language_id);
            		unset($rowval['alert1_sound_file_id']);
    		        unset($rowval['alert2_distance']);
    		        unset($rowval['alert2_distance']);
    		        unset($rowval['alert2_sound_file_id']);
    		        unset($rowval['alert2_sound_file_url']);
    		        unset($rowval['description']);
    		        unset($rowval['location_name']);
    		        unset($rowval['short_name']);
    		        unset($rowval['address']);
    		        unset($rowval['short_description']);
    		        unset($rowval['location_id']);
    		        unset($rowval['latitude']);
    		        unset($rowval['longitude']);
    		        unset($rowval['alert1_distance']);
    		        unset($rowval['alert1_sound_file_url']);
    		        unset($rowval['distance']);
    		        unset($rowval['image_path']);
    		        unset($rowval['alert1_sound_file_url']);
    		        $inforesponse['alert']='On';
                	$inforesponse['autoplay_audio']='On';
    			    //$rowval['alert1_sound_file_url']=base_url().'assets/static/locations/soundfiles/'.$location_beacon_onspot['popup_audio'];
    			    $inforesponse['audio']=base_url().'assets/static/locations/gps_path/'.$location_beacon_onspot['popup_audio'];
    			    $aud_file = '/home/dsysin607/public_html/codeigniter/hriday/assets/static/locations/gps_path/'.$location_beacon_onspot['popup_audio']; 
                	$ThisFileInfo = $getID3->analyze($aud_file);
                		//$inforesponse['audio']=base_url().'assets/static/locations/gps_path/'.$location_beacon_onspot['popup_audio'];
                	$inforesponse['audio_duration']=intval($ThisFileInfo['playtime_seconds']);
    			    
    			    
    			    //$inforesponse['audio']=$inforesponse;
    			    
    			    $datetime=date('Y-m-d H:i:s');
        			$post_vl['device_id']='0';
                    $post_vl['assigned']='L';
                    $post_vl['type_id']=$loc_id;
                    $post_vl['playing_type']='G';
                    $post_vl['datetime']=$datetime;
                    $post_vl['language_id']=$language_id;
                    $post_vl['mobileId']=$mobileid;
                    $post_respone=array('latitude'=>$latitude,'longitude'=>$longitude,'distance'=>$in_meter);
                    $post_vl['post_response']=json_encode($post_respone);
                    $post_vl['get_distance']=500;
        			$addlog=$this->add_log($post_vl);
        			unset($post_vl);
    			    
    			    $add_custom[] = $inforesponse;
    			} 
    			
    			
    			/*if($in_meter==0){
    			    
    			}*/
    		}
    	}
		if(empty($add_custom)){
		    $rowval1['alert']='Off';
		    $add_custom[] = $rowval1;
		}
		$result=$add_custom;
		unset($add_custom);
    	return $result; 
    }
    
    function date_difference($stsate,$eddate){
        $start_date = strtotime($stsate); 
        $end_date = strtotime($eddate); 
       return $date=($end_date - $start_date)/60/60/24; 
    }
    
    function locations_gps_info($id,$language_id){
	    $last_row=$this->db->select('*')->where('location_id',$id)->where('language_id',$language_id)->limit(1)->get('locations_gps_info')->row();
	    return json_decode($last_row->location_gps_info,true);
	}
    //https://dreambsys.in/codeigniter/hriday/api/appversion/app_version
    	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
	
	function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'assets/image-not-available.jpg';
        }
	
	}
	
	function get_listing_count($response){
	    $this->db->order_by("sounds_log_tracking.sounds_log_id", "desc");
        $this->db->where('sounds_log_tracking.mobileId', $response['mobileid']);
        $this->db->where('sounds_log_tracking.language_id', $response['language_id']);
        $query=$this->db->get('sounds_log_tracking');
        $resultdata = $query->num_rows(); 
        return $resultdata;
	}
	
	function get_listing($response,$page_no,$limit){
	    $offset=($page_no*$limit)-$limit;
        $this->db->order_by("sounds_log_tracking.sounds_log_id", "desc");
        $this->db->where('sounds_log_tracking.mobileId', $response['mobileid']);
        $this->db->where('sounds_log_tracking.language_id', $response['language_id']);
        $this->db->limit($limit, $offset);
        $query=$this->db->get('sounds_log_tracking');
        $resultdata = $query->result_array(); 
        $result=array();
        foreach($resultdata as $res){
            $beacon_id=$res['device_id'];
            $resp['beacon_id']=$beacon_id;
            $resp['language_id']=$response['language_id'];
            $pl_type=$res['playing_type'];
            $datetime=date('d M Y h:i a',strtotime($res['datetime']));
            $log_result=$this->response_log_notification($resp,'Off',$pl_type,$datetime); 
            unset($resp);
            $result[]=$log_result;
        }
        return $result;
	}
    
    
    function response_log_notification($response,$autoplay,$pl_type,$datetime){
		 $this->db->order_by("beacon_locations1.beacon_auto_id", "asc");
		 $this->db->where('beacon_locations1.beacon_unique_id', $response['beacon_id']);
		 $this->db->where('beacon_locations1.language_id', $response['language_id']);
		$query=$this->db->get('beacon_locations1');
		$resultdata = $query->result_array(); 
		//print $this->db->last_query();
		$row_info=array();
		//print $this->db->last_query();
		$i=0;
		$v=0;
		$video_url='';
		$media_url='';
		if($query->num_rows()>0){
    		foreach($resultdata as $row1){
    		    
    		    
    		    $type=$row1['assigned_to']; 
			   if($type=='L'){
			       $id=$row1['type_id'];
			       $nameget=$this->location_info($id);
			       $name=$nameget->location_name;
			       $notification_decription=$nameget->short_description;
			   }if($type=='V'){
			       $id=$row1['type_id'];
			       $name=$this->vendor_info($id);
			       $notification_decription="this is test description in API.";
			       
			   }
    		    $beacon_auto_id=$row1['beacon_auto_id'];
    		    $beacon_auto_soundfile=$this->beacon_initial_sound($beacon_auto_id);
    		    //print '<pre>';print_r($beacon_auto_soundfile);die;
			   //$soundfile=$beacon_auto_soundfile[0]['files'];
    		    foreach($beacon_auto_soundfile as $row){
        		    //$row['alert']='on';
        		    
        		    $row['instruction_option_selection']=$row['choose_opt'];
        		    if($row['instruction_id']==1 || $row['instruction_id']==7){
        		        if($row['instruction_option_selection']=="text_to_speech"){
            		        $row['description']=$row['text_to_speech_description'];
            		        $description=$row['text_to_speech_description'];
            		        unset($row['text_to_speech_description']);
            		        $row['type']='T';
            		    }elseif($row['instruction_option_selection']=="upload_file"){
            		        $row['beacon_audio_file']=base_url().'assets/static/locations/beacons/'.$row['files'];
            		        $row['type']='M';
            		        $audiopl=$row['beacon_audio_file'];
            		        //print $row['beacon_audio_file'];die;
            		       // $row['beacon_audio_file']=$row['beacon_audio_file'];
            		    }
        		    }elseif($row['instruction_id']==3){
        		        $row['type']='V';
        		        $video_url=$row['video_url'];
        		        $video_title=$row['video_title'];
        		        $v++;
        		    }/*elseif($row['instruction_id']==2){
        		        $row['type']='P';
        		        $row['media_file']=base_url().'assets/static/locations/beacons/'.$row['files'];
        		        $media_url= $row['media_file'];
        		        $row['description']='This is poup description';
        		         $row['title']='This is poup title';
    
        		    }*/elseif($row['instruction_id']==5){
        		        $row['type']='N';
        		        //$row['media_file']=base_url().'assets/static/locations/beacons/'.$row['media_file'];
        		        $row['description']='This is noti description';
        		        $row['title']='This is noti title';
        		    }
        		    
        		    //$loc_id=$row['location_id'];
        		   
        		    $getpath=$this->defaultDigitalMedia($id,gallery_files);
        		    //print $getpath;
        			if($getpath!=''){
        			    $filename=base_url().gallery_path.$getpath->media_file_name;
        			    $pathinfo=$this->check_filexists($filename);
        				$media_url = $pathinfo;
        			}else{ 
        				$media_url = '';
        			}
    		    
        		    $row_info[] = $row;	
        		    $loc_id=$row['location_id'];
        		    $location_name=$row['location_name'];
        		    $i++;
    	    	}
    		}
    		
    		
    		//print $video_url;die;
    		
    		$inforesponse['alert']='On';
    		$inforesponse['autoplay_audio']=$autoplay;
    		$inforesponse['title']=$name;
    		$inforesponse['location_name']=$name;
    		$inforesponse['location_id']=$id; 
    		$inforesponse['video_url']=$video_url;
    		$inforesponse['video_title']=$video_title;
    		$inforesponse['content']=$notification_decription;
    		//$inforesponse['content']=$description;
    		//$inforesponse['text_to_speech']=$description;
    		$inforesponse['description']=$notification_decription;
    		$inforesponse['media_url']=$media_url;
    		$inforesponse['audio']=$audiopl;
    		$inforesponse['type']=$pl_type;
    		
    		$inforesponse['datetime']=$datetime; 
    		return $inforesponse;
		}else{
		    $row_info['alert']='off';
		    $row_info['type']='';
		}
		return $row_info;
    }
    function calculateFileSize($file){

        $ratio = 16000; //bytespersec
    
        if (!$file) {
    
            exit("Verify file name and it's path");
    
        }
    
        $file_size = filesize($file);
    
        if (!$file_size)
            exit("Verify file, something wrong with your file");
    
        $duration = ($file_size / $ratio);
        $minutes = floor($duration / 60);
        $seconds = $duration - ($minutes * 60);
        $seconds = round($seconds);
        $totalSecs   = ($minutes * 60) + $seconds; 
        return $totalSecs;
    }
    
    function beacon_associated($id,$lid){
        $last_row=$this->db->select('*')->where('beacon_unique_id',$id)->where('language_id',$lid)->limit(1)->get('beacon_locations1')->row();
	    return $last_row;
    }
    
}