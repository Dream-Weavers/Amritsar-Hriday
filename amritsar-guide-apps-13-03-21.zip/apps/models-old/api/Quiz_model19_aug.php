<?php
class Quiz_model extends CI_Model{
	
	  function quiz_boolean($user_id,$language_id,$location_id){
		$this->db->select('question_bank_settings.question_bank_setting_id');
		$this->db->join('question_bank', 'question_bank.quiz_id = question_bank_settings.question_bank_setting_id');
		$this->db->where('question_bank_settings.location_id',$location_id);
		$this->db->where('question_bank_settings.language_id',$language_id);
	    $query = $this->db->get('question_bank_settings');
		$rows = $query->num_rows(); 
	//	print $this->db->last_query();die;
		return $rows;
	}
	
	function start_quiz($language_id,$location_id){
		$this->db->select('question_bank_setting_id,location_id,language_id,quiz_name,quiz_mode,types_assigned,theme_assigned');
		$this->db->where('quiz_status','1');
		$this->db->where('language_id',$language_id);
		$this->db->where('location_id',$location_id);
		$this->db->order_by('quiz_name', 'ASC');
		$query = $this->db->get('question_bank_settings');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $question_bank_setting_id = $row['question_bank_setting_id'];
					   $types_assigned = $row['types_assigned'];
				
						$listing = $this->get_quiz_types($language_id,$types_assigned,$question_bank_setting_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_quiz_types($language_id,$types_assigned,$question_bank_setting_id){
	   $types_assigned = explode(",",$types_assigned);
		
		$this->db->select('type_id,type,display_time,compulsory_status,back_button_status,next_button_status,edit_options_status');
		$this->db->where('language_id',$language_id);
		$this->db->where_in('type_id',$types_assigned);
		$this->db->order_by('type', 'ASC');
		$query=$this->db->get('question_bank_types');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{ 	$row_info['quiz_id'] = $question_bank_setting_id;
		
		    $listing = $this->get_quiz_questions($language_id,$question_bank_setting_id);
			$row_info['attributeresults']=$listing;
			
			
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	
	
	function get_quiz_questions($language_id,$quiz_id){
		$this->db->select('question_id,language_id,question,ques_explanation,option1,option2,option3,option4,answer');
		$this->db->where('language_id',$language_id);
		$this->db->where('quiz_id',$quiz_id);
		$this->db->order_by('que_order', 'ASC');
		$query = $this->db->get('question_bank');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				     	$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}

    function quiz_result_save($quiz_result_data){
	 	$result=$this->db->insert('quiz_results',$quiz_result_data);
		$quiz_result_id = $this->db->insert_id();
		return $quiz_result_id;
	}
	
	
	function quiz_result_score($language_id,$user_id,$quiz_result_id)
    {
		  $this->db->select('quiz_result_id,answers'); 
		  $this->db->where('language_id',$language_id);
		  $this->db->where('user_id',$user_id);
		  $this->db->where('quiz_result_id',$quiz_result_id);
		  $this->db->order_by('quiz_result_id', 'DESC');
		  $query = $this->db->get('quiz_results');
		  //echo $this->db->last_query();
		//  die();
		  if($query -> num_rows() > 0)
		  {
          $quiz_row = $query->row();	
		  $answers = $quiz_row->answers;
	      $answers = substr($answers,0,-1);
		  $quiz_answers = explode(",",$answers);
	      $total_question=0;
		  $correct=0;
		  $incorrect=0;
		  foreach ($quiz_answers as $ques_ans_row) {
			  
			  $total_question++;
			  $ques_ans = explode(".",$ques_ans_row);
			  $ques_id   = $ques_ans[0];
			  $ans = $ques_ans[1];
			
			  $this->db->select('question_bank.*'); 
			  $this->db->where('question_id',$ques_id);
			  $this->db->order_by('question_id', 'ASC');
			  $ques_query = $this->db->get('question_bank');
			  $ques_row = $ques_query->row();	
			  if($ques_row->answer == $ans)
			  {
				  $correct++;
			  }
			  else
			  {
				  $incorrect++;
			  }
		  }
		      $test_percentage=round(($correct/$total_question)*100);
			  $test_scrore=$correct.'/'.$total_question;
			   return $test_scrore;
		     // return $test_percentage.':'.$test_scrore;
		  }
		  else
		  {
			   return '999';
		  }

    } //End of View  function
	
	
	
	function quiz_result_info($language_id,$user_id,$quiz_result_id){
	    $this->db->select('question_bank_settings.quiz_name,quiz_results.quiz_result_id,quiz_results.quiz_id,quiz_results.answers'); 
		$this->db->join('question_bank_settings', 'question_bank_settings.question_bank_setting_id = quiz_results.quiz_id');
	    $this->db->where('quiz_results.language_id',$language_id);
	    $this->db->where('quiz_results.user_id',$user_id);
	    $this->db->where('quiz_results.quiz_result_id',$quiz_result_id);
	    $this->db->order_by('quiz_results.quiz_result_id', 'DESC');
	    $query = $this->db->get('quiz_results');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				      $quiz_result_id = $row['quiz_result_id'];
					  $quiz_id = $row['quiz_id'];
					  $answers = $row['answers'];
					  $answers = substr($answers,0,-1);
					  $quiz_answers = explode(",",$answers);
					  $total_question=0;
					  $correct=0;
					  $incorrect=0;
					  $quesids=array();
					  foreach ($quiz_answers as $ques_ans_row) {
						  $total_question++;
						  $ques_ans = explode(".",$ques_ans_row);
						  $ques_id  = $ques_ans[0];
						  $ans = $ques_ans[1];
						  $this->db->select('question_bank.*'); 
						  $this->db->where('question_id',$ques_id);
						  $this->db->order_by('question_id', 'ASC');
						  $ques_query = $this->db->get('question_bank');
						  $ques_row = $ques_query->row();	
						  if($ques_row->answer == $ans)
						  {  $correct++;
						  }
						  else
						  {  $incorrect++;
						  }
						  
						  $quesids[] = $ques_id; 
					  }
						  $quiz_score=round(($correct/$total_question)*100);
						 
					    $row['total_question'] = $total_question;
					    $row['correct'] = $correct;
						$row['quiz_score'] = $quiz_score;
				
						$listing=$this->get_quiz_result_questions($language_id,$quesids,$quiz_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function quiz_results($language_id,$user_id){
	    $this->db->select('question_bank_settings.quiz_name,quiz_results.quiz_result_id,quiz_results.quiz_id,quiz_results.answers'); 
		$this->db->join('question_bank_settings', 'question_bank_settings.question_bank_setting_id = quiz_results.quiz_id');
	    $this->db->where('quiz_results.language_id',$language_id);
	    $this->db->where('quiz_results.user_id',$user_id);
		$this->db->group_by('quiz_results.quiz_result_id');
	    $this->db->order_by('quiz_results.quiz_result_id', 'DESC');
	    $query = $this->db->get('quiz_results');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				  $quiz_result_id = $row['quiz_result_id'];
				  $quiz_id = $row['quiz_id'];
				  $answers = $row['answers'];
				  $answers = substr($answers,0,-1);
				  $quiz_answers = explode(",",$answers);
				  $total_question=0;
				  $correct=0;
				  $incorrect=0;
				  $quesids=array();
				  foreach ($quiz_answers as $ques_ans_row) {
					  $total_question++;
					  $ques_ans = explode(".",$ques_ans_row);
					  $ques_id  = $ques_ans[0];
					  $ans = $ques_ans[1];
					  $this->db->select('question_bank.*'); 
					  $this->db->where('question_id',$ques_id);
					  $this->db->order_by('question_id', 'ASC');
					  $ques_query = $this->db->get('question_bank');
					  $ques_row = $ques_query->row();	
					  if($ques_row->answer == $ans)
					  {  $correct++;
					  }
					  else
					  {  $incorrect++;
					  }
					  
					  $quesids[] = $ques_id; 
				  }
					  $quiz_score=round(($correct/$total_question)*100);
					 
					$row['total_question'] = $total_question;
					$row['correct'] = $correct;
					$row['quiz_score'] = $quiz_score;
			
					$listing=$this->get_quiz_result_questions($language_id,$quesids,$quiz_id);
					$row['attributes']=$listing;
					$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_quiz_result_questions($language_id,$quesids,$quiz_id){
		$this->db->select('question_id,language_id,question,ques_explanation,option1,option2,option3,option4,answer');
		$this->db->where('language_id',$language_id);
		//$this->db->where('quiz_id',$quiz_id);
		$this->db->where_in('question_id',$quesids);
		$this->db->order_by('que_order', 'ASC');
		$query = $this->db->get('question_bank');
		//echo $this->db->last_query();
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				      $row_info[] = $row;	
				}
			return $row_info;
		} else {
			return $row_info;
		}
	}
	
  
	
}
?>