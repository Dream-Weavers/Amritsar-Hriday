<?php
class Story_model extends CI_Model
{
    function add_story($post_val){
    	$result=$this->db->insert('stories',$post_val);
    	//print $this->db->last_query();
    	if($result){
    	    return True;
    	}else{
    	    return False;
    	}
    }
    
    function story_detail($user_id,$story_id){
        $this->db->select('*');
	    $this->db->where('story_id', $story_id);
		$query=$this->db->get('stories');
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $created_date=$row['postdate'];
		    
		    $date=date('d M Y',strtotime($created_date));
		    
			//Get User Photo Path 
			$row['postdate']=$date;
			
		    if($row!='image_url'){
				$row['image_url'] = base_url().'images/story/'.$row['image_url'];
			}else{
				 
				  $row['image_url'] = base_url().'assets/image-not-available.jpg';
			    }
				$fileexist=$this->check_filexists($row['image_url']);
				$row['story_path'] =$fileexist;
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
    }
    function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'assets/image-not-available.jpg';
        }
	
	}
	
	function story_listing($user_id,$language_id,$page_no,$limit)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('*');
	    $this->db->where('language_id', $language_id);
	    $this->db->where('user_id', $user_id);
	    $this->db->order_by("story_id", "desc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('stories');
		//print $this->db->last_query();
		$resultdata = $query->result_array(); 
		
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $created_date=$row['postdate'];
		    
		    $date=date('d M Y',strtotime($created_date));
		  
			//Get User Photo Path 
			$row['postdate']=$date;
			
		    if($row!='image_url'){
				$row['image_url'] = base_url().'images/story/'.$row['image_url'];
			}else{
				 
				  $row['image_url'] = '';
			    }
				$fileexist=$this->check_filexists($row['image_url']);
				$row['story_path'] =$fileexist;
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
	
	function story_listing_count($user_id,$language_id,$page_no,$limit)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('*');
	    $this->db->where('language_id', $language_id);
	    $this->db->where('user_id', $user_id);
	    $this->db->order_by("story_id", "desc");
		//$this->db->limit($limit, $offset);
		$query=$this->db->get('stories');
		return $query->num_rows();
		
	}
}