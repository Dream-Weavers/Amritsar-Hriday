<?php 
class Sos_model extends CI_Model
{
	
	function get_sos_category_Detail($language_id,$category_id,$sos_type){
		$this->db->select('module_layout_id,language_id,module_type,module_layout,module_name,weight');
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','2');
		$this->db->where('is_active','1');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('module_layout');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			//$row = array();
			//$add_custom= array();
			foreach($resultdata as $skey=>$row){
				$moduleid=$row['module_layout_id'];
				$module_type=$row['module_type'];
				$module_layout=$row['module_layout'];
				    if($module_type=='1'){  // If it is location type
						$listing=$this->get_category_children_content($language_id,$category_id,$sos_type);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					else if($module_type=='5'){ // if it is SOS Category Locations
						$listing=$this->get_categorylocations_map_content($language_id,$category_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					elseif($module_type=='2'){  // if it is Location Map.
						
						$listing=$this->get_category_locations_content($language_id,$category_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
				
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}

	function get_category_children_content($language_id,$category_id,$sos_type){
		$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
		$this->db->where('is_active','1');
		if($sos_type=='h')
		$this->db->where('category_parent_id','12');
		elseif($sos_type=='p')
		$this->db->where('category_parent_id','13');
		$this->db->where('language_id',$language_id);
		$result = $this->db->get('categories');
		$merge_array = array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			$main_rows = array();
			$fields = array('category_id'=>$category_id,'is_active'=>'1');
			$catrow = gettableinfo('categories',$fields);
			$main_row['category_name'] ='All '.$catrow->category_name.'';
			$main_row['description'] =$catrow->description;
			$main_row['category_id'] =$category_id;
			if($catrow->icon!=''){
				$main_row['icon'] = $catrow->icon;
				$main_row['image_path'] = base_url().category_icons_path.$catrow->icon;
			}else{
				$main_row['icon'] = '';
				$main_row['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$main_rows[] =$main_row;
		    foreach($listing as $row_info)
			{	$loc_id=$row_info['category_id'];
				if($row_info['icon']!=''){
					$row_info['image_path'] = base_url().category_icons_path.$row_info['icon'];
				}else{
					$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
				}
				$rows[] = $row_info;
			}
			$merge_array = array_merge($main_rows,$rows);	
			
			return $merge_array;
		}else{
			return $merge_array;
		}
		
	}
	
	
	function get_categorylocations_map_content($language_id,$category_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.description,locations.latitude,locations.longitude,locations.map_icon');
		$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('categories.language_id',$language_id);
		$this->db->where('categories.category_id',$category_id);
		$this->db->where('location_categories.is_active','1');
		$query=$this->db->get('categories');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$row_info['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$row_info['map_icon']));
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	
	function get_category_locations_content($language_id,$category_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.short_description as description,locations.map_icon,locations.city_id,locations.state_id,locations.pin_code,locations.address,locations.latitude,locations.longitude');
		$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('categories.language_id',$language_id);
		$this->db->where('categories.category_id',$category_id);
		$this->db->where('location_categories.is_active','1');
		$query=$this->db->get('categories');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$row_info['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$row_info['map_icon']));
			
			$cityrow = get_table_info('city','city_id',$row_info['city_id']);
			$staterow = get_table_info('state','state_id',$row_info['state_id']);
			$countryrow = get_table_info('country','country_id',$staterow->country_id);
			$row_info['city_name']= $cityrow->city_name;
			$row_info['state_name']= $staterow->state_name;
			$row_info['country_name']=$countryrow->country_name;
			 
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	
	

	function get_sos_location_detail_content($language_id,$location_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.short_name,locations.mobile_no,locations.landline_no,locations.short_description,locations.description,locations.city_id,locations.state_id,locations.pin_code,locations.address,locations.longitude,locations.latitude,locations.map_icon');
		$this->db->where('locations.language_id',$language_id);
		$this->db->where('locations.location_id',$location_id);
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('locations');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$rows = array();
		foreach($listing as $row_info)
		{
		    $loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			 $cityrow = get_table_info('city','city_id',$row_info['city_id']);
			 $staterow = get_table_info('state','state_id',$row_info['state_id']);
			 $countryrow = get_table_info('country','country_id',$staterow->country_id);
			 $row_info['city_name']= $cityrow->city_name;
			 $row_info['state_name']= $staterow->state_name;
			 $row_info['country_name']=$countryrow->country_name;
			
		   if($row_info['map_icon']!='')
		   $row_info['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$row_info['map_icon']));
		   else
		   $row_info['map_icon']='';
			
			
			
			$rows = $row_info;
		}
		return $rows;
	}
	
	
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
	
	
	function FacilityContent($language_id,$location_id)
    {
		$this->db->select('facility_type,facility_name_no,facility_description,contact_mobile_no,contact_landline_no,photo_name');
		$this->db->from('location_facilities');
		$this->db->where('location_facilities.location_id', $location_id);
		$this->db->where('location_facilities.facility_type','11');
		$this->db->order_by('location_facilities.facility_name_no', 'ASC');
		$query = $this->db->get();
		$mediaresult=$query->result_array();
		//print $this->db->last_query();die;
		$rows =array();
		foreach($mediaresult as $row_info)
		{
			  $fields = array('list_id'=>'facility_type','option_id'=>$row_info['facility_type'],'language_id'=>$language_id);
			  $listrow = gettableinfo('list_options',$fields);
			  $row_info['facility_title'] = trim($listrow->title);
			  $row_info['photo_name'] = base_url().facility_path.$row_info['photo_name'];
			
			$rows[] = $row_info;
		}
		return $rows;
	
	} //End of View function
	
	function getSos_Details($language_id,$location_id){
		$this->db->select('module_layout_id,language_id,module_type,module_layout,module_name,weight');
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','3');
		$this->db->where('is_active','1');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('module_layout');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				$moduleid=$row['module_layout_id'];
				$module_type=$row['module_type'];
				$module_layout=$row['module_layout'];
				    if($module_type=='1'){  // If it is location type
						$listing=$this->get_sos_location_detail_content($language_id,$location_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					else if($module_type=='2'){ // if it is SOS Category Locations
					
				     	$resultfacility = $this->FacilityContent($language_id,$location_id);
						$row['contact_attributes']=$resultfacility;
						$add_custom[] = $row; 
					}
				
				
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	
	function get_location_detail_content($language_id,$location_id,$needed_fields,$module_type){
		$this->db->select('locations.location_id,locations.location_name,locations.short_name,locations.short_description,locations.description,locations.city_id,locations.state_id');
		$this->db->where('locations.language_id',$language_id);
		$this->db->where('locations.location_id',$location_id);
		$this->db->where('locations.is_active','1');
		$query=$this->db->get('locations');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		$rows = array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			if($module_type=='1')
			{	$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($getpath!=''){
					$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
				}else{
					$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
				}
			 $cityrow = get_table_info('city','city_id',$row_info['city_id']);
			 $staterow = get_table_info('state','state_id',$row_info['state_id']);
			 $countryrow = get_table_info('country','country_id',$staterow->country_id);
			 $row_info['city_name']= $cityrow->city_name;
			 $row_info['state_name']= $staterow->state_name;
			 $row_info['country_name']=$countryrow->country_name;
		     if($row_info['map_icon']!='')
		     $row_info['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$row_info['map_icon']));
		     else
		     $row_info['map_icon']='';
			
			$rows = $row_info;
		}
		return $rows;
	  }
	}
	
	

}
?>