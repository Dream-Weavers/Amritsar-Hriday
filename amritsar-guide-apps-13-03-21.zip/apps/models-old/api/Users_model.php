<?php 
class Users_model extends CI_Model
{
	function getusers()
	{
		$this->db->select('*');
		//$this->db->where('category_types.language_id',$language_id);
		//$this->db->where('category_types.is_active','1');
		$query = $this->db->get('users');
		$result=$query->result_array();
		return $result;
	}
}
?>