<?php
class Groups_model extends CI_Model{
	
	
  function search_friend($user_id,$search_keyword)
	{   
	    $currentuid=array('user_id'=>$user_id);
	    $this->db->select('user_id,first_name,last_name,gender,email,mobile_no1,user_photo');
	    if (filter_var($search_keyword, FILTER_VALIDATE_EMAIL)) {
		   $this->db->like('email', $search_keyword);
	    }
	   elseif (filter_var($search_keyword, FILTER_SANITIZE_NUMBER_INT)) {
		   $this->db->like('mobile_no1', $search_keyword);
	    }
	    else{
		   $this->db->where("CONCAT( first_name,  ' ', last_name ) LIKE  '%".trim($search_keyword)."%'");
	    }
		$this->db->where_not_in('user_id', $currentuid);
	 	$this->db->where('is_active','1');
		$this->db->where('user_type','U');
		$this->db->order_by("first_name", "asc");
		$this->db->order_by("last_name", "asc");
		$query=$this->db->get('users');
		$resultdata = $query->result_array(); 
		//echo "--->".$this->db->last_query();
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $user_id=$row['user_id'];
			//Get User Photo Path 
		    if($row!='user_photo'){
				$row['user_photo_path'] = base_url().'assets/users/'.$row['user_id'].'/'.$row['user_photo'];
			}else{
				 if($row['gender']=='m')
				  $row['user_photo_path'] = base_url().'images/male.jpg';
				 elseif($row['gender']=='f')
				  $row['user_photo_path'] = base_url().'images/female.jpg';
				 else
				  $row['user_photo_path'] = base_url().'assets/image-not-available.jpg';
			    }
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
	
  function insert_group($group_data){
	    $result=$this->db->insert('tourist_groups',$group_data);
		return $result;
	}
	
  function update_group($language_id,$group_id,$user_id,$group_data){
	    $this->db->where('language_id',$language_id);
		$this->db->where('group_id',$group_id);
		$this->db->where('created_by',$user_id);
	 	$updateresult=$this->db->update('tourist_groups',$group_data);
		return $updateresult;
	}
	
  function group_update_friends($language_id,$group_id,$user_id,$group_member_ids){
	    $group_data=array('group_member_ids'=>$group_member_ids,'modified_on'=>date('Y-m-d H:i:s'));
	    $this->db->where('language_id',$language_id);
		$this->db->where('group_id',$group_id);
		$this->db->where('created_by',$user_id);
	 	$updateresult=$this->db->update('tourist_groups',$group_data);
		return $updateresult;
	}
	
function my_groups($user_id,$language_id){   
	$this->db->select('group_id,language_id,group_name,group_passcode,group_desc,group_owner_id,group_member_ids,created_on,modified_on');
	$this->db->where('language_id',$language_id);
	$this->db->where('created_by',$user_id);
	$this->db->order_by("group_name", "asc");
	$query=$this->db->get('tourist_groups');
	$resultdata = $query->result_array(); 
	$row_info=array();
	$member_ids=array();
	if($query->num_rows()>0){
		foreach($resultdata as $key=>$row){
		    $group_member_ids=json_decode($row['group_member_ids'],true);
			$rowinfo=array();
			//print '<pre>';print_r($row['group_member_ids']);
		foreach($group_member_ids['uid'] as $val){
		        $member_ids[$val]=$val; 
				$fields = array('user_id'=>$val,'is_active'=>'1');
				$userrow = gettableinfowithfields('users',$fields,'user_id,first_name,last_name,gender,mobile_no1,user_photo');
				//Get User Photo Path 
				if($userrow->user_photo!=''){
					$userrow->user_photo = base_url().'assets/users/'.$userrow->user_id.'/'.$userrow->user_photo;
				}else{
					if($userrow->gender=='m')
						$userrow->user_photo = base_url().'images/male.jpg';
					elseif($userrow->gender=='f')
						$userrow->user_photo = base_url().'images/female.jpg';
					else
						$userrow->user_photo = base_url().'assets/image-not-available.jpg';
				}
				$rowinfo[] = $userrow;	
			}
			$implode_member=implode(',',$member_ids);
			$row['group_member_ids']=$implode_member;
			$row['attributes']=$rowinfo;
			$row_info[] = $row;	
		} 
		return $row_info;
	}else{
		return $row_info;
	}
}
	
	function request_status_update($friendship_id,$user_id,$status){
		$status_data = array(
			 'status'=>$status,
		 	 'friend_acknowledge_timestamp'=>date('Y-m-d H:i:s')
           );
		$this->db->where('friendship_id',$friendship_id);
		$this->db->where('receiver_user_id',$user_id);
	 	$updateresult=$this->db->update('friendships',$status_data);
	  
	  return $updateresult;
	   
	}
	
	function group_info($user_id,$language_id,$group_id){
	    $this->db->select('group_id,language_id,group_name,group_passcode,group_desc,group_owner_id,group_member_ids,created_on,modified_on');
	$this->db->where('language_id',$language_id);
	$this->db->where('created_by',$user_id);
	$this->db->where('group_id',$group_id);
	$this->db->order_by("group_name", "asc");
	$query=$this->db->get('tourist_groups');
	$resultdata = $query->result_array(); 
	$row_info=array();
	$member_ids=array();
	if($query->num_rows()>0){
		foreach($resultdata as $key=>$row){
		    $group_member_ids=json_decode($row['group_member_ids'],true);
			$rowinfo=array();
			//print '<pre>';print_r($row['group_member_ids']);
		foreach($group_member_ids['uid'] as $val){
		        $member_ids[$val]=$val;
				$fields = array('user_id'=>$val,'is_active'=>'1');
				$userrow = gettableinfowithfields('users',$fields,'user_id,first_name,last_name,gender,mobile_no1,user_photo');
				//Get User Photo Path 
				if($userrow->user_photo!=''){
					$userrow->user_photo = base_url().'assets/users/'.$userrow->user_id.'/'.$userrow->user_photo;
				}else{
					if($userrow->gender=='m')
						$userrow->user_photo = base_url().'images/male.jpg';
					elseif($userrow->gender=='f')
						$userrow->user_photo = base_url().'images/female.jpg';
					else
						$userrow->user_photo = base_url().'assets/image-not-available.jpg';
				}
				$rowinfo[] = $userrow;	
			}
			$implodemember=implode(',',$member_ids);
			$row['group_member_ids']=$implodemember;
			unset($member_ids);
			$row['attributes']=$rowinfo;
			$row_info[] = $row;	
		} 
		return $row_info;
	}else{
		return $row_info;
	}
	}
	
	function delete_group($user_id,$group_id){
	     $this->db->where('created_by', $user_id);
	     $this->db->where('group_id', $group_id);
        $result= $this->db->delete('tourist_groups');
	   // print $this->db->last_query();
	    return $result;
	}
	
}
?>