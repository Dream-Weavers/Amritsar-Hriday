<?php 
class CategoryType_model extends CI_Model
{

	function get_categorytype_module_Detail($language_id,$categorytype_id){
		 
		
		$visibility=array('all','app');
		$this->db->select('module_id,module_name,language_id,module_visibility,module_type,module_layout,no_of_records,is_latest,module_category_id');
		$this->db->where_in('module_visibility',$visibility);
		$this->db->where('language_id',$language_id);
		$this->db->where('module_category_id','4');
		$this->db->order_by("weight", "asc");
	    $query=$this->db->get('modules');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
				$moduleid=$row['module_id'];
				$module_type=$row['module_type'];
				$is_latest=$row['is_latest'];
				$module_layout=$row['module_layout'];
			
				if($is_latest=='2'){ // If it is custom field configuration
					if($module_type=='2'){
						$jointable='locations';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->join('locations', 'locations.location_id = module_interlinks.location_id');
						$this->db->where('locations.is_active','1');
					}else if($module_type=='3'){
						$jointable='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$this->db->join('categories', 'categories.category_id = module_interlinks.category_id');
						$this->db->where('categories.is_active','1');
					}else if($module_type=='1'){
						$jointable='categories';
						$this->db->select('category_types.category_type,category_types.category_type_id,category_types.description,category_types.icon');
						$this->db->join('category_types', 'category_types.category_type_id = module_interlinks.category_type_id');
						$this->db->where('category_types.is_active','1');
					}else if($module_type=='4'){
						$jointable='categories';
						$this->db->select('slides.slide_title,slides.slide_file_name');
						$this->db->join('slides', 'slides.slide_id = module_interlinks.slide_id');
						$this->db->where('slides.is_active','1');
					}else{
						$this->db->select('*');
					}
					$this->db->where('module_interlinks.module_id',$moduleid);
					$this->db->order_by("module_interlinks.weight", "asc");
					$query_attr=$this->db->get('module_interlinks');
					$module_attributes = $query_attr->result_array(); 
					if($query_attr->num_rows()>0){
						foreach($query_attr->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							$interlink_type=$row_info['interlink_type'];
							if($module_type=='2'){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
									$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
								}else{
									//$row_info['image_path'] = '';
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';;
								}
							}else if($module_type=='3'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().category_icons_path.$row_info['icon'];
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type=='1'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().categorytype_icons_path.$row_info['icon'];
								}else{
									//$row_info['image_path'] = '';
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type=='4'){
								if($row_info['slide_file_name']!=''){
									$row_info['image_path'] = base_url().slide_image.$row_info['slide_file_name'];
								}else{
									//$row_info['image_path'] = '';
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}
							$rows[] = $row_info;
						}
					}
					$row['attributes']=$rows;
					$add_custom[]=$row;
					unset($rows);
				}else if($is_latest=='1'){  // If it is latest field configuration
					if($module_type=='2'){ 
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id');
						$this->db->where('locations.is_active','1');
					}else if($module_type=='3'){
						$tablename='categories';
						$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
						$orderby='category_id';
						$this->db->where('categories.is_active','1');
					}else if($module_type=='1'){
						$tablename='category_types';
						$this->db->select('category_types.category_type,category_types.description,category_types.category_type_id,category_types.icon');
						$orderby='category_type_id';
						$this->db->where('category_types.is_active','1');
					}else if($module_type=='4'){
						$tablename='locations';
						$orderby='location_id';
						$this->db->select('locations.location_name,locations.short_name,locations.short_description,locations.location_id,locations.latitude,locations.longitude');
						$this->db->where('locations.is_active','1');
					}
					
					$this->db->order_by($orderby, "desc");
					$this->db->limit(10,0);
					$query_latest=$this->db->get($tablename);
					$module_latest = $query_latest->result_array(); 
					if($query_latest->num_rows()>0){
						foreach($query_latest->result_array() as $row_info)
						{
							$loc_id=$row_info['location_id'];
							if($module_type=='2'){
								$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
								if($getpath!=''){
									$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
								}else{
								    $row_info['image_path'] = base_url().'assets/image-not-available.jpg';
									//$row_info['image_path'] = '';
								}
							}else if($module_type=='3'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().category_icons_path.$row_info['icon'];
								}else{
									$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}else if($module_type=='1'){
								if($row_info['icon']!=''){
									$row_info['image_path'] = base_url().categorytype_icons_path.$row_info['icon'];
								}else{
									//$row_info['image_path'] = '';
										$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
								}
							}
							
							$rows[] = $row_info;
						}
					}
					
					
					$row['attributes']=$rows;
					$add_custom[] = $row; 
					unset($rows);
				}else if($is_latest=='3'){ // if is RAW ID from URL
					if($module_type=='2'){  // If it is location type
						
						$listing=$this->get_category_locations_content($language_id,$category_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type=='3'){  // If it is category
						
						$listing=$this->get_category_children_content($language_id,$categorytype_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type=='1'){  // if it is category type.
						$listing=$this->get_categorytype_content($language_id,$categorytype_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}else if($module_type=='5'){
						$listing=$this->get_categorylocations_map_content($language_id,$category_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
					}
					//$row['attributes']=$rows;
					//$add_custom[] = $row; 
					//unset($rows);
				}
			}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_category_children_content($language_id,$categorytype_id){
		$this->db->select('categories.category_name,categories.description,categories.category_id,categories.icon');
		$this->db->where('is_active','1');
		$this->db->where('category_type_id',$categorytype_id);
		$this->db->where('category_parent_id',0);
		$this->db->where('language_id',$language_id);
		$result = $this->db->get('categories');
		$rows =array();
		if($result->num_rows()>0){
			$listing=$result->result_array();
			foreach($listing as $row_info)
			{
				$loc_id=$row_info['category_id'];
				//$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
				if($row_info['icon']!=''){
					$row_info['image_path'] = base_url().category_icons_path.$row_info['icon'];
				}else{
					$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
				}
				$rows[] = $row_info;
			}
			/*$add_custom = $rows; 
			unset($rows);
			$resultdata=$add_custom;
			unset($add_custom);*/
			return $rows;
		}else{
			return $rows;
		}
		
	}
	
	function get_categorylocations_map_content($language_id,$category_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.description,locations.latitude,locations.longitude');
		$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('categories.language_id',$language_id);
		$this->db->where('categories.category_id',$category_id);
		$this->db->where('location_categories.is_active','1');
		$query=$this->db->get('categories');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
				//$row_info['image_path'] = '';
					$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	function get_category_locations_content($language_id,$category_id){
		
		$this->db->select('locations.location_id,locations.location_name,locations.short_description as description,locations.map_icon');
		$this->db->join('location_categories', 'location_categories.category_id = categories.category_id');
		$this->db->join('locations', 'locations.location_id = location_categories.location_id');
		$this->db->where('categories.language_id',$language_id);
		$this->db->where('categories.category_id',$category_id);
		$this->db->where('location_categories.is_active','1');
		$query=$this->db->get('categories');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{
			$loc_id=$row_info['location_id'];
			$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
			if($getpath!=''){
				$row_info['image_path'] = base_url().gallery_path.$getpath->media_file_name;
			}else{
			//	$row_info['image_path'] = '';
				$row_info['image_path'] = base_url().'assets/image-not-available.jpg';
			}
			$row_info['map_icon']=base64_encode(file_get_contents(base_url().icon_url_path.$row_info['map_icon']));
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
	
	function get_categorytype_content($language_id,$category_id){
		$listing=$this->get_category_types($language_id,$category_id);
		return $listing;
	}
	
	
	
	
	function get_category_parent($language_id,$category_id){
		
		$this->db->select('*');
		$this->db->where('language_id',$language_id);
		$this->db->where('category_id',$category_id);
		$this->db->where('is_active','1');
		$query = $this->db->get('categories');
		$result=$query->row();
		return $result->category_parent_id;
	}
	
	function get_category_types($language_id,$id){
		$result =array();
		$this->db->select('category_types.category_type as title,category_types.category_type_id as id ,"category_type" as `type`');
		$this->db->where('category_types.language_id',$language_id);
		$this->db->where('category_types.is_active','1');
		//$this->db->where('category_types.category_type_id',$id);
		$query = $this->db->get('category_types');
		$result=$query->result_array();
		return $result;
	}
	
}
?>