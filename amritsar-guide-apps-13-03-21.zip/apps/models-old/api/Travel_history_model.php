<?php
class Travel_history_model extends CI_Model{
	
	
	function travel_history_select_year($user_id){
	    $this->db->select('YEAR(track_date) as year');
		$this->db->where('user_id',$user_id);
		$this->db->group_by('YEAR(track_date)');
		$this->db->order_by('track_date', 'DESC');
		$query = $this->db->get('user_location_trackings');
		//print $this->db->last_query();
		$resultdata=$query->result_array();
		$row_main=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
			 $row_main[] = $row;	
			}
		
			return $row_main;
		} else {
			return $row_main;
		}

	}
	
	function user_travel_history($user_id,$select_year,$select_month){
		$this->db->select('track_date');
		$this->db->where('year(track_date)', date($select_year));
		if($select_month!='')
		$this->db->where('month(track_date)', date($select_month));
		$this->db->where('user_id',$user_id);
		$this->db->order_by('created_on', 'DESC');
		$this->db->group_by('DAY(track_date),MONTH(track_date), YEAR(track_date)');
		$query = $this->db->get('user_location_trackings');
		//print $this->db->last_query();die;
		$resultdata = $query->result_array(); 
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				          $track_date_format = date('d M, Y',strtotime($row['track_date']));
					      $listing = $this->get_date_travel_history($user_id,$row['track_date']);
						  $row['track_date'] = $track_date_format;
						  $row['attributes']=$listing;
			 	
					$row_info[] = $row;
				}
		
			return $row_info;
		} else {
			return $row_info;
		}
	}
	
	
	function get_date_travel_history($user_id,$track_date){
	    $this->db->select('lat_lng_data');
		$this->db->where('track_date >=', date(''.$track_date.' 00:00:00'));
		if($track_date!='0')
		$this->db->where('track_date <=', date(''.$track_date.' 23:59:59'));
		$this->db->where('user_id',$user_id);
		$this->db->order_by('track_date', 'DESC');
		$query = $this->db->get('user_location_trackings');
		$row_main=array();
		if($_SERVER['REMOTE_ADDR']=='157.39.113.168')
		{
			 //print $this->db->last_query();
			//echo "<br>";
		}
		$rowhistory = $query->row_array(); 
		$row_main=json_decode($rowhistory['lat_lng_data'],true);
		
		return $row_main;
	}
	
	
	
}
?>