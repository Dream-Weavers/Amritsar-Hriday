<?php
class Quiz_model extends CI_Model{
	
	function start_quiz($language_id,$location_id){
		$this->db->select('question_bank_setting_id,location_id,language_id,quiz_name,quiz_mode,types_assigned,theme_assigned');
		$this->db->where('quiz_status','1');
		$this->db->where('language_id',$language_id);
		$this->db->where('location_id',$location_id);
		$this->db->order_by('quiz_name', 'ASC');
		$query = $this->db->get('question_bank_settings');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $question_bank_setting_id = $row['question_bank_setting_id'];
					   $types_assigned = $row['types_assigned'];
				
						$listing = $this->get_quiz_types($language_id,$types_assigned,$question_bank_setting_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
	function get_quiz_types($language_id,$types_assigned,$question_bank_setting_id){
	   $types_assigned = explode(",",$types_assigned);
		
		$this->db->select('type_id,type,display_time,compulsory_status,back_button_status,next_button_status,edit_options_status');
		$this->db->where('language_id',$language_id);
		$this->db->where_in('type_id',$types_assigned);
		$this->db->order_by('type', 'ASC');
		$query=$this->db->get('question_bank_types');
		//print $this->db->last_query();die;
		$listing=$query->result_array();
		foreach($listing as $row_info)
		{ 	$row_info['quiz_id'] = $question_bank_setting_id;
		
		    $listing = $this->get_quiz_questions($language_id,$question_bank_setting_id);
			$row_info['attributeresults']=$listing;
			
			
			$rows[] = $row_info;
		}
		$add_custom = $rows; 
		unset($rows);
		$resultdata=$add_custom;
		unset($add_custom);
		return $resultdata;
	}
	
	
	
	function get_quiz_questions($language_id,$quiz_id){
		$this->db->select('question_id,language_id,question,ques_explanation,option1,option2,option3,option4,answer');
		$this->db->where('language_id',$language_id);
		$this->db->where('quiz_id',$quiz_id);
		$this->db->order_by('que_order', 'ASC');
		$query = $this->db->get('question_bank');
		$resultdata = $query->result_array(); 
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				     	$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}

  function quiz_result_save($quiz_result_data){
	 	$result=$this->db->insert('quiz_results',$quiz_result_data);
		$quiz_result_id = $this->db->insert_id();
		return $quiz_result_id;
	}
	
	
	function quiz_result_info($user_id,$language_id,$tour_trail_id){
		$this->db->select('tour_trails.tour_trail_name,tour_trails.tour_trail_id,tour_trails.language_id,tour_trails.user_id');
		$this->db->join('tour_trails', 'tour_trails.tour_trail_id = tour_trail_locations.tour_trail_id');
		$this->db->where('tour_trails.user_id',$user_id);
		$this->db->where('tour_trails.tour_trail_id',$tour_trail_id);
		$this->db->where('tour_trails.language_id',$language_id);
	    $query = $this->db->get('tour_trail_locations');
		$resultdata = $query->result_array(); 
		//echo $this->db->last_query();
		if($query->num_rows()>0){
			foreach($resultdata as $skey=>$row){
				       $tour_trail_id = $row['tour_trail_id'];
				
						$listing=$this->get_user_tour_trail_location_info($tour_trail_id);
						$row['attributes']=$listing;
						$add_custom[] = $row; 
				}
			$resultdata=$add_custom;
			unset($add_custom);
			
			return $resultdata;
		} else {
			return false;
		}
	}
	
    function quiz_boolean($user_id,$language_id,$location_id){
		$this->db->select('question_bank_settings.question_bank_setting_id');
		$this->db->join('question_bank', 'question_bank.quiz_id = question_bank_settings.question_bank_setting_id');
	//	$this->db->where('question_bank_settings.user_id',$user_id);
		$this->db->where('question_bank_settings.location_id',$location_id);
		$this->db->where('question_bank_settings.language_id',$language_id);
	    $query = $this->db->get('question_bank_settings');
		$rows = $query->num_rows(); 
	//	print $this->db->last_query();die;
		return $rows;
	}
	
}
?>