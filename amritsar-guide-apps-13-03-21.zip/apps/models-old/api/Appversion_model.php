<?php 
class Appversion_model extends CI_Model
{
	function get_version()
	{   
		$last_row=$this->db->select('*')->order_by('app_version_id',"desc")->limit(1)->get('app_version')->row();
		$version_id=$last_row->version_id;
		return $version_id;
	}

}
?>