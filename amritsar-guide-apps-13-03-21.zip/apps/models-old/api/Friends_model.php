<?php
class Friends_model extends CI_Model{
	
	
	function search_total_friend($user_id,$search_keyword,$page_no,$limit)
	{   
		$offset=($page_no*$limit)-$limit;
	    $currentuid=array('user_id'=>$user_id);
	    $this->db->select('user_id,first_name,last_name,gender,email,mobile_no1,user_photo');
	    if (filter_var($search_keyword, FILTER_VALIDATE_EMAIL)) {
		   $this->db->like('email', $search_keyword);
	    }
	   elseif (filter_var($search_keyword, FILTER_SANITIZE_NUMBER_INT)) {
		   $this->db->like('mobile_no1', $search_keyword);
	    }
	    else{
		   $this->db->where("CONCAT( first_name,  ' ', last_name ) LIKE  '%".trim($search_keyword)."%'");
	    }
		$this->db->where_not_in('user_id', $currentuid);
	 	$this->db->where('is_active','1');
		$this->db->where('user_type','U');
		$this->db->order_by("first_name", "asc");
		$this->db->order_by("last_name", "asc");
		$query=$this->db->get('users');
		$resultdata = $query->result_array(); 
		//echo "--->".$this->db->last_query();
		$row_info=array();
	return	$query->num_rows();
		
	}
	
	
  function search_friend($user_id,$search_keyword,$page_no,$limit)
	{   
		$offset=($page_no*$limit)-$limit;
	    $currentuid=array('user_id'=>$user_id);
	    $this->db->select('user_id,first_name,last_name,gender,email,mobile_no1,user_photo,user_online_status,latitude,longitude,response_code');
	    if (filter_var($search_keyword, FILTER_VALIDATE_EMAIL)) {
		   $this->db->like('email', $search_keyword);
	    }
	   elseif (filter_var($search_keyword, FILTER_SANITIZE_NUMBER_INT)) {
		   $this->db->like('mobile_no1', $search_keyword);
	    }
	    else{
		   $this->db->where("CONCAT( first_name,  ' ', last_name ) LIKE  '%".trim($search_keyword)."%'");
	    }
		$this->db->where_not_in('user_id', $currentuid);
	 	$this->db->where('is_active','1');
		$this->db->where('user_type','U');
		$this->db->order_by("first_name", "asc");
		$this->db->order_by("last_name", "asc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('users');
		$resultdata = $query->result_array(); 
		//echo "--->".$this->db->last_query();
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		  
			//Get User Photo Path 
			/*if($row!='user_photo'){
		        if($row['user_photo']==''){
		         $row['user_photo_path'] = base_url().'images/male.jpg';
		        }else{
		             $userpath=base_url().'assets/users/'.$row['user_id'].'/'.$row['user_photo'];
		            $fileexist=$this->check_filexists($userpath);
				$row['user_photo_path'] =$fileexist;
		        }
			}else{
				 if($row['gender']=='m')
				  $row['user_photo_path'] = base_url().'images/male.jpg';
				 elseif($row['gender']=='f')
				  $row['user_photo_path'] = base_url().'images/female.jpg';
				 else
				  $row['user_photo_path'] = '';
			    }*/
			   $photo= $row['user_photo'];
			   $resp=$row['response_code'];
			
			if($row!='response_code'){    
    			if($row['response_code']!=NULL){
    			    $responsedecode=json_decode($row['response_code'],true);
    			    if($responsedecode['user_dp']!='')
    			    $row['user_photo_path']=$responsedecode['user_dp'];
    			}
			}
			if($row!='user_photo'){    
		        if($row['user_photo']!=NULL){
		            //print $row['user_photo'];
			    	$row['user_photo_path']=users_photo_path.$photo;
			    }
			}
			//print $row['user_photo_path'];
			$fileexist=$this->check_filexists($row['user_photo_path']);
			$row['user_photo_path'] =$fileexist;
			if($row['user_photo_path']=='' || $row['user_photo_path']==null){
			    $row['user_photo_path'] =base_url().'images/male.jpg';
			}
			    
			    
				$friend_status=$this->check_friend_status($user_id,$row['user_id']);
				//echo "--friend_status------------>".$friend_status;
				//$row['friend_status'] = $friend_status;
				foreach($friend_status as $rkey=>$rval){
				    $row[$rkey]=$rval;
				}
				
				
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
	

	
  function insert_friend($user_id,$friend_user_id){
	    $already=$this->already_friend($user_id,$friend_user_id);
		if($already==0)
	    {
		  $friend_data = array(
			 'requester_user_id'=>$user_id,
		 	 'receiver_user_id'=>$friend_user_id,
			 'friend_request_timestamp'=>date('Y-m-d H:i:s'),
			 'created_on'=>date('Y-m-d H:i:s')
           );
			$result=$this->db->insert('friendships',$friend_data);
	    	$result=$this->db->insert_id();
		}else
		{
			$result ='already';
		}
	 	
		return $result;
	}


			
   function check_friend_status($user_id,$friend_user_id)
    {
		$sqlcheck ="SELECT `friendship_id`,`status`,`requester_user_id`,`receiver_user_id` from friendships where (receiver_user_id =".$user_id." and 
		requester_user_id=".$friend_user_id.") or (requester_user_id =".$user_id." and 
		receiver_user_id=".$friend_user_id.")";
		$query = $this->db->query($sqlcheck);
		//echo "--->".$this->db->last_query();
		$frnd_array=array();
		if($query -> num_rows() == 0)
		{	
		    //return '0';
		    $frnd_array['friend_status']='0';
		    $frnd_array['requester_user_id']='0';
		    $frnd_array['receiver_user_id']='0';
		    $frnd_array['friendship_id']=0;
		    return $frnd_array;
		    
		}
		else
		{
			 $row = $query->row();	
			 $frnd_array['friend_status']=$row->status;
		    $frnd_array['requester_user_id']=$row->requester_user_id;
		    $frnd_array['receiver_user_id']=$row->receiver_user_id;
		     $frnd_array['friendship_id']=$row->friendship_id;
		    return $frnd_array;
			//return $row->status;
		}

    } //End of View  function
    
    	function remove_friend($user_id,$friend_user_id)
    {
		$sqlcheck ="DELETE FROM friendships
WHERE (requester_user_id = ".$user_id." AND receiver_user_id =".$friend_user_id.")
   OR (requester_user_id = ".$friend_user_id." AND receiver_user_id = ".$user_id.")";
		
		
		
		//echo $count;
		//die;
		$query = $this->db->query($sqlcheck);	
		return true;

    } 
    
	
	function already_friend($user_id,$friend_user_id)
    {
		$sqlcheck ="SELECT * from friendships where (receiver_user_id =".$user_id." and 
		requester_user_id=".$friend_user_id.") or (requester_user_id =".$user_id." and 
		receiver_user_id=".$friend_user_id.")";
		//echo $count;
		//die;
		$query = $this->db->query($sqlcheck);	
		return $query->num_rows();

    } //End of View  function
	
	function pending_friend_request_count($user_id)
	{   
	    $this->db->select('friendships.friendship_id,friendships.status,users.user_id,users.first_name,users.last_name,users.gender,users.user_online_status,users.email,users.mobile_no1,users.user_photo');
	    $this->db->join('friendships', 'friendships.requester_user_id = users.user_id');
	 	$this->db->where('users.is_active','1');
		$this->db->where('users.user_type','U');
		$this->db->where('friendships.status','2');
		$this->db->where('friendships.receiver_user_id',$user_id);
		$this->db->order_by("users.first_name", "asc");
		$this->db->order_by("users.last_name", "asc");
		$query=$this->db->get('users');
		$resultdata = $query->result_array(); 
		//print $_SERVER['REMOTE_ADDR'];
	//	echo "--->".$this->db->last_query();
		$row_info=array();
		return $query->num_rows();
		 
	}

	function pending_friend_request_count_pending($user_id,$page_no,$limit)
	{   
	    $offset=($page_no*$limit)-$limit;
	    $this->db->select('friendships.friendship_id,friendships.status,users.user_id,users.first_name,users.last_name,users.gender,users.user_online_status,users.email,users.mobile_no1,users.user_photo');
	    $this->db->join('friendships', 'friendships.requester_user_id = users.user_id');
	 	$this->db->where('users.is_active','1');
		$this->db->where('users.user_type','U');
		$this->db->where('friendships.status','2');
		$this->db->where('friendships.receiver_user_id',$user_id);
		$this->db->order_by("users.first_name", "asc");
		$this->db->order_by("users.last_name", "asc");
		$query=$this->db->get('users');
		$resultdata = $query->result_array(); 
		//print $_SERVER['REMOTE_ADDR'];
	//	echo "--->".$this->db->last_query();
		$row_info=array();
		return $query->num_rows();
		 
	}
	function pending_friend_request($user_id,$page_no,$limit)
	{   
	    $offset=($page_no*$limit)-$limit;
	    
	    $this->db->select('friendships.friendship_id,friendships.status,users.user_id,users.first_name,users.last_name,users.gender,users.user_online_status,users.email,users.mobile_no1,users.user_photo');
	    $this->db->join('friendships', 'friendships.requester_user_id = users.user_id');
	 	$this->db->where('users.is_active','1');
		$this->db->where('users.user_type','U');
		$this->db->where('friendships.status','2');
		$this->db->where('friendships.receiver_user_id',$user_id);
		$this->db->order_by("users.first_name", "asc");
		$this->db->order_by("users.last_name", "asc");
		$this->db->limit($limit, $offset);
		$query=$this->db->get('users');
		
		$resultdata = $query->result_array(); 
		//print $_SERVER['REMOTE_ADDR'];
	//	echo "--->".$this->db->last_query();
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $user_id=$row['user_id'];
			//Get User Photo Path 
		    if($row!='user_photo'){
				$row['user_photo_path'] = base_url().'assets/users/'.$row['user_id'].'/'.$row['user_photo'];
			}else{
				 if($row['gender']=='m')
				  $row['user_photo_path'] = base_url().'images/male.jpg';
				 elseif($row['gender']=='f')
				  $row['user_photo_path'] = base_url().'images/female.jpg';
				 else
				  $row['user_photo_path'] = base_url().'assets/image-not-available.jpg';
			    }
				$fileexist=$this->check_filexists($row['user_photo_path']);
				$row['user_photo_path'] =$fileexist;
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
	
	function request_status_update($friendship_id,$user_id,$status){
	  //  print $friendship_id.'-'.$user_id;
		$status_data = array(
			 'status'=>$status,
		 	 'friend_acknowledge_timestamp'=>date('Y-m-d H:i:s')
           );
		$this->db->where('friendship_id',$friendship_id);
		//$this->db->where('receiver_user_id',$user_id);
	 	$updateresult=$this->db->update('friendships',$status_data);
	    //print $this->db->last_query();
	    
	    if($status==0){
	        $reset = array(
			 'requester_user_id'=>0,
		 	 'receiver_user_id'=>0,
		 	 'status'=>0,
           );
           $this->db->where('friendship_id',$friendship_id);
		//$this->db->where('receiver_user_id',$user_id);
	 	$updateresult=$this->db->update('friendships',$reset);
	    }
	    
	  return $updateresult;
	   
	}
	
	
	function friend_list_count($user_id,$search_keyword)
	{   
	    if($search_keyword!=''){
	        $search_key="and users.first_name like '%$search_keyword%'";
	    }
	    //	$offset=($page_no*$limit)-$limit;
	    $sql="SELECT friendships.requester_user_id AS friend_id, user_id,first_name,last_name,gender,email,mobile_no1,user_photo,user_online_status,latitude,longitude FROM friendships,users WHERE receiver_user_id =".$user_id." AND friendships.requester_user_id = users.user_id and users.is_active ='1'  and friendships.status ='1' UNION SELECT friendships.receiver_user_id AS friend_id, user_id,first_name,last_name,gender,email,mobile_no1,user_photo,user_online_status,latitude,longitude FROM friendships,users WHERE requester_user_id =".$user_id." AND friendships.receiver_user_id = users.user_id  and users.is_active ='1'  and friendships.status ='1' $search_key";//and users.is_active ='1'  and friendships.status ='2'
	   //rint $sql;
    	    $query = $this->db->query($sql);
	    return $query->num_rows();
	}
	
	function friend_list($user_id,$search_keyword,$page_no,$limit)
	{   
	     if($search_keyword!=''){
	        $search_key="and users.first_name like '%$search_keyword%'";
	    }
	    	$offset=($page_no*$limit)-$limit;
	    $sql="SELECT friendships.requester_user_id AS friend_id, user_id,first_name,last_name,gender,email,mobile_no1,user_photo,response_code,user_online_status,latitude,longitude FROM friendships,users WHERE receiver_user_id =".$user_id." AND friendships.requester_user_id = users.user_id and users.is_active ='1'  and friendships.status ='1' UNION SELECT friendships.receiver_user_id AS friend_id, user_id,first_name,last_name,gender,email,mobile_no1,user_photo,response_code,user_online_status,latitude,longitude FROM friendships,users WHERE requester_user_id =".$user_id." AND friendships.receiver_user_id = users.user_id  and users.is_active ='1'  and friendships.status ='1' $search_key limit $offset, $limit";//and users.is_active ='1'  and friendships.status ='2'
	  //print $sql;
	    $query = $this->db->query($sql);
		$resultdata = $query->result_array(); 
		//echo "--->".$this->db->last_query();
		//die();
		$row_info=array();
		if($query->num_rows()>0){
			foreach($resultdata as $key=>$row){
		    $user_id=$row['user_id'];
			//Get User Photo Path 
		    /*if($row!='user_photo'){
		        if($row['user_photo']==''){
		         $row['user_photo_path'] = base_url().'images/male.jpg';
		        }else{
		             $userpath=base_url().'assets/users/'.$row['user_id'].'/'.$row['user_photo'];
		            $fileexist=$this->check_filexists($userpath);
				$row['user_photo_path'] =$fileexist;
		        }
			}else{
				 if($row['gender']=='m')
				  $row['user_photo_path'] = base_url().'images/male.jpg';
				 elseif($row['gender']=='f')
				  $row['user_photo_path'] = base_url().'images/female.jpg';
				 else
				  $row['user_photo_path'] = '';
			    }*/
			    
			    $photo= $row['user_photo'];
			   $resp=$row['response_code'];
		
			if($row!='response_code'){    
    			if($row['response_code']!=NULL){
    			    $responsedecode=json_decode($row['response_code'],true);
    			    if($responsedecode['user_dp']!='')
    			    $row['user_photo_path']=$responsedecode['user_dp'];
    			}
			}
				if($row!='user_photo'){    
		        if($photo!=''){
			    	$row['user_photo_path']=users_photo_path.$photo;
			    }
			}
			$fileexist=$this->check_filexists($row['user_photo_path']);
			$row['user_photo_path'] =$fileexist;
			if($row['user_photo_path']=='' || $row['user_photo_path']==null){
			    $row['user_photo_path'] =base_url().'images/male.jpg';
			}
			    
			   
			    
			    
			   $row_info[] = $row;	
			}
			   return $row_info;
		 } else {
			   return $row_info;
		       }
	}
		
	function check_filexists($filename){
	    
	    $ch = curl_init($filename);
        curl_setopt($ch, CURLOPT_NOBODY, true);
        curl_exec($ch);
        $responseCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        //print $responseCode.'-'.$filename;
        if($responseCode == 200){
            return $filename;
        }else{
             return base_url().'images/male.jpg';
             //return base_url().'assets/image-not-available.jpg';
        }
	
	}
	
}
?>