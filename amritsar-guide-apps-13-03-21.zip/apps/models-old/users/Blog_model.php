<?php

class Blog_model extends CI_Model
{
   
   function addBlog(){
	
         $data          = array(
		    'language_id'=>$this->session->userdata('lang_id'),
		    'created_by'=>$this->session->userdata('user_id'),
            'category_id'     		=>  $this->category_id,
            'title'     	=>  $this->title,
            'description'     		=>  $this->description,
            'status'     		=>  '0',
            'visibility'     		=>  $this->visibility,
            'user_type'     		=>  'U',
            
            'video_url'     	=>  $this->video_url,
           
            'created_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result  = $this->db->insert('blogs', $data);
		
		$id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0;
   
   }//End of addBlog
	
   function add_icon($blog_id,$filename)
   {			
		$data     = array(
			'image_url'     => time().'_'.$blog_id.'_'.$filename
		);
		$this->db->where('blog_id', $blog_id);
		$result = $this->db->update('blogs', $data);
   }
	
   function editBlog(){
           $data          = array(
            'modified_by' =>$this->session->userdata('user_id'),
            'category_id'     		=>  $this->category_id,
            'title'     	=>  $this->title,
            'description'     		=>  $this->description,
			'visibility'     		=>  $this->visibility,
            'video_url'     	=>  $this->video_url
        );
		$this->db->where('blog_id', $this->blog_id);
        $result  = $this->db->update('blogs', $data);
		if($result)
			return $this->blog_id;
		else
			return 0;
   }//End of editBlog
   
   function editBlogData(){
		$this->db->where('blog_id',$this->blog_id);         
		$query  = $this->db->get('blogs');		  
   		$result = $query->row(); 

		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editBlogData
   
   function viewBlogs($category_id,$title, $limit, $start){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, blogs.*, blog_categories.category_name");	
		$this->db->join('blog_categories','blogs.category_id=blog_categories.category_id','left');
		$this->db->join('users','blogs.created_by=users.user_id');
		$this->db->where('blogs.language_id',$this->session->userdata('lang_id'));
		$this->db->where('blogs.created_by',$this->session->userdata('user_id'));
		
		if($category_id!='0')
		$this->db->where('blogs.category_id', $category_id);
	
		if($title!='') {
			$this->db->like('blogs.title', $title);
			$this->db->or_like('blogs.description', $title);
		} 
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
		
		$query=$this->db->order_by('blog_id','desc');
		$query=$this->db->get('blogs');
		//echo $this->db->last_query();die;
   		
		
		$result = $query->result(); 
		return $result;
   } // End of viewBlog
   
   function update_visibilitystatus($blog_id, $status)
    {
		 if($status=='public')
		 {	$data = array(
				'visibility' => $status,
			);
		 }
		 else
		 {
			$data = array(
				'visibility' => $status,
			);
		 }
        $this->db->where('blog_id', $blog_id);
        $result = $this->db->update('blogs', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
	function update_approvalstatus($blog_id, $status)
    {
		 $data = array(
				'approval_status' => $status,
		 );
	
        $this->db->where('blog_id', $blog_id);
        $result = $this->db->update('blogs', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
   function countblogrecords(){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, blogs.*, blog_categories.category_name");	
		$this->db->join('blog_categories','blogs.category_id=blog_categories.category_id','left');
		$this->db->join('users','blogs.created_by=users.user_id');
		$this->db->where('blogs.language_id',$this->session->userdata('lang_id'));
		$this->db->where('blogs.created_by',$this->session->userdata('user_id'));
		
		$query=$this->db->get('blogs');
   		return $num = $query->num_rows(); 
   }
   
}
?>