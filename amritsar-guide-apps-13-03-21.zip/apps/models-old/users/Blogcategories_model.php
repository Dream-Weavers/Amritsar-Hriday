<?php

class Blogcategories_model extends CI_Model
{
   
   function addCategories(){
	
         $data          = array(
			'language_id'=>$this->session->userdata('lang_id'),
            'category_name'     	=>  $this->category_name,
            'description'     		=>  $this->description,
            'post_date'       		=>  date('Y-m-d H:i:s'),
        );
        $result = $this->db->insert('blog_categories', $data);
		
		$id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0;
   
   }//End of addCategories
	
	
   function editCategories(){
           $data          = array(
             'category_name'     	=>  $this->category_name,
            'description'     		=>  $this->description
        );
		$this->db->where('category_id', $this->category_id);
        $result  = $this->db->update('blog_categories', $data);

		if($result)
			return $this->category_id;
		else
			return 0;
   }//End of editCategories
   
   function editCategoriesData(){
		$this->db->where('category_id',$this->category_id);         
		$query  = $this->db->get('blog_categories');		  
   		$result = $query->row(); 

		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editCategoriesData
   
   
   
   function viewCategories(){
		$this->db->select('*');	
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('blog_categories');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } // End of viewCategories
}
?>