<?php
class Ajaxrequestmodel extends CI_Model
{
		  /*=========== Get states ===========*/
		 function get_states($country_id){ 
				$this->db->select('state_id,state_name');
				$this->db->where('country_id',$country_id);
				$this->db->where('is_active','1');
				$query = $this->db->get('state');	  	
				$result=$query->result(); 
				//echo $this->db->last_query();die;	
				return json_encode($result);
		 }
		 
		  /*=========== Get locations ===========*/
		 function get_locations($search_text,$language_id){ 
				$this->db->select('*');
				if($search_text!='')
				$this->db->like('location_name', $search_text);
				$this->db->where('language_id',$language_id);
				//$this->db->where('location_name',$search_text);
				//$this->db->where('is_active','1');
				$query = $this->db->get('locations');	  	
				$result=$query->result(); 
				//echo $this->db->last_query();die;	
				return json_encode($result);
		 }
		 
		 function get_locations_category($search_text){ 
		 
				$this->db->select('a.*,b.*'); 
				$this->db->from('locations a');
				$this->db->join('location_categories b', 'b.location_id = a.location_id'); 
				$this->db->where('b.category_id',$search_text);
				$query = $this->db->get();
				$result=$query->result(); 
				//echo $this->db->last_query();die;	
				return json_encode($result);
					
				/* $this->db->select('*');
				if($search_text!='')
				$this->db->like('location_name', $search_text);
				//$this->db->where('location_name',$search_text);
				//$this->db->where('is_active','1');
				$query = $this->db->get('locations');	  	
				$result=$query->result(); 
				//echo $this->db->last_query();die;	
				return json_encode($result); */
		 }
		 
		 /*=========== Get city list ===========*/
		 function get_cities($state_id){ 
				$this->db->select('city_id,city_name');
				$this->db->where('state_id',$state_id);
				$this->db->where('is_active','1');
				$query = $this->db->get('city');	  	
				$result=$query->result(); 
				//echo $this->db->last_query();die;	
				return json_encode($result);
		 }
		 
		 /*=========== Get location list ===========*/
		 function get_location($category_id){ 
				$this->db->select('locations.location_id,locations.location_name');
				$this->db->join('locations','location_categories.location_id=locations.location_id');
				$this->db->where('location_categories.category_id',$category_id);
				$this->db->where('location_categories.is_active','1');
				$this->db->where('locations.is_active','1');
				$query = $this->db->get('location_categories');	  	
				$result=$query->result(); 
				//echo $this->db->last_query();die;	
				return json_encode($result);
		 }
		 
		 /*=========== Get All Locations Filteration ===========*/
		 function get_all_locations($category_type_id=NULL,$category_id=NULL,$location_id=NULL){ 
				$this->db->select('locations.location_id, locations.location_name,locations.estimated_visit_time ,state.state_name,locality.locality_name,city.city_name,location_categories.category_type_id,location_categories.category_id');
				$this->db->join('locality','locality.locality_id=locations.locality_id');
				$this->db->join('state','state.state_id=locations.state_id');
				$this->db->join('city','city.city_id=locations.city_id');
				$this->db->join('location_categories','locations.location_id=location_categories.location_id');
				$this->db->where('locations.is_active','1');
				
				if($category_type_id!='-1' && $category_type_id!=''){
					$this->db->join('location_categories','locations.location_id=location_categories.location_id');
					$this->db->where('location_categories.category_type_id', $category_type_id);
					$this->db->where('location_categories.is_active','1');
					
				}
				if($category_id!='-1' && $category_id!=''){
					$this->db->join('location_categories','locations.location_id=location_categories.location_id');
					$this->db->where('location_categories.category_id', $category_id);
					$this->db->where('location_categories.is_active','1');
				}
				if($location_id!='-1' && $location_id!=''){
					$this->db->join('location_categories','locations.location_id=location_categories.location_id');
					$this->db->where('location_categories.location_id', $location_id);
					$this->db->where('location_categories.is_active','1');
				}
				$this->db->where('location_categories.is_active','1');	 
				$this->db->group_by("location_categories.location_id");				
				//$this->db->group_by(array("location_categories.category_type_id", "location_categories.category_id","location_categories.location_id"));				
				$query = $this->db->get('locations');	  	
				$result=$query->result(); 
				
				/* echo "<pre>";
				print_r($result);
				die; */
				
				$estimated_time_array = get_estimated_time_array();

				foreach($result as $key=>$row){
					 if($row->estimated_visit_time!='00:00:00' && $row->estimated_visit_time!='')
					 $result[$key]->estimated_visit_time = $estimated_time_array[$row->estimated_visit_time]; 
					 else
					 $result[$key]->estimated_visit_time='';
				}
															 
				//echo $this->db->last_query();die;	
				return json_encode($result);
		 }
		 
		 /*=========== Get locality list ===========*/
		 function get_localities($city_id){ 
				$this->db->select('locality_id,locality_name');
				$this->db->where('city_id',$city_id);
				$this->db->where('is_active','1');
				$query = $this->db->get('locality');	  	
				$result=$query->result(); 
				//echo $this->db->last_query();die;	
				return json_encode($result);
		 }
			  
		 function get_category($category_type_id){ 
				$this->db->select('category_id,category_name');
				$this->db->where('category_type_id',$category_type_id);
				$this->db->where('is_active','1');
				$this->db->order_by('category_name','ASC');
				$query = $this->db->get('categories');	  	
				$result=$query->result(); 
				//echo $this->db->last_query();die;	
				return json_encode($result);
		 }
		
		 function get_credentials($email,$password){ 
				$this->db->select('email,password');
				$this->db->where('email',$email);
				$this->db->where('password',md5($password));
				$this->db->where('user_type','S');
				$query = $this->db->get('users');
				if($query->num_rows>0){
					$result=$query->row(); 
					return json_encode($result);
				}else{
					return false;
				}
		 }
		 
		 function delete_survey_collection_record($survey_gal_id){ 
			$this->db->where('survey_gal_id', $survey_gal_id);
			$this->db->delete('survey_attribute_collection');
		 }
		 
	function get_locations_limit($limit,$lang_id){
		$this->db->select('location_id,location_name,short_name,address,state_id,city_id,pin_code');
		$this->db->where('language_id',$lang_id);
		$this->db->order_by('location_id','desc');
		$this->db->limit($limit, 0);
		$query = $this->db->get('locations');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result);
	}	
	
	function get_trails_limit($limit,$lang_id){
		$this->db->select('tour_trail_id,tour_trail_name,tour_trail_image');
		$this->db->where('language_id',$lang_id);
		$this->db->where('user_id',1);
		$this->db->order_by('tour_trail_id','desc');
		$this->db->limit($limit, 0);
		$query = $this->db->get('tour_trails');	  	
		
		$result=$query->result(); 
		foreach($result as $row){
		    $trail_id=$row->tour_trail_id;
		    $row->locations=$this->trail_locations($trail_id);
		}
			
		return json_encode($result);
	}	
	
	function trail_locations($trail_id){
	    $this->db->select('locations.location_name');
	    $this->db->join('locations','tour_trail_locations.location_id=locations.location_id');
		$this->db->order_by('tour_trail_locations.weight','desc');
		$this->db->where('tour_trail_locations.tour_trail_id',$trail_id);
		$this->db->limit($limit, 0);
		$query = $this->db->get('tour_trail_locations');	  	
		$result=$query->result(); 
		$locations=array();
		$implode='';
		foreach($result as $row){
		    $locations[]=$row->location_name;
		}
		$implode=implode(',',$locations);
		//echo $this->db->last_query();die;	
		return $implode;
	}
	
	function get_categories_limit($limit,$lang_id){
		$this->db->select('category_name,description,icon,is_active');
		$this->db->order_by('category_id','desc');
		$this->db->where('language_id',$lang_id);
		$this->db->limit($limit, 0);
		$query = $this->db->get('categories');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result);
	}
	
	  /*=========== Get kiosks ===========*/
	 function get_kiosks($kiosk_category_id){ 
			$this->db->select('kiosk_id,kiosk_name,mac_id');
			$this->db->where('kiosk_category_id',$kiosk_category_id);
			$this->db->where('is_active','1');
			$this->db->order_by('kiosk_name','asc');
			$query = $this->db->get('kiosks');	  	
			$result=$query->result(); 
			//echo $this->db->last_query();die;	
			return json_encode($result);
	 }
		 
	
	  function get_Category_List($category_type_id,$default_opt)
		{
			$result = array();
			$str = '';
			if($category_type_id!='0' && $category_type_id!='')
			{		
				$this->db->select('*');
				$this->db->from('categories');
				$this->db->where('language_id',$this->session->userdata('lang_id'));
				$this->db->where('category_type_id',$category_type_id);
				$this->db->where('category_parent_id','0');
				$this->db->where('is_active','1');
				$this->db->order_by('weight', 'ASC');
				$query = $this->db->get();
				$result = $query->result();
			
			
				$str.="<div class='locationrights'>";
				  $class='all_select';
				  $str_val='location_category';
				
				foreach($result as $res){
					$name=strtoupper($res->category_name);
					$ids=$res->category_id;
					
								
					if(is_array($default_opt))
					{	$key = array_search($ids,$default_opt);
						if( $key !== false ) {
						   $checked='checked';
						} else {
						   $checked='';
						}
					}else
					{	 $checked='';
					}
					
					$field = array('category_parent_id'=>$res->category_id,'category_type_id'=>$category_type_id);
					$cat_row = gettableinfo('categories',$field);
					$str.= "<div class='md-checkbox'><input  class='".$class." md-check parent".$ids."' type='checkbox' ".$checked."  name='".$str_val."[]' id='".$str_val."".$ids."' value='".$ids."'><label for='".$str_val."".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name."</label></div>";
					
				$str.=$this->get_child_checkbox($ids,$res->category_type_id,$default_opt,'parent',$ids);
				}
				$str.= "</div>";
				//echo $this->db->last_query();
				
			}
			
			if($result!=null)
			{ 
		
			}
			else
			{
				$str = 'This Category Type does not contain any categories.';
			}			
			echo $str;
	}
	
	//for frontend
	function get_categories_list($category_type_id){ 
		if($this->session->userdata('lang_id')==''){
			$language_id=1;
		} else {
			$language_id=$this->session->userdata('lang_id');
		}
				$this->db->select('*');
				$this->db->from('categories');
				$this->db->where('language_id',$language_id);
				$this->db->where('category_type_id',$category_type_id);
				$this->db->where('category_parent_id','0');
				$this->db->where('is_active','1');
				$this->db->order_by('weight', 'ASC');
				$query = $this->db->get();
				$result = $query->result();
				return json_encode($result);
		 }
		 
	
	
	   function get_Kioskcategorylist($kiosk_category_id,$default_opt)
		{
			 $result = array();
			 $str = '';
		
				$this->db->select('*');
				$this->db->from('kiosks');
				$this->db->where('language_id',$this->session->userdata('lang_id'));
				if($kiosk_category_id!='0')
				$this->db->where('kiosk_category_id',$kiosk_category_id);
				$this->db->where('is_active','1');
				$this->db->order_by('kiosk_name', 'ASC');
				$query = $this->db->get();
				$result = $query->result();
				//echo $this->db->last_query();
			
				$str.="<div class='locationrights'>";
				  $class='all_select';
				  $str_val='kiosk_id';
				
				foreach($result as $res){
					$kiskrow = get_table_info('kiosk_categories','kiosk_category_id',$res->kiosk_category_id);
					
					$name=$kiskrow->category_name.' - '.strtoupper($res->kiosk_name);
					$ids=$res->kiosk_id;
					
								
					if(is_array($default_opt))
					{	$key = array_search($ids,$default_opt);
						if( $key !== false ) {
						   $checked='checked';
						} else {
						   $checked='';
						}
					}else
					{	 $checked='';
					}
					
					$field = array('kiosk_id'=>$res->kiosk_id,'kiosk_category_id'=>$kiosk_category_id);
					$str.= "<div class='md-checkbox'><input  class='".$class." md-check parent".$ids."' type='checkbox' ".$checked."  name='".$str_val."[]' id='".$str_val."".$ids."' value='".$ids."'><label for='".$str_val."".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name."</label></div>";
			
				}
				$str.= "</div>";
				//echo $this->db->last_query();
			if($result!=null)
			{ 
		
			}
			else
			{
				$str = 'This Category does not contain any Kiosk.';
			}			
			echo $str;
	}
	
	
	   function getKioskcategorylist($kiosk_category_id,$default_opt)
		{
				$result = array();
				$str = '';
		
				$this->db->select('*');
				$this->db->from('kiosks');
				$this->db->where('language_id',$this->session->userdata('lang_id'));
				if($kiosk_category_id!='0')
				$this->db->where('kiosk_category_id',$kiosk_category_id);
				$this->db->where('is_active','1');
				$this->db->order_by('kiosk_name', 'ASC');
				$query = $this->db->get();
				$result = $query->result();
				//echo $this->db->last_query();
			
				$str.="<div class='locationrights'>";
				  $class='all_select';
				  $str_val='kiosk_id';
				
				foreach($result as $res){
					$kiskrow = get_table_info('kiosk_categories','kiosk_category_id',$res->kiosk_category_id);
					
					$name=$kiskrow->category_name.' - '.strtoupper($res->kiosk_name);
					$ids=$res->kiosk_id;
					
								
					if(is_array($default_opt))
					{	$key = array_search($ids,$default_opt);
						if( $key !== false ) {
						   $checked='checked';
						} else {
						   $checked='';
						}
					}else
					{	 $checked='';
					}
					
					
					$str.= "<div class='md-checkbox'><input  class='".$class." md-check parent".$ids."' type='checkbox' ".$checked."  name='".$str_val."[]' id='".$str_val."".$ids."' value='".$ids."'><label for='".$str_val."".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name."</label></div>";
				
				}
				$str.= "</div>";
				//echo $this->db->last_query();
			if($result!=null)
			{ 
		
			}
			else
			{
				$str = 'This Category does not contain any Kiosk.';
			}			
			echo $str;
	}
	
	
	   function getalreadyupdatedKiosklist()
		{
				$result = array();
				$str = '';
		
				$this->db->select('kiosks.kiosk_id,kiosks.kiosk_name,kiosks.kiosk_category_id,location_kiosks.location_kiosk_id');
				$this->db->join('kiosks', 'kiosks.kiosk_id = location_kiosks.kiosk_id');
				$this->db->from('location_kiosks');
				$this->db->where('location_kiosks.is_active','1');
				$this->db->order_by('location_kiosks.kiosk_id', 'ASC');
				$query = $this->db->get();
				$result = $query->result();
				//echo $this->db->last_query();
			
			    $str.="<div class='locationrights'>";
			    $class='all_select';
			    $str_val='already_kiosk_id';
				foreach($result as $res){
					$kiskrow = get_table_info('kiosk_categories','kiosk_category_id',$res->kiosk_category_id);
					
					$name=$kiskrow->category_name.' - '.strtoupper($res->kiosk_name);
					$ids=$res->kiosk_id;
					
								
					if(is_array($default_opt))
					{	$key = array_search($ids,$default_opt);
						if( $key !== false ) {
						   $checked='checked';
						} else {
						   $checked='';
						}
					}else
					{	 $checked='';
					}
					
					//$str.= '<i class="fa fa-check fa-2x"></i>&nbsp;&nbsp;'.$name.'<a class="label label-sm label-danger"><i class="fa fa-close"></i></a><br>';
					$str.= '<i class="fa fa-check fa-2x"></i>&nbsp;&nbsp;'.$name.'<br>';
					//$str.= "<input  class='".$class." md-check parent".$ids."' ".$checked."  name='".$str_val."[]' id='".$str_val."".$ids."' value='".$ids."'><label for='".$str_val."".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name."</label></div>";
				
				}
				$str.= "</div>";
				//echo $this->db->last_query();
			if($result!=null)
			{ 
		
			}
			else
			{
				$str = 'Not Updated any Kiosk.';
			}			
			echo $str;
	}
	
	
	  function get_child_checkbox($cid,$category_type_id,$default_opt,$child_sta,$parentid){
		$str_data='';
		$this->db->from('categories');
		$this->db->where('category_parent_id',$cid);
		$this->db->where('language_id',$this->session->userdata('lang_id'));
		$this->db->where('category_type_id',$category_type_id);
		$this->db->where('is_active','1');
		$this->db->order_by('weight', 'ASC');
		$query = $this->db->get();
		//echo $this->db->last_query();
		$countrows=$query->num_rows();
		if($countrows>0){
			$result = $query->result();
			$str_data.= "<ul>";
			foreach($result as $childs){//echo "<pre>";print_r($childs);
				$name_get=strtoupper($childs->category_name);
				$ids=$childs->category_id;
			    $checked='';
			    if(is_array($default_opt))
				{
					$key = array_search($ids,$default_opt);
					if( $key !== false ) {
					   $checked='checked';
					} else {
					   $checked='';
					}
				}
				 $class='all_select';
				 $str_val='location_category';
			
				if($child_sta=='child'){
					$parentget=$parentid;
				}else{
					$parentget=$cid;
				}
				$classname = str_replace(' ', '_', $name_get);//echo $parentget;
				$str_data.=  "<div class='md-checkbox'><input class='md-check ".$class." getParentid$cid getAncestorid$parentget'  type='checkbox' ".$checked."  name='".$str_val."[]' id='".$str_val."".$ids."' value='".$ids."'><label for='".$str_val."".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name_get."</label></div>";
				$nameof= $this->get_child_checkbox($childs->category_id,$childs->category_type_id,$default_opt,'child',$cid); 
			}
			$str_data.= "</ul>";
		}else{
			$str_data.= "";
		}
		
		return $str_data;
	  }
	  
	  function get_CategoryLanguage_List($category_type_id,$default_opt)
			{
			
		   /*echo "<pre>";
			print_r($default_opt);	
			echo "</pre>"; 
			die();*/
			$result = array();
			$str = '';
			if($category_type_id!='0' && $category_type_id!='')
			{		
				$this->db->select('*');
				$this->db->from('categories');
				$this->db->where('language_id',$this->session->userdata('content_language_id'));
				$this->db->where('category_type_id',$category_type_id);
				$this->db->where('category_parent_id','0');
				$this->db->where('is_active','1');
				$this->db->order_by('weight', 'ASC');
				$query = $this->db->get();
				$result = $query->result();
				/* echo "<pre>";
				print_r($result);
				die; */
				$str.="<div class='locationrights'>";
				  $class='all_select';
				  $str_val='location_category';
				
				foreach($result as $res){
					$name=strtoupper($res->category_name);
					$ids=$res->category_id;
					
								
					if(is_array($default_opt))
					{	$key = array_search($ids,$default_opt);
						if( $key !== false ) {
						   $checked='checked';
						} else {
						   $checked='';
						}
					}else
					{	 $checked='';
					}
					
					$field = array('category_parent_id'=>$res->category_id,'category_type_id'=>$category_type_id);
					$cat_row = gettableinfo('categories',$field);
					$str.= "<div class='md-checkbox'><input  class='".$class." md-check parent".$ids."' type='checkbox' ".$checked."  name='".$str_val."[]' id='".$str_val."".$ids."' value='".$ids."'><label for='".$str_val."".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name."</label></div>";
					
				$str.=$this->get_child_checkbox_lang($ids,$res->category_type_id,$default_opt,'parent',$ids);
				}
				$str.= "</div>";
				//echo $this->db->last_query();
				
			}
			
			if($result!=null)
			{ 
		
			}
			else
			{
				$str = 'This Category Type does not contain any categories.';
			}			
			echo $str;
	}
	  function get_child_checkbox_lang($cid,$category_type_id,$default_opt,$child_sta,$parentid){
		$str_data='';
		$this->db->from('categories');
		$this->db->where('category_parent_id',$cid);
		$this->db->where('language_id',$this->session->userdata('content_language_id'));
		$this->db->where('category_type_id',$category_type_id);
		$this->db->where('is_active','1');
		$this->db->order_by('weight', 'ASC');
		$query = $this->db->get();
		//echo $this->db->last_query();
		$countrows=$query->num_rows();
		if($countrows>0){
			$result = $query->result();
			$str_data.= "<ul>";
			foreach($result as $childs){//echo "<pre>";print_r($childs);
				$name_get=strtoupper($childs->category_name);
				$ids=$childs->category_id;
			    $checked='';
			    if(is_array($default_opt))
				{
					$key = array_search($ids,$default_opt);
					if( $key !== false ) {
					   $checked='checked';
					} else {
					   $checked='';
					}
				}
				 $class='all_select';
				 $str_val='location_category';
			
				if($child_sta=='child'){
					$parentget=$parentid;
				}else{
					$parentget=$cid;
				}
				$classname = str_replace(' ', '_', $name_get);//echo $parentget;
				$str_data.=  "<div class='md-checkbox'><input class='md-check ".$class." getParentid$cid getAncestorid$parentget'  type='checkbox' ".$checked."  name='".$str_val."[]' id='".$str_val."".$ids."' value='".$ids."'><label for='".$str_val."".$ids."'><span></span><span class='check'></span><span class='box'></span>".$name_get."</label></div>";
				$nameof= $this->get_child_checkbox($childs->category_id,$childs->category_type_id,$default_opt,'child',$cid); 
			}
			$str_data.= "</ul>";
		}else{
			$str_data.= "";
		}
		
		return $str_data;
	  }
	  
	  function get_locations_modulewise($module_id){
		$this->db->select('module_interlinks.location_id');
		$this->db->where('module_interlinks.module_id',$module_id);
		$query=$this->db->get('module_interlinks');
		$result = $query->result();	
		foreach($result as $row){
			$ids[] = $row->location_id;
		}
		$this->db->select('locations.location_id,locations.location_name');
		$this->db->where_not_in('locations.location_id', $ids);
		$query=$this->db->get('locations');
		$result1 = $query->result();	
		return json_encode($result1);
	}
	
	function get_category_locations_modulewise($module_id,$category_id){
		$this->db->select('module_interlinks.location_id');
		$this->db->where('module_interlinks.module_id',$module_id);
		$query=$this->db->get('module_interlinks');
		$result = $query->result();	
		foreach($result as $row){
			$ids[] = $row->location_id;
		}
		
		$this->db->select('a.*,b.*'); 
		$this->db->from('locations a');
		$this->db->join('location_categories b', 'b.location_id = a.location_id'); 
		$this->db->where('b.category_id',$category_id);
		$this->db->where_not_in('a.location_id', $ids);
		$query = $this->db->get();
		$result=$query->result(); 
		
		return json_encode($result);
	}
	function get_categorytypes($language_id){
		$this->db->select('*');
		$this->db->order_by('category_type_id','desc');
		$this->db->where('language_id',$language_id);
		$query = $this->db->get('category_types');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result);
	}
	
	function get_category_type_limit($limit,$language_id){
		$this->db->select('category_type,description,icon,is_active');
		$this->db->order_by('category_type_id','desc');
		$this->db->where('language_id',$language_id);
		$this->db->limit($limit, 0);
		$query = $this->db->get('category_types');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result);
	}
	/*function get_slides_limit($limit,$lang_id){
		$this->db->select('slide_title,slide_file_name');
		$this->db->order_by('slide_id','desc');
		$this->db->where('language_id',$lang_id);
		$this->db->limit($limit, 0);
		$query = $this->db->get('slides');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result);
	}*/
	function get_slides_limit($limit,$lang_id){
		$this->db->select('location_name,location_id');
		$this->db->order_by('location_id','desc');
		$this->db->where('language_id',$lang_id);
		$this->db->limit($limit, 0);
		$query = $this->db->get('locations');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	 
		foreach($result as $row){
		    $loc_id=$row->location_id;
		    $getpath = $this->defaultDigitalMedia($loc_id,gallery_files);
		    if($getpath->media_file_name!=''){
			    $filename=base_url().gallery_path.$getpath->media_file_name;
				$row->image_path= $filename;
			}else{
				$row->image_path= '';
			}
		    
		}
		//echo $this->db->last_query();die;	
		return json_encode($result);
	}
	//$getpath=$this->defaultDigitalMedia($loc_id,gallery_files);
	

	
	function defaultDigitalMedia($location_id,$media_type)
    {
		$this->db->select('media_file_name');
		$this->db->from('location_digital_media');
		$this->db->where('location_digital_media.location_id', $location_id);
		$this->db->where('location_digital_media.media_type', $media_type);
		$this->db->where('location_digital_media.default_media','1');
		$this->db->order_by('location_digital_media.created_on', 'ASC');
		$query = $this->db->get();
		$results = $query->row();
		return $results;

	} //End of View function
	/*function get_slides($lang_id){
		$this->db->select('slide_title,slide_file_name,slide_id');
		$this->db->where('language_id',$lang_id);
		$this->db->order_by('slide_id','desc');
		$query = $this->db->get('slides');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result);
	}*/
	
	function get_slides($lang_id){
		$this->db->select('location_name,location_id');
		$this->db->order_by('location_id','desc');
		$this->db->where('language_id',$lang_id);
		$this->db->limit($limit, 0);
		$query = $this->db->get('locations');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	 
		foreach($result as $row){
		    $loc_id=$row->location_id;
		    $getpath = $this->defaultDigitalMedia($loc_id,gallery_files);
		    if($getpath->media_file_name!=''){
			    $filename=base_url().gallery_path.$getpath->media_file_name;
				$row->image_path= $filename;
			}else{
				$row->image_path= '';
			}
		    
		}
		//echo $this->db->last_query();die;	
		return json_encode($result);
	}
	
	function fieldconfig_types($field_config_id){
		 if($field_config_id==1){
			$unset_field=array(3);
		}else if($field_config_id==4){
			$unset_field=array(1,2);
		}else{
			$unset_field=array(0);
		}
		//print '<pre>';print_r($field_config_id);die;
		$this->db->select('option_id,title');
		$this->db->where('list_id','module_conf_type');
		$this->db->where_not_in('option_id',$unset_field);
		$this->db->order_by('option_id','asc');
		$query = $this->db->get('list_options');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result); 
	}
	function fielmodule_types($category_id,$module_type){
		if($category_id!=1){
			if($module_type==5){
				$unset_field=array(1,2);
			}else if($module_type==4){
				$unset_field=array(3);
			}else if($category_id==4 && $module_type==3){
				$unset_field=array(1,2);
			}else if($category_id==4 && $module_type==1){
				$unset_field=array(1,2);
			}
			else{
				$unset_field=array(0);
			}
		}else{
			$unset_field=array(3);
		}
		$this->db->select('option_id,title');
		$this->db->where('list_id','module_conf_type');
		$this->db->where_not_in('option_id',$unset_field);
		$this->db->order_by('option_id','asc');
		$query = $this->db->get('list_options');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result); 
	}
	
	function getmodule_types($category_id){
		if($category_id==1){
			$unset_field=array(5);
		}else if($category_id==4){
			$unset_field=array(2,4,5,6,7,8);
		}else{
			$category_id=array(0);
			$unset_field=array(6,7,8);
		}
		
		$this->db->select('option_id,title');
		$this->db->where('list_id','module_type');
		$this->db->where_not_in('option_id',$unset_field);
		$this->db->order_by('option_id','asc');
		$query = $this->db->get('list_options');	  	
		$result=$query->result(); 
		//echo $this->db->last_query();die;	
		return json_encode($result); 
	}
	function post_moduleLayout($module_id,$layoutid){
		$this->db->trans_start();
		$data = array( 
			'module_layout'      => $layoutid, 
		);
		$this->db->where('module_id', $module_id);
		$this->db->update('modules', $data);
		$this->db->trans_complete();
		// was there any update or error?
		if ($this->db->affected_rows() >=0) {
			return TRUE;
		} else {
			// any trans error?
			if ($this->db->trans_status() === FALSE) {
				return false;
			}
			return true;
		}
	}
	
	function load_digital_media($entity,$content_id){
        $this->db->select('*');
        $this->db->where('product_id',$content_id);
        $query = $this->db->get($entity.'_digital_media');	  	
        $result=$query->result_array(); 
        //echo $this->db->last_query();die;	
        return json_encode($result); 
	}
	
	function product_delete($pid){
	    $tables = array('products', 'product_translation');
        $this->db->where('product_id', $pid);
        $this->db->delete($tables);
        //product_digital_media
        
        $this->db->select('*');
		$this->db->where('product_id',$pid);
		$query = $this->db->get('product_digital_media');	  	
		$result=$query->result(); 
		unset($tables);
		foreach($result as $row){
		    $media_id=$row->product_media_id;
		    $res=$row->media_file_name;
		    $tables = array('product_digital_media');
            $this->db->where('product_media_id', $media_id);
            $this->db->delete($tables);
            unlink('./assets/products/gallery/'.$res);
            unset($tables);
		}
		$this->db->where('product_id', $pid);
		$this->db->delete('product_digital_media');
		
		return true;
	}
	
	function get_product_listing($category_id){
        $this->db->select('a.*,b.*'); 
        $this->db->from('products a');
        $this->db->join('product_categories b', 'b.product_id = a.product_id'); 
        $this->db->where('b.category_id',$category_id);
        $query = $this->db->get();
        $result=$query->result(); 
        //echo $this->db->last_query();die;	
        return json_encode($result);
	}
	
	function get_all_trails($lan_id){
	    $this->db->select('*'); 
        $this->db->from('tour_trails');
        $this->db->where('language_id',$lan_id);
        $this->db->where('user_id',1);
        $query = $this->db->get();
        $result=$query->result(); 
        //echo $this->db->last_query();die;	
        $options=array();
        foreach($result as $res){
            $options[$res->tour_trail_id]=$res->tour_trail_name;
        }
        return json_encode($options);
	}
	
	function get_latest_vendors_limit($limit,$lang_id){
		$this->db->select('b.first_name,a.*'); 
        $this->db->from('vendor_details a');
        $this->db->join('users b', 'b.user_id = a.user_id'); 
        $this->db->order_by('a.vendor_detail_id','desc');
        $this->db->limit($limit, 0);
        //$this->db->where('b.category_id',$category_id);
        $query = $this->db->get();
        $result=$query->result(); 
        //echo $this->db->last_query();die;	
        return json_encode($result);
	}	
	function get_latest_products_limit($limit,$lang_id){
		$this->db->select('*'); 
        $this->db->from('products a');
        $this->db->order_by('product_id','desc');
        $this->db->limit($limit, 0);
        //$this->db->where('b.category_id',$category_id);
        $query = $this->db->get();
        $result=$query->result(); 
        //echo $this->db->last_query();die;	
        return json_encode($result);
	}
	
	function get_all_vendors(){
		$this->db->select('b.first_name,a.*'); 
        $this->db->from('vendor_details a');
        $this->db->join('users b', 'b.user_id = a.user_id'); 
        $this->db->order_by('a.vendor_detail_id','desc');
        //$this->db->limit($limit, 0);
        //$this->db->where('b.category_id',$category_id);
        $query = $this->db->get();
        $result=$query->result(); 
        $options=array();
        foreach($result as $res){
            $options[$res->vendor_detail_id]=$res->first_name.' - '.$res->shop_title;
        }
        return json_encode($options);
        //return json_encode($result);
	}
	function get_all_products(){
		$this->db->select('*'); 
        $this->db->from('products a');
        $this->db->order_by('product_id','desc');
        //$this->db->limit($limit, 0);
        //$this->db->where('b.category_id',$category_id);
        $query = $this->db->get();
        $result=$query->result(); 
        //echo $this->db->last_query();die;	
        $options=array();
        foreach($result as $res){
            $options[$res->product_id]=$res->product_name;
        }
        return json_encode($options);
        //return json_encode($result);
	}
	
	function get_latest_blogs_limit($limit,$lang_id){
		$this->db->select('*'); 
        $this->db->from('blogs a');
        $this->db->order_by('blog_id','desc');
        $this->db->where('user_type','A');
        $this->db->limit($limit, 0);
        //$this->db->where('b.category_id',$category_id);
        $query = $this->db->get();
        $result=$query->result(); 
        //echo $this->db->last_query();die;	
        return json_encode($result);
	}
	
	function update_version(){
	    $last_row=$this->db->select('*')->order_by('app_version_id',"desc")->limit(1)->get('app_version')->row();
		$version_id=$last_row->version_id;
		$explode=explode('.',$version_id);
		$addnew=$explode[1]+1;
		$newversion=$explode[0].'.'.$addnew;
		$data = array( 
			'version_id'      => $newversion, 
		);

    $this->db->insert('app_version',$data);
    return true;
		
	}
	  
}