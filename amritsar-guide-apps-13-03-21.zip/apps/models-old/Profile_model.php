<?php

class Profile_model extends CI_Model
{	
  
	
	
	function updateUserAddress($user_id,$user_address_id)
 	  {			$address_data =array( 
				'country_id' => $this->input->post("country_id"),
				'state_id' => $this->input->post("state_id"),
				'city_id' => $this->input->post("city_id"),
				'address' => $this->input->post("address"),
				'pin_code' => $this->input->post("pin_code")
			 );	
			 $this->db->where('user_address_id', $user_address_id);
			 $this->db->where('user_id', $user_id);	
			 $result = $this->db->update('user_address', $address_data);
			if($result)
				return 1;
			else
				return 0;
	}
	
	 
	
		 function user_edit($user_id)
		 {
			if ($user_id == '') {
				redirect(base_url() . "users/view");
			}
			$this->db->select('users.*,user_address.country_id,user_address.state_id,user_address.city_id,user_address.pin_code,user_address.address');
			$this->db->from('users');
			//$this->db->where('user_roles.is_active','1');
			$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id');
			//$this->db->join('user_roles', 'users.user_id = user_roles.user_id');
			$this->db->where('user_address.is_primary', '1');
			$this->db->where('users.user_id', $user_id);
			$query = $this->db->get();
			//echo "<pre>";print_r($this->db->last_query());die;
			return $query->row();
	
		} //End of edit function
	
	
		 function update_user($user_id,$user_address_id)
		 {
		
		
			$data = array(
				'alternate_email'     => $this->input->post("alternate_email"),
				'first_name'   => $this->input->post("first_name"),
				'last_name'     => $this->input->post("last_name"),
				'gender'     => $this->input->post("gender"),
				'date_of_birth'     => $this->input->post("date_of_birth"),
				'landline_no'     => $this->input->post("landline_no"),
				'mobile_no1'     => $this->input->post("mobile_no1"),
				'mobile_no2'     => $this->input->post("mobile_no2")
			);
			$this->db->where('user_id', $user_id);
			$result = $this->db->update('users', $data);
			if($result > 0)
   		    {
				if($this->input->post("country_id")!='')
				 {
					$user_address_id = $this->updateUserAddress($user_id,$user_address_id);
				 }
		    }
			if ($result)
			   return 1;
			 else
			   return 0;
			
		 } //End of Update function
		 
	
	 
	function update_photo($user_id,$file_name)
    { 
        $data = array(
			'user_photo'   => $file_name,
        );
        $this->db->where('user_id', $user_id);
        $result = $this->db->update('users', $data);
		if($result)
		{
		  return 1;
		}
        
    } //End of Update User function
	 

    
}