<?php 
class Ulogin_model extends CI_Model
{
	function login(){ 
		$email_mobile=$this->input->post("email_mobile");
		$this->db->select('*');
		$this->db->where('email',$email_mobile);
		$this->db->or_where('mobile_no1',$email_mobile);
		$query = $this->db->get('users');
		//echo $this->db->last_query();die;
		$result = $query->row();
		if($result){
			$this->session->set_userdata('user_id', $result->user_id);
			$this->session->set_userdata('user_details', $result);
			$this->session->set_userdata('email_mobile', $email_mobile);
			//$this->session->set_userdata('login_mobile', $result->mobile);
			return 1;
		} else {
			return 0;
		}
	}
	function normal_login(){
		$email_mobile=$this->session->userdata('email_mobile');
		//$password=md5($this->input->post("password"));
		$password=$this->input->post("password");
		$this->db->select('*');
		$this->db->where('password',$password);
		$this->db->where("(email='$email_mobile' or mobile_no1='$email_mobile')");
		//$this->db->or_where('mobile',$email_mobile);
		$query = $this->db->get('users');
		$num_rows=$query->num_rows();
		
		$sql = $this->db->last_query();
		if($num_rows>0){
			$result = $query->row();
			return $result;
		}else{
			return False;
		}
		
		//$result = $query->result();
		
	} 
	function update_password()
	{
			 $data        = array(
				'password'     => md5($this->input->post("newpassword")), 
			);
		 
		 $this->db->where('user_id', $this->session->userdata('user_id'));
		 $result = $this->db->update('users', $data);
			
		if ($result)
		   return 1;
		 else
		   return 0;
		
	} //End of Update function	
	 
	
}
?>