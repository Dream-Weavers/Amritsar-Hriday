<?php

class Dashboard_model extends CI_Model
{
	function login_as_shadow_user($user_id){
        $this->db->select('*');
        $this->db->where('user_id', $user_id);
        $this->db->from('users');
		$this -> db -> limit(1);
        $query = $this->db->get();
        $user_row   = $query->row();
		// get master user info 
		
		if($user_row->master_id==0)
		  $master_id=$user_id;
		  else
		  $master_id=$user_row->master_id;
		  
		$this->db->select('*');
        $this->db->where('user_id', $master_id);
        $this->db->from('users');
		$this -> db -> limit(1);
        $master_query = $this->db->get();
		
        $master_user_row   = $master_query->row();
	
		$this->session->set_userdata('user_shadow_id', $this->session->userdata('user_id'));
		//unset session values
		$this->session->unset_userdata('user_id');
		$this->session->unset_userdata('f_name');
		$this->session->unset_userdata('l_name');
		$this->session->unset_userdata('name');
		$this->session->unset_userdata('user_type');
		$this->session->unset_userdata('role_id');
		$this->session->unset_userdata('user_rights');
		$this->session->unset_userdata('user_modules');
		$this->session->unset_userdata('is_master');
		$this->session->unset_userdata('master_id');
		$this->session->unset_userdata('myhotline_master_id');
						
		//Set the basic values into the session
		$this->session->set_userdata('user_id', $user_row->user_id);
		$this->session->set_userdata('f_name', $user_row->first_name);
		$this->session->set_userdata('l_name', $user_row->last_name);
		$this->session->set_userdata('user_type',$user_row->user_type);
		$this->session->set_userdata('designation_id',$user_row->designation_id);
		$this->session->set_userdata('is_master',$user_row->is_master);
		$this->session->set_userdata('master_id',$user_row->master_id);
		$this->session->set_userdata('myhotline_master_id',$master_user_row->myhotline_master_id);
		if($user_row->user_type==COMPANY)
		{
			   $this->db->select('user_modules,company_modules');
			   $this->db->from('company_plans');
			   $this->db->where('company_id',$user_row->user_id);
			   $this->db->order_by('company_plan_id','DESC');
			   $this->db->limit(1);
			   $userquery = $this->db->get();
			  // echo $this->db->last_query();
			   if($userquery->num_rows()>0)
			   { $rowuser = $userquery->row();	
				 $user_rights =json_decode($rowuser->company_modules);
				 $this->session->set_userdata('user_rights',$user_rights);
				 
				 $user_modules =json_decode($rowuser->user_modules);
				 $this->session->set_userdata('user_modules',$user_modules);
			   }
		}
		elseif($user_row->user_type==COMPANY_USER)
		{
			$fields = array('user_id'=>$user_row->user_id,'is_active'=>'1');
		    $rolerow = gettableinfo('user_roles',$fields);
			$this->session->set_userdata('role_id',$rolerow->role_id);
		}
		//Check Master Id Admin/Company Login
		if($user_row->user_type==SUPERADMIN || $user_row->user_type==COMPANY)
		{
			if($user_row->is_master=='1')
			{    $this->session->set_userdata('master_id',$user_row->user_id);
			}
			else
			 {   $this->db->select('user_id');
				 $this->db->from('users');
				 $this->db->where('user_id',$user_row->master_id);
				 $query = $this->db->get();
				 $masterrow = $query->row();	
				 $this->session->set_userdata('master_id',$masterrow->user_id);
			 }
		}
		else
		{	$this->session->set_userdata('master_id',$user_row->master_id);
		}
		
		//Insert Log sessions
		$this->load->library('user_agent');
		if ($this->agent->is_browser())
		{
				$agent = $this->agent->browser().' '.$this->agent->version();
		}
		elseif ($this->agent->is_robot())
		{
				$agent = $this->agent->robot();
		}
		elseif ($this->agent->is_mobile())
		{
				$agent = $this->agent->mobile();
		}
		else
		{
				$agent = 'Unidentified User Agent';
				
		}
		
		$data = array(
            'logout_time' => date('Y-m-d H:i:s'),
            'log_status'  => 'o',
        );
        $this->db->where('session_id', session_id());
        $this->db->where('user_id', $this->session->userdata('user_shadow_id'));
        $this->db->update('log_sessions', $data);
		
		 $data = array(
		 'session_id'=>session_id(),
		 'user_id'=>$this->session->userdata('user_id'),
		 'login_time'=>date('Y-m-d H:i:s'),
		 'logout_time'=>date('Y-m-d H:i:s'),
		 'IP_address'=>$_SERVER['REMOTE_ADDR'],
		 'user_agent'=>$agent,	
		 'shadow'         => '1',
		 'user_shadow_id' => $this->session->userdata('user_shadow_id'),			 
		 );
		$resultlog = $this->db->insert('log_sessions',$data);
	    if($resultlog){
		   if($user_row->user_type==COMPANY)
			redirect(base_url() . 'company/dashboard');
		   elseif($user_row->user_type==COMPANY_USER)
			redirect(base_url() . 'users/dashboard');
		   elseif($user_row->user_type==CLIENT)
			redirect(base_url() . 'clients/dashboard');
			else
			redirect(base_url() . 'backoffice/dashboard');
	   }

    } //End of shadow function


    function login_as_user()
    {
		if($this->session->userdata('user_shadow_id')!='')
			{
			$this->db->select('*');
			$this->db->where('user_id', $this->session->userdata('user_shadow_id'));
			$this->db->from('users');
			$query = $this->db->get();
			$row   = $query->row();
	
		// get master user info 
		
		if($row->master_id==0)
		  $master_id=$this->session->userdata('user_shadow_id');
		  else
		  $master_id=$row->master_id;
		  
		  
		 $this->db->select('*');
        $this->db->where('user_id', $master_id);
        $this->db->from('users');
		$this -> db -> limit(1);
        $master_query = $this->db->get();
        $master_user_row   = $master_query->row();
		
		
			$data = array(
				'logout_time' => date('Y-m-d H:i:s'),
				'log_status'  => 'o',
			);
			$this->db->where('session_id', session_id());
			$this->db->where('user_id', $this->session->userdata('user_id'));
			$this->db->update('log_sessions', $data);
			// echo $this->db->last_query();
			 //die();
		   //unset session values
			$this->session->unset_userdata('user_id');
			$this->session->unset_userdata('f_name');
			$this->session->unset_userdata('l_name');
			$this->session->unset_userdata('name');
			$this->session->unset_userdata('user_type');
			$this->session->unset_userdata('role_id');
			$this->session->unset_userdata('user_shadow_id');
			$this->session->unset_userdata('user_rights');
			$this->session->unset_userdata('user_modules');
			$this->session->unset_userdata('is_master');
			$this->session->unset_userdata('master_id');
			$this->session->unset_userdata('myhotline_master_id');
							
			//Set the basic values into the session
			$this->session->set_userdata('user_id', $row->user_id);
			$this->session->set_userdata('f_name', $row->first_name);
			$this->session->set_userdata('l_name', $row->last_name);
			$this->session->set_userdata('user_type',$row->user_type);
			$this->session->set_userdata('is_master',$row->is_master);
			$this->session->set_userdata('master_id',$row->master_id);
			$this->session->set_userdata('myhotline_master_id',$master_user_row->myhotline_master_id);
			if($row->user_type==COMPANY)
			{
			 $user_rights =json_decode($row->user_rights);
			 $this->session->set_userdata('user_modules',$user_rights);
			}
			elseif($row->user_type==COMPANY_USER)
			{
				$fields = array('user_id'=>$row->user_id,'is_active'=>'1');
		    	$rolerow = gettableinfo('user_roles',$fields);
				$this->session->set_userdata('role_id',$rolerow->role_id);
			}
			//Check Master Id Admin/Company Login
			if($row->user_type==SUPERADMIN || $row->user_type==COMPANY_USER)
			{
				if($row->is_master=='1')
				{    $this->session->set_userdata('master_id',$row->user_id);
				}
				else
				 {   $this->db->select('user_id');
					 $this->db->from('users');
					 $this->db->where('user_id',$row->master_id);
					 $query = $this->db->get();
					 $masterrow = $query->row();	
					 $this->session->set_userdata('master_id',$masterrow->user_id);
				 }
			}
			else
			{	$this->session->set_userdata('master_id',$row->master_id);
			}
			
			//Insert Log sessions
			$this->load->library('user_agent');
			if ($this->agent->is_browser())
			{
					$agent = $this->agent->browser().' '.$this->agent->version();
			}
			elseif ($this->agent->is_robot())
			{
					$agent = $this->agent->robot();
			}
			elseif ($this->agent->is_mobile())
			{
					$agent = $this->agent->mobile();
			}
			else
			{
					$agent = 'Unidentified User Agent';
					
			}
			
			 $data = array(
			 'session_id'=>session_id(),
			 'user_id'=>$this->session->userdata('user_id'),
			 'login_time'=>date('Y-m-d H:i:s'),
			 'logout_time'=>date('Y-m-d H:i:s'),
			 'IP_address'=>$_SERVER['REMOTE_ADDR'],
			 'user_agent'=>$agent,				 
			 );
			$result = $this->db->insert('log_sessions',$data);
			if ($result) {
				  if($this->session->userdata('user_type')==SUPERADMIN)
					redirect(base_url() . 'backoffice/dashboard');
				   elseif($this->session->userdata('user_type')==COMPANY)
					redirect(base_url() . 'company/dashboard');
				   elseif($this->session->userdata('user_type')==COMPANY_USER)
					redirect(base_url() . 'users/dashboard');
				   elseif($this->session->userdata('user_type')==CLIENT)
					redirect(base_url() . 'clients/dashboard');
					else
					redirect(base_url() . 'backoffice/dashboard');
			}
		}
		else
		{
			redirect(base_url() . 'backoffice/dashboard');
		}

  } //End of function
	
  function count_users() {
		$this->db->where('users.user_type','U');
		$this->db->where('users.email!=','');
		$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id','LEFT');	
		$this->db->group_by('users.user_id'); 
		$query=$this->db->get('users');			   
		return $query->num_rows();
	}     
	
	function count_employees() {
		$this->db->where('users.user_type','E');
		$this->db->where('user_roles.is_active','1');
		$this->db->join('user_address', 'user_address.user_address_id = users.user_address_id');
		$this->db->join('user_roles', 'users.user_id = user_roles.user_id');
		$this->db->group_by('users.user_id'); 
		$query=$this->db->get('users');		   
		return $query->num_rows();
	}
	
	function count_areas()
	{
		$this->db->select('*');
		$this->db->from('areas');
		$this->db->order_by('area_id', 'DESC');
		$query = $this->db->get();
		return $query->num_rows();
	}
	
	function count_soundfiles()
	{
		$this->db->select('*');
		$this->db->from('sound_files');
		$this->db->order_by('sound_file_id', 'DESC');
		$query = $this->db->get();
		return $query->num_rows();
	} 
	
	function count_filters() {
			
		$query=$this->db->get('filters');		 
		return $query->num_rows();
		
	}
	
	function count_locations() {
		$this->db->join('location_categories', 'location_categories.location_id = locations.location_id');
		$this->db->join('categories', 'categories.category_id = location_categories.category_id');
		$this->db->join('locality', 'locality.locality_id = locations.locality_id');
		$this->db->where('location_categories.is_active','1');
		$this->db->where('locations.type!=','event');
		//$this->db->where('locations.language_id',$this->session->userdata('lang_id'));
		//$this->db->group_by('locations.location_id'); 
		$query=$this->db->get('locations');		
		//echo $this->db->last_query();die;
		return $query->num_rows();
		
	} 
	
	function countLocationCategoryTypes(){
		$this->db->select('category_types.*, projects.project_name');	
		$this->db->join('projects','category_types.project_id=projects.project_id','left');
		//$this->db->where('category_types.language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('category_types');
		//echo $this->db->last_query();die;
   		return $query->num_rows();
   } 
   
   function countLocationCategories(){
		$this->db->select('categories.*, categories_parent.category_name as parent_category, category_types.category_type');	
		$this->db->join('categories as categories_parent','categories.category_parent_id=categories_parent.category_id','left');
		$this->db->join('category_types','categories.category_type_id=category_types.category_type_id','left');
		//$this->db->where('categories.language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('categories');
		//echo $this->db->last_query();die;
   		return $query->num_rows();
   } 
   
   function count_quiz()	{		
	
		$this->db->select('question_bank_settings.*, locations.location_name');	
		$this->db->join('locations','question_bank_settings.location_id=locations.location_id');				
		
		$this->db->from('question_bank_settings');	
		$this->db->order_by('question_bank_settings.question_bank_setting_id', 'DESC');	
		$query = $this->db->get();
		return $query->num_rows();	
	}
	
	function countBlogCategories(){
		$this->db->select('*');	
		//$this->db->where('language_id',$this->session->userdata('lang_id'));
		$query=$this->db->get('blog_categories');
		return $query->num_rows();	
   }
   
    function countBlogs(){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, blogs.*, blog_categories.category_name");	
		$this->db->join('blog_categories','blogs.category_id=blog_categories.category_id','left');
		$this->db->join('users','blogs.created_by=users.user_id');
		//$this->db->where('blogs.language_id',$this->session->userdata('lang_id'));
		$this->db->where('blogs.approval_status','1');
		
		
		$query=$this->db->order_by('blog_id','desca');
		$query=$this->db->get('blogs');
		return $query->num_rows();	
   }
   
   function count_beacons($beacon_id,$status) {
		
	//	$query=$this->db->get('beacons');		
	//	return $query->num_rows();
		return '0';
	}
	
	function countTours($tour_name,$status){
		/*$this->db->select('*');
		//$this->db->where('language_id',$this->session->userdata('lang_id'));
		$this->db->order_by('tour_trail_id','desc');
		$query=$this->db->get('tour_trails');
   		return $query->num_rows();*/
   			return '0';
    }
	
	function countdesignation()
	{
		$this->db->select('*');
		$this->db->from('designation');
		$query = $this->db->get();
		return $query->num_rows();
	}
	
	function countdepartment()
	{
		$this->db->select('*');
		$this->db->from('department');
		$query = $this->db->get();
		return $query->num_rows();
	}
}