<?php

class Complaint_model extends CI_Model
{
   
   function addComplaint(){
	
         $data          = array(
		    'language_id'=>$this->session->userdata('lang_id'),
		    'created_by'=>$this->session->userdata('user_id'),
            'complaint_id'     	=>  $this->complaint_id,
            'title'     		=>  $this->title,
            'description'     	=>  $this->description,
            'status'     		=>  '1',
            'approval_status'   =>  '1',
            'visibility'     	=>  'public',
            'user_type'     	=>  'A',
            'video_url'     	=>  $this->video_url,
            'created_date'      =>  date('Y-m-d H:i:s'),
        );
        $result  = $this->db->insert('complaints', $data);
		
		$id  = $this->db->insert_id();
		 if($result)
			return $id;
		else
			return 0;
   
   }
   //End of addComplaint
	
   function add_icon($complaint_id,$filename)
   {			
		$data     = array(
			'image_url'     => time().'_'.$complaint_id.'_'.$filename
		);
		$this->db->where('complaint_id', $complaint_id);
		$result = $this->db->update('complaints', $data);
   }
	
   function editComplaint(){
           $data          = array(
            'modified_by' =>$this->session->userdata('user_id'),
            'complaint_id'     		=>  $this->complaint_id,
            'title'     	=>  $this->title,
            'description'     		=>  $this->description,
            'video_url'     	=>  $this->video_url
        );
		$this->db->where('complaint_id', $this->complaint_id);
        $result  = $this->db->update('complaints', $data);
		if($result)
			return $this->complaint_id;
		else
			return 0;
   }//End of editComplaint
   
   function editComplaintData(){
		$this->db->where('complaint_id',$this->complaint_id);         
		$query  = $this->db->get('complaints');		  
   		$result = $query->row(); 

		//echo $this->db->last_query();
		if($result)
			return $result;   
	    else
			return 0;
   }// End of editComplaintData
   
   function viewComplaints($complaint_type,$title, $limit, $start){
		$this->db->select("complaints.*, CONCAT(users.first_name,  ' ', users.last_name ) as tourist_name");	
		$this->db->join('users', 'complaints.post_user_id = users.user_id','LEFT');
		$this->db->where('complaints.department_id',$this->session->userdata('dept_id'));
		$this->db->where('complaints.language_id',$this->session->userdata('lang_id'));
		//$this->db->where('complaints.approval_status','1');
		
		if($complaint_type!='0')
		$this->db->where('complaints.complaint_type', $complaint_type);
	
		if($title!='') {
			//$this->db->like('complaints.title', $title);
			//$this->db->or_like('complaints.description', $title);
			$where .= "(complaints.complaint_title  LIKE '%$title%' OR ";
			$where .= "complaints.complaint_description LIKE '%$title%')";
			$this->db->where($where);
		} 
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
		$query=$this->db->order_by('complaints.complaint_id','desc');
		$query=$this->db->get('complaints');
		//echo $this->db->last_query();
   		$result = $query->result(); 
		return $result;
   } // End of viewComplaint
   
   function viewUserComplaints($complaint_id,$title, $limit, $start){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, complaints.*, complaints.category_name");	
		$this->db->join('complaints','complaints.complaint_id=complaints.complaint_id','left');
		$this->db->join('users','complaints.created_by=users.user_id');
		$this->db->where('complaints.department_id',$this->session->userdata('dept_id'));
		$this->db->where('complaints.language_id',$this->session->userdata('lang_id'));
		$this->db->where('complaints.user_type','U');
		$this->db->where('complaints.approval_status','0');
		
		if($complaint_id!='0')
		$this->db->where('complaints.complaint_id', $complaint_id);
	
		if($title!='') {
			$where .= "(complaints.title LIKE '%$title%' OR ";
			$where .= "complaints.description LIKE '%$title%')";
			$this->db->where($where);
		} 
		
		if($limit!=null || $start!=null)
		{
			$this->db->limit($limit,$start);
		}	
		$query=$this->db->order_by('complaint_id','desca');
		$query=$this->db->get('complaints');
		//echo $this->db->last_query();die;
   		$result = $query->result(); 
		return $result;
   } // End of viewComplaint
   
   function update_status($complaint_id, $status)
    {
		 
		$data = array(
			'complaint_status' => $status,
		);
		 
        $this->db->where('complaint_id', $complaint_id);
        $result = $this->db->update('complaints', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
	function update_publish($complaint_id, $status)
    {
		$data = array(
				'status' => $status,
				'approval_status' => $status
		);

		
        $this->db->where('complaint_id', $complaint_id);
        $result = $this->db->update('complaints', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
	
	function reject_status($complaint_id, $status, $rejection_status_remarks )
    {
		$data = array(
				'approval_status' => $status,
				'rejection_status_remarks' => $rejection_status_remarks
			);
			
		
	
        $this->db->where('complaint_id', $complaint_id);
        $result = $this->db->update('complaints', $data);
		if($result)
		  return '1';
		 else 
		 return '0';

    } //End of Update status function
  
   
   function countusercomplaintrecords(){
		$this->db->select("CONCAT(users.first_name, ' ', users.last_name) AS fullname, complaints.*, complaints.category_name");	
		$this->db->join('complaints','complaints.complaint_id=complaints.complaint_id','left');
		$this->db->join('users','complaints.created_by=users.user_id');
		$this->db->where('complaints.department_id',$this->session->userdata('dept_id'));
		$this->db->where('complaints.language_id',$this->session->userdata('lang_id'));
		$this->db->where('complaints.user_type','U');
		$this->db->where('complaints.approval_status','0');
		$query=$this->db->get('complaints');
   		return $num = $query->num_rows(); 
   }
   
}
?>