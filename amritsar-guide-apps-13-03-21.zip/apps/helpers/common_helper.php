<?php 

function create_salt($password)
{
	if($password!='') 
	return SHA1($password);
	else
    return SHA1(random_string('alnum', 32));
}
function success_message($success_message=NULL){
	$return = "<div class='alert alert-success alert-dismissable'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'></button>
					<strong>Success!</strong> $success_message
				</div>";
	echo $return;
}
function error_message($error_msg=NULL){
	$return = "  <div class='alert alert-danger ' >
				<button class='close' data-close='alert'></button>
				<span> <i class='fa fa-exclamation-triangle' aria-hidden='true'></i>$error_msg </span>
			</div>";
	echo $return;
}
function get_navigation_list($user_type,$parent_id, $count, $lastname='') {
    static $option_results;
	$indent_flag='';
    // if there is no current navigation id set, start off at the top level (zero)
    if (!isset($parent_id)) {
        $parent_id=1;
    }
    // increment the counter by 1
    $count = $count+1;

    // query the database for the sub-navigation_menus of whatever the parent navigation is
	$CI= & get_instance();
	$CI->load->database();
	$CI->db->select('*');
	$CI->db->from('navigation_menus');
	$CI->db->where('user_type', $user_type);
	$CI->db->where('is_parent', $parent_id);
	$CI->db->where('is_active', '1');
	$CI->db->order_by('set_order','ASC');
	  $result = $CI->db->get();
       $return = array();
       if ($result->num_rows() > 0) {
		$option_results[''] = '- None - ';
		foreach ($result->result_array() as $rowmenu) {
	
        if ($parent_id!=0) {
            $indent_flag =  $lastname . '--';
                $indent_flag .=  '>';
        }
            $rowmenu['menu_name'] = $indent_flag.$rowmenu['menu_name'];
            $option_results[$rowmenu['menu_id']] = $rowmenu['menu_name'];
            // now call the function again, to recurse through the child Navigation
            get_navigation_list($user_type,$rowmenu['menu_id'], $count, $rowmenu['menu_name']);
        }
    }
	
    return $option_results;
}
function user_type_array()
{  
   
   $user_type_array = array();
   $user_type_array['']=' Select User Type ';
   //$user_type_array['A'] ='Admin';
   $user_type_array['D'] ='Department';
   $user_type_array['U'] ='Users'; 
   $user_type_array['E'] ='Employees';
   return $user_type_array;
} 
function validateAccess(){
$oUser = getLoggedUser();
//see if logged user
if(null == $oUser)
redirect('admin/login',301);
}
function getLoggedUser()
{
	$CI = &get_instance();
	if($CI->session->userdata('user_id')!=''){
		return true;
	}else{
		return false;
	}	
	//echo "<pre>";print_r(unserialize($CI->session->userdata('user')));die;
	//return $user;
}

		
function per_page_records()
	{   $per_page_records = array();
		$per_page_records[50] ='50';
		$per_page_records[100] ='100';
		$per_page_records[150] ='150';
		$per_page_records[200] ='200';
		$per_page_records[500] ='500';
		$per_page_records[1000] ='1000';
	    return $per_page_records;
	}	

function app_menu_type_array()
{  
   $app_menu_type_array = array();
   $app_menu_type_array['']=' Select ';
   $app_menu_type_array['1'] ='App Main Menu';
   $app_menu_type_array['2'] ='App Footer Menu'; 
   $app_menu_type_array['3'] ='My Memories Menu';
   return $app_menu_type_array;
} 

function campaign_rule_array()
{  
    $campaign_rule_array = array();
    $CI= & get_instance();
	$CI->load->database();
	$CI->db->select('rule_name,rule_id');
	$CI->db->where('is_active','1');
	$CI->db->where('language_id',$CI->session->userdata('lang_id'));
	$CI->db->from('rules');
	$query = $CI->db->get();
	$campaign_rule_array[''] = 'Select';
	foreach ($query->result_array() as $row) {
		$campaign_rule_array[$row['rule_id']] = $row['rule_name'];
	}
   return $campaign_rule_array;
}

	
function limit_words($string, $word_limit)
{
	if($word_limit>0){ 
		$words = explode(" ",$string);
		if($word_limit<str_word_count ($string)){
			$dots="...";
		} else {
			$dots="";
		}
		return implode(" ",array_splice($words,0,$word_limit)).$dots;
	} 
}

function returnquery_parameter($table,$fields,$value,$key){
	$CI= & get_instance();
	$CI->load->database();
	$CI->db->select('*');
	if(is_array($fields)){
		foreach($fields as $keys => $values) {
			$CI->db->where($keys, $values);
		}         
	}
	$CI->db->from($table);
	$query = $CI->db->get();	  
	$result = $query->result_array();
/* 	echo "<pre>";
	print_r($result);
	die; */
	if($key!='')
		$result1 = array_column($result, $value,$key);
	else	
		$result1 = array_column($result, $value);
	 $empty_option = array(
         ''=>'Select Option'
	 );
     $arr_option = $empty_option + $result1;
	//print '<pre>';print_r($result1);die;
	//$finalDropDown = array_merge(array('' => ''), $result1);
	return $arr_option;
}

function fetch_countries(){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('country_name,country_id');
		//$CI->db->where('is_active','0');
        $CI->db->from('country');
        $query = $CI->db->get();
        return $result = $query->result();
} //End of View function
function get_type($type=''){
		if($type=='A'){
				$key = 'supper_admin_id';			
				if( $type ) {
					$key = "{$type}:{$key}";
				}		
		}
		elseif($type=='E'){
				$key = 'employee_id';			
				if( $type ) {
					$key = "{$type}:{$key}";
				}		
		}	
		elseif($type=='D'){
				$key = 'department_id';			
				if( $type ) {
					$key = "{$type}:{$key}";
				}		
		}	
		elseif($type=='U'){
				$key = 'user_id';			
				if( $type ) {
					$key = "{$type}:{$key}";
				}		 
		}	
		
		return $key;
	}

function search_status_array()
	{    $search_status_array = array();
		 $search_status_array[''] = "Select Status";
		 $search_status_array['a'] = "Active";
		 $search_status_array['d'] = "De-Active";
	    return $search_status_array;
	}		

function created_by_array()
	{    $created_by_array = array();
		 $created_by_array[''] = "Select";
		 $created_by_array['s'] = "Superadmin";
		 $created_by_array['u'] = "Users";
	    return $created_by_array;
	}
function answer_array()
{    $answer_array = array();
	 $answer_array[''] = "Select Option";
	 $answer_array['1'] = "Option 1";
	 $answer_array['2'] = "Option 2";
	 $answer_array['3'] = "Option 3";
	 $answer_array['4'] = "Option 4";
	return $answer_array;
}
	
function get_estimated_time_array() {

 $estimated_visit_array=array();
 $estimated_mins_array1[''] = 'Select';
 for($i=05; $i<=60; $i+=5){
	 $estimated_mins_array1[$i]=$i .' Mins';
 }
	$estimated_mins_array2[75] ='1.15 Hrs';
	$estimated_mins_array2[90] ='1.30 Hrs';
	$estimated_mins_array2[105] ='1.45 Hrs';
	$estimated_mins_array2[120] ='2.00 Hrs';
	$estimated_mins_array2[135] ='2.15 Hrs';
	$estimated_mins_array2[150] ='2.30 Hrs';
	$estimated_mins_array2[165] ='2.45 Hrs';
	$estimated_mins_array2[180] ='3.00 Hrs';
	
    $estimated_visit_array =  $estimated_mins_array1+$estimated_mins_array2;
	
	return $estimated_visit_array;

}

		
	 function is_logged_in()
	 {  $CI= & get_instance();
	   $CI->load->library('session');
		if ($CI->session->userdata('user_id') == "") {
				redirect(base_url());
			  }	
	 } 
	

   function logged_in($type=''){
		$CI= & get_instance();
		if($CI->session->userdata('user_id')!='')
		{
		 $userrow = get_table_info('users','user_id',$CI->session->userdata('user_id'));
		 $user_type = $userrow->user_type;
		}
		if($CI->session->userdata('user_id')==''){
		  redirect(base_url());
		}
		elseif($type== $user_type)
		{	
		   return TRUE;
		}
		 return FALSE;
		
	}

   function valid_logged_in($requires_logout=FALSE, $type='')
	{ 
	    $CI= & get_instance();
		$key = get_type($type);
		if(!$requires_logout && !logged_in($type) )	{
			redirect(base_url() . 'unauthorized');
		}
	}
  
function check_unique($table,$fields){
		 $set_values='';
	     if(is_array($fields)){ //echo "<pre>";print_r($fields);
			$CI= & get_instance();
			$CI->load->database();
			$CI->db->select('*');
			foreach($fields as $keys => $values) {
				$CI->db->where($keys, $values);
			} 
			$CI->db->from($table);	
			$query = $CI->db->get();//echo "<pre>";print_r($CI->db->last_query());die;
			return $query->num_rows();
		}
		return false;  
}

function check_unique_edit($table,$fields,$prim_fields){
		 $set_values='';
	     if(is_array($fields)){
			$CI= & get_instance();
			$CI->load->database();
			$CI->db->select('*');
			foreach($fields as $keys => $values) {
				$CI->db->where($keys, $values);
			} 
			foreach($prim_fields as $pkeys => $pvalues) {
				$CI->db->where("$pkeys !=", $pvalues);
			} 
			$CI->db->from($table);	
			$query = $CI->db->get();
			//echo $CI->db->last_query();die;	
			return $query->num_rows();
			
		}
		return false;  
 }


function get_table_info($table,$field,$uniqueid){
		$CI= & get_instance();
	    $CI->load->database();
        $CI->db->select('*');
        $CI->db->where($field, $uniqueid);
        $CI->db->from($table);
		$query = $CI->db->get();
		if($table=='languages')
		{
		 //echo "--------------------->". $CI->db->last_query();
		}
        if($query -> num_rows() == 0)
			{		return '0';
			}
			else
			{		return $query->row();
			}

    } //End of Get Info Details function


	function update_table_fields($table,$fields,$prim_fields){
			 if(is_array($fields)){
				$CI= & get_instance();
				$CI->load->database();
				$CI->db->select('*');
				foreach($prim_fields as $pkeys => $pvalues) {
					$CI->db->where("$pkeys =", $pvalues);
				} 
				$result = $CI->db->update($table, $fields);
				//print $this->db->last_query();
				return true;
			}
			return false;  
	 }


  function gettableinfo($table,$fields)
    {
		$CI= & get_instance();
	    $CI->load->database();
        $CI->db->select('*');
		if(is_array($fields)){
	     foreach($fields as $keys => $values) {
			 $CI->db->where($keys, $values);
			 }         
	   }
        $CI->db->from($table);
        $query = $CI->db->get();
		/* if($table=='user_timetable')*
		echo "--------------------->". $CI->db->last_query(); die; */
        if($query -> num_rows() == 0)
			{		return '0';
			}
			else
			{		return $query->row();
			}

    } //End of Get Info Details function
	
	
	function gettableinfowithfields($table,$fields,$needed_fields)
    {   //echo $needed_fields;die;
		$CI= & get_instance();
	    $CI->load->database();
        $CI->db->select($needed_fields);
		if(is_array($fields)){
	     foreach($fields as $keys => $values) {
			 $CI->db->where($keys, $values);
			 }         
	   }
        $CI->db->from($table);
        $query = $CI->db->get();
		//echo $CI->db->last_query();die;
        if($query -> num_rows() == 0)
			{		return '0';
			}
			else
			{		return $query->row();
			}

    } //End of Get Info Details function
	
	

 function gettabledropdown($table,$fields,$unique_id,$view_feild,$orderval=NULL,$order=NULL)
    {
		$CI= & get_instance();
	    $CI->load->database();
        $CI->db->select('*');
		if(is_array($fields)){
	     foreach($fields as $keys => $values) {
			 if(is_array($values))
			 $CI->db->where_in($keys, $values);
			 else
			 $CI->db->where($keys, $values);
			 }         
	    }
	
        $CI->db->from($table);
		if($orderval!=NULL)
		$CI->db->order_by($orderval,$order);
		$result = $CI->db->get();
		//echo $CI->db->last_query();die;
		$return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select';
            foreach ($result->result_array() as $row) {
                $return[$row[$unique_id]] = $row[$view_feild];
            }
        }
		 return $return;

    } //End of Get Info Details function

	//for frontend
	function getcategorytypes($table,$fields,$unique_id,$view_feild,$orderval=NULL,$order=NULL)
    {
		$CI= & get_instance();
	    $CI->load->database();
        $CI->db->select('*');
		$CI->db->where('type!=', 'event');
		if(is_array($fields)){
	     foreach($fields as $keys => $values) {
			 if(is_array($values))
			 $CI->db->where_in($keys, $values);
			 else
			 $CI->db->where($keys, $values);
			 }         
	    }
	
        $CI->db->from($table);
		if($orderval!=NULL)
		$CI->db->order_by($orderval,$order);
		$result = $CI->db->get();
		//echo $CI->db->last_query();die;
		$return = array();
        if ($result->num_rows() > 0) {
            $return[''] = 'Select Category Type';
            foreach ($result->result_array() as $row) {
                $return[$row[$unique_id]] = $row[$view_feild];
            }
        }
		 return $return;

    } //End of Get Info Details function
	
function gettableresult($table,$fields,$order=NULL,$group=NULL)
    {
		$CI= & get_instance();
	    $CI->load->database();
        //$CI->db->select('*');
		if(is_array($fields)){
	     foreach($fields as $keys => $values) {
			 $CI->db->where($keys, $values);
			 }         
	   }
        $CI->db->from($table);
		if($order!=NULL)
		$CI->db->order_by($order,"asc");
		if($group!=NULL)
		$CI->db->group_by($group);
        $query = $CI->db->get();
		//if($table=='user_timetable')
		//echo "--------------------->". $CI->db->last_query();
        if($query->num_rows() == 0)
			{		return '0';
			}
			else
			{		return $query->result();
			}

} //End of Get Info Details function


function get_max_values($TB,$max_field,$fields=NULL)
    {
		$CI= & get_instance();
	    $CI->load->database();
		$CI->db->select_max($max_field,$max_field);
		if(is_array($fields)){
	     foreach($fields as $keys => $val) {
			 $CI->db->where($keys, $val);
			 }         
	   }
		$result = $CI->db->get($TB);  
		// $CI->db->order_by($feild, 'ASC');
		//echo $CI->db->last_query();die;
        $order_result = $result->row();
		if($result->num_rows() > 0 && !is_null($order_result->$max_field))
		{
			$max_value =$order_result->$max_field+1;
		}
		else
		{
			$max_value ='1';
		}
		 return $max_value;
    }
	
  function get_list_options($list_id,$order)
    {
		$CI= & get_instance();
	    $CI->load->database();
		$CI->db->select('*');
		$CI->db->from('list_options');
		if($list_id!='')
		$CI->db->where('list_id', $list_id);
		/* if($CI->session->userdata('site_lang'))
		{  // $languagerow = get_table_info('languages','language_short_name','english');
		    $CI->db->where('language_id', $CI->session->userdata('lang_id'));
		}else
		{
			//$languagerow = get_table_info('languages','language_short_name','english');
			//$CI->db->where('list_id', $languagerow->language_id);
			$CI->db->where('language_id', $CI->session->userdata('lang_id'));
		} */
		$CI->db->order_by('seq', $order);
		$result = $CI->db->get();
		//echo $CI->db->last_query();
		
	    $return = array();
        if ($result->num_rows() > 0) {
		   $return[''] = 'Select';
		    foreach ($result->result_array() as $row) {
						
                $return[$row['option_id']] = $row['title'];
            }
	   }
        return $return;
		//print_r($return);
    }
    
    function get_list_options_lang($list_id,$order,$language_id=1)
    {
		$CI= & get_instance();
	    $CI->load->database();
		$CI->db->select('*');
		$CI->db->from('list_options');
		if($list_id!='')
		$CI->db->where('list_id', $list_id);
		/* if($CI->session->userdata('site_lang'))
		{  // $languagerow = get_table_info('languages','language_short_name','english');
		    $CI->db->where('language_id', $CI->session->userdata('lang_id'));
		}else
		{
			//$languagerow = get_table_info('languages','language_short_name','english');
			//$CI->db->where('list_id', $languagerow->language_id);
			$CI->db->where('language_id', $CI->session->userdata('lang_id'));
		} */
		$CI->db->where('language_id', $language_id);
		$CI->db->order_by('seq', $order);
		$result = $CI->db->get();
		//echo $CI->db->last_query();
		
	    $return = array();
        if ($result->num_rows() > 0) {
		   $return[''] = 'Select';
		    foreach ($result->result_array() as $row) {
						
                $return[$row['option_id']] = $row['title'];
            }
	   }
        return $return;
		//print_r($return);
    }
	
function get_users_dropdown($user_type){
		$CI= & get_instance();
	    $CI->load->database();
	    $CI->db->select('*');
        $CI->db->from('users');
		$CI->db->where('user_type', $user_type);
		$CI->db->where('is_master', '1');
		$CI->db->where('is_active', '1');
		$CI->db->order_by('first_name','ASC');
		$CI->db->order_by('last_name','ASC');
		//echo $CI->db->last_query();
        $result = $CI->db->get();
        $return = array();
        if ($result->num_rows() > 0) {
        	$return[''] = 'Select ';
            foreach ($result->result_array() as $row) {
				
				if($row['user_type']=='E')
				{
				 $desigrow = get_table_info('designation','designation_id',$row['designation_id']);
			     $return[$row['user_id']] = ucwords($row['first_name']).' '.ucwords($row['last_name']).' - '.$desigrow->designation_name;
				}
				else
				{
                 $return[$row['user_id']] = ucwords($row['first_name']).' '.ucwords($row['last_name']);
				}
            }
        }
        return $return;
		//print_r($return);
    }
	

function time_zone_array()
	{  		$timezone=array (
				'' => 'Select Timezone',
						"Pacific/Midway","value"=>"(GMT-11:00 Midway Island, Samoa",
						"America/Adak","value"=>"(GMT-10:00 Hawaii-Aleutian",
						"Etc/GMT+10","value"=>"(GMT-10:00 Hawaii",
						"Pacific/Marquesas","value"=>"(GMT-09:30 Marquesas Islands",
						"Pacific/Gambier","value"=>"(GMT-09:00 Gambier Islands",
						"America/Anchorage","value"=>"(GMT-09:00 Alaska",
						"America/Ensenada","value"=>"(GMT-08:00 Tijuana, Baja California",
						"Etc/GMT+8","value"=>"(GMT-08:00 Pitcairn Islands",
						"America/Los_Angeles","value"=>"(GMT-08:00 Pacific Time (US & Canada",
						"America/Denver","value"=>"(GMT-07:00 Mountain Time (US & Canada",
						"America/Chihuahua","value"=>"(GMT-07:00 Chihuahua, La Paz, Mazatlan",
						"America/Dawson_Creek","value"=>"(GMT-07:00 Arizona",
						"America/Belize","value"=>"(GMT-06:00 Saskatchewan, Central America",
						"America/Cancun","value"=>"(GMT-06:00 Guadalajara, Mexico City, Monterrey",
						"Chile/EasterIsland","value"=>"(GMT-06:00 Easter Island",
						"America/Chicago","value"=>"(GMT-06:00 Central Time (US & Canada",
						"America/New_York","value"=>"(GMT-05:00 Eastern Time (US & Canada",
						"America/Havana","value"=>"(GMT-05:00 Cuba",
						"America/Bogota","value"=>"(GMT-05:00 Bogota, Lima, Quito, Rio Branco",
						"America/Caracas","value"=>"(GMT-04:30 Caracas",
						"America/Santiago","value"=>"(GMT-04:00 Santiago",
						"America/La_Paz","value"=>"(GMT-04:00 La Paz",
						"Atlantic/Stanley","value"=>"(GMT-04:00 Faukland Islands",
						"America/Campo_Grande","value"=>"(GMT-04:00 Brazil",
						"America/Goose_Bay","value"=>"(GMT-04:00 Atlantic Time (Goose Bay",
						"America/Glace_Bay","value"=>"(GMT-04:00 Atlantic Time (Canada",
						"America/St_Johns","value"=>"(GMT-03:30 Newfoundland",
						"America/Araguaina","value"=>"(GMT-03:00 UTC-3",
						"America/Montevideo","value"=>"(GMT-03:00 Montevideo",
						"America/Miquelon","value"=>"(GMT-03:00 Miquelon, St. Pierre",
						"America/Godthab","value"=>"(GMT-03:00 Greenland",
						"America/Argentina/Buenos_Aires","value"=>"(GMT-03:00 Buenos Aires",
						"America/Sao_Paulo","value"=>"(GMT-03:00 Brasilia",
						"America/Noronha","value"=>"(GMT-02:00 Mid-Atlantic",
						"Atlantic/Cape_Verde","value"=>"(GMT-01:00 Cape Verde Is.",
						"Atlantic/Azores","value"=>"(GMT-01:00 Azores",
						"Europe/Belfast","value"=>"(GMT Greenwich Mean Time : Belfast",
						"Europe/Dublin","value"=>"(GMT Greenwich Mean Time : Dublin",
						"Europe/Lisbon","value"=>"(GMT Greenwich Mean Time : Lisbon",
						"Europe/London","value"=>"(GMT Greenwich Mean Time : London",
						"Africa/Abidjan","value"=>"(GMT Monrovia, Reykjavik",
						"Europe/Amsterdam","value"=>"(GMT+01:00 Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna",
						"Europe/Belgrade","value"=>"(GMT+01:00 Belgrade, Bratislava, Budapest, Ljubljana, Prague",
						"Europe/Brussels","value"=>"(GMT+01:00 Brussels, Copenhagen, Madrid, Paris",
						"Africa/Algiers","value"=>"(GMT+01:00 West Central Africa",
						"Africa/Windhoek","value"=>"(GMT+01:00 Windhoek",
						"Asia/Beirut","value"=>"(GMT+02:00 Beirut",
						"Africa/Cairo","value"=>"(GMT+02:00 Cairo",
						"Asia/Gaza","value"=>"(GMT+02:00 Gaza",
						"Africa/Blantyre","value"=>"(GMT+02:00 Harare, Pretoria",
						"Asia/Jerusalem","value"=>"(GMT+02:00 Jerusalem",
						"Europe/Minsk","value"=>"(GMT+02:00 Minsk",
						"Asia/Damascus","value"=>"(GMT+02:00 Syria",
						"Europe/Moscow","value"=>"(GMT+03:00 Moscow, St. Petersburg, Volgograd",
						"Africa/Addis_Ababa","value"=>"(GMT+03:00 Nairobi",
						"Asia/Tehran","value"=>"(GMT+03:30 Tehran",
						"Asia/Dubai","value"=>"(GMT+04:00 Abu Dhabi, Muscat",
						"Asia/Yerevan","value"=>"(GMT+04:00 Yerevan",
						"Asia/Kabul","value"=>"(GMT+04:30 Kabul",
						"Asia/Yekaterinburg","value"=>"(GMT+05:00 Ekaterinburg",
						"Asia/Tashkent","value"=>"(GMT+05:00 Tashkent",
						"Asia/Kolkata","value"=>"(GMT+05:30 Chennai, Kolkata, Mumbai, New Delhi",
						"Asia/Katmandu","value"=>"(GMT+05:45 Kathmandu",
						"Asia/Dhaka","value"=>"(GMT+06:00 Astana, Dhaka",
						"Asia/Novosibirsk","value"=>"(GMT+06:00 Novosibirsk",
						"Asia/Rangoon","value"=>"(GMT+06:30 Yangon (Rangoon",
						"Asia/Bangkok","value"=>"(GMT+07:00 Bangkok, Hanoi, Jakarta",
						"Asia/Krasnoyarsk","value"=>"(GMT+07:00 Krasnoyarsk",
						"Asia/Hong_Kong","value"=>"(GMT+08:00 Beijing, Chongqing, Hong Kong, Urumqi",
						"Asia/Irkutsk","value"=>"(GMT+08:00 Irkutsk, Ulaan Bataar",
						"Australia/Perth","value"=>"(GMT+08:00 Perth",
						"Australia/Eucla","value"=>"(GMT+08:45 Eucla",
						"Asia/Tokyo","value"=>"(GMT+09:00 Osaka, Sapporo, Tokyo",
						"Asia/Seoul","value"=>"(GMT+09:00 Seoul",
						"Asia/Yakutsk","value"=>"(GMT+09:00 Yakutsk",
						"Australia/Adelaide","value"=>"(GMT+09:30 Adelaide",
						"Australia/Darwin","value"=>"(GMT+09:30 Darwin",
						"Australia/Brisbane","value"=>"(GMT+10:00 Brisbane",
						"Australia/Hobart","value"=>"(GMT+10:00 Hobart",
						"Asia/Vladivostok","value"=>"(GMT+10:00 Vladivostok",
						"Australia/Lord_Howe","value"=>"(GMT+10:30 Lord Howe Island",
						"Etc/GMT-11","value"=>"(GMT+11:00 Solomon Is., New Caledonia",
						"Asia/Magadan","value"=>"(GMT+11:00 Magadan",
						"Pacific/Norfolk","value"=>"(GMT+11:30 Norfolk Island",
						"Asia/Anadyr","value"=>"(GMT+12:00 Anadyr, Kamchatka",
						"Pacific/Auckland","value"=>"(GMT+12:00 Auckland, Wellington",
						"Etc/GMT-12","value"=>"(GMT+12:00 Fiji, Kamchatka, Marshall Is.",
						"Pacific/Chatham","value"=>"(GMT+12:45 Chatham Islands",
						"Pacific/Tongatapu","value"=>"(GMT+13:00 Nuku'alofa",
						"Pacific/Kiritimati","value"=>"(GMT+14:00 Kiritimati"
				);

	   return $timezone;
	}	
	
		
function time_zone()
{
	$CI= & get_instance();
    $CI->load->database();
	$timezone="";
	$logged_user_type = $CI->session->userdata('user_type');
	$time_zone_array = time_zone_array();
	if($logged_user_type==SUPERADMIN)
	{
		$userrow = get_table_info('users','user_id',$CI->session->userdata('user_id'));
		if(!empty($userrow->time_zone))
		$timezone=$time_zone_array[$userrow->time_zone];
		else
		$timezone='Asia/Kolkata';
		
	}else if($logged_user_type==EMPLOYEE)
	{
		$userrow = get_table_info('users','user_id',$CI->session->userdata('user_id'));
		if(!empty($userrow->time_zone))
		$timezone=$time_zone_array[$userrow->time_zone];
		else
			$timezone='Asia/Kolkata';
	}
	else if($logged_user_type==DEPARTMENT)
	{
		$userrow = get_table_info('users','user_id',$CI->session->userdata('user_id'));
		if(!empty($userrow->time_zone))
		$timezone=$time_zone_array[$userrow->time_zone];
		else
			$timezone='Asia/Kolkata';
	}
	else if(($logged_user_type==USERS))
	{
		$userrow = get_table_info('users','user_id',$CI->session->userdata('user_id'));
		if(!empty($userrow->time_zone))
		$timezone=$time_zone_array[$userrow->time_zone];
		else
			$timezone='Asia/Kolkata';
	}else
	{
			$timezone='Asia/Kolkata';
	}
	
	return date_default_timezone_set($timezone);
}
	
	
	function createLogFile($operation,$id,$update_by_id,$table_name)	
	{
		$CI= & get_instance();
		$CI->load->database();
		if (!is_dir('assets/static/global/logs')) {
			mkdir('./assets/static/global/logs', 0777, TRUE);
	    }			
		$info = array();
		$info['update_by'] = $update_by_id;
		$info['id'] = $id;
		$info['table_name'] = $table_name;
		$info['operation'] = $operation;
		$json = json_encode($info);
		$my_file = "log_".date('Y-m').".txt"; 
		$file = "./assets/static/global/logs/".$my_file;
		//using the FILE_APPEND flag to append the content.
		file_put_contents ($file, $json.",", FILE_APPEND);	
		
	}
	function password_generate($chars) 
	{
	  $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
	  return substr(str_shuffle($data), 0, $chars);
	}
	
	function check_unique_edit_params($table,$fields,$prim_fields){
		 $set_values='';
	     if(is_array($fields)){
			$CI= & get_instance();
			$CI->load->database();
			$CI->db->select('*');
			foreach($fields as $keys => $values) {
				$CI->db->where($keys, $values);
			} 
			foreach($prim_fields as $pkeys => $pvalues) {
				$CI->db->where("$pkeys !=", $pvalues);
			} 
			$CI->db->from($table);	
			$query = $CI->db->get();
			return $query->num_rows();
		}
		return false;  
	}
	
	function get_role_array($type_id=NULL)
	{
		$CI= & get_instance();
		$CI->load->database();
		$CI->db->select('*');
		//$CI->db->where('is_active','1');
		$CI->db->from('roles');
		$CI->db->order_by('role_name','ASC');
		$result = $CI->db->get();
		$return = array();
		if ($result->num_rows() > 0) {
			$return[''] = 'Select ';
			foreach ($result->result_array() as $row) {
				$return[$row['roleid']] = $row['role_name'];
			}
		}
		return $return;
	}
	function fetch_categories(){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('category_id,category_name');
		$CI->db->where('language_id', $CI->session->userdata('lang_id'));
        $CI->db->from('categories');
        $query = $CI->db->get();
        return $result = $query->result();
	} //End of View function

	function fetch_category_types(){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('category_type_id,category_type');
        $CI->db->from('category_types');
        $CI->db->where('language_id', $CI->session->userdata('lang_id'));
        $query = $CI->db->get();
        return $result = $query->result();
	} //End of View function

	function fetch_projects(){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('project_id,project_name');
        $CI->db->from('projects');
        $query = $CI->db->get();
        return $result = $query->result();
	} //End of View function

	function fetch_states($country_id){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('state_name,state_id');
		
		//$CI->db->where('is_active','0');
		
		$CI->db->where('country_id',$country_id);
        $CI->db->from('state');
        //$CI->db->where('country_id','101');
        $query = $CI->db->get();
        return $result = $query->result();
	} //End of View function

	function fetch_cities($state_id){
			$CI = &get_instance();
			$CI->load->database();
			$CI->db->select('city_name,city_id');
			$CI->db->where('state_id',$state_id);
			$CI->db->from('city');
			$query = $CI->db->get();
			return $result = $query->result();
	} //End of View function

	function fetch_localities($city_id){
			$CI = &get_instance();
			$CI->load->database();
			$CI->db->select('locality_name,locality_id');
			$CI->db->where('city_id',$city_id);
			$CI->db->from('locality');
			$query = $CI->db->get();
			return $result = $query->result();
	} //End of View function
	
	function get_categories_list($parent_id,$is_active,$is_deleted, $count, $lastname='') {
		$CI = &get_instance();
		$CI->load->database();
		static $option_results;
		//$option_results[''] = '- None - ';
		$indent_flag='';
			// if there is no current navigation id set, start off at the top level (zero)
			if (!isset($parent_id)) {
				$parent_id=1;
			}
			// increment the counter by 1
			$count = $count+1;

			// query the database for the sub-options_categories of whatever the parent navigation is
		$CI->db->select('categories.*');
		$CI->db->from('categories');
		$CI->db->join('category_types', 'category_types.category_type_id = categories.category_type_id');
		//if($is_active!='all')
		//$this->db->where('categories.is_active', $is_active);
		//$this->db->where('categories.is_deleted', $is_deleted);
		$CI->db->where('categories.category_parent_id', $parent_id);
		$CI->db->order_by('categories.category_name','ASC');
		$result = $CI->db->get();

       $return = array();
       if ($result->num_rows() > 0) {

		foreach ($result->result_array() as $rowcat) {

			if ($parent_id!=0) {
				$indent_flag =  $lastname . '--';
					$indent_flag .=  '>';
			}
				$rowcat['category_name'] = $indent_flag.$rowcat['category_name'];
				$option_results[$rowcat['category_id']] = $rowcat['category_name'];
				// now call the function again, to recurse through the child Navigation
				get_categories_list($rowcat['category_id'],$is_active,$is_deleted, $count, $rowcat['category_name']);
		}
    }

    return $option_results;
	}
	
	function get_group_categories_list($parent_id,$is_active,$is_deleted, $count, $lastname='',$language_id) {
		$CI = &get_instance();
		$CI->load->database();
		static $option_results;
		//$option_results[''] = '- None - ';
		$indent_flag='';
			// if there is no current navigation id set, start off at the top level (zero)
			if (!isset($parent_id)) {
				$parent_id=1;
			}
			// increment the counter by 1
			$count = $count+1;

			// query the database for the sub-options_categories of whatever the parent navigation is
		$CI->db->select('categories.*');
		$CI->db->from('categories');
		$CI->db->join('category_types', 'category_types.category_type_id = categories.category_type_id');
		//if($is_active!='all')
		//$this->db->where('categories.is_active', $is_active);
		//$this->db->where('categories.is_deleted', $is_deleted);
		$CI->db->where('categories.category_parent_id', $parent_id);
		$CI->db->where('categories.language_id', $language_id);
		$CI->db->order_by('categories.category_name','ASC');
		$result = $CI->db->get();

       $return = array();
       if ($result->num_rows() > 0) {

		foreach ($result->result_array() as $rowcat) {

			if ($parent_id!=0) {
				$indent_flag =  $lastname . '--';
					$indent_flag .=  '>';
			}
				$rowcat['category_name'] = $indent_flag.$rowcat['category_name'];
				$option_results[$rowcat['category_id']] = $rowcat['category_name'];
				// now call the function again, to recurse through the child Navigation
				get_group_categories_list($rowcat['category_id'],$is_active,$is_deleted, $count, $rowcat['category_name'],$language_id);
		}
    }

    return json_encode($option_results);
}

function get_group_categories_list_module($parent_id,$is_active,$is_deleted, $count, $lastname='',$language_id) {
		$CI = &get_instance();
		$CI->load->database();
		static $option_results;
		//$option_results[''] = '- None - ';
		$indent_flag='';
			// if there is no current navigation id set, start off at the top level (zero)
			if (!isset($parent_id)) {
				$parent_id=1;
			}
			// increment the counter by 1
			$count = $count+1;

			// query the database for the sub-options_categories of whatever the parent navigation is
		$CI->db->select('categories.*,category_types.*');
		$CI->db->from('categories');
		$CI->db->join('category_types', 'category_types.category_type_id = categories.category_type_id');
		//if($is_active!='all')
		//$this->db->where('categories.is_active', $is_active);
		//$this->db->where('categories.is_deleted', $is_deleted);
		$CI->db->where('categories.category_parent_id', $parent_id);
		$CI->db->where('categories.language_id', $language_id);
		$CI->db->order_by('categories.category_name','ASC');
		$result = $CI->db->get();

       $return = array();
       if ($result->num_rows() > 0) {

		foreach ($result->result_array() as $rowcat) {

			if ($parent_id!=0) {
				$indent_flag =  $lastname . '--';
					$indent_flag .=  '>';
			}
			    $ctype=$rowcat['category_type']; 
				$rowcat['category_name'] = '('.$ctype.')'.$indent_flag.$rowcat['category_name'];
				$option_results[$rowcat['category_id']] = $rowcat['category_name'];
				// now call the function again, to recurse through the child Navigation
				get_group_categories_list($rowcat['category_id'],$is_active,$is_deleted, $count, $rowcat['category_name'],$language_id);
		}
    }

    return json_encode($option_results);
}


function get_category_types_interlinks_array($link_type=NULL,$language_id)
	{
		$CI= & get_instance();
		$CI->load->database();
		$CI->db->select('category_types.category_type_id,category_types.category_type');
		$CI->db->from('category_types');
		$CI->db->join('category_types_interlinks', 'category_types_interlinks.category_type_id = category_types.category_type_id');
		$CI->db->where('category_types.is_active','1');
		$CI->db->where('category_types.language_id', $language_id);
		$CI->db->where('category_types_interlinks.'.$link_type.'', '1');
		$CI->db->order_by('category_types.category_type','ASC');
		$result = $CI->db->get();
		//echo $CI->db->last_query(); 
		$return = array();
		if ($result->num_rows() > 0) {
			$return[''] = 'Select ';
			foreach ($result->result_array() as $row) {
				$return[$row['category_type_id']] = $row['category_type'];
			}
		}
		return $return;
	}

    function get_vendor_users_results($vendor_type_id=NULL)
	{
		$CI= & get_instance();
		$CI->load->database();
		$CI->db->select('users.user_id,users.first_name,users.last_name,vendor_details.shop_title');
		$CI->db->from('users');
		$CI->db->join('vendor_details', 'vendor_details.user_id = users.user_id');
		$CI->db->where('users.is_active','1');
		$CI->db->where('users.user_type','V');
		$CI->db->where_in('vendor_details.vendor_type_id',$vendor_type_id);
		$CI->db->order_by('vendor_details.shop_title','ASC');
		$query = $CI->db->get();
		//echo $CI->db->last_query(); 
		$result = $query->result();
		return $result;
	}
	
	function get_vendor_users($vendor_type_id=NULL)
	{
		$CI= & get_instance();
		$CI->load->database();
		$CI->db->select('users.user_id,users.first_name,users.last_name,vendor_details.shop_title');
		$CI->db->from('users');
		$CI->db->join('vendor_details', 'vendor_details.user_id = users.user_id');
		$CI->db->where('users.is_active','1');
		$CI->db->where('users.user_type','V');
		$CI->db->where_in('vendor_details.vendor_type_id',$vendor_type_id);
		$CI->db->order_by('vendor_details.shop_title','ASC');
		$result = $CI->db->get();
		//echo $CI->db->last_query(); 
		$return = array();
		if ($result->num_rows() > 0) {
			$return[''] = 'Select ';
			foreach ($result->result_array() as $row) {
				$return[$row['user_id']] = $row['shop_title']. " ".$row['first_name']. " ".$row['last_name'];
			}
		}
		return $return;
	}
	
	
		
function get_count_table($table,$fields=NULL)
{
$CI= & get_instance();
$CI->load->database();
$CI->db->select('*');
if(is_array($fields)){
 foreach($fields as $keys => $values) {
 $CI->db->where($keys, $values);
 }         
   }
   $CI->db->from($table);
   $query = $CI->db->get();
   //echo $CI->db->last_query(); 
   return $query -> num_rows();
} //End of Get Info Details function

	function get_left_menus($login_type,$access_url){
		//print_r($_SESSION);
		$CI= & get_instance();
		$CI->load->database();//echo "login_type".$login_type;
		if($login_type=='U'){
		$CI->db->select('*,b.role_rights as rights');
		$CI->db->where('a.user_id',$CI->session->userdata('user_id'));
		$CI->db->where('a.is_active','1');
		$CI->db->join('roles as b','a.role_id=b.role_id' );
		$CI->db->from('user_roles as a');
		$query = $CI->db->get();
		$result = $query->row();
		$user_rights = json_decode($result->role_rights);
		}
		else {
			
			$CI->db->select('*');
			$CI->db->from('user_roles');
			$CI->db->where('is_active','1');
			$CI->db->where('user_id',$CI->session->userdata('user_id'));
			$query = $CI->db->get();
			$result = $query->row();
			$user_rights = json_decode($result->role_rights);
			//$user_rights = $result->role_rights;
			 /* echo "<pre>";
			print_r($user_rights);
			die; */
			
		}
		
		/* print_r($user_rights );die; */
			
		$CI->db->select('*');
		$CI->db->from('navigation_menus');
		$CI->db->where('is_parent',0);
		//$CI->db->where('module_type',$login_type);
		$CI->db->where('is_active','1');
		$CI->db->where('display_leftmenu','1');
		$CI->db->where_in('menu_id',$user_rights);
		$CI->db->order_by('set_order', 'ASC');
		$query = $CI->db->get();
		//echo $CI->db->last_query();die;
		
		$result = $query->result();
		 /* echo "<pre>";
		print_r($result);
		die;  */ 
		foreach($result as $res){
			$menu_id=$res->menu_id;
			$menu_name=$res->menu_name;
			if($res->menu_link=='#')
			$menu_link=$res->menu_link;
			else
			$menu_link=base_url().$res->menu_link;
			$menu_class=$res->menu_class; 
						
			echo "<li aria-haspopup='true' class='menu-dropdown classic-menu-dropdown active'>
					<a href='$menu_link'>  $res->menu_name
						<span class='arrow'></span>
					</a>";
			$getchilds=getchild($menu_id,"",$user_rights);
		}//echo $CI->db->last_query(); die;
	}
	
	
	function get_user_left_menus($login_type,$access_url){
		//print_r($_SESSION);
		$CI= & get_instance();
		$CI->load->database();//echo "login_type".$login_type;
		if($login_type=='E'){
		$CI->db->select('*,b.role_permission');
		$CI->db->where('a.user_id',$CI->session->userdata('user_id'));
		$CI->db->where('a.is_active','1');
		$CI->db->join('roles as b','a.role_id=b.role_id' );
		$CI->db->from('user_roles as a');
		$query = $CI->db->get();
		$result = $query->row();
		$user_rights = json_decode($result->role_permission);
	/* 	echo "<pre>";
		print_r($user_rights);
		die; */
	/* 	$ip=$_SERVER['REMOTE_ADDR'];
		if($ip=='103.17.97.181'){
		  	echo "<pre>";
		print_r($user_rights);
		die;   
		} */
		}
		/* else {
			
			$CI->db->select('*');
			$CI->db->from('user_roles');
			$CI->db->where('is_active','1');
			$CI->db->where('user_id',$CI->session->userdata('user_id'));
			$query = $CI->db->get();
			$result = $query->row();
			$user_rights = json_decode($result->role_rights);
			//$user_rights = $result->role_rights;
			 /* echo "<pre>";
			print_r($user_rights);
			die; 
			
		} */
		
		/* print_r($user_rights );die; */
			
		$CI->db->select('*');
		$CI->db->from('navigation_menus');
		$CI->db->where('is_parent',0);
		//$CI->db->where('module_type',$login_type);
		$CI->db->where('is_active','1');
		$CI->db->where('display_leftmenu','1');
		$CI->db->where_in('menu_id',$user_rights);
		$CI->db->order_by('set_order', 'ASC');
		$query = $CI->db->get();
		//echo $CI->db->last_query();die;
		
		$result = $query->result();
		$ip=$_SERVER['REMOTE_ADDR'];
		/* if($ip=='103.17.97.181'){
		  echo "<pre>";
		print_r($result);
		die;   
		} */
		foreach($result as $res){
			$menu_id=$res->menu_id;
			$menu_name=$res->menu_name;
			if($res->menu_link=='#')
			$menu_link=$res->menu_link;
			else
			$menu_link=base_url().$res->menu_link;
			$menu_class=$res->menu_class; 
						
			echo "<li aria-haspopup='true' class='menu-dropdown classic-menu-dropdown active'>
					<a href='$menu_link'>  $res->menu_name
						<span class='arrow'></span>
					</a>";
			$getchilds=getchild($menu_id,"",$user_rights);
		}//echo $CI->db->last_query(); die;
	}
	
	
	function getchild($menu_id ,$access_url,$user_rights){
		$CI= & get_instance();
		$CI->load->database();
		$CI->db->select('*');
		$CI->db->from('navigation_menus');
		$CI->db->where('display_leftmenu','1');
		$CI->db->where('is_parent',$menu_id);
		$CI->db->where_in('menu_id',$user_rights);
		$CI->db->order_by('set_order', 'ASC');
		$query = $CI->db->get();
		$countrows=$query->num_rows();
		if($countrows>0){
			$result_child = $query->result();
			print " <ul class='dropdown-menu pull-left'>";
			foreach($result_child as $res){
			$count_result = 0;
			$count_result = get_count_table('navigation_menus',array('is_parent'=> $res->menu_id,'display_leftmenu'=>'1'));
			$menu_name=$res->menu_name;
			$menu_id=$res->menu_id;
			$menu_link=base_url().$res->menu_link;
			$menu_class=$res->menu_class;
			
			
			/****check for arrow************/
			if($count_result >0)
				$class_drop_menu = "dropdown-submenu";
			else
				$class_drop_menu = "";
			print "  <li>
					 <a href='$menu_link'> $menu_name </a></li>
					";
					//echo "<br>==========".$menu_name;
			getchild($menu_id,"",$user_rights);
			
			}
			print "</ul>";
		}else{
			print "</li>";
		}
	}
	function fetch_particular_categories($location_id){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('categories.category_name');
        $CI->db->from('location_categories');
        $CI->db->join('categories','location_categories.category_id=categories.category_id');
		$CI->db->where('location_categories.location_id',$location_id);
		$CI->db->where('location_categories.is_active','1');
        $query = $CI->db->get();
        return $result = $query->result();

	} //End of View function
	
	function send_sms($errNo,$numbers,$message)
	{
	// Authorisation details.
	$username = sms_username;
	$hash = sms_pass;
	$sms_response = sms_response;

	// Config variables. Consult http://api.textlocal.in/docs for more info.
	//$test = sms_config_var;

	// Data for text message. This is the text message data.
	$sender = sms_senderid; // This is who the message appears to be from.
	//$numbers = "910000000000"; // A single number or a comma-seperated list of numbers
	//$message = "This is a test message from the PHP API script.";
	// 612 chars or less
	// A single number or a comma-seperated list of numbers
	$numbers = '91'.substr($numbers,-10);
	$message = urlencode($message);
	$data = "username=".$username."&pass=".$hash."&message=".$message."&senderid=".$sender."&dest_mobileno=".$numbers."&response=".$sms_response;
	$ch = curl_init(sms_url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	$result = curl_exec($ch); // This is the result from the API
	curl_close($ch);
	return $result;
}

function send_email($to,$body,$subject){
	$message = $body;
	
	$header = "From:dreamweaversgroup1@gmail.com \r\n";
	$header .= "MIME-Version: 1.0\r\n";
	$header .= "Content-type: text/html\r\n";

	$retval = mail ($to,$subject,$message,$header);
	//print 'ffff';
	if( $retval == true ) {
		return True;
	}else {
	    //print 'ggggg';
		return False;
	}
}

function questions_display_time() {

	 $questions_display_time=array();
	 $questions_display_time[''] = 'Select';
	 for($i=30; $i<=180; $i+=10){
		 $questions_display_time[$i]=$i .' Seconds';
	 }
     $questions_display_time =  $questions_display_time;
	
	 return $questions_display_time;

}

function quiz_theme()
{    $quiz_theme = array();
	 $quiz_theme[''] = "Select Option";
	 $quiz_theme['1'] = "Theme 1";
	 $quiz_theme['2'] = "Theme 2";
	 $quiz_theme['3'] = "Theme 3";
	return $quiz_theme;
}

function quiz_sorting()
{    $quiz_sorting = array();
	 $quiz_sorting[''] = "Select Option";
	 $quiz_sorting['random'] = "Random";
	 $quiz_sorting['sequence'] = "Sequence";
	 return $quiz_sorting;
}

function quiz_status()
{    $quiz_status = array();
	 $quiz_status[''] = "Select";
	 $quiz_status['1'] = "Activate";
	 $quiz_status['0'] = "Deactivate";
	 return $quiz_status;
}
function statuses()
{    $statuses = array();
	 $statuses[''] = "Select";
	 $statuses['1'] = "Yes";
	 $statuses['0'] = "No";
	 return $statuses;
}
function getlocation()
    {
		$CI= & get_instance();
	    $CI->load->database();
        $CI->db->select('location_name,location_id');
        $CI->db->where('is_active','1');
        $CI->db->from('locations');
        $query = $CI->db->get();
		$return[''] = 'Select';
		foreach ($query->result_array() as $row) {
			$return[$row['location_id']] = $row['location_name'];
		}
		return $return;

} //End of Get Info Details function

 function location_names($tour_id){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('locations.location_name');
		$CI->db->join('locations','locations.location_id=tour_trail_locations.location_id');
		$CI->db->where('tour_trail_locations.tour_trail_id',$tour_id);
		$CI->db->order_by('tour_trail_locations.weight','asc');
		$query=$CI->db->get('tour_trail_locations');
   		$result = $query->result_array();	
		$locs='';
		foreach($result as $val){
			//echo $val['location_name'];die;
			$locs .=$val['location_name']."<br/>";
		}
		
		
		return $locs; 
 }
 
 function tour_trail_name($tour_trail_id){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('tour_trail_name');
		$CI->db->where('tour_trail_id',$tour_trail_id);
		$query=$CI->db->get('tour_trails');
   		return $query->row_array();	
 }
 
 function get_categories_name($location_id){
		$CI = &get_instance();
		$CI->load->database();
		$CI->db->select('categories.category_name,categories.category_id,');
		$CI->db->join('categories','location_categories.category_id=categories.category_id');
		$CI->db->where('location_categories.location_id',$location_id);
		$CI->db->where('location_categories.is_active','1');
		$query=$CI->db->get('location_categories');
   		$result = $query->result_array();	
		$cats='';
		foreach($result as $val){
			$cat_names .=$val['category_name']."<br/>";
			$cat_ids .=$val['category_id'].",";
		}
		$cat_ids =trim($cat_ids,","); 
		return $cat_names."||".$cat_ids; 
 }
 
 
   function special_char_remove($string){
		if($string==''){
			return '';
		}
		return trim(preg_replace("/[^(x20-x7F)]*/","",$string));
		 $output = iconv("UTF-8", "ASCII//TRANSLIT//IGNORE", $string);
		
	     $output =  preg_replace("/^'|[^A-Za-z0-9\s-\s.]|'$/", '', $output); // lets remove utf-8 special characters except blank spaces
		return trim($string);
		
	}
	
 function get_youtube_video_id($link){
	
	 $video_id = explode("?v=", $link); // For videos like http://www.youtube.com/watch?v=...
	 if (empty($video_id[1]))
		$video_id = explode("/v/", $link); // For videos like http://www.youtube.com/watch/v/..

	 $video_id = explode("&", $video_id[1]); // Deleting any other params
	 return $video_id = $video_id[0];
 }
 function get_user_role($user_id){
	 $CI = &get_instance();
	 
	 $CI->load->database();
	 $CI->db->select('role_id');
	 $CI->db->from('user_roles');
	 $CI->db->where('is_active','1');
	 $CI->db->where('user_id',$user_id);
	 $query = $CI->db->get();
	 return $result = $query->row();
 }
 function get_user_name($user_id){
	 $CI = &get_instance();
	 $CI->load->database();
	 $CI->db->select("CONCAT(first_name, ' ', last_name) AS name");
	 $CI->db->from('users');
	 $CI->db->where('user_id',$user_id);
	 $query = $CI->db->get();
	 //echo "<pre>";print_r($CI->db->last_query());die;
	 return $result = $query->row();
 }
 function count_diff($old, $new){
		$from_start = strspn($old ^ $new, "\0");        
		$from_end = strspn(strrev($old) ^ strrev($new), "\0");

		$old_end = strlen($old) - $from_end;
		$new_end = strlen($new) - $from_end;

		$start = substr($new, 0, $from_start);
		$end = substr($new, $new_end);
		$new_diff = substr($new, $from_start, $new_end - $from_start);  

		if($new_diff!=''){
			return $new_diff;
		} else {
			return 0;
		}
	}
  function get_decorated_diff($old, $new){
		$from_start = strspn($old ^ $new, "\0");        
		$from_end = strspn(strrev($old) ^ strrev($new), "\0");

		$old_end = strlen($old) - $from_end;
		$new_end = strlen($new) - $from_end;

		$start = substr($new, 0, $from_start);
		$end = substr($new, $new_end);
		$new_diff = substr($new, $from_start, $new_end - $from_start);  
		//$old_diff = substr($old, $from_start, $old_end - $from_start);

		//$new = "$start<ins style='background-color:#ccffcc'>$new</ins>$end";
		//$new = "$start<ins style='background-color:#ffcccc'>$new_diff</ins>$end";
		//$old = "$start<del style='background-color:#ffcccc'>$old_diff</del>$end";
		//$old = "$start<del style='background-color:#ffcccc'>$old_diff</del>$end";
		//return array("old"=>$old, "new"=>$new);
		//return $new;
		
		
		if($new_diff!=''){
			return "<ins style='background-color:#ffcccc'>".ucfirst($new)."</ins>";
		} else {
			return ucfirst($new);
		}
		//return $new;
	}

	function complaint_type()
	{    $complaint_type = array();
		 $complaint_type[''] = "Select";
		 $complaint_type['1'] = "Complaint";
		 $complaint_type['2'] = "Feedback";
		 return $complaint_type;
	}
     function get_user_details($user_id){
    	 $CI = &get_instance();
    	 $CI->load->database();
    	 $CI->db->select("user_photo,CONCAT(first_name, ' ', last_name) AS name");
    	 $CI->db->from('users');
    	 $CI->db->where('user_id',$user_id);
    	 $query = $CI->db->get();
    	 return $result = $query->row();
     }
	function get_designation(){
		 $CI = &get_instance();
		 $CI->load->database();
		 $CI->db->select("designation_id");
		 $CI->db->from('users');
		 $CI->db->where('user_id',$CI->session->userdata('user_id'));
		 $query = $CI->db->get();
		 return $query->row();
	}
		function get_language($lang_id){
		 $CI = &get_instance();
		 $CI->load->database();
		 $CI->db->select("*");
		 $CI->db->from('languages');
		 $CI->db->where('language_id',$lang_id);
		 $query = $CI->db->get();
		 return $query->row();
	}
	
	function showhidebuttons($location_id)
 	{ 
		 $CI = &get_instance();
		 $CI->load->database();
					$CI->db->select('slocation_audits.status');
					$CI->db->from('slocation_audits');
					$CI->db->join('slocation_audit_orders','slocation_audits.order_id=slocation_audit_orders.order_id');
					$CI->db->where('slocation_audits.location_id',$location_id);
					$CI->db->where('slocation_audit_orders.designation_id',$CI->session->userdata('designation_id'));
					$que = $CI->db->get();
				
					$status_id=$que->row()->status;
					if($status_id!=''){
						return $status_id;
					} else {
						return NULL;
					}
				
			
			
	}
	
	/*function get_translatecontent($lang_id,$content_id,$entity){
        $CI = &get_instance();
        $CI->load->database();
        if($lang_id==1){
            $field='target_id';
        }else{
            $field='entity_id';
        }
        $CI->db->select('*');
        $CI->db->from('language_entity');
        //$CI->db->join('slocation_audit_orders','slocation_audits.order_id=slocation_audit_orders.order_id');
        //$CI->db->where('slocation_audits.location_id',$location_id);
        $CI->db->where('entity_type',$entity);
        $CI->db->where('language_id',$lang_id);
        $CI->db->where($field,$content_id);
        $que = $CI->db->get();
        //print $CI->db->last_query();die;
        $row=$que->row();
        return $row;
	}*/
		function get_translatecontent($lang_id,$content_id,$tablename,$wherefield){
        $CI = &get_instance();
        $CI->load->database();
        $CI->db->select('*');
        $CI->db->from($tablename);
        //$CI->db->join('slocation_audit_orders','slocation_audits.order_id=slocation_audit_orders.order_id');
        //$CI->db->where('slocation_audits.location_id',$location_id);
        //$CI->db->where('entity_type',$entity);
        $CI->db->where('language_id',$lang_id);
        $CI->db->where($wherefield,$content_id);
        $que = $CI->db->get();
        //print $CI->db->last_query();die;
        $row=$que->row();
        return $row;
	}
	
function get_categories_list_rec($parent_id, $count, $lastname='') {
    static $option_results;
	$indent_flag='';
    // if there is no current navigation id set, start off at the top level (zero)
    if (!isset($parent_id)) {
        $parent_id=1;
    }
    // increment the counter by 1
    $count = $count+1;

    // query the database for the sub-navigation_menus of whatever the parent navigation is
	$CI= & get_instance();
	$CI->load->database();
	$CI->db->select('*');
	$CI->db->from('categories');
    $CI->db->where('language_id', 1);
    $CI->db->where('category_parent_id', $parent_id);
	$CI->db->where('is_active', '1');
	//$CI->db->order_by('set_order','ASC');
	  $result = $CI->db->get();
       $return = array();
       if ($result->num_rows() > 0) {
		$option_results[''] = '- None - ';
		foreach ($result->result_array() as $rowmenu) {
	
        if ($parent_id!=0) {
            $indent_flag =  $lastname . '--';
                $indent_flag .=  '>';
        }
        unset($loc_array);
        $loc_array=total_locations($rowmenu['category_id']);
        //print '<pre>';print_r($loc_array);
        if(count($loc_array)>0){
            $implode=implode("<br>",$loc_array);
        }else{
            $implode='-';
        }
            
            $rowmenu['category_name'] = $indent_flag.$rowmenu['category_name'];
            $option_results[$rowmenu['category_id']] = $rowmenu['category_name'].'<br>('.$implode.')';
            $implode='';
            // now call the function again, to recurse through the child Navigation
            get_categories_list_rec($rowmenu['category_id'], $count, $rowmenu['category_name']);
        }
    }
	
    return $option_results;
}

function total_locations($cat_id){
    $CI= & get_instance();
	$CI->load->database();
	$CI->db->select('*');
	$CI->db->from('location_categories');
    //$CI->db->where('language_id', 1);
    $CI->db->where('category_id', $cat_id);
	$CI->db->where('is_active', '1');
	$result = $CI->db->get();
	$loc_array=array();
	if ($result->num_rows() > 0) {
	    foreach ($result->result_array() as $rowmenu) {
	        $location_id=$rowmenu['location_id'];
	        $locarray=array('location_id'=>$location_id,'is_active'=>'1');
	        $locrow = gettableinfo('locations',$locarray);
	        if($locrow!='0')
	        $loc_array[$location_id]=$locrow->location_name.'('.$locrow->location_id.')';
	    }
	   
	}
	 return $loc_array;
}

function get_weather_report(){

$apiKey = "0aa504de2f612e050299352d220b8acd";
$cityId = "1278710";
$city = "Amritsar";
$googleApiUrl = "https://api.openweathermap.org/data/2.5/weather?q=" . $city. "&lang=en&units=metric&APPID=" . $apiKey;

$ch = curl_init();

curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_URL, $googleApiUrl);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_VERBOSE, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);

curl_close($ch);
$data = json_decode($response);
return $data;
}	

function calculate_distance($lat1, $lon1, $lat2, $lon2, $unit) {
  if (($lat1 == $lat2) && ($lon1 == $lon2)) {
    return 0;
  }
  else {
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);

    if ($unit == "K") {
      return ($miles * 1.609344);
    } else if ($unit == "N") {
      return ($miles * 0.8684);
    } else {
      return $miles;
    }
  }
}

function page_sidebar(){
	return '<div class="col-md-5 pr-0 login-img-main">
                  <img src="'.base_url().'assets/frontend/images/login-bg.jpg" alt="" class="img-fluid">
                  <div class="login-logo">
                     <a class="navbar-brand logo" href="'.base_url().'">
							<img src="'.base_url().'assets/frontend/images/logo.png" alt="Amritsar Guide" title="Amritsar Guide" class="img-fluid">
					</a>
                  </div>
               </div>';
	
}

function google_translate_text($source_language,$target_language,$text_to_translate){
    if($source_language!='' &&  $target_language!='' && $text_to_translate!=''){
        $apiKey=google_translate_api;
        $url = 'https://www.googleapis.com/language/translate/v2?key='.$apiKey.'&q='.rawurlencode($text_to_translate).'&source='.$source_language.'&target='.$target_language;
        $handle = curl_init($url);
        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($handle, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($handle);
    	$response_message=array();
        $responseDecoded = json_decode($response, true);
    	$string=$text;
    	if(isset($responseDecoded['data'])){
    		if(isset($responseDecoded['data']['translations'])){
    			if(isset($responseDecoded['data']['translations'][0])){
    				if(isset($responseDecoded['data']['translations'][0]['translatedText'])){
    					$string=$responseDecoded['data']['translations'][0]['translatedText'];
    					$response_message=array('status'=>true,'translatedText'=>$string);
    				}else{
    					$string=$text;
    					$response_message=array('status'=>false,'translatedText'=>$string);
    				}					
    			}else{
    				$string=$text;
    				$response_message=array('status'=>false,'translatedText'=>$string);
    			}
    		}else{
    			$string=$text;
    			$response_message=array('status'=>false,'translatedText'=>$string);
    		}
    	}else{
    		$string=$text;
    		$response_message=array('status'=>false,'translatedText'=>$string);
    	}
    }else{
        $string='';
        $response_message=array('status'=>false,'translatedText'=>$string);
    }
    return json_encode($response_message);
}

?>