<?php   
  /**
   * @package Contact :  CodeIgniter Multi Language Loader
   *
   * @author TechArise Team
   *
   * @email  info@techarise.com
   *   
   * Description of Multi Language Loader Hook
   */

  class MultiLanguageLoader
  {
      function initialize() {
          $ci =& get_instance();
          // load language helper
          $ci->load->helper('language');
          $siteLang = $ci->session->userdata('site_lang');
		  
		 $user_type = $ci->session->userdata('user_type');
		  if ($user_type=='E') {
			if ($siteLang) {
				  // define all language files
				  $ci->lang->load('common/login',$siteLang);
				  $ci->lang->load('employees/header',$siteLang);
				  $ci->lang->load('employees/message',$siteLang);
				  $ci->lang->load('employees/dashboard',$siteLang);
				  $ci->lang->load('employees/locations',$siteLang);
				  $ci->lang->load('employees/survey',$siteLang);
				  $ci->lang->load('employees/footer',$siteLang);
			  } else {
				  // default language files
				  $ci->lang->load('common/login','english');
				  $ci->lang->load('employees/header','english');
				  $ci->lang->load('employees/message','english');
				  $ci->lang->load('employees/dashboard','english');
				  $ci->lang->load('employees/locations','english');
				  $ci->lang->load('employees/survey',$siteLang);
				  $ci->lang->load('employees/footer','english');
			  }
		    
		  }  else if ($user_type=='A' ||  $user_type=='D') {
			if ($siteLang) {
			
				  // define all language files
				  $ci->lang->load('backoffice/common',$siteLang);
				  $ci->lang->load('common/login',$siteLang);
				  $ci->lang->load('backoffice/header',$siteLang);
				  $ci->lang->load('backoffice/content',$siteLang);
				  $ci->lang->load('backoffice/message',$siteLang);
				  $ci->lang->load('backoffice/dashboard',$siteLang);
				  $ci->lang->load('backoffice/masters',$siteLang);
				  $ci->lang->load('backoffice/users',$siteLang);
				  $ci->lang->load('backoffice/areas',$siteLang);
				  $ci->lang->load('backoffice/sound',$siteLang);
				  $ci->lang->load('backoffice/categorytypes',$siteLang);
				  $ci->lang->load('backoffice/categories',$siteLang);
				  $ci->lang->load('backoffice/filters',$siteLang);
				  $ci->lang->load('backoffice/beacons',$siteLang);
				  $ci->lang->load('backoffice/kiosks',$siteLang);
				  $ci->lang->load('backoffice/groups',$siteLang);
				  $ci->lang->load('employees/locations',$siteLang);
				  $ci->lang->load('backoffice/locations_quiz',$siteLang);
				  $ci->lang->load('backoffice/footer',$siteLang);
			  } else {
				  // default language files
				   $ci->lang->load('backoffice/common','english');
				  
				  $ci->lang->load('common/login','english');
				  $ci->lang->load('backoffice/header','english');
				  $ci->lang->load('backoffice/content','english');
				  $ci->lang->load('backoffice/message','english');
				  $ci->lang->load('backoffice/dashboard','english');
				  $ci->lang->load('backoffice/masters','english');
				  $ci->lang->load('backoffice/users','english');
				  $ci->lang->load('backoffice/areas','english');
				  $ci->lang->load('backoffice/sound','english');
				  $ci->lang->load('backoffice/categorytypes','english');
				  $ci->lang->load('backoffice/categories','english');
				  $ci->lang->load('backoffice/footer','english');
			  }
		    
		  }
		  else{
          if ($siteLang) {
              // difine all language files
			  $ci->lang->load('common/login',$siteLang);
              $ci->lang->load('users/header',$siteLang);
              $ci->lang->load('users/content',$siteLang);
              $ci->lang->load('users/footer',$siteLang);
          } else {
              // default language files
			  $ci->lang->load('common/login','english');
              $ci->lang->load('users/header','english');
              $ci->lang->load('users/content','english');
              $ci->lang->load('users/footer','english');
          }
		  
		  }
      }
  }
  ?>